﻿
/*---------------------------------------------------------------------
* 			Copyright (C) 2017 TECHSCAN 版权所有。
*           www.techscan.cn
*┌────────────────────────────────────────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．　│
*│　版权所有：上海太迅自动识别技术有限公司 　 　　　　　　　　　　　　│
*└────────────────────────────────────────────────────────────────────┘
*
* 文件名：   proc_ts_ReferVouch_SalesOut_Get.SQL
* 功能：     存储过程
* 描述：     ST库存[销售出库单]-获取上游可参照单据信息(采用临时表#，临时表表名是固定的)
* 作者：     马永龙
* 创建时间： 2017-12-12 15:12:31
* 文件版本： V1.0.8

===============================版本履历===============================
* Ver 		变更日期 				负责人 	变更内容
* V1.0.0	2017-12-12 15:12:31		Myl		Create
* V1.0.1	2018-01-11				Myl		所有查询到的表头表体字段以小写字母展现
* V1.0.2	2018-01-30				Myl		添加已扫描数量和已扫描件数字段iScanedQuantity和iScanedNum
* V1.0.3	2018-03-12				Myl		添加本次剩余应发数量(inquantity)和件数(innum)
* V1.0.4	2018-05-15				Myl		修改所有参照单据中的日期格式为'yyyy-MM-dd'格式（CONVERT(varchar(100), ddate, 23)）
* V1.0.5	2018-05-31				Myl		参照发货单表体上添加存货供需政策字段cSRPolicy
* V1.0.6	2018-06-06				Myl		参照发货单表体上添加一些前台对应的字段处理
* V1.0.7	2018-07-13				Myl		表体添加统一bodyautoid字段（表体唯一ID的副本字段，前台用）
* V1.0.8	2018-07-18				Myl		表体bodyautoid字段修改为对应发货退货单子表id（idlsid），以前对应的是autoid，这个不对
* V1.0.9	2018-12-21				Leo		增加表头属性，是否货位仓，和仓库编码
======================================================================
//--------------------------------------------------------------------*/
--proc_ts_ReferVouch_SalesOut_Get '0',DEFAULT,'cDLCode:0000000001@@ShowClosed:1@@cSOCODE:0000000001@@cSTCODE:01'
--proc_ts_ReferVouch_SalesOut_Get '0',DEFAULT,'ShowClosed:1@@cSTCODE:01@@bRed:0'
--proc_ts_ReferVouch_SalesOut_Get '0',DETAIL,'ShowClosed:1@@cSTCODE:01@@bRed:0'
--proc_ts_ReferVouch_SalesOut_Get '0',DEFAULT,'Dlids:1000000002,1000000003'

--proc_ts_ReferVouch_SalesOut_Get '0', 'DETAIL', '' 

create PROC proc_ts_ReferVouch_SalesOut_Get
    (
      @OperType CHAR(1) = N'0' ,
      --获取类型（'LIST'获取上游参照单据列表;'DETAIL'获取上游参照单据详情（包含表头表体））
      --默认获取上游参照单据列表
      @GetType VARCHAR(10) = N'LIST' ,
      --传入的参数列表字符串
      --默认传空值
      @ParamsList NVARCHAR(2000) = N''
    )
AS
    BEGIN

		--是否参照销售退货单（发货单红字）/bRed参数
        DECLARE @bRed VARCHAR(1);
        SET @bRed = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                           N'bRed', DEFAULT,
                                                           DEFAULT);
        IF ( @bRed = N'' )
            BEGIN
                SET @bRed = N'0';
            END;


	  -- 单据条码
	    DECLARE @CSYSBARCODE NVARCHAR(1000);

            SET @CSYSBARCODE = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'csysbarcode', DEFAULT, DEFAULT);
		--产品-存货编码
        DECLARE @ProInvCode NVARCHAR(60);
        SET @ProInvCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ProInvCode',
                                                              DEFAULT, DEFAULT);
        --产品-存货代码
        --DECLARE @ProInvAddCode NVARCHAR(255);
        --SET @ProInvAddCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
        --                                                      N'ProInvAddCode',
        --                                                      DEFAULT, DEFAULT);
        --产品-存货名称
        DECLARE @ProInvName NVARCHAR(255);
        SET @ProInvName = '%'
            + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                     N'ProInvName', DEFAULT,
                                                     DEFAULT) + '%';
        --产品-存货规格
        --DECLARE @ProInvStd NVARCHAR(255);
        --SET @ProInvStd = '%'
        --    + dbo.func_ts_GetParamValueBySplitString(@ParamsList, N'ProInvStd',
        --                                             DEFAULT, DEFAULT) + '%';
                    
        --执行完未关闭是否显示(1:显示/0:不显示;默认不显示)
        DECLARE @ShowClosed CHAR(1);
        SET @ShowClosed = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ShowClosed',
                                                              DEFAULT, DEFAULT);
        IF ( @ShowClosed = N'' )
            BEGIN
                SET @ShowClosed = N'0';
            END;

        --产品仓库编码
        DECLARE @cWhCode NVARCHAR(20);
        BEGIN
            SET @cWhCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cWhCode',
                                                              DEFAULT, DEFAULT);
            IF ( @cWhCode <> N'' )
                BEGIN
                     
                    IF EXISTS ( SELECT  0
                                WHERE   NOT OBJECT_ID('tempdb..#STPDATempWhs') IS NULL )
                        DROP TABLE #STPDATempWhs;
                    
                    CREATE   TABLE #STPDATempWhs ( cWhCode NVARCHAR(10) );
                    INSERT  INTO #STPDATempWhs
                            EXEC proc_ts_SplitParamString @cWhCode;
                END;
        END;

        DECLARE @ParmList NVARCHAR(MAX);SET @ParmList= N'';
        DECLARE @SqlCommand NVARCHAR(MAX);SET @SqlCommand = N'';

		      DECLARE @SqlBODYCommand NVARCHAR(MAX);
      DECLARE @SqlHEADCommand NVARCHAR(MAX);

      SET @SqlBODYCommand = N'';
      SET @SqlHEADCommand = N'';

        IF ( @OperType = N'0' )
        --ST销售出库-参照销售发货单
        --(参照退货单生成销售退货单时，使用参数'bRed'传递
        --[bRed=0表示普通的参照发货单生成销售出库单/bRed=1表示参照退货单（发货单红字）生成销售退货单]。参照发货单和发货单（红字）的区别是添加查询条件：'AND (dbo.DispatchList.bReturnFlag=1)'
            BEGIN
            
            --定义查询参数
            
				--销售发货单号
                --DECLARE @cDLCode NVARCHAR(30);
                --SET @cDLCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                --                                              N'cDLCode',
                --                                              DEFAULT, DEFAULT);

				  DECLARE @cDLCode NVARCHAR(MAX);
                SET @cDLCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cDLCode',
                                                              DEFAULT, DEFAULT);
IF(@cDLCode <> N'')
            BEGIN                             
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempDLCodes') IS NULL )
                    DROP TABLE #STPDATempDLCodes;
                    
                CREATE   TABLE #STPDATempDLCodes ( DLCode NVARCHAR(30) );
                INSERT  INTO #STPDATempDLCodes
                        EXEC proc_ts_SplitParamString @cDLCode;
            END;



				--发货单单据起始日期
                DECLARE @dDateFrom NVARCHAR(20);
                SET @dDateFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dDateFrom',
                                                              DEFAULT, DEFAULT);
                --发货单单据起始日期
                DECLARE @dDateTo NVARCHAR(20);
                SET @dDateTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dDateTo',
                                                              DEFAULT, DEFAULT);
                IF ( @dDateTo = N'' )
                    BEGIN
                        SET @dDateTo = @dDateFrom;
                    END;
                 
				--业务类型（"普通销售"/"分期收款"/"委托代销"）
                DECLARE @cBusType NVARCHAR(10);
                SET @cBusType = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cBusType',
                                                              DEFAULT, DEFAULT);
				--客户编码
                DECLARE @cCusCode NVARCHAR(20);
                SET @cCusCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cCusCode',
                                                              DEFAULT, DEFAULT);
				--客户名称
                DECLARE @cCusName NVARCHAR(120);
                SET @cCusName = '%'
                    + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                             N'cCusName',
                                                             DEFAULT, DEFAULT)
                    + '%';
 
				--部门编码
                DECLARE @cDeptCode NVARCHAR(12);
                SET @cDeptCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cDeptCode',
                                                              DEFAULT, DEFAULT);
				--部门名称
				--DECLARE @cDeptName NVARCHAR(255);
				--SET @cDeptName = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
    --                                                          N'cDeptName',
    --                                                          DEFAULT, DEFAULT);
               	--业务员编码
                DECLARE @cPersonCode NVARCHAR(20);
                SET @cPersonCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cPersonCode',
                                                              DEFAULT, DEFAULT);
				--业务员名称
				--DECLARE @cPersonName NVARCHAR(40);
				--SET @cPersonName = dbo.func_ts_GetParamValueBySplitString(@ParamsList,N'cPersonName',DEFAULT, DEFAULT);
 
				--制单人
                DECLARE @cMaker NVARCHAR(30);
                SET @cMaker = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cMaker',
                                                              DEFAULT, DEFAULT);
				--单据类型('05':发货单)
                --DECLARE @cVouchType NVARCHAR(5);
                --SET @cVouchType = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                --                                              N'cVouchType',
                --                                              DEFAULT, DEFAULT);
                --IF @cVouchType=N''
                --BEGIN
                --SET @cVouchType=N'05'
                --END



				--销售订单号
                DECLARE @cSoCode NVARCHAR(30);
                SET @cSoCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cSoCode',
                                                              DEFAULT, DEFAULT);
                --销售类型编码
                DECLARE @cSTCode NVARCHAR(5);
                SET @cSTCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cSTCode',
                                                              DEFAULT, DEFAULT);

                DECLARE @Dlids NVARCHAR(1000);--发货退货单主表标识列表（用','隔开）
                
                BEGIN
                
                    SET @Dlids = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'Dlids',
                                                              DEFAULT, DEFAULT);
                    IF ( @Dlids <> N'' )
                        BEGIN                             
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDATempDLIDs') IS NULL )
                                DROP TABLE #STPDATempDLIDs;
                    
                            CREATE   TABLE #STPDATempDLIDs ( DLID INT );
                            INSERT  INTO #STPDATempDLIDs
                                    EXEC proc_ts_SplitParamString @Dlids;
                        END;
                                                              
                END;

                SET NOCOUNT ON;
                --START
                  
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#UFIDA_MYL_PDA_0_dispatchautoid') IS NULL )
                    DROP TABLE #UFIDA_MYL_PDA_0_dispatchautoid;
                  
                SELECT  CONVERT(INT, 0) AS groupautoid ,
                        CONVERT(INT, 0) AS iDLsID ,
                        cParentCode ,
                        cChildCode
                INTO    #UFIDA_MYL_PDA_0_dispatchautoid
                FROM    dbo.DispatchLists
                WHERE   1 = 0; 
                CREATE  CLUSTERED  INDEX [ix_UFIDA_MYL_PC_0_dispatch_idlsid] ON  #UFIDA_MYL_PDA_0_dispatchautoid  (iDLsID);
                --IF EXISTS ( SELECT  name
                --            FROM    tempdb..sysobjects
                --            WHERE   id = OBJECT_ID(N'tempdb..#UFIDA_MYL_PDA_0_dispatchautoid')
                --                    AND xtype = 'U' )
                --    DROP TABLE tempdb..#UFIDA_MYL_PDA_0_dispatchautoid;

                SET @SqlCommand = N'SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                INSERT INTO #UFIDA_MYL_PDA_0_dispatchautoid (groupautoid ,iDLsID ,cparentcode ,cchildcode)
SELECT DD.iDLsID as groupautoid,DD.iDLsID ,ISNULL(DD.cParentCode, '''') AS cparentcode ,ISNULL(DD.cChildCode, '''') AS cchildcode
          FROM dbo.DispatchList AS DH INNER JOIN DispatchLists AS DD ON DH.DLID = DD.DLID INNER JOIN Inventory AS I ON DD.cInvCode = I.cInvCode
          WHERE ( DH.cVouchType = ''05'' OR DH.cVouchType = ''06'')
                    AND NOT ( ISNULL(DH.bFirst, 0) = 1 AND ISNULL(DD.bIsSTQc, 0) = 0)';
                IF @ShowClosed = N'0'
                    BEGIN
                        SET @SqlCommand = @SqlCommand
                            + 'AND ((ABS(ISNULL(( CASE WHEN ( ISNULL(DD.bQANeedCheck, 0) = 1 AND DD.iQuantity > 0 ) THEN DD.iQAQuantity ELSE DD.iQuantity END ), 0)) - ABS(ISNULL(DD.fOutQuantity, 0)) ) >= 0.01
                          OR ( iGroupType = 2 AND ( ABS(ISNULL(( CASE WHEN ( ISNULL(DD.bQANeedCheck,0) = 1 AND DD.iQuantity > 0 ) THEN DD.iQANum ELSE DD.iNum END ), 0)) - ABS(ISNULL(DD.fOutNum, 0)) ) >= 0.01))';
                    END;
                SET @SqlCommand = @SqlCommand
                    + '--AND DATEDIFF(DAY, DH.dDate, ''2017-09-01'') <= 0
                    AND (ISNULL(DD.cWhCode, '''') <> '''' ) AND bInvType = 0 AND bService = 0
                    AND ((ISNULL(DD.bSettleAll, 0) = 0 AND DH.cVouchType = ''05'') OR DH.cVouchType = ''06'') AND ISNULL(DH.cVerifier, '''') <> '''' AND ( 1 = 1 ';
                IF ( @cDLCode <> N'' )
                    --SET @SqlCommand = @SqlCommand
                    --    + ' AND (( DH.cDLCode >=  @cDLCode) AND ( DH.cDLCode <= @cDLCode )) ';

					 SET @SqlCommand = @SqlCommand
                        + ' AND ( DH.cDLCode in (SELECT DISTINCT DLCode FROM #STPDATempDLCodes)) ';

   
                IF ( @cSoCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (( DH.cSOCode >=  @cSoCode) AND ( DH.cSOCode <= @cSoCode )) ';
                IF ( @cSTCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND ( DH.cSTCode = @cSTCode ) ';
                IF ( @bRed = N'1' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND ( DH.bReturnFlag = 1 ) ';
				IF ( @bRed = N'0' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND ( DH.bReturnFlag = 0 ) ';

                IF ( @Dlids <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND ( DH.DLID IN ( SELECT DISTINCT DLID FROM #STPDATempDLIDs)) ';
                IF ( @dDateFrom <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (( DH.dDate >=  @dDateFrom) AND ( DH.dDate <= @dDateTo )) ';
                IF ( @cBusType <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND ( DH.cBusType = @cBusType ) ';
                IF ( @cCusCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND ( DH.cCusCode = @cCusCode ) ';
                IF ( @cMaker <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND ( DH.cMaker = @cMaker ) ';
                IF ( @cCusName <> N''
                     AND @cCusName <> '%%'
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND ( DH.cCusName LIKE @cCusName ) ';
                IF ( @cDeptCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND ( DH.cDepCode = @cDeptCode ) ';
                IF ( @cPersonCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND ( DH.cPersonCode = @cPersonCode ) ';
                IF ( @cWhCode <> N'' )
					--现在支持多个仓库（前台传参时仓库编码中间用','隔开）
                    SET @SqlCommand = @SqlCommand
                        + ' AND (DD.cWhCode IN (SELECT DISTINCT cWhCode FROM #STPDATempWhs)) ';
                IF ( @ProInvCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND ( DD.cInvCode = @ProInvCode ) ';
                IF ( @ProInvName <> N''
                     AND @ProInvName <> '%%'
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND ( DD.cInvName LIKE @ProInvName ) ';
                SET @SqlCommand = @SqlCommand
                    + N'AND ( (1 > 0) ))
                    AND ( ( CASE WHEN ISNULL(DD.bQANeedCheck, 0) = 1 AND ISNULL(DD.iQuantity, 0) > 0 THEN DD.iQAQuantity ELSE DD.iQuantity END ) <> 0
                          OR ( CASE WHEN ISNULL(DD.bQANeedCheck, 0) = 1 AND ISNULL(DD.iNum, 0) > 0 THEN DD.iQANum ELSE DD.iNum END ) <> 0)
                    AND DH.DLID NOT IN ( SELECT ISNULL(cShipID, 0) FROM   EB_Trade WHERE  ISNULL(EB_Trade.isHold, 0) = 1 )
                    AND ISNULL(DD.cParentCode, '''') = '''';
INSERT  INTO  #UFIDA_MYL_PDA_0_dispatchautoid ( iDLsID ,groupautoid ,cparentcode ,cchildcode)
        SELECT DISTINCT a.iDLsID ,0 ,ISNULL(a.cParentCode, '''') ,ISNULL(a.cChildCode, '''')
        FROM    DispatchLists a INNER JOIN DispatchLists b ON ISNULL(a.cParentCode, '''') = ISNULL(b.cChildCode,'''')
        INNER JOIN  #UFIDA_MYL_PDA_0_dispatchautoid c ON b.iDLsID = c.iDLsID
        WHERE   ISNULL(a.cParentCode, '''') <> ''''; 
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;';
                --PRINT @SqlCommand;
                SET @ParmList = '@cDLCode		NVARCHAR(30),
								   @dDateFrom   NVARCHAR(20),
								   @dDateTo     NVARCHAR(20),
								   @cBusType	NVARCHAR(10),
								   @cCusCode    NVARCHAR(20), 
								   @cMaker      NVARCHAR(30), 
								   @cCusName	NVARCHAR(120),
								   @cDeptCode	NVARCHAR(12),
								   @cPersonCode	NVARCHAR(20),
								   @ProInvCode  NVARCHAR(60),
								   @cSoCode		NVARCHAR(30),
								   @cSTCode		NVARCHAR(5),
								   @ProInvName	NVARCHAR(255)';

                EXEC sp_executesql @SqlCommand, @ParmList, @cDLCode = @cDLCode,
                    @dDateFrom = @dDateFrom, @dDateTo = @dDateTo,
                    @cBusType = @cBusType, @cCusCode = @cCusCode,
                    @cMaker = @cMaker, @cCusName = @cCusName,
                    @cDeptCode = @cDeptCode, @cPersonCode = @cPersonCode,
                    @ProInvCode = @ProInvCode, @cSoCode = @cSoCode,
                    @cSTCode = @cSTCode, @ProInvName = @ProInvName;

 --SELECT * FROM #UFIDA_MYL_PDA_0_dispatchautoid
 
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#UFIDA_MYL_PDA_0_dispatchgroup') IS NULL )
                    DROP TABLE  #UFIDA_MYL_PDA_0_dispatchgroup;
                
                SELECT  IDENTITY( INT ) AS groupautoid ,
                        ISNULL(a.cChildCode, '') AS cchildcode ,
                        MAX(iDLsID) AS idlsid
                INTO    #UFIDA_MYL_PDA_0_dispatchgroup
                FROM    #UFIDA_MYL_PDA_0_dispatchautoid a
                WHERE   ISNULL(a.cParentCode, '') = ''
                GROUP BY ISNULL(a.cChildCode, '')
                ORDER BY idlsid;            
                
                UPDATE  a
                SET     groupautoid = b.groupautoid
                FROM    #UFIDA_MYL_PDA_0_dispatchautoid a
                        INNER JOIN #UFIDA_MYL_PDA_0_dispatchgroup b ON ISNULL(a.cChildCode,
                                                              '') = ISNULL(b.cchildcode,
                                                              '')
                WHERE   ISNULL(a.cParentCode, '') = '';
                UPDATE  a
                SET     groupautoid = b.groupautoid
                FROM    #UFIDA_MYL_PDA_0_dispatchautoid a
                        INNER JOIN #UFIDA_MYL_PDA_0_dispatchgroup b ON ISNULL(a.cParentCode,
                                                              '') = ISNULL(b.cchildcode,
                                                              '')
                WHERE   ISNULL(a.cParentCode, '') <> '';     
                
                DROP TABLE  #UFIDA_MYL_PDA_0_dispatchgroup; 
                
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#UFIDA_MYL_PDA_0_SaleMakeVouchH_ST') IS NULL )
                    DROP TABLE  #UFIDA_MYL_PDA_0_SaleMakeVouchH_ST;
                
                
                SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                SELECT  *
                INTO    #UFIDA_MYL_PDA_0_SaleMakeVouchH_ST
                FROM    ( SELECT DISTINCT
                                    DispatchList.caddcode ,
                                    ( CASE WHEN ISNULL(DispatchList.cSBVCode,
                                                       '') <> ''
                                           THEN SaleBillVouch.cVouchType
                                           ELSE DispatchList.cVouchType
                                      END ) AS cbilltype ,
                                    VouchType.cVouchName AS cbillname ,
                                    DispatchList.cDLCode AS cdlcode ,
                                    DispatchList.SBVID AS sbvid ,
                                    DispatchList.cSBVCode AS csbvcode ,
                                    CONVERT(VARCHAR(100), DispatchList.dDate, 23) AS ddate ,
                                    dbo.DispatchList.cRdCode AS crdcode ,
                                    dbo.DispatchList.cSOCode AS csocode ,
                                    DispatchList.cPayCode AS cpaycode ,
                                    DispatchList.cSCCode AS csccode ,
                                    DispatchList.cexch_name ,
                                    DispatchList.iExchRate AS iexchrate ,
                                    DispatchList.iTaxRate AS itaxrate ,
                                    DispatchList.bFirst AS bfirst ,
                                    DispatchList.bReturnFlag AS breturnflag ,
                                    DispatchList.bSettleAll AS bsettleall ,
                                    DispatchList.cSaleOut AS csaleout ,
                                    DispatchList.iSale AS isale ,
                                    DispatchList.iVTid AS ivtid ,
                                    DispatchList.bIAFirst AS biafirst ,
                                    DispatchList.bCredit AS bcredit ,
                                    DispatchList.iverifystate ,
                                    DispatchList.iswfcontrolled ,
                                    DispatchList.icreditstate ,
                                    DispatchList.bARFirst AS barfirst ,
                                    DispatchList.bsigncreate ,
                                    DispatchList.bcashsale ,
                                    DispatchList.cgathingcode ,
                                    DispatchList.cChanger AS cchanger ,
                                    DispatchList.cChangeMemo AS cchangememo ,
                                    DispatchList.outid ,
                                    DispatchList.bmustbook ,
                                    DispatchList.cBookType AS cbooktype ,
                                    DispatchList.cBookDepcode AS cbookdepcode ,
                                    DispatchList.bSaUsed AS bsaused ,
                                    DispatchList.bneedbill ,
                                    DispatchList.baccswitchflag ,
                                    DispatchList.iPrintCount AS iprintcount ,
                                    DispatchList.cSourceCode AS csourcecode ,
                                    DispatchList.ccusperson ,
                                    DispatchList.ccuspersoncode ,
                                    DispatchList.bsaleoutcreatebill ,
                                    DispatchList.cSysBarCode AS csysbarcode ,
                                    DispatchList.csscode ,
                                    DispatchList.cCurrentAuditor AS ccurrentauditor ,
                                    DispatchList.bNotToGoldTax AS bnottogoldtax ,
                                    DispatchList.cBusType AS cbustype ,
                                    DispatchList.DLID AS dlid ,
                                    DispatchList.cSTCode AS cstcode ,
                                    SaleType.cSTName AS cstname ,
                                    DispatchList.cCusCode AS ccuscode ,
                                    Customer.cCusAbbName AS ccusabbname ,
                                    Customer.cCusName AS ccusname ,
                                    DispatchList.cDepCode AS cdepcode ,
                                    Department.cDepName AS cdepname ,
                                    DispatchList.cPersonCode AS cpersoncode ,
                                    person.cPersonName AS cpersonname ,
                                    DispatchList.cMaker AS cmaker ,
                                    DispatchList.cVerifier AS cverifier ,
                                    DispatchList.cShipAddress AS cshipaddress ,
                                    CONVERT(CHAR, CONVERT(MONEY, DispatchList.ufts), 2) AS ufts ,
                                    DispatchList.cDefine1 AS cdefine1 ,
                                    DispatchList.cDefine2 AS cdefine2 ,
                                    DispatchList.cDefine3 AS cdefine3 ,
                                    DispatchList.cDefine4 AS cdefine4 ,
                                    DispatchList.cDefine5 AS cdefine5 ,
                                    DispatchList.cDefine6 AS cdefine6 ,
                                    DispatchList.cDefine7 AS cdefine7 ,
                                    DispatchList.cDefine8 AS cdefine8 ,
                                    DispatchList.cDefine9 AS cdefine9 ,
                                    DispatchList.cDefine10 AS cdefine10 ,
                                    DispatchList.cDefine11 AS cdefine11 ,
                                    DispatchList.cDefine12 AS cdefine12 ,
                                    DispatchList.cDefine13 AS cdefine13 ,
                                    DispatchList.cDefine14 AS cdefine14 ,
                                    DispatchList.cDefine15 AS cdefine15 ,
                                    DispatchList.cDefine16 AS cdefine16 ,
                                    DispatchList.cMemo AS cmemo ,
                                    SABizFlow.iFlowID AS iflowid ,
                                    SABizFlow.cSalesProcessDescribes AS cflowname ,
                                    DispatchList.cinvoicecompany ,
                                    cus.cCusAbbName AS cinvoicecompanyabbname ,
                                    DispatchList.fEBweight AS febweight ,
                                    DispatchList.cEBweightUnit AS cebweightunit ,
                                    DispatchList.cEBExpressCode AS cebexpresscode ,
                                    '' AS cgcroutecode ,
                                    '' AS cgcroutename,
                                    DispatchLists.cwhcode,
                                    Warehouse.cwhname,
                                    Warehouse.bwhpos
                          FROM      DispatchList
                                    INNER JOIN DispatchLists ON DispatchList.DLID = DispatchLists.DLID
                                    INNER JOIN Inventory ON DispatchLists.cInvCode = Inventory.cInvCode
                                    LEFT JOIN ComputationUnit ON Inventory.cComUnitCode = ComputationUnit.cComunitCode
                                    Left JOIN Warehouse ON DispatchLists.cWhCode = Warehouse.cWhCode
                                    LEFT OUTER JOIN SaleType ON DispatchList.cSTCode = SaleType.cSTCode
                                    LEFT OUTER JOIN ( SELECT  cPersonCode AS cpersoncode2 ,
                                                              cPersonName
                                                      FROM    Person
                                                    ) person ON DispatchList.cPersonCode = person.cpersoncode2
                                    LEFT OUTER JOIN Customer ON DispatchList.cCusCode = Customer.cCusCode
                                    LEFT OUTER JOIN Department ON DispatchList.cDepCode = Department.cDepCode
                                    LEFT JOIN SaleBillVouch ON SaleBillVouch.SBVID = dbo.DispatchList.SBVID
                                    LEFT JOIN VouchType ON VouchType.cVouchType = CASE
                                                              WHEN SaleBillVouch.SBVID IS NULL
                                                              THEN DispatchList.cVouchType
                                                              ELSE SaleBillVouch.cVouchType
                                                              END
                                    LEFT JOIN SABizFlow ON SABizFlow.iFlowID = DispatchList.iflowid
                                    LEFT JOIN Vendor v1 ON v1.cVenCode = DispatchLists.cvmivencode
                                    LEFT JOIN Customer cus ON cus.cCusCode = DispatchList.cinvoicecompany
                                    --LEFT JOIN V_GC_Route WITH ( NOLOCK ) ON DispatchList.cGCRouteCode = V_GC_Route.cCode
                                    INNER JOIN #UFIDA_MYL_PDA_0_dispatchautoid m ON DispatchLists.iDLsID = m.iDLsID
                        ) a;
                SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

                CREATE  CLUSTERED  INDEX [ix_UFIDA_MYL_PC_0_dlid] ON  #UFIDA_MYL_PDA_0_SaleMakeVouchH_ST  (dlid);    
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#UFIDA_MYL_PDA_0_SaleMakeVouchB_ST') IS NULL )
                    DROP TABLE  #UFIDA_MYL_PDA_0_SaleMakeVouchB_ST;
  
                SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; 
                SELECT  *
                INTO    #UFIDA_MYL_PDA_0_SaleMakeVouchB_ST
                FROM    ( SELECT    CAST(0 AS INT) AS parentautoid ,
                                    m.groupautoid ,
                                    DispatchLists.AutoID AS autoid ,
                                    DispatchLists.cWhCode AS cwhcode ,
                                    Warehouse.cWhName AS cwhname ,
                                    '' AS cfactorycode ,
                                    '' AS cfactoryname ,
                                    '' AS gcsourceid ,
                                    '' AS gcsourceids ,
                                    DispatchLists.DLID AS dlid ,
                                    DispatchLists.iCorID AS icorid ,
                                    DispatchLists.cordercode ,
                                    DispatchLists.iorderrowno ,
                                    DispatchLists.bsaleprice ,
                                    DispatchLists.bgift ,
                                    DispatchLists.bmpforderclosed ,
                                    DispatchLists.cbSysBarCode AS cbsysbarcode ,
                                    DispatchLists.cInvCode AS cinvcode ,
                                    Inventory.cInvAddCode AS cinvaddcode ,
                                    Inventory.cInvName AS cinvname ,
                                    Inventory.cInvStd AS cinvstd ,
                                    DispatchLists.iQuotedPrice AS iquotedprice ,
                                    DispatchLists.cCusInvCode AS ccusinvcode ,
                                    DispatchLists.cCusInvName AS ccusinvname ,
                                    DispatchLists.iExpiratDateCalcu AS iexpiratdatecalcu ,
                                    DispatchLists.cExpirationdate AS cexpirationdate ,
                                    DispatchLists.dExpirationdate AS dexpirationdate ,
                                    DispatchLists.iUnitPrice AS iunitprice ,
                                    DispatchLists.iTaxUnitPrice AS itaxunitprice ,
                                    DispatchLists.iMoney AS imoney ,
                                    DispatchLists.iTax AS itax ,
                                    DispatchLists.iDisCount AS idiscount ,
                                    DispatchLists.iSum AS isum ,
                                    DispatchLists.iNatUnitPrice AS inatunitprice ,
                                    DispatchLists.iNatMoney AS inatmoney ,
                                    DispatchLists.iNatTax AS inattax ,
                                    DispatchLists.iNatSum AS inatsum ,
                                    DispatchLists.iNatDisCount AS inatdiscount ,
                                    DispatchLists.iSettleNum AS isettlenum ,
                                    DispatchLists.iSettleQuantity AS isettlequantity ,
                                    DispatchLists.iBatch AS ibatch ,
                                    DispatchLists.cInVouchType AS cinvouchtype ,
                                    CONVERT(NVARCHAR(2), '') AS coutvouchtype ,
                                    ComputationUnit.cComUnitName AS cinvm_unit ,
                                    ComputationUnit_1.cComUnitName AS cinva_unit ,
                                    DispatchLists.iInvExchRate AS iinvexchrate ,
                                    DispatchLists.cBatch AS cbatch ,
                                    DispatchLists.bSettleAll AS bsettleall ,
                                    DispatchLists.cvmivencode ,
                                    v1.cVenAbbName AS cvmivenname ,
                                    DispatchLists.iTB AS itb ,
                                    DispatchLists.dMDate AS dmadedate ,
                                    DispatchLists.dvDate AS dvdate ,
                                    DispatchLists.cMassUnit AS cmassunit ,
                                    DispatchLists.iMassDate AS imassdate ,
                                    DispatchLists.TBQuantity AS tbquantity ,
                                    DispatchLists.TBNum AS tbnum ,
                                    DispatchLists.iSOsID AS isosid ,
                                    DispatchLists.iDLsID AS idlsid ,
                                    DispatchLists.KL AS kl ,
                                    DispatchLists.iTaxRate AS itaxrate ,
                                    DispatchLists.KL2 AS kl2 ,
                                -- (case when isnull(DispatchLists.cordercode,'')<>''then 
                                --    CONVERT(INT, 1)
								--	else
								--	 CONVERT(INT, 0) end)
								--	 AS isotype ,
                                    DispatchLists.cdemandid AS isodid ,
                                    DispatchLists.idemandtype ,
									 DispatchLists.idemandtype  as isotype,
                                    DispatchLists.cdemandcode ,
                                    DispatchLists.cdemandid ,
                                    DispatchLists.idemandseq ,
                                    DispatchLists.cItemCode AS citemcode ,
                                    DispatchLists.cItem_class AS citem_class ,
                                    DispatchLists.fSaleCost AS fsalecost ,
                                    DispatchLists.fSalePrice AS fsaleprice ,
                                    DispatchLists.cVenAbbName AS cvenabbname ,
                                    DispatchLists.cItemName AS citemname ,
                                    DispatchLists.cContractID AS ccontractid ,
                                    DispatchLists.cContractTagCode AS ccontracttagcode ,
                                    DispatchLists.cContractRowGuid AS ccontractrowguid ,
                                    ISNULL(DispatchLists.cParentCode, '') AS cparentcode ,
                                    ISNULL(DispatchLists.cChildCode, '') AS cchildcode ,
                                    DispatchLists.fchildqty ,
                                    DispatchLists.cItem_CName AS citem_cname ,
                                    DispatchLists.cFree1 AS cfree1 ,
                                    DispatchLists.cFree2 AS cfree2 ,
                                    DispatchLists.cFree3 AS cfree3 ,
                                    DispatchLists.cFree4 AS cfree4 ,
                                    DispatchLists.cFree5 AS cfree5 ,
                                    DispatchLists.cFree6 AS cfree6 ,
                                    DispatchLists.cFree7 AS cfree7 ,
                                    DispatchLists.cFree8 AS cfree8 ,
                                    DispatchLists.cFree9 AS cfree9 ,
                                    DispatchLists.cFree10 AS cfree10 ,
                                    DispatchLists.bIsSTQc AS bisstqc ,
                                    DispatchLists.cbatchproperty1 ,
                                    DispatchLists.cbatchproperty2 ,
                                    DispatchLists.cbatchproperty3 ,
                                    DispatchLists.cbatchproperty4 ,
                                    DispatchLists.cbatchproperty5 ,
                                    DispatchLists.cbatchproperty6 ,
                                    DispatchLists.cbatchproperty7 ,
                                    DispatchLists.cbatchproperty8 ,
                                    DispatchLists.cbatchproperty9 ,
                                    DispatchLists.cbatchproperty10 ,
                                    DispatchLists.cUnitID AS cunitid ,
                                    DispatchLists.cCode AS ccode ,
                                    DispatchLists.iRetQuantity AS iretquantity ,
                                    DispatchLists.fEnSettleQuan AS fensettlequan ,
                                    DispatchLists.fEnSettleSum AS fensettlesum ,
                                    DispatchLists.iSettlePrice AS isettleprice ,
                                    DispatchLists.cDefine22 AS cdefine22 ,
                                    DispatchLists.cDefine23 AS cdefine23 ,
                                    DispatchLists.cDefine24 AS cdefine24 ,
                                    DispatchLists.cDefine25 AS cdefine25 ,
                                    DispatchLists.cDefine26 AS cdefine26 ,
                                    DispatchLists.cDefine27 AS cdefine27 ,
                                    DispatchLists.cDefine28 AS cdefine28 ,
                                    DispatchLists.cDefine29 AS cdefine29 ,
                                    DispatchLists.cDefine30 AS cdefine30 ,
                                    DispatchLists.cDefine31 AS cdefine31 ,
                                    DispatchLists.cDefine32 AS cdefine32 ,
                                    DispatchLists.cDefine33 AS cdefine33 ,
                                    DispatchLists.cDefine34 AS cdefine34 ,
                                    DispatchLists.cDefine35 AS cdefine35 ,
                                    DispatchLists.cDefine36 AS cdefine36 ,
                                    DispatchLists.cDefine37 AS cdefine37 ,
                                    DispatchLists.bGsp AS bgsp ,
                                    DispatchLists.cGspState AS cgspstate ,
                                    DispatchLists.bQANeedCheck AS bqaneedcheck ,
                                    DispatchLists.irowno AS ivouchrowno ,
                                    DispatchList.bsaleoutcreatebill ,
                                    DispatchLists.bIAcreatebill AS biacreatebill ,
                                    DispatchLists.isaleoutid ,
                                    DispatchList.bneedbill ,
                                    DispatchLists.cSoCode AS csocode ,
                                    DispatchLists.cMemo AS cbmemo ,
                                    DispatchList.iflowid ,
                                    SABizFlow.cSalesProcessDescribes AS cflowname ,
                                    SaleType.cSTCode AS cstcode ,
                                    SaleType.cSTName AS cstname ,
                                    SA_SORowNo.iRowNo AS irowno ,
                                    Inventory.cInvCCode AS cinvccode ,
                                    Inventory.cVenCode AS cvencode ,
                                    Inventory.cReplaceItem AS creplaceitem ,
                                    Inventory.cPosition AS cposition ,
                                    Inventory.bSale AS bsale ,
                                    Inventory.bPurchase AS bpurchase ,
                                    Inventory.bSelf AS bself ,
                                    Inventory.bComsume AS bcomsume ,
                                    Inventory.bProducing AS bproducing ,
                                    Inventory.bService AS bservice ,
                                    Inventory.bAccessary AS baccessary ,
                                    Inventory.iInvWeight AS iinvweight ,
                                    Inventory.iVolume AS ivolume ,
                                    Inventory.iInvRCost AS iinvrcost ,
                                    Inventory.iInvSPrice AS iinvsprice ,
                                    Inventory.iInvSCost AS iinvscost ,
                                    Inventory.iInvLSCost AS iinvlscost ,
                                    Inventory.iInvNCost AS iinvncost ,
                                    Inventory.iInvAdvance AS iinvadvance ,
                                    Inventory.iInvBatch AS iinvbatch ,
                                    Inventory.iSafeNum AS isafenum ,
                                    Inventory.iTopSum AS itopsum ,
                                    Inventory.iLowSum AS ilowsum ,
                                    Inventory.iOverStock AS ioverstock ,
                                    Inventory.cInvABC AS cinvabc ,
                                    Inventory.bInvQuality AS binvquality ,
                                    Inventory.bInvBatch AS binvbatch ,
                                    Inventory.bInvEntrust AS binventrust ,
                                    Inventory.bInvOverStock AS binvoverstock ,
                                    Inventory.dSDate AS dsdate ,
                                    Inventory.dEDate AS dedate ,
                                    Inventory.bFree1 AS bfree1 ,
                                    Inventory.bFree2 AS bfree2 ,
                                    Inventory.I_id AS i_id ,
                                    Inventory.bInvType AS binvtype ,
                                    Inventory.iInvMPCost AS iinvmpcost ,
                                    Inventory.cQuality AS cquality ,
                                    Inventory.iInvSaleCost AS iinvsalecost ,
                                    Inventory.iInvSCost1 AS iinvscost1 ,
                                    Inventory.iInvSCost2 AS iinvscost2 ,
                                    Inventory.iInvSCost3 AS iinvscost3 ,
                                    Inventory.bFree3 AS bfree3 ,
                                    Inventory.bFree4 AS bfree4 ,
                                    Inventory.bFree5 AS bfree5 ,
                                    Inventory.bFree6 AS bfree6 ,
                                    Inventory.bFree7 AS bfree7 ,
                                    Inventory.bFree8 AS bfree8 ,
                                    Inventory.bFree9 AS bfree9 ,
                                    Inventory.bFree10 AS bfree10 ,
                                    Inventory.cCreatePerson AS ccreateperson ,
                                    Inventory.cModifyPerson AS cmodifyperson ,
                                    Inventory.dModifyDate AS dmodifydate ,
                                    Inventory.fSubscribePoint AS fsubscribepoint ,
                                    Inventory.fVagQuantity AS fvagquantity ,
                                    Inventory.cValueType AS cvaluetype ,
                                    Inventory.bFixExch AS bfixexch ,
                                    Inventory.fOutExcess AS foutexcess ,
                                    Inventory.fInExcess AS finexcess ,
                                    Inventory.iWarnDays AS iwarndays ,
                                    Inventory.fExpensesExch AS fexpensesexch ,
                                    Inventory.bTrack AS btrack ,
                                    Inventory.bSerial AS bserial ,
                                    Inventory.bBarCode AS bbarcode ,
                                    Inventory.iId AS iid ,
                                    Inventory.cBarCode AS cbarcode ,
                                    Inventory.cInvDefine1 AS cinvdefine1 ,
                                    Inventory.cInvDefine2 AS cinvdefine2 ,
                                    Inventory.cInvDefine3 AS cinvdefine3 ,
                                    Inventory.cInvDefine4 AS cinvdefine4 ,
                                    Inventory.cInvDefine5 AS cinvdefine5 ,
                                    Inventory.cInvDefine6 AS cinvdefine6 ,
                                    Inventory.cInvDefine7 AS cinvdefine7 ,
                                    Inventory.cInvDefine8 AS cinvdefine8 ,
                                    Inventory.cInvDefine9 AS cinvdefine9 ,
                                    Inventory.cInvDefine10 AS cinvdefine10 ,
                                    Inventory.cInvDefine11 AS cinvdefine11 ,
                                    Inventory.cInvDefine12 AS cinvdefine12 ,
                                    Inventory.cInvDefine13 AS cinvdefine13 ,
                                    Inventory.cInvDefine14 AS cinvdefine14 ,
                                    Inventory.cInvDefine15 AS cinvdefine15 ,
                                    Inventory.cInvDefine16 AS cinvdefine16 ,
                                    CONVERT(BIT, 0) AS bquansign ,
                                    Inventory.iGroupType AS igrouptype ,
                                    Inventory.cGroupCode AS cgroupcode ,
                                    Inventory.cAssComUnitCode AS casscomunitcode ,
                                    Inventory.cSAComUnitCode AS csacomunitcode ,
                                    Inventory.cPUComUnitCode AS cpucomunitcode ,
                                    Inventory.cSTComUnitCode AS cstcomunitcode ,
                                    Inventory.cComUnitCode AS ccomunitcode ,
                                    Inventory.cCAComUnitCode AS ccacomunitcode ,
                                    Inventory.cFrequency AS cfrequency ,
                                    Inventory.iFrequency AS ifrequency ,
                                    Inventory.iDays AS idays ,
                                    Inventory.dLastDate AS dlastdate ,
                                    Inventory.iWastage AS iwastage ,
                                    Inventory.bSolitude AS bsolitude ,
                                    Inventory.cEnterprise AS centerprise ,
                                    Inventory.cAddress AS caddress ,
                                    Inventory.cFile AS cfile ,
                                    Inventory.cLabel AS clabel ,
                                    Inventory.cCheckOut AS ccheckout ,
                                    Inventory.cLicence AS clicence ,
                                    Inventory.bSpecialties AS bspecialties ,
                                    Inventory.cDefWareHouse AS cdefwarehouse ,
                                    Inventory.iHighPrice AS ihighprice ,
                                    Inventory.cPriceGroup AS cpricegroup ,
                                    Inventory.iExpSaleRate AS iexpsalerate ,
                                    Inventory.cOfferGrade AS coffergrade ,
                                    Inventory.iOfferRate AS iofferrate ,
                                    Inventory.cMonth AS cmonth ,
                                    Inventory.iAdvanceDate AS iadvancedate ,
                                    Inventory.cCurrencyName AS ccurrencyname ,
                                    Inventory.cProduceAddress AS cproduceaddress ,
                                    Inventory.cProduceNation AS cproducenation ,
                                    Inventory.cRegisterNo AS cregisterno ,
                                    Inventory.cEnterNo AS centerno ,
                                    Inventory.cPackingType AS cpackingtype ,
                                    Inventory.cEnglishName AS cenglishname ,
                                    Inventory.bPropertyCheck AS bpropertycheck ,
                                    Inventory.cPreparationType AS cpreparationtype ,
                                    Inventory.cCommodity AS ccommodity ,
                                    Inventory.iRecipeBatch AS irecipebatch ,
                                    Inventory.cNotPatentName AS cnotpatentname ,
                                    Inventory.cSRPolicy AS csrpolicy ,
                                    --Inventory.pubufts ,
                                    ( CASE WHEN ( ISNULL(DispatchLists.bQANeedCheck,
                                                         0) = 1
                                                  AND DispatchLists.iQuantity > 0
                                                )
                                           THEN ISNULL(DispatchLists.iQAQuantity,
                                                       0)
                                           ELSE ISNULL(DispatchLists.iQuantity,
                                                       0)
                                      END ) AS iquantity ,
                                    ( CASE WHEN ( ISNULL(DispatchLists.bQANeedCheck,
                                                         0) = 1
                                                  AND DispatchLists.iNum > 0
                                                )
                                           THEN ISNULL(DispatchLists.iQANum, 0)
                                           ELSE ISNULL(DispatchLists.iNum, 0)
                                      END ) AS inum ,
                                    ISNULL(DispatchLists.fOutQuantity, 0) AS foutquantity ,
                                    ISNULL(CASE WHEN Inventory.iGroupType = 1
                                                THEN DispatchLists.fOutQuantity
                                                     / DispatchLists.iInvExchRate
                                                ELSE DispatchLists.fOutNum
                                           END, 0) AS foutnum ,
                                    --START Myl 20180606 ADD(为前台处理方便我自己加的列)
                                    CONVERT(CHAR, CONVERT(MONEY, DispatchList.ufts), 2) AS corufts ,
                                    DispatchLists.iSOsID AS iorderdid ,
                                    CONVERT(INT, 1) AS iordertype ,
                                    DispatchLists.cSoCode AS iordercode ,
                                    DispatchLists.iorderrowno AS iorderseq ,
                                    ( CASE WHEN Inventory.cSRPolicy = N'PE'
                                           THEN DispatchLists.iSOsID
                                           ELSE NULL
                                      END ) AS ipesodid ,
                                    ( CASE WHEN Inventory.cSRPolicy = N'PE'
                                           THEN CONVERT(INT, 1)
                                           ELSE CONVERT(INT, 0)
                                      END ) AS ipesotype ,
                                    ( CASE WHEN Inventory.cSRPolicy = N'PE'
                                           THEN DispatchLists.cSoCode
                                           ELSE NULL
                                      END ) AS cpesocode ,
                                    ( CASE WHEN Inventory.cSRPolicy = N'PE'
                                           THEN DispatchLists.iorderrowno
                                           ELSE NULL
                                      END ) AS ipesoseq ,
                                    ( CASE WHEN idemandtype <> NULL
                                           THEN DispatchLists.idemandtype
                                           ELSE CONVERT(SMALLINT, 0)
                                      END ) AS isodemandtype ,
                                    dbo.DispatchList.cDLCode AS cbdlcode, dbo.DispatchList.cDLCode as csrccode
                                      --END Myl 20180606
                          FROM      dbo.DispatchList WITH ( NOLOCK )
                                    INNER JOIN DispatchLists ON DispatchList.DLID = DispatchLists.DLID
                                    INNER JOIN Inventory ON DispatchLists.cInvCode = Inventory.cInvCode
                                    LEFT JOIN Warehouse ON DispatchLists.cWhCode = Warehouse.cWhCode
                                    --LEFT JOIN Factory ON DispatchLists.cFactoryCode = Factory.cFactoryCode
                                    INNER JOIN ComputationUnit ON Inventory.cComUnitCode = ComputationUnit.cComunitCode
                                    LEFT OUTER JOIN Department ON DispatchList.cDepCode = Department.cDepCode
                                    LEFT OUTER JOIN ComputationUnit ComputationUnit_1 ON DispatchLists.cUnitID = ComputationUnit_1.cComunitCode
                                    LEFT JOIN SA_SORowNo ON DispatchLists.iSOsID = SA_SORowNo.iSOsID
                                    LEFT JOIN SaleType ON DispatchList.cSTCode = SaleType.cSTCode
                                    LEFT JOIN Vendor v1 ON v1.cVenCode = DispatchLists.cvmivencode
                                    LEFT JOIN Customer ON Customer.cCusCode = DispatchList.cCusCode
                                    LEFT JOIN ( SELECT  cPersonCode AS cpersoncode2 ,
                                                        cPersonName
                                                FROM    Person
                                              ) person ON person.cpersoncode2 = DispatchList.cPersonCode
                                    LEFT JOIN SaleBillVouch ON SaleBillVouch.SBVID = DispatchList.SBVID
                                    LEFT JOIN VouchType ON VouchType.cVouchType = CASE
                                                              WHEN SaleBillVouch.SBVID IS NULL
                                                              THEN DispatchList.cVouchType
                                                              ELSE SaleBillVouch.cVouchType
                                                              END
                                    LEFT JOIN SABizFlow ON SABizFlow.iFlowID = DispatchList.iflowid
                                    INNER JOIN #UFIDA_MYL_PDA_0_dispatchautoid m ON DispatchLists.iDLsID = m.iDLsID
                        ) a
                ORDER BY dlid ,
                        idlsid;
                UPDATE  a
                SET     parentautoid = b.iDLsID
                FROM    #UFIDA_MYL_PDA_0_SaleMakeVouchB_ST a
                        INNER JOIN DispatchLists b ON a.cchildcode = b.cParentCode
                WHERE   ISNULL(a.cchildcode, '') <> ''; 
                SET TRANSACTION ISOLATION LEVEL READ COMMITTED; 

                CREATE  CLUSTERED  INDEX [ix_UFIDA_MYL_PC_0_dlid_idlisd] ON  #UFIDA_MYL_PDA_0_SaleMakeVouchB_ST  (dlid,idlsid );
 
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#UFIDA_MYL_PDA_0_dispatchautoid') IS NULL )
                    DROP TABLE  #UFIDA_MYL_PDA_0_dispatchautoid;
     
                SET NOCOUNT OFF;
       
                SELECT  *
                FROM    #UFIDA_MYL_PDA_0_SaleMakeVouchH_ST
                ORDER BY cdlcode ,
                        ddate;
                IF ( @GetType = N'DETAIL' )
                    BEGIN
					IF (@bRed ='0')
					BEGIN

                        SELECT  idlsid AS bodyautoid ,
                                * ,
                                0 AS iscanedquantity ,
                                0 AS iscanednum ,
								foutquantity as ireceivedqty,
                                ( iquantity - foutquantity ) AS inquantity ,
                                ( inum - foutnum ) AS innum
                        FROM    #UFIDA_MYL_PDA_0_SaleMakeVouchB_ST
                        ORDER BY dlid ,
                                idlsid ,
                                irowno ,
                                cinvcode;
					END;
					IF (@bRed ='1')
					BEGIN
                        SELECT  idlsid AS bodyautoid ,
                                * ,
                                0 AS iscanedquantity ,
                                0 AS iscanednum ,
                               0-( iquantity - foutquantity ) AS inquantity ,
                               0-( isnull(inum,0) - isnull(foutnum,0) ) AS innum
                        FROM    #UFIDA_MYL_PDA_0_SaleMakeVouchB_ST
                        ORDER BY dlid ,
                                idlsid ,
                                irowno ,
                                cinvcode;
					END;
                    END;    
                
                --删除临时表
				  IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempDLCodes') IS NULL )
                    DROP TABLE #STPDATempDLCodes;

                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempDLIDs') IS NULL )
                    DROP TABLE #STPDATempDLIDs;
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempWhs') IS NULL )
                    DROP TABLE #STPDATempWhs;
                
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#UFIDA_MYL_PDA_0_SaleMakeVouchH_ST') IS NULL )
                    DROP TABLE #UFIDA_MYL_PDA_0_SaleMakeVouchH_ST;
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#UFIDA_MYL_PDA_0_SaleMakeVouchB_ST') IS NULL )
                    DROP TABLE #UFIDA_MYL_PDA_0_SaleMakeVouchB_ST;
            END;
       ELSE  IF ( @OperType = N'1' )
	   BEGIN
	   --退货验收单qccode
	   				    DECLARE @GSPVouchQCOUTCodes NVARCHAR(MAX);                
                        BEGIN
						--验收单号
                            SET @GSPVouchQCOUTCodes = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                    N'qccodes',
                                                    DEFAULT, DEFAULT);
                            IF ( @GSPVouchQCOUTCodes <> N'' )
                                BEGIN                             
                                    IF EXISTS ( SELECT
                                                    0
                                                WHERE
                                                    NOT OBJECT_ID('tempdb..#STPDATempGSPQCOutVoucherCodes') IS NULL )
                                        DROP TABLE #STPDATempGSPQCOutVoucherCodes;
                    
                                    CREATE   TABLE #STPDATempGSPQCOutVoucherCodes (QCID
                                                    NVARCHAR(30) );
                                    INSERT  INTO #STPDATempGSPQCOutVoucherCodes
                                            EXEC proc_ts_SplitParamString @GSPVouchQCOUTCodes;
                                END;
                        END;

		  SET NOCOUNT ON;
	
        IF EXISTS ( SELECT  0
                    WHERE   NOT OBJECT_ID('tempdb..#STPDAStockOutGSPQCRefIDs') IS NULL )
            DROP TABLE #STPDAStockOutGSPQCRefIDs;
         
        SELECT  IDENTITY( INT ) AS tmpId ,
                CONVERT(INT, 0) AS M_ID ,
                CONVERT(INT, 0) AS S_ID ,
                CONVERT(MONEY, ufts) AS oriufts
        INTO    #STPDAStockOutGSPQCRefIDs
        FROM    GSP_VouchQC
        WHERE   1 = 0; 
                
        CREATE CLUSTERED INDEX ix_UFIDA_MYL_PC_0_dispatch_idlsid_813 ON #STPDAStockOutGSPQCRefIDs( M_ID,S_ID,tmpId ); 
		    SET @SqlCommand = 'INSERT INTO #STPDAStockOutGSPQCRefIDs ( M_ID ,S_ID ,oriufts)
SELECT  GSP_VouchQC.id,GSP_VouchsQC.autoid,CONVERT(MONEY,GSP_VouchQC.ufts)
FROM  GSP_VouchQC  
	 inner join GSP_VOUCHSQC ON GSP_VOUCHQC.ID=GSP_VOUCHSQC.ID  
left join DispatchList on  DispatchList.cdlcode =GSP_VOUCHQC.ccode
left join SaleType on DispatchList.cSTCode = SaleType.cSTCode 
left join customer on DispatchList.ccuscode=customer.ccuscode 
left join Department ON DispatchList.cDepCode = Department.cDepCode
left join Person ON DispatchList.cPersonCode = Person.cPersonCode
Where ( (1>0) AND (1>0) ) AND ( 1>0 ) 
and GSP_VOUCHQC.CVOUCHTYPE =''004'' 
and ISNULL(GSP_VOUCHQC.CVERIFIER,'''')<>'''' 
and ISNULL(FELGQUANTITY,0)-isnull(FSTQTY,0) <>0 
and isnull(GSP_VOUCHSQC.BMAKESALEOUT,0)=0 ';
         --药品入库质量验收记录单号
		IF(@GSPVouchQCOUTCodes<>N'')
		 SET @SqlCommand = @SqlCommand
                                + ' AND (QCID IN (SELECT DISTINCT QCID FROM #STPDATempGSPQCOutVoucherCodes))';  




		     IF( @CSYSBARCODE <> N'' )
              SET @SqlCommand=@SqlCommand
                              + ' AND (GSP_VOUCHQC.CBSYSBARCODE =@CSYSBARCODE) ';

		    SET @ParmList = '@GSPVouchQCOUTCodes  NVARCHAR(MAX),@CSYSBARCODE NVARCHAR(1000)' 
		     EXEC Sp_executesql  @SqlCommand, @ParmList,@GSPVouchQCOUTCodes,@CSYSBARCODE=@CSYSBARCODE
		    SELECT IDENTITY(INT) AS tmpId,
                   M_ID,
                   Max(oriufts)  AS oriufts
            INTO   #STPDAStockOutGSPQCRefID
            FROM   #STPDAStockOutGSPQCRefIDs
            GROUP  BY M_ID;

		    SET NOCOUNT OFF;

	SET	@SqlHEADCommand=N'	select distinct convert(bit,0) isChecked,'''' as selcol,''退货验收单'' as csource,GSP_VouchQC.id,QCID ccode,DispatchList.ccuscode,ccusabbname,
                                   Convert(varchar(10),GSP_VouchQC.ddate,120) as ddate,GSP_VouchQC.ccode csocode,
                                   DispatchList.cdepcode,cdepname,DispatchList.cstcode,SaleType.cstname,
                                   cbustype,DispatchList.cpersoncode,cpersonname,dlid,
                                   iexchrate,cexch_name,cdlcode,cBusType,
                                   GSP_VouchQC.cmaker,GSP_VouchQC.cverifier,sbvid,GSP_VouchQC.ufts,cShipAddress,
                                   DispatchList.caddcode,GSP_VouchQC.iswfcontrolled,GSP_VouchQC.iverifystate,
                                   iflowid,DispatchList.ccusname,GSP_VouchQC.CBSYSBARCODE csysbarcode,DispatchList.cinvoicecompany,
                                   Rd_Style.crdname,SaleType.crdcode,cgcroutecode,
                                   GSP_VouchQC.cmemo,csysbarcode,cshipaddress,csbvcode,cEBExpressCode,
                                   GSP_VouchQC.cdefine1,GSP_VouchQC.cdefine2,GSP_VouchQC.cdefine3,GSP_VouchQC.cdefine4,
                                   GSP_VouchQC.cdefine5,GSP_VouchQC.cdefine6,GSP_VouchQC.cdefine7,GSP_VouchQC.cdefine8,
                                   GSP_VouchQC.cdefine9,GSP_VouchQC.cdefine10,GSP_VouchQC.cdefine11,GSP_VouchQC.cdefine12,
                                   GSP_VouchQC.cdefine13,GSP_VouchQC.cdefine14,GSP_VouchQC.cdefine15,GSP_VouchQC.cdefine16
                                   FROM  GSP_VouchQC 
	                               inner join GSP_VOUCHSQC ON GSP_VOUCHQC.ID=GSP_VOUCHSQC.ID  
                                   left join DispatchList on  DispatchList.cdlcode =GSP_VOUCHQC.ccode
                                   left join SaleType on DispatchList.cSTCode = SaleType.cSTCode  
                                   left join Rd_Style on Rd_Style.cRdCode=SaleType.cRdCode
                                   left join customer on DispatchList.ccuscode=customer.ccuscode 
                                   left join Department ON DispatchList.cDepCode = Department.cDepCode
                                   left join Person ON DispatchList.cPersonCode = Person.cPersonCode
                                   Where ( (1>0) AND (1>0) ) AND ( 1>0 ) 
                                   and GSP_VOUCHQC.CVOUCHTYPE =''004'' 
                                   and ISNULL(GSP_VOUCHQC.CVERIFIER,'''')<>'''' 
                                   and ISNULL(FELGQUANTITY,0)-isnull(FSTQTY,0) <>0 
                                   and isnull(GSP_VOUCHSQC.BMAKESALEOUT,0)=0
								   and GSP_VouchQC.ID in (SELECT M_ID
                            FROM   #STPDAStockOutGSPQCRefID)';
							  EXEC Sp_executesql  @SqlHEADCommand;

							   IF ( @GetType = N'DETAIL' )
							   BEGIN

							  SET	@SqlBODYCommand=N' select '''' as selcol,cinvccode,DispatchLists.cwhcode,cwhname,GSP_VOUCHSQC.cinvcode,cinvaddcode,Inventory.cinvname,cinvstd,
                                     cinvdefine1,cinvdefine2,cinvdefine3,cinvdefine4,cinvdefine5,cinvdefine6,cinvdefine7,cinvdefine8,
                                     cinvdefine9,cinvdefine10,cinvdefine11,cinvdefine12,cinvdefine13,cinvdefine14,cinvdefine15,cinvdefine16,
			                         Inventory.ccomunitcode,COM1.cComUnitName cinvm_unit,GSP_VOUCHSQC.cunitid,COM2.cComUnitName cinva_unit,iinvexchrate,
			                         GSP_VouchsQC.cfree1,GSP_VouchsQC.cfree2,GSP_VouchsQC.cfree3,GSP_VouchsQC.cfree4,GSP_VouchsQC.cfree5,
			                         GSP_VouchsQC.cfree6,GSP_VouchsQC.cfree7,GSP_VouchsQC.cfree8,GSP_VouchsQC.cfree9,GSP_VouchsQC.cfree10,
			                         GSP_VouchsQC.cbatch,DPRODATE dmadedate,GSP_VouchsQC.imassdate,GSP_VouchsQC.dvdate,GSP_VouchsQC.cmassunit,
			                         cexpirationdate,dexpirationdate,iexpiratdatecalcu,idemandseq,idemandtype,
                                     '''' cinvouchcode,citem_class,citem_cname citemcname,citemcode,citemname cname,abs(iquantity) inewquantity,
                                     abs(inum) inewnum,foutquantity,foutnum,cdlcode as cbdlcode,cdlcode as cSourceCode,
                                     isnull(FELGQUANTITY,0)-isnull(FSTQTY,0) iquantity, isnull(FQUANTITY,0) inquantity,
                                     isnull(FELGQUANTITYS,0)-isnull(FSTnum,0) inum,isnull(FQUANTITYS,0) innum,
                                     GSP_VouchsQC.autoid,bqaneedcheck,cvmivencode,v1.cvenabbname cvmivenname,
                                     DispatchList.dlid,DispatchList.csocode,foutexcess,idlsid,idlsid as iSourceIds,irowno,isosid,
                                     ibatch,inatmoney,inatunitprice,igrouptype,convert(bit,0) bquansign,bgsp,ccontractid,GSP_VouchQC.ccode,ccontracttagcode,
                                     ccontractrowguid,cdemandcode,cdemandid,ccusinvcode,ccusinvname,QCID ccheckcode,GSP_VouchsQC.AUTOID icheckids,
                                     CMEMO_T cbmemo,Dispatchlists.irowno ivouchrowno,GSP_VouchsQC.cbsysbarcode,iorderrowno, iQuotedPrice,bgift,cEBExpressCode,cSRPolicy,  
                                     GSP_VOUCHSQC.cdefine22,GSP_VOUCHSQC.cdefine23,GSP_VOUCHSQC.cdefine24,GSP_VOUCHSQC.cdefine25,GSP_VOUCHSQC.cdefine26,
                                     GSP_VOUCHSQC.cdefine27,GSP_VOUCHSQC.cdefine28,GSP_VOUCHSQC.cdefine29,GSP_VOUCHSQC.cdefine30,GSP_VOUCHSQC.cdefine31,
                                     GSP_VOUCHSQC.cdefine32,GSP_VOUCHSQC.cdefine33,GSP_VOUCHSQC.cdefine34,GSP_VOUCHSQC.cdefine35,GSP_VOUCHSQC.cdefine36,
                                     GSP_VOUCHSQC.cdefine37,GSP_VOUCHSQC.cbatchproperty1,GSP_VOUCHSQC.cbatchproperty2,GSP_VOUCHSQC.cbatchproperty3,
                                     GSP_VOUCHSQC.cbatchproperty4,GSP_VOUCHSQC.cbatchproperty5,GSP_VOUCHSQC.cbatchproperty6,GSP_VOUCHSQC.cbatchproperty7,
                                     GSP_VOUCHSQC.cbatchproperty8,GSP_VOUCHSQC.cbatchproperty9,GSP_VOUCHSQC.cbatchproperty10
                                     FROM  GSP_VouchsQC 
			                         inner join GSP_VOUCHQC ON GSP_VOUCHQC.ID=dbo.GSP_VOUCHSQC.ID 
		  	                         left join DispatchLists on  DispatchLists.iDLsID =GSP_VouchsQC.ICODE_T 
		 	                         left join DispatchList on  DispatchList.dlid =DispatchLists.dlid
		 	                         left join Inventory ON Inventory.cInvCode = GSP_VOUCHSQC.CINVCODE    
			                         left join ComputationUnit COM1 ON Inventory.cComUnitCode = COM1.cComunitCode
			                         left join ComputationUnit COM2 ON DispatchLists.cUnitID = COM2.cComunitCode  
			                         left join Warehouse on DispatchLists.cWhCode = Warehouse.cWhCode 
			                         left join vendor v1 on v1.cvencode =dispatchlists.cvmivencode 
			                         where  GSP_VOUCHQC.CVOUCHTYPE =''004''
                                     and ISNULL(GSP_VOUCHQC.CVERIFIER,'''')<>'''' 
                                     and ISNULL(FELGQUANTITY,0)-isnull(FSTQTY,0) <>0 
                                     and isnull(GSP_VOUCHSQC.BMAKESALEOUT,0)=0 and GSP_VouchsQC.ID in (
                                                    SELECT
                                                    M_ID
                                                    FROM
                                                    #STPDAStockOutGSPQCRefID )';	
													 EXEC Sp_executesql  @SqlBODYCommand;						   
							   END;
--删除临时表
	
		IF EXISTS ( SELECT  0
                WHERE   NOT OBJECT_ID('tempdb..#STPDATempGSPQCOutVoucherCodes') IS NULL )
        DROP TABLE #STPDATempGSPQCOutVoucherCodes;


        IF EXISTS ( SELECT  0
                    WHERE   NOT OBJECT_ID('tempdb..#STPDAStockOutGSPQCRefIDs') IS NULL )
            DROP TABLE #STPDAStockOutGSPQCRefIDs;
        IF EXISTS ( SELECT  0
                    WHERE   NOT OBJECT_ID('tempdb..#STPDAStockOutGSPQCRefID') IS NULL )
            DROP TABLE #STPDAStockOutGSPQCRefID;
        --IF EXISTS ( SELECT  0
        --            WHERE   NOT OBJECT_ID('tempdb..#STPDATempArrIDs') IS NULL )
        --    DROP TABLE #STPDATempArrIDs;


	   PRINT @OperType;
	   END;
	    ELSE  IF ( @OperType = N'2' )
	   BEGIN
	   --处理通知单
	     DECLARE @GSPOutVouchINFORMCodes NVARCHAR(MAX);                
                        BEGIN
						--单号
                            SET @GSPOutVouchINFORMCodes = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                    N'cinids',
                                                    DEFAULT, DEFAULT);
                            IF ( @GSPOutVouchINFORMCodes <> N'' )
                                BEGIN                             
                                    IF EXISTS ( SELECT
                                                    0
                                                WHERE
                                                    NOT OBJECT_ID('tempdb..#STPDATempGSPOutINFORMVoucherCodes') IS NULL )
                                        DROP TABLE #STPDATempGSPOutINFORMVoucherCodes;
                    
                                    CREATE   TABLE #STPDATempGSPOutINFORMVoucherCodes (CINID
                                                    NVARCHAR(30) );
                                    INSERT  INTO #STPDATempGSPOutINFORMVoucherCodes
                                            EXEC proc_ts_SplitParamString @GSPOutVouchINFORMCodes;
                                END;
                END;

		  SET NOCOUNT ON;
        IF EXISTS ( SELECT  0
                    WHERE   NOT OBJECT_ID('tempdb..#STPDAStockOutGSPINFORMRefIDs') IS NULL )
            DROP TABLE #STPDAStockOutGSPINFORMRefIDs;
         
        SELECT  IDENTITY( INT ) AS tmpId ,
                CONVERT(INT, 0) AS M_ID ,
                CONVERT(INT, 0) AS S_ID ,
                CONVERT(MONEY, ufts) AS oriufts
        INTO    #STPDAStockOutGSPINFORMRefIDs
        FROM    GSP_VOUCHINFORM
        WHERE   1 = 0; 
                
        CREATE CLUSTERED INDEX ix_STPDAStockOutRefIDs_tmpid_813 ON #STPDAStockOutGSPINFORMRefIDs( M_ID,S_ID,tmpId ); 
		    SET @SqlCommand = 'INSERT INTO #STPDAStockOutGSPINFORMRefIDs ( M_ID ,S_ID ,oriufts)
SELECT  GSP_VOUCHINFORM.id,GSP_VOUCHINFORMS.autoid,CONVERT(MONEY,GSP_VOUCHINFORM.ufts)
 FROM  GSP_VOUCHINFORM  
	                               inner join GSP_VOUCHINFORMS ON  GSP_VOUCHINFORMS.ID=GSP_VOUCHINFORM.ID   
	                               inner JOIN GSP_VOUCHSQC on GSP_VOUCHSQC.AUTOID=GSP_VOUCHINFORM.CSOURCEAUTOID
	                               inner join GSP_VOUCHQC ON  GSP_VOUCHQC.ID=GSP_VOUCHSQC.ID and GSP_VOUCHQC.CVOUCHTYPE =''004''
                                   left join DispatchList on  DispatchList.cDLCode = GSP_VOUCHQC.CCODE
                                   left join Department ON DispatchList.cDepCode = Department.cDepCode
                                   left join Person ON DispatchList.cPersonCode = Person.cPersonCode
                                   left join customer on DispatchList.ccuscode=customer.ccuscode 
                                   left join SaleType on DispatchList.cSTCode = SaleType.cSTCode 
                                   left join Rd_Style on SaleType.cRdCode=Rd_Style.cRdCode
                                   where GSP_VOUCHINFORM.cSource =''004''  
								   and ISNULL(dbo.GSP_VOUCHINFORM.CVERIFIER,'''')<>'''' 
								   and isnull(GSP_VOUCHSQC.BMAKESCRAPIN,0)=0 and isnull(GSP_VOUCHINFORMS.FQTY,0)-isnull(GSP_VOUCHINFORMS.FOUTINQTY,0)<>0';
         --药品入库质量验收记录单号
		IF(@GSPOutVouchINFORMCodes<>N'')
		 SET @SqlCommand = @SqlCommand
                                + ' AND (CINID IN (SELECT DISTINCT CINID FROM #STPDATempGSPOutINFORMVoucherCodes))';  

		  IF( @CSYSBARCODE <> N'' )
              SET @SqlCommand=@SqlCommand
                              + ' AND (GSP_VOUCHINFORM.CBSYSBARCODE =@CSYSBARCODE) ';

		    SET @ParmList = '@GSPOutVouchINFORMCodes	NVARCHAR(MAX),@CSYSBARCODE NVARCHAR(1000)' 
		     EXEC Sp_executesql  @SqlCommand, @ParmList,@GSPOutVouchINFORMCodes,@CSYSBARCODE=@CSYSBARCODE
		    SELECT IDENTITY(INT) AS tmpId,
                   M_ID,
                   Max(oriufts)  AS oriufts
            INTO   #STPDAStockOutGSPINFORMRefID
            FROM   #STPDAStockOutGSPINFORMRefIDs
            GROUP  BY M_ID;

		    SET NOCOUNT OFF;
		SET	@SqlHEADCommand=N'select distinct convert(bit,0) isChecked,'''' as selcol,''处理通知单'' as csource,GSP_VOUCHINFORM.id,CINID ccode,DispatchList.ccuscode,ccusabbname,
                                   Convert(varchar(10),GSP_VOUCHINFORM.ddate,120) as ddate,GSP_VouchQC.ccode csocode,
                                   DispatchList.cdepcode,cdepname,DispatchList.cstcode,SaleType.cstname,
                                   cbustype,DispatchList.cpersoncode,cpersonname,
                                   GSP_VOUCHINFORM.cmemo,GSP_VOUCHINFORM.CBSYSBARCODE csysbarcode,cshipaddress,csbvcode,cEBExpressCode,
                                   GSP_VOUCHINFORM.cdefine1,GSP_VOUCHINFORM.cdefine2,GSP_VOUCHINFORM.cdefine3,GSP_VOUCHINFORM.cdefine4,
                                   GSP_VOUCHINFORM.cdefine5,GSP_VOUCHINFORM.cdefine6,GSP_VOUCHINFORM.cdefine7,GSP_VOUCHINFORM.cdefine8,
                                   GSP_VOUCHINFORM.cdefine9,GSP_VOUCHINFORM.cdefine10,GSP_VOUCHINFORM.cdefine11,GSP_VOUCHINFORM.cdefine12,
                                   GSP_VOUCHINFORM.cdefine13,GSP_VOUCHINFORM.cdefine14,GSP_VOUCHINFORM.cdefine15,GSP_VOUCHINFORM.cdefine16
                                   FROM  GSP_VOUCHINFORM  
	                               inner join GSP_VOUCHINFORMS ON  GSP_VOUCHINFORMS.ID=GSP_VOUCHINFORM.ID   
	                               inner JOIN GSP_VOUCHSQC on GSP_VOUCHSQC.AUTOID=GSP_VOUCHINFORM.CSOURCEAUTOID
	                               inner join GSP_VOUCHQC ON  GSP_VOUCHQC.ID=GSP_VOUCHSQC.ID and GSP_VOUCHQC.CVOUCHTYPE =''004''
                                   left join DispatchList on  DispatchList.cDLCode = GSP_VOUCHQC.CCODE
                                   left join Department ON DispatchList.cDepCode = Department.cDepCode
                                   left join Person ON DispatchList.cPersonCode = Person.cPersonCode
                                   left join customer on DispatchList.ccuscode=customer.ccuscode 
                                   left join SaleType on DispatchList.cSTCode = SaleType.cSTCode 
                                   left join Rd_Style on SaleType.cRdCode=Rd_Style.cRdCode
                                   where GSP_VOUCHINFORM.cSource =''004''  
								   and ISNULL(dbo.GSP_VOUCHINFORM.CVERIFIER,'''')<>'''' 
								   and isnull(GSP_VOUCHSQC.BMAKESCRAPIN,0)=0 and isnull(GSP_VOUCHINFORMS.FQTY,0)-isnull(GSP_VOUCHINFORMS.FOUTINQTY,0)<>0 and GSP_VOUCHINFORM.ID in (SELECT M_ID   FROM   #STPDAStockOutGSPINFORMRefID)';
	       EXEC Sp_executesql  @SqlHEADCommand;			

							   IF ( @GetType = N'DETAIL' )
							   BEGIN
					  SET	@SqlBODYCommand=N'		   select '''' as selcol,cinvccode,GSP_VOUCHINFORMS.cwhcode,cwhname,GSP_VOUCHINFORM.cinvcode,cinvaddcode,Inventory.cinvname,cinvstd,
                                      cinvdefine1,cinvdefine2,cinvdefine3,cinvdefine4,cinvdefine5,cinvdefine6,cinvdefine7,cinvdefine8,
                                      cinvdefine9,cinvdefine10,cinvdefine11,cinvdefine12,cinvdefine13,cinvdefine14,cinvdefine15,cinvdefine16,
			                          Inventory.ccomunitcode,COM1.cComUnitName cinvm_unit,GSP_VOUCHINFORM.cunitid,COM2.cComUnitName cinva_unit,iinvexchrate,
			                          GSP_VOUCHINFORM.cfree1,GSP_VOUCHINFORM.cfree2,GSP_VOUCHINFORM.cfree3,GSP_VOUCHINFORM.cfree4,GSP_VOUCHINFORM.cfree5,
			                          GSP_VOUCHINFORM.cfree6,GSP_VOUCHINFORM.cfree7,GSP_VOUCHINFORM.cfree8,GSP_VOUCHINFORM.cfree9,GSP_VOUCHINFORM.cfree10,
			                          GSP_VOUCHINFORM.cbatch,GSP_VOUCHINFORM.DPRODATE dmadedate,GSP_VouchsQC.imassdate,GSP_VOUCHINFORM.DValDate dvdate,GSP_VOUCHINFORM.cmassunit,
			                          cexpirationdate,dexpirationdate,iexpiratdatecalcu,idemandseq,idemandtype,
                                      '''' cinvouchcode,citem_class,citem_cname citemcname,citemcode,citemname cname,abs(iquantity) inewquantity,
                                      abs(inum) inewnum,foutquantity,foutnum,cdlcode as cbdlcode,cdlcode as cSourceCode,
                                      isnull(GSP_VOUCHINFORMS.FQTY,0)-isnull(GSP_VOUCHINFORMS.FOUTINQTY,0) iquantity,
                                      isnull(GSP_VOUCHINFORMS.FQTYS,0)-isnull(GSP_VOUCHINFORMS.FOUTINNUM,0) inum,
                                      isnull(GSP_VOUCHINFORMS.FQTY,0) inquantity,
                                      isnull(GSP_VOUCHINFORMS.FQTYS,0) innum,
                                      GSP_VouchsQC.autoid,bqaneedcheck,cvmivencode,v1.cvenabbname cvmivenname,
                                      DispatchList.dlid,DispatchList.csocode,foutexcess,idlsid,idlsid as iSourceIds,irowno,isosid,
                                      ibatch,inatmoney,inatunitprice,igrouptype,convert(bit,0) bquansign,bgsp,ccontractid,GSP_VouchQC.ccode,ccontracttagcode,
                                      ccontractrowguid,cdemandcode,cdemandid,ccusinvcode,ccusinvname,CINID ccheckcode,GSP_VOUCHINFORMS.AUTOID icheckids,
                                      CMEMO_T cbmemo,Dispatchlists.irowno ivouchrowno,GSP_VOUCHINFORMS.cbsysbarcode,iorderrowno, iQuotedPrice,bgift,cEBExpressCode,cSRPolicy,  
                                      GSP_VOUCHINFORMS.cdefine22,GSP_VOUCHINFORMS.cdefine23,GSP_VOUCHINFORMS.cdefine24,GSP_VOUCHINFORMS.cdefine25,GSP_VOUCHINFORMS.cdefine26,
                                      GSP_VOUCHINFORMS.cdefine27,GSP_VOUCHINFORMS.cdefine28,GSP_VOUCHINFORMS.cdefine29,GSP_VOUCHINFORMS.cdefine30,GSP_VOUCHINFORMS.cdefine31,
                                      GSP_VOUCHINFORMS.cdefine32,GSP_VOUCHINFORMS.cdefine33,GSP_VOUCHINFORMS.cdefine34,GSP_VOUCHINFORMS.cdefine35,GSP_VOUCHINFORMS.cdefine36,
                                      GSP_VOUCHINFORMS.cdefine37,GSP_VOUCHINFORM.cbatchproperty1,GSP_VOUCHINFORM.cbatchproperty2,GSP_VOUCHINFORM.cbatchproperty3,
                                      GSP_VOUCHINFORM.cbatchproperty4,GSP_VOUCHINFORM.cbatchproperty5,GSP_VOUCHINFORM.cbatchproperty6,GSP_VOUCHINFORM.cbatchproperty7,
                                      GSP_VOUCHINFORM.cbatchproperty8,GSP_VOUCHINFORM.cbatchproperty9,GSP_VOUCHINFORM.cbatchproperty10
                                      FROM  GSP_VOUCHINFORM  
	                                  inner join GSP_VOUCHINFORMS ON  GSP_VOUCHINFORMS.ID=GSP_VOUCHINFORM.ID   
	                                  inner JOIN GSP_VOUCHSQC on GSP_VOUCHSQC.AUTOID=GSP_VOUCHINFORM.CSOURCEAUTOID
	                                  inner join GSP_VOUCHQC ON  GSP_VOUCHQC.ID=GSP_VOUCHSQC.ID and GSP_VOUCHQC.CVOUCHTYPE =''004''
                                      left join DispatchList on  DispatchList.cDLCode = GSP_VOUCHQC.CCODE
                                      left join DispatchLists on  DispatchLists.DLID = DispatchList.DLID 
                                      left join customer on DispatchList.ccuscode=customer.ccuscode  
		 	                          left join Inventory ON Inventory.cInvCode = GSP_VOUCHINFORM.CINVCODE    
			                          left join ComputationUnit COM1 ON Inventory.cComUnitCode = COM1.cComunitCode
			                          left join ComputationUnit COM2 ON DispatchLists.cUnitID = COM2.cComunitCode  
			                          left join Warehouse on GSP_VOUCHINFORMS.cWhCode = Warehouse.cWhCode 
			                          left join vendor v1 on v1.cvencode =dispatchlists.cvmivencode 
                                      where GSP_VOUCHINFORM.cSource =''004''  
								      and ISNULL(dbo.GSP_VOUCHINFORM.CVERIFIER,'''')<>'''' 
								      and isnull(GSP_VOUCHINFORMS.FQTY,0)-isnull(GSP_VOUCHINFORMS.FOUTINQTY,0)<>0 
								      and isnull(GSP_VOUCHSQC.BMAKESCRAPIN,0)=0  
                            and GSP_VOUCHINFORM.ID in (
                                                    SELECT
                                                    M_ID
                                                    FROM
                                                    #STPDAStockOutGSPINFORMRefID )';							   
							 EXEC Sp_executesql  @SqlBODYCommand;	
							   END;
--删除临时表
	
		IF EXISTS ( SELECT  0
                WHERE   NOT OBJECT_ID('tempdb..#STPDATempGSPOutINFORMVoucherCodes') IS NULL )
        DROP TABLE #STPDATempGSPOutINFORMVoucherCodes;


        IF EXISTS ( SELECT  0
                    WHERE   NOT OBJECT_ID('tempdb..#STPDAStockOutGSPINFORMRefIDs') IS NULL )
            DROP TABLE #STPDAStockOutGSPINFORMRefIDs;
        IF EXISTS ( SELECT  0
                    WHERE   NOT OBJECT_ID('tempdb..#STPDAStockOutGSPINFORMRefID') IS NULL )
            DROP TABLE #STPDAStockOutGSPINFORMRefID;

	   --PRINT @OperType;
	   END;
	   
	    ELSE
            BEGIN
                PRINT @OperType;
            END;
    END;
