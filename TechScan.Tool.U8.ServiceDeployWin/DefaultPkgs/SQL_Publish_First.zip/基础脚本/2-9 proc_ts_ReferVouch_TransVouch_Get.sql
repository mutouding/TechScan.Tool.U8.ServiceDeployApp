﻿

/*---------------------------------------------------------------------
* 			Copyright (C) 2018 TECHSCAN 版权所有。
*           www.techscan.cn
*┌──────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．　│
*│　版权所有：上海太迅自动识别技术有限公司 　 　　　　　　　　　　　　│
*└──────────────────────────────────┘
*
* 文件名：   proc_ts_ReferVouch_TransVouch_Get.SQL
* 功能：     存储过程
* 描述：     ST库存[调拨单]-获取上游可参照单据信息
* 作者：     马永龙
* 创建时间： 2018-03-22 10:07:21
* 文件版本： V1.0.5

===============================版本履历===============================
* Ver 		变更日期 				负责人 	变更内容
* V1.0.0	2018-03-22 10:07:21		Myl		Create
* V1.0.1	2018-03-26				Myl		添加调拨申请单参照类型
* V1.0.2	2018-05-02				Myl		参照调拨申请单时，带'_1'的列名统一修改
* V1.0.3	2018-05-03				Myl		参照调拨申请单和委外订单时，添加制单人cMaker筛选条件
* V1.0.4	2018-05-15				Myl		修改所有参照单据中的日期格式为'yyyy-MM-dd'格式（CONVERT(varchar(100), ddate, 23)）
* V1.0.5	2018-07-13				Myl		表体添加统一bodyautoid字段（表体唯一ID的副本字段，前台用）
* V1.0.6	2018-12-21				Leo		生产订单，调拨申请单表头仓库增加属性《是否货位》
======================================================================
//--------------------------------------------------------------------*/

--EXEC proc_ts_ReferVouch_TransVouch_Get '0','DETAIL','ShowClosed:1,ccode:0000000001'
--EXEC proc_ts_ReferVouch_TransVouch_Get '0','DETAIL',''
--EXEC proc_ts_ReferVouch_TransVouch_Get '1','DETAIL','cmaker:demo'
--EXEC proc_ts_ReferVouch_TransVouch_Get '2','DETAIL','cmaker:demo'

CREATE PROC [dbo].[proc_ts_ReferVouch_TransVouch_Get]
    (
      @OperType CHAR(1) ,
      --获取类型（'LIST'获取上游参照单据列表;'DETAIL'获取上游参照单据详情（包含表头表体））
      --默认获取上游参照单据列表
      @GetType VARCHAR(10) = N'LIST' ,
      --传入的参数列表字符串
      --默认传空值
      @ParamsList NVARCHAR(2000) = N''
    )
AS
    BEGIN

		--制单人
        DECLARE @cMaker NVARCHAR(30);
        SET @cMaker = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                             N'cMaker',
                                                             DEFAULT, DEFAULT);
                                                              
		--是否参照生产订单（红字）/委外订单（红字）bRed参数
        DECLARE @bRed VARCHAR(1);
		SET @bRed= N''

        --SET @bRed = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
        --                                                   N'bRed', DEFAULT,
        --                                                   DEFAULT);
        IF ( @bRed = N'' )
            BEGIN
                SET @bRed = N'0';
            END;

		--生产部门编码（OR 委外订单部门编码 OR 领料申请单部门编码）
        DECLARE @DeptCode NVARCHAR(12);
        SET @DeptCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'DeptCode',
                                                              DEFAULT, DEFAULT);
        --生产部门名称（OR 委外订单部门名称 OR 领料申请单部门名称）
        DECLARE @DeptName NVARCHAR(255);
        SET @DeptName = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'DeptName',
                                                              DEFAULT, DEFAULT);
                                                              
		--产品-存货编码
        DECLARE @ProInvCode NVARCHAR(60);
        SET @ProInvCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ProInvCode',
                                                              DEFAULT, DEFAULT);
        --产品-存货代码
        DECLARE @ProInvAddCode NVARCHAR(255);
        SET @ProInvAddCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ProInvAddCode',
                                                              DEFAULT, DEFAULT);
        --产品-存货名称
        DECLARE @ProInvName NVARCHAR(255);
        SET @ProInvName = '%'
            + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                     N'ProInvName', DEFAULT,
                                                     DEFAULT) + '%';
        --产品-存货规格
        DECLARE @ProInvStd NVARCHAR(255);
        SET @ProInvStd = '%'
            + dbo.func_ts_GetParamValueBySplitString(@ParamsList, N'ProInvStd',
                                                     DEFAULT, DEFAULT) + '%';
                    
        --执行完未关闭是否显示(1:显示/0:不显示;默认不显示)
        DECLARE @ShowClosed CHAR(1);
        SET @ShowClosed = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ShowClosed',
                                                              DEFAULT, DEFAULT);
        IF ( @ShowClosed = N'' )
            BEGIN
                SET @ShowClosed = N'0';
            END;
            
        --材料编码
        DECLARE @MaterialInvCode NVARCHAR(60);
        SET @MaterialInvCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MaterialInvCode',
                                                              DEFAULT, DEFAULT);
          
        --材料存货代码
        DECLARE @MaterialInvAddCode NVARCHAR(255);
        SET @MaterialInvAddCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MaterialInvAddCode',
                                                              DEFAULT, DEFAULT);                      
         --材料存货名称
        DECLARE @MaterialInvName NVARCHAR(255);
        SET @MaterialInvName = '%'
            + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                     N'MaterialInvName',
                                                     DEFAULT, DEFAULT) + '%';
        --材料存货规格
        DECLARE @MaterialInvStd NVARCHAR(255);
        SET @MaterialInvStd = '%'
            + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                     N'MaterialInvStd',
                                                     DEFAULT, DEFAULT) + '%';
       
		--材料需求日期
        DECLARE @MaterialDemandDate NVARCHAR(20);
        SET @MaterialDemandDate = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MaterialDemandDate',
                                                              DEFAULT, DEFAULT);
                                                               
        --材料仓库编码
        DECLARE @MaterialWhCode NVARCHAR(100);
        BEGIN
               
            SET @MaterialWhCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MaterialWhCode',
                                                              DEFAULT, DEFAULT);
            IF ( @MaterialWhCode <> N'' )
                BEGIN
                     
                    IF EXISTS ( SELECT  0
                                WHERE   NOT OBJECT_ID('tempdb..#STPDATempWhs') IS NULL )
                        DROP TABLE #STPDATempWhs;
                    
                    CREATE   TABLE #STPDATempWhs ( cWhCode NVARCHAR(10) );
                    INSERT  INTO #STPDATempWhs
                            EXEC proc_ts_SplitParamString @MaterialWhCode;
                END;
        END;
       
        --材料供应类型(倒冲/工序倒冲/领用)
        DECLARE @WIPType NVARCHAR(10);
        SET @WIPType = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'WIPType',
                                                              DEFAULT, DEFAULT);
        --IF ( @WIPType = N'' )
        --    BEGIN
        --        SET @WIPType = N'3';
        --    END;
       
        DECLARE @ParmList NVARCHAR(MAX);
        DECLARE @SqlCommand NVARCHAR(MAX) ;

	SET	@ParmList=  N'';
		SET	@SqlCommand=  N'';
	

        IF ( @OperType = N'0' )
        --ST调拨单-参照生产订单
            BEGIN
            --定义查询参数
            
				--生产订单单号
                DECLARE @MoCode NVARCHAR(30);
                SET @MoCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MoCode',
                                                              DEFAULT, DEFAULT);
				--生产订单行号
                DECLARE @MoSeq NVARCHAR(30);
                SET @MoSeq = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MoSeq',
                                                              DEFAULT, DEFAULT);
				--生产订单子表行号
                DECLARE @MoDids NVARCHAR(1000);
                
                BEGIN
                
                    SET @MoDids = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MoDids',
                                                              DEFAULT, DEFAULT);
                    IF ( @MoDids <> N'' )
                        BEGIN                             
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDATempMODIDs') IS NULL )
                                DROP TABLE #STPDATempMODIDs;
                    
                            CREATE   TABLE #STPDATempMODIDs ( MoDid INT );
                            INSERT  INTO #STPDATempMODIDs
                                    EXEC proc_ts_SplitParamString @MoDids;
                        END;
                                                              
                END;
                
            --产品-存货自定义项
            --SELECT cInvDefine2, * FROM dbo.Inventory
            --产品-存货自定义项1
            --DECLARE @ProInvDefine1 NVARCHAR(20)
            --产品-存货自定义项2
            --DECLARE @ProInvDefine2 NVARCHAR(20)
            --客户编码
                DECLARE @CusCode NVARCHAR(20);
                SET @CusCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'CusCode',
                                                              DEFAULT, DEFAULT);
				--客户名称
                DECLARE @CusName NVARCHAR(98);
                SET @CusName = '%'
                    + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                             N'CusName',
                                                             DEFAULT, DEFAULT)
                    + '%';
          
				--工单开工日期FROM
                DECLARE @StartDateFrom VARCHAR(10);
                SET @StartDateFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'StartDateFrom',
                                                              DEFAULT, DEFAULT);
				--工单开工日期TO
                DECLARE @StartDateTo VARCHAR(10);
                SET @StartDateTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'StartDateTo',
                                                              DEFAULT, DEFAULT);
				--工单完工日期FROM
                DECLARE @DueDateFrom VARCHAR(10);
                SET @DueDateFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'DueDateFrom',
                                                              DEFAULT, DEFAULT);
				--工单完工日期TO
                DECLARE @DueDateTo VARCHAR(10);
                SET @DueDateTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'DueDateTo',
                                                              DEFAULT, DEFAULT);
             --需求跟踪号
             --DECLARE @SoCode NVARCHAR(30)
             --SET @SoCode =dbo.func_ts_GetParamValueBySplitString(@ParamsList,N'SoCode',DEFAULT,DEFAULT)
             --需求跟踪行号
             --DECLARE @SoSeq NVARCHAR(20)
             --SET @SoSeq =dbo.func_ts_GetParamValueBySplitString(@ParamsList,N'SoSeq',DEFAULT,DEFAULT)
             --销售订单类别
             --DECLARE @OrderType NVARCHAR(20)
             --SET @OrderType =dbo.func_ts_GetParamValueBySplitString(@ParamsList,N'OrderType',DEFAULT,DEFAULT)
             --销售订单号
             --DECLARE @OrderCode NVARCHAR(30)
             --SET @OrderCode =dbo.func_ts_GetParamValueBySplitString(@ParamsList,N'OrderCode',DEFAULT,DEFAULT)
             --销售订单行号
             --DECLARE @OrderSeq NVARCHAR(20)
             --SET @OrderSeq =dbo.func_ts_GetParamValueBySplitString(@ParamsList,N'OrderSeq',DEFAULT,DEFAULT)
             --不良品处理单单号
             --DECLARE @cRejectCode NVARCHAR(30)
             --SET @cRejectCode =dbo.func_ts_GetParamValueBySplitString(@ParamsList,N'cRejectCode',DEFAULT,DEFAULT)
				--手册号
                DECLARE @cCiqbookCode NVARCHAR(30);
                SET @cCiqbookCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cCiqbookCode',
                                                              DEFAULT, DEFAULT);
				--生产批号
                DECLARE @MoLotCode NVARCHAR(60);
                SET @MoLotCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MoLotCode',
                                                              DEFAULT, DEFAULT);
				--服务单号
                DECLARE @cServiceCode NVARCHAR(30);
                SET @cServiceCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cServiceCode',
                                                              DEFAULT, DEFAULT);
				--材料领料部门编码
                DECLARE @MaterialDeptCode NVARCHAR(12);
                SET @MaterialDeptCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MaterialDeptCode',
                                                              DEFAULT, DEFAULT);
				--材料批号
                DECLARE @MaterialLotNo NVARCHAR(255);
                SET @MaterialLotNo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MaterialLotNo',
                                                              DEFAULT, DEFAULT);
				--工厂编码
                DECLARE @cFactoryCode NVARCHAR(50);
                SET @cFactoryCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cFactoryCode',
                                                              DEFAULT, DEFAULT);
                SET NOCOUNT ON;
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDARefIDs') IS NULL )
                    DROP TABLE #STPDARefIDs;
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDARefID') IS NULL )
                    DROP TABLE #STPDARefID;
                    
                SELECT  IDENTITY( INT ) AS tmpId ,
                        CONVERT(INT, 0) AS M_ID ,
                        CONVERT(INT, 0) AS S_ID ,
                        CONVERT(MONEY, Ufts) AS oriufts ,
                        CONVERT(INT, 0) AS m_ST_moid
                INTO    #STPDARefIDs
                FROM    v_st_mom_orderdetail
                WHERE   1 = 0; 
                CREATE CLUSTERED INDEX ix_STPDARefIDs_tmpid_813 ON #STPDARefIDs( M_ID,S_ID,tmpId ); 
 
                SET @SqlCommand = ' INSERT INTO #STPDARefIDs
        ( M_ID ,
          S_ID ,
          oriufts ,
          m_ST_moid
        )
        SELECT  v_st_mom_orderdetail.MoDId ,
                AllocateId ,
                CONVERT(MONEY, v_st_mom_orderdetail.Ufts) ,
                v_st_mom_orderdetail.MoId
        FROM    v_st_mom_orderdetail 
                LEFT JOIN ( SELECT  MoDId AS m_modid ,
                                    AllocateId 
                            FROM    v_st_moallocate
                            WHERE	ISNULL(ByproductFlag, 0) = 0
									AND ISNULL(WIPType, 0) <> 5';
                IF ( @WIPType <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND ISNULL(WIPType, 0)= @WIPType ';
                IF ( @MaterialDeptCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND v_st_moallocate.Dept =@MaterialDeptCode ';
                IF ( @MaterialInvCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND v_st_moallocate.InvCode =@MaterialInvCode ';
                IF ( @MaterialInvAddCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND v_st_moallocate.InvAddCode =@MaterialInvAddCode ';
                IF ( @MaterialInvName <> N''
                     AND @MaterialInvName <> N'%%'
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND v_st_moallocate.InvName LIKE @MaterialInvName ';
                IF ( @MaterialInvStd <> N''
                     AND @MaterialInvStd <> N'%%'
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND v_st_moallocate.InvStd LIKE @MaterialInvStd ';
                IF ( @MaterialLotNo <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND v_st_moallocate.LotNo = @MaterialLotNo ';
                IF ( @ShowClosed = N'0' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND ( ISNULL(Qty, 0) - ISNULL(ftransqty, 0)) > 0 ';
                IF ( @MaterialDemandDate <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND v_st_moallocate.Demdate = @MaterialDemandDate ';
                IF ( @MaterialWhCode <> N'' )
				--现在支持多个仓库（前台传参时仓库编码中间用','隔开）
                    SET @SqlCommand = @SqlCommand
                        --+ ' AND v_st_moallocate.WhCode = @MaterialWhCode ';
                        + ' AND v_st_moallocate.WhCode IN (SELECT DISTINCT cWhCode FROM #STPDATempWhs) ';
                IF ( @cFactoryCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND v_st_moallocate.cfactorycode = @cFactoryCode ';
                IF ( @MoDids <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_moallocate.MoDId IN  (SELECT DISTINCT MoDid FROM #STPDATempMODIDs)) ';
 
                SET @SqlCommand = @SqlCommand
                    + ' ) v_mom_moallocate ON v_st_mom_orderdetail.MoDId = v_mom_moallocate.m_modid
        WHERE   v_st_mom_orderdetail.ByProductFlag = 0
                AND ISNULL(v_st_mom_orderdetail.Status, 0) = 3
                AND ISNULL(v_mom_moallocate.m_modid, 0) <> 0 ';
                SET @SqlCommand = @SqlCommand + ' AND ( 1=1 ';
 
                IF ( @MoCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.MoCode=@MoCode) ';
                IF ( @MoSeq <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.MoSeq=@MoSeq) ';
                IF ( @cMaker <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.maker=@cMaker) ';
                IF ( @ProInvCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.InvCode=@ProInvCode) ';
                IF ( @ProInvAddCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.InvAddCode=@ProInvAddCode) ';
                IF ( @ProInvName <> N''
                     AND @ProInvName <> N'%%'
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.InvName LIKE @ProInvName) ';
                IF ( @ProInvStd <> N''
                     AND @ProInvStd <> N'%%'
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.InvStd LIKE @ProInvStd) ';
                IF ( @CusCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.Cuscode = @CusCode) ';
                IF ( @CusName <> N''
                     AND @CusName <> N'%%'
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.cusname LIKE @CusName) ';
                IF ( @DeptCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.MDept = @DeptCode) ';
                IF ( @DeptName <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.DeptName = @DeptName) ';
                IF ( @StartDateFrom <> N''
                     AND @StartDateTo <> N''
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (( v_st_mom_orderdetail.StartDate >= @StartDateFrom )
                            AND ( v_st_mom_orderdetail.StartDate <= @StartDateTo )) ';
                IF ( @DueDateFrom <> N''
                     AND @DueDateTo <> N''
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (( v_st_mom_orderdetail.DueDate >= @DueDateFrom )
                            AND ( v_st_mom_orderdetail.DueDate <= @DueDateTo )) ';
                IF ( @MoLotCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.MoLotCode = @MoLotCode) ';
                IF ( @cCiqbookCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.cciqbookcode = @cCiqbookCode) '; 
                IF ( @cServiceCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.cservicecode = @cServiceCode) ';
 
                IF ( @MoDids <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.MoDId IN (SELECT DISTINCT MoDid FROM #STPDATempMODIDs)) ';
                SET @SqlCommand = @SqlCommand + ' ) ';
                SET @ParmList = '@WIPType NVARCHAR(10),
				   @MaterialDeptCode        NVARCHAR(12),
				   @MaterialInvCode			NVARCHAR(60),
				   @MaterialInvAddCode      NVARCHAR(255), 
				   @MaterialInvName			NVARCHAR(255),
				   @MaterialInvStd			NVARCHAR(255),
				   @MaterialLotNo			NVARCHAR(255),
				   @MaterialDemandDate      NVARCHAR(20),
				   @cFactoryCode			NVARCHAR(50),
				   @MoCode					NVARCHAR(30),
				   @MoSeq					NVARCHAR(30),
				   @cMaker					NVARCHAR(30),
				   @ProInvCode				NVARCHAR(60),
				   @ProInvAddCode			NVARCHAR(255),
				   @ProInvName				NVARCHAR(255),
				   @ProInvStd				NVARCHAR(255),
				   @CusCode					NVARCHAR(20),
				   @CusName					NVARCHAR(98),
				   @DeptCode				NVARCHAR(12),
				   @DeptName				NVARCHAR(255),
				   @StartDateFrom			VARCHAR(10),
				   @StartDateTo				VARCHAR(10),
				   @DueDateFrom				VARCHAR(10),
				   @DueDateTo				VARCHAR(10),
				   @MoLotCode				NVARCHAR(60),
				   @cCiqbookCode			NVARCHAR(30),
				   @cServiceCode			NVARCHAR(30)';
   
                EXEC sp_executesql @SqlCommand, @ParmList, @WIPType = @WIPType,
                    @MaterialDeptCode = @MaterialDeptCode,
                    @MaterialInvCode = @MaterialInvCode,
                    @MaterialInvAddCode = @MaterialInvAddCode,
                    @MaterialInvName = @MaterialInvName,
                    @MaterialInvStd = @MaterialInvStd,
                    @MaterialLotNo = @MaterialLotNo,
                    @MaterialDemandDate = @MaterialDemandDate,
                    --@MaterialWhCode = @MaterialWhCode,
                    @cFactoryCode = @cFactoryCode, @MoCode = @MoCode,
                    @MoSeq = @MoSeq, @cMaker = @cMaker,
                    @ProInvCode = @ProInvCode, @ProInvAddCode = @ProInvAddCode,
                    @ProInvName = @ProInvName, @ProInvStd = @ProInvStd,
                    @CusCode = @CusCode, @CusName = @CusName,
                    @DeptCode = @DeptCode, @DeptName = @DeptName,
                    @StartDateFrom = @StartDateFrom,
                    @StartDateTo = @StartDateTo, @DueDateFrom = @DueDateFrom,
                    @DueDateTo = @DueDateTo, @MoLotCode = @MoLotCode,
                    @cCiqbookCode = @cCiqbookCode,
                    @cServiceCode = @cServiceCode;	
 
                SELECT  IDENTITY( INT ) AS tmpId ,
                        M_ID ,
                        MAX(oriufts) AS oriufts ,
                        MAX(m_ST_moid) AS m_ST_moid
                INTO    #STPDARefID
                FROM    #STPDARefIDs
                GROUP BY M_ID;
 
                CREATE CLUSTERED INDEX ix_STPDARefID_tmpid_813 ON #STPDARefID( tmpId,M_ID ); 
                SET NOCOUNT OFF;
                --查询列表（表头）
                SELECT DISTINCT
                        '' AS selcol ,
                        SoType AS sotype ,
                        MDept cdepcode ,
                        MoCode AS mocode ,
                        MoSeq AS moseq ,
                        DeptName cdepname ,
                        InvCode AS cinvcode ,
                        InvAddCode AS cinvaddcode ,
                        SoCode AS socode ,
                        InvName AS cinvname ,
                        SoSeq AS soseq ,
                        InvStd AS cinvstd ,
                        Define1 cdefine1 ,
                        Define2 cdefine2 ,
                        Define3 cdefine3 ,
                        Define4 cdefine4 ,
                        Define5 cdefine5 ,
                        Define6 cdefine6 ,
                        Define7 cdefine7 ,
                        Define8 cdefine8 ,
                        Define9 cdefine9 ,
                        Define10 cdefine10 ,
                        Define11 cdefine11 ,
                        Define12 cdefine12 ,
                        Define13 cdefine13 ,
                        Define14 cdefine14 ,
                        Define15 cdefine15 ,
                        Define16 cdefine16 ,
                        InvDefine1 AS hcinvdefine1 ,
                        InvDefine2 AS hcinvdefine2 ,
                        InvDefine3 AS hcinvdefine3 ,
                        InvDefine4 AS hcinvdefine4 ,
                        InvDefine5 AS hcinvdefine5 ,
                        InvDefine6 AS hcinvdefine6 ,
                        InvDefine7 AS hcinvdefine7 ,
                        InvDefine8 AS hcinvdefine8 ,
                        InvDefine9 AS hcinvdefine9 ,
                        InvDefine10 AS hcinvdefine10 ,
                        InvDefine11 AS hcinvdefine11 ,
                        InvDefine12 AS hcinvdefine12 ,
                        InvDefine13 AS hcinvdefine13 ,
                        InvDefine14 AS hcinvdefine14 ,
                        InvDefine15 AS hcinvdefine15 ,
                        InvDefine16 AS hcinvdefine16 ,
                        UnitId AS unitid ,
                        UnitCode AS unitcode ,
                        AuxUnitId AS auxunitid ,
                        AuxUnitCode AS auxunitcode ,
                        Free1 AS cfree1 ,
                        Free2 AS cfree2 ,
                        Free3 AS cfree3 ,
                        Free4 AS cfree4 ,
                        Free5 AS cfree5 ,
                        Free6 AS cfree6 ,
                        Free7 AS cfree7 ,
                        Free8 AS cfree8 ,
                        Free9 AS cfree9 ,
                        Free10 AS cfree10 ,
                        CONVERT(VARCHAR(100), StartDate, 23) AS startdate ,
                        CONVERT(VARCHAR(100), DueDate, 23) AS duedate ,
                        AuxQty AS auxqty ,
                        impqty ,
                        QualifiedInQty AS qualifiedinqty ,
                        ( (ISNULL(impqty, 0) - ISNULL(QualifiedInQty, 0)) ) AS iqty ,
                        maker AS cmaker ,
                        SoDId AS sodid ,
                        MoDId AS modid ,
                        Ufts AS ufts ,
                        MoLotCode AS molotcode ,
                        OrderCode AS ordercode ,
                        OrderDId AS orderdid ,
                        OrderSeq AS orderseq ,
                        OrderType AS ordertype ,
                        cusname ,
                        Cuscode AS cuscode ,
                        CusabbName AS cusabbname ,
                        WhCode as  cwhcode ,
                        WhName as cwhname ,
                        Warehouse.bWhPos as bwhpos,
                        cservicecode ,
                        Remark AS remark ,
                        motypecode ,
                        motypedesc ,
                        csysbarcode ,
                        cbSysBarCode AS cbsysbarcode ,
                        MoId AS moid,
						1 as csource,
						'生产订单' as cordertype
                FROM    v_st_mom_orderdetail WITH ( NOLOCK )
					Left Join Warehouse On v_st_mom_orderdetail.WhCode = Warehouse.cWhCode
                WHERE   orimodid IN ( 
						--生产订单子表ID
                        SELECT DISTINCT
                                M_ID
                        FROM    #STPDARefID --where tmpId > 0 and tmpId < 21 
						--order by m_ST_moid,m_id 
									)
                        AND moid IN (
						--生产订单主表ID
                        SELECT DISTINCT
                                m_ST_moid
                        FROM    #STPDARefID --where tmpId > 0 and tmpId < 21 
						--order by m_ST_moid,m_id
									)
                        AND v_st_mom_orderdetail.ByProductFlag = 0;
                --查询表体
                IF ( @GetType = N'DETAIL' )
                    BEGIN
                        DECLARE @SqlCommandBody NVARCHAR(MAX);
						--v_st_moallocate.WcCode 工作中心编码
                        SET @SqlCommandBody = 'SELECT allocateid as bodyautoid, '''' AS selcol ,0 AS iscanedquantity,0 AS iscanednum,
        vsm.WcCode wccode, vsm.WcName wcname, vsm.WhCode cwhcode, vsm.WhName cwhname,Dept cdepcode, vsm.DeptName cdepname,
         vsm.InvCode cinvcode, vsm.InvAddCode cinvaddcode, vsm.InvName cinvname, vsm.InvStd cinvstd, vsm.InvDefine1 cinvdefine1,
         vsm.InvDefine2 cinvdefine2, vsm.InvDefine3 cinvdefine3, vsm.InvDefine4 cinvdefine4, vsm.InvDefine5 cinvdefine5, vsm.InvDefine6 cinvdefine6,
         vsm.InvDefine7 cinvdefine7, vsm.InvDefine8 cinvdefine8, vsm.InvDefine9 cinvdefine9, vsm.InvDefine10 cinvdefine10,
         vsm.InvDefine11 cinvdefine11, vsm.InvDefine12 cinvdefine12, vsm.InvDefine13 cinvdefine13, vsm.InvDefine14 cinvdefine14,
         vsm.InvDefine15 cinvdefine15, vsm.InvDefine16 cinvdefine16, vsm.UnitCode unitcode,UnitName unitname,BomQty bomqty,
         vsm.Free1 cfree1, vsm.Free2 cfree2, vsm.Free3 cfree3, vsm.Free4 cfree4, vsm.Free5 cfree5, vsm.Free6 cfree6, vsm.Free7 cfree7, vsm.Free8 cfree8, vsm.Free9 cfree9,
         vsm.Free10 cfree10,LotNo clotno,Demdate ddemanddate, vsm.Qty qty,((ISNULL(IssQty, 0) - ISNULL(ReplenishQty, 0))) AS issqty ,
        ((ISNULL( vsm.Qty, 0) - ISNULL(IssQty, 0) + ISNULL(ReplenishQty, 0))) AS isnqty,
         vsm.OPSeq opseq,OpDecs opdecs, vsm.MoDId modid,AllocateId allocateid, vsm.Ufts ufts,WIPType wiptype,
        cassunit cassunit,cinva_unit,iinvexchrate,itnum,isnum,iunnum,ReplenishQty replenishqty,
         vsm.Define22 cdefine22, vsm.Define23 cdefine23, vsm.Define24 cdefine24, vsm.Define25 cdefine25, vsm.Define26 cdefine26,
         vsm.Define27 cdefine27, vsm.Define28 cdefine28, vsm.Define29 cdefine29, vsm.Define30 cdefine30, vsm.Define31 cdefine31,
         vsm.Define32 cdefine32, vsm.Define33 cdefine33, vsm.Define34 cdefine34, vsm.Define35 cdefine35, vsm.Define36 cdefine36,
         vsm.Define37 cdefine37,(ftransqty) AS ftransqty,(ftransnum) AS ftransnum,
        (funtransqty) AS funtransqty,(funtransnum) AS funtransnum,funtransqty AS fcurtransqty,funtransnum AS fcurtransnum,
        (CONVERT(DECIMAL(38, 6),NULL)) AS fstockanum,(CONVERT(DECIMAL(38, 6),NULL)) AS fstockaqty,
        (CONVERT(DECIMAL(38, 6),NULL)) AS fstocknum,(CONVERT(DECIMAL(38, 6),NULL)) AS fstockqty,
        istsodid,istsotype , vsm.SoCode socode, vsm.SoDId sodid, vsm.SoSeq soseq, vsm.SoType sotype, vsm.cbmemo,
        Inv.bInvBatch AS binvbatch,Inv.bInvQuality AS binvquality,Inv.bSerial AS bserial,Inv.bBarCode AS bbarcode,
		vsmo.InvCode,vsmo.InvName,vsmo.MoCode as cmocode,vsmo.MoCode as csrccode,vsmo.MoSeq as imoseq,allocateid as imoids,csubsysbarcode
FROM    v_st_moallocate vsm WITH ( NOLOCK )
left join v_st_mom_orderdetail vsmo on vsmo.MoDId=vsm.MoDId
        INNER JOIN #STPDARefIDs b ON vsm.MoDId = b.m_id AND vsm.AllocateId = b.s_id
        INNER JOIN Inventory Inv ON vsm.InvCode = Inv.cInvCode 
WHERE 1=1  AND ISNULL(vsm.ByproductFlag, 0) = 0
        AND ISNULL(vsm.WIPType, 0) <> 5 ';
                
                        IF ( @ShowClosed = N'0' )
                            BEGIN
                                SET @SqlCommandBody = @SqlCommandBody
                                    + N' AND ( ISNULL(vsm.Qty, 0) - ISNULL(vsm.FTRANSQTY,0)) > 0 ';
                            END;
                        
                        EXEC sp_executesql @SqlCommandBody;
                    END;
                --删除临时表
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDARefIDs') IS NULL )
                    DROP TABLE #STPDARefIDs;
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDARefID') IS NULL )
                    DROP TABLE #STPDARefID;
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempMODIDs') IS NULL )
                    DROP TABLE #STPDATempMODIDs;
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempWhs') IS NULL )
                    DROP TABLE #STPDATempWhs;
            END;
        ELSE
            IF ( @OperType = N'1' )--根据委外订单生成调拨单
                BEGIN
                --委外订单子表ID
                    DECLARE @MoDetailsIds NVARCHAR(1000);
                    BEGIN
                
                        SET @MoDetailsIds = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MoDetailsIds',
                                                              DEFAULT, DEFAULT);
                        IF ( @MoDetailsIds <> N'' )
                            BEGIN                             
                                IF EXISTS ( SELECT  0
                                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempOMDIDs') IS NULL )
                                    DROP TABLE #STPDATempOMDIDs;
                    
                                CREATE   TABLE #STPDATempOMDIDs ( MoDetailsId
                                                              INT );
                                INSERT  INTO #STPDATempOMDIDs
                                        EXEC proc_ts_SplitParamString @MoDetailsIds;
                            END;
                                                              
                    END;

					--委外订单单号
                    DECLARE @cCode NVARCHAR(30);
                    SET @cCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cCode',
                                                              DEFAULT, DEFAULT);
					--委外订单日期FROM
                    DECLARE @dDateFrom VARCHAR(10);
                    SET @dDateFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dDateFrom',
                                                              DEFAULT, DEFAULT);
					--委外订单日期TO
                    DECLARE @dDateTo VARCHAR(10);
                    SET @dDateTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dDateTo',
                                                              DEFAULT, DEFAULT);
    --            --委外订单部门编码
    --                DECLARE @DeptCode NVARCHAR(12);
    --                SET @DeptCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
    --                                                          N'DeptCode',
    --                                                          DEFAULT, DEFAULT);
				----委外订单部门名称
    --                DECLARE @DeptName NVARCHAR(255);
    --                SET @DeptName = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
    --                                                          N'DeptName',
    --                                                          DEFAULT, DEFAULT);
                    
					--委外商编码
                    DECLARE @cVenCode NVARCHAR(20);
                    SET @cVenCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cVenCode',
                                                              DEFAULT, DEFAULT);  
					--委外商名称
                    DECLARE @cVenName NVARCHAR(98);
                    SET @cVenName = '%'
                        + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cVenName',
                                                              DEFAULT, DEFAULT)
                        + '%';   
                
					--业务员编码
                    DECLARE @cPersonCode NVARCHAR(20);
                    SET @cPersonCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cPersonCode',
                                                              DEFAULT, DEFAULT);  
					--业务员名称
                    DECLARE @cPersonName NVARCHAR(40);
                    SET @cPersonName = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cPersonName',
                                                              DEFAULT, DEFAULT);   
                
                
    --				--产品-存货编码
    --                DECLARE @ProInvCode NVARCHAR(60);
    --                SET @ProInvCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
    --                                                          N'ProInvCode',
    --                                                          DEFAULT, DEFAULT);
				----产品-存货代码
    --                DECLARE @ProInvAddCode NVARCHAR(255);
    --                SET @ProInvAddCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
    --                                                          N'ProInvAddCode',
    --                                                          DEFAULT, DEFAULT);
				----产品-存货名称
    --                DECLARE @ProInvName NVARCHAR(255);
    --                SET @ProInvName = '%'
    --                    + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
    --                                                          N'ProInvName',
    --                                                          DEFAULT, DEFAULT)
    --                    + '%';
				----产品-存货规格
    --                DECLARE @ProInvStd NVARCHAR(255);
    --                SET @ProInvStd = '%'
    --                    + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
    --                                                          N'ProInvStd',
    --                                                          DEFAULT, DEFAULT)
    --                    + '%';
                --产品-存货自定义项1
                    DECLARE @ProInvDefine1 NVARCHAR(20);
                    SET @ProInvDefine1 = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ProInvDefine1',
                                                              DEFAULT, DEFAULT);
                --产品-自由项1
                    DECLARE @cFree1 NVARCHAR(20);
                    SET @cFree1 = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cFree1',
                                                              DEFAULT, DEFAULT);
                
                --计划下达日期FROM
                    DECLARE @dStartDate VARCHAR(10);
                    SET @dStartDate = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dStartDate',
                                                              DEFAULT, DEFAULT);
                --计划到货日期FROM
                    DECLARE @dArriveDate VARCHAR(10);
                    SET @dArriveDate = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dArriveDate',
                                                              DEFAULT, DEFAULT);

                --委外订单类型('0':标准;'1':非标准)
                    DECLARE @iOrderType VARCHAR(10);
                    SET @iOrderType = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'iOrderType',
                                                              DEFAULT, DEFAULT);
            ----材料需求日期
            --        DECLARE @MaterialDemandDate NVARCHAR(20);
            --        SET @MaterialDemandDate = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
            --                                                  N'MaterialDemandDate',
            --                                                  DEFAULT, DEFAULT);
 
                    SET NOCOUNT ON;
                    IF EXISTS ( SELECT  0
                                WHERE   NOT OBJECT_ID('tempdb..#STPDARefOMIDs') IS NULL )
                        DROP TABLE #STPDARefOMIDs;
                --IF EXISTS ( SELECT  0
                --            WHERE   NOT OBJECT_ID('tempdb..#STPDARefID') IS NULL )
                --    DROP TABLE #STPDARefID;
                    SELECT  IDENTITY( INT ) AS tmpId ,
                            CONVERT(INT, 0) AS M_ID ,--委外订单子表ID（委外订单表体行母件ID）
                            CONVERT(MONEY, corufts) AS oriufts ,
                            CONVERT(INT, 0) AS S_ID --委外用料单子表ID 
                    INTO    #STPDARefOMIDs
                    FROM    dbo.om_mobody
                    WHERE   1 = 0; 
                    CREATE CLUSTERED INDEX ix_STPDARefIDs_tmpid_813 ON #STPDARefOMIDs( M_ID,tmpId ); 

                    --DECLARE @ParmList NVARCHAR(MAX) = N'';
                    --DECLARE @SqlCommand NVARCHAR(MAX) = N'';

                    SET @SqlCommand = 'INSERT INTO #STPDARefOMIDs
								( M_ID ,
								  oriufts,
								  S_ID
								)
								SELECT DISTINCT
										modetailsid,om_mobody.corufts ,momaterialsid
								FROM    om_mohead
										INNER JOIN om_mobody ON om_mohead.moid = om_mobody.moid
										INNER JOIN ( SELECT DISTINCT
															modetailsid AS did,momaterialsid
													 FROM   om_momaterialsbody
													 WHERE  1 = 1 
															AND (ISNULL(bcomsumeom,0) = 1) 
															AND ISNULL(iwiptype,0) <> 5
															AND (ISNULL(om_momaterialsbody.iproducttype,0) = 0) '; 
                    
                    IF ( @WIPType <> N'' )
                        BEGIN
                       
                            SET @SqlCommand = @SqlCommand
                                + ' AND (ISNULL(WIPType, 0)= @WIPType) ';
                        END; 
                       
                    IF ( @ShowClosed = N'0' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (ISNULL(iquantity,0)- ISNULL(ftransqty,0)) > 0 ';
                    IF ( @MaterialInvCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_momaterialsbody.cinvcode=@MaterialInvCode) ';
                    IF ( @MaterialInvName <> N''
                         AND @MaterialInvName <> N'%%'
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_momaterialsbody.cinvname LIKE @MaterialInvName) ';
                    IF ( @MaterialInvAddCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_momaterialsbody.cinvaddcode =@MaterialInvAddCode) ';
                    IF ( @MaterialInvStd <> N''
                         AND @MaterialInvStd <> N'%%'
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_momaterialsbody.cinvstd LIKE @MaterialInvStd) ';
                    IF ( @MaterialWhCode <> N'' )
				--现在支持多个仓库（前台传参时仓库编码中间用','隔开）
                        SET @SqlCommand = @SqlCommand
                            + ' AND om_momaterialsbody.cWhCode IN (SELECT DISTINCT cWhCode FROM #STPDATempWhs) ';
                    IF ( @MaterialDemandDate <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND om_momaterialsbody.drequireddate = @MaterialDemandDate ';
                    IF ( @ShowClosed = N'0' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND ( ISNULL(iquantity, 0) - ISNULL(isendqty, 0)
                                  + ISNULL(icomplementqty, 0) ) > 0 ';
                                  
					--参照委外订单（红字）生成材料退库单                  
                    --IF ( @bRed = N'1' )
                    --    SET @SqlCommand = @SqlCommand
                    --        + N' AND ISNULL(isendqty, 0) - ISNULL(icomplementqty, 0) > 0 ';
                    --ELSE
                    --    SET @SqlCommand = @SqlCommand
                    --        + N' AND (ISNULL(csendtype, ''0'') = ''0'') ';
                    
                    IF ( @MoDetailsIds <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_momaterialsbody.modetailsid IN  (SELECT DISTINCT MoDetailsId FROM #STPDATempOMDIDs) ) ';

                    SET @SqlCommand = @SqlCommand
                        + N' ) om_momaterialsbody ON om_mobody.modetailsid = om_momaterialsbody.did
        WHERE   ( CASE WHEN ISNULL(cchanger, N'''') <> N''''
                       THEN ISNULL(cchangeverifier, N'''')
                       ELSE ISNULL(cverifier, N'''')
                  END ) <> N''''
                AND ISNULL(cbcloser, N'''') = N'''' 
                 AND ( 1 = 1 ';
                
                    IF ( @cCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mohead.ccode=@cCode) ';
                    IF ( @cMaker <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mohead.cmaker=@cMaker) ';
                    IF ( @dDateFrom <> N''
                         AND @dDateTo <> N''
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND ((om_mohead.ddate >= @dDateFrom )
                            AND ( om_mohead.ddate <= @dDateTo )) ';
                    IF ( @DeptCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mohead.cdepcode=@DeptCode) ';
                    IF ( @DeptName <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mohead.cdepname=@DeptName) ';
                    IF ( @cVenCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mohead.cvencode=@cVenCode) ';
                    IF ( @cVenName <> N''
                         AND @cVenName <> N'%%'
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mohead.cvenname LIKE @cVenName) '; 
                    IF ( @cPersonCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mohead.cpersoncode = @cPersonCode) '; 
                    IF ( @cPersonName <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mohead.cpersonname = @cPersonName) '; 
                    IF ( @ProInvCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mobody.cinvcode = @ProInvCode) '; 
                    IF ( @ProInvAddCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mobody.cinvaddcode = @ProInvAddCode) '; 
                    IF ( @ProInvName <> N''
                         AND @ProInvName <> N'%%'
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mobody.cinvname LIKE @ProInvName) ';
                    IF ( @ProInvStd <> N''
                         AND @ProInvStd <> N'%%'
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mobody.cinvstd LIKE @ProInvStd) ';
                    IF ( @ProInvDefine1 <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mobody.cinvdefine1 = @ProInvDefine1) ';
                    IF ( @cFree1 <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mobody.cfree1 = @cFree1) ';
                    IF ( @dStartDate <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mobody.dstartdate = @dStartDate) ';
                    IF ( @dArriveDate <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mobody.darrivedate = @dArriveDate) ';
                    IF ( @iOrderType <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mohead.iordertype = @iOrderType) ';
                            
                    SET @SqlCommand = @SqlCommand + N' );';
                    SET @ParmList = '@WIPType NVARCHAR(10),
                   @cMaker					NVARCHAR(30),
 				   @MaterialInvCode			NVARCHAR(60),
				   @MaterialInvAddCode      NVARCHAR(255), 
				   @MaterialInvName			NVARCHAR(255),
				   @MaterialInvStd			NVARCHAR(255),
				   @MaterialDemandDate      NVARCHAR(20),
				   @cCode					NVARCHAR(30),
				   @dDateFrom				VARCHAR(10),
				   @dDateTo					VARCHAR(10),
				   @DeptCode				NVARCHAR(12),
				   @DeptName				NVARCHAR(255),
				   @cVenCode				VARCHAR(20),
				   @cVenName				VARCHAR(98),
				   @cPersonCode				NVARCHAR(20),
				   @cPersonName				NVARCHAR(40),
				   @ProInvCode				NVARCHAR(60),
				   @ProInvAddCode			NVARCHAR(255),
				   @ProInvName				NVARCHAR(255),
				   @ProInvStd				NVARCHAR(255),
				   @ProInvDefine1			NVARCHAR(20),
				   @cFree1					NVARCHAR(20),
				   @dStartDate				NVARCHAR(10),
				   @dArriveDate				NVARCHAR(10),
				   @iOrderType				VARCHAR(10)
				 ';
                    EXEC sp_executesql @SqlCommand, @ParmList,
                        @WIPType = @WIPType, @cMaker = @cMaker,
                        @MaterialInvCode = @MaterialInvCode,
                        @MaterialInvAddCode = @MaterialInvAddCode,
                        @MaterialInvName = @MaterialInvName,
                        @MaterialInvStd = @MaterialInvStd,
                        @MaterialDemandDate = @MaterialDemandDate,
                    --@MaterialWhCode = @MaterialWhCode,
                        @cCode = @cCode, @dDateFrom = @dDateFrom,
                        @dDateTo = @dDateTo, @DeptCode = @DeptCode,
                        @DeptName = @DeptName, @cVenCode = @cVenCode,
                        @cVenName = @cVenName, @cPersonCode = @cPersonCode,
                        @cPersonName = @cPersonName, @ProInvCode = @ProInvCode,
                        @ProInvAddCode = @ProInvAddCode,
                        @ProInvName = @ProInvName, @ProInvStd = @ProInvStd,
                        @ProInvDefine1 = @ProInvDefine1, @cFree1 = @cFree1,
                        @dStartDate = @dStartDate, @dArriveDate = @dArriveDate,
                        @iOrderType = @iOrderType;
                        
                    SET NOCOUNT OFF;
					--查询委外订单列表（表头）  
                    SELECT  '' AS selcol ,
                            irowno ,
                            csocode ,
                            sotype ,
                            ccode ,
                            CONVERT(VARCHAR(100), ddate, 23) AS ddate ,
                            cdepcode ,
                            cdepname ,
                            cvencode ,
                            cvenabbname ,
                            cpersoncode ,
                            cpersonname ,
                            cmaker ,
                            cverifier ,
                            cinvcode ,
                            cinvaddcode ,
                            cinvname ,
                            cinvstd ,
                            cinvdefine1 AS hcinvdefine1 ,
                            cinvdefine2 AS hcinvdefine2 ,
                            cinvdefine3 AS hcinvdefine3 ,
                            cinvdefine4 AS hcinvdefine4 ,
                            cinvdefine5 AS hcinvdefine5 ,
                            cinvdefine6 AS hcinvdefine6 ,
                            cinvdefine7 AS hcinvdefine7 ,
                            cinvdefine8 AS hcinvdefine8 ,
                            cinvdefine9 AS hcinvdefine9 ,
                            cinvdefine10 AS hcinvdefine10 ,
                            cinvdefine11 AS hcinvdefine11 ,
                            cinvdefine12 AS hcinvdefine12 ,
                            cinvdefine13 AS hcinvdefine13 ,
                            cinvdefine14 AS hcinvdefine14 ,
                            cinvdefine15 AS hcinvdefine15 ,
                            cinvdefine16 AS hcinvdefine16 ,
                            ccomunitcode ,
                            cinvm_unit ,
                            cunitid ,
                            cinva_unit ,
                            citem_class ,
                            citem_name ,
                            citemcode ,
                            citemname ,
                            CONVERT(VARCHAR(100), dstartdate, 23) AS dstartdate ,
                            CONVERT(VARCHAR(100), darrivedate, 23) AS darrivedate ,
                            cfree1 ,
                            cfree2 ,
                            cfree3 ,
                            cfree4 ,
                            cfree5 ,
                            cfree6 ,
                            cfree7 ,
                            cfree8 ,
                            cfree9 ,
                            cfree10 ,
                            iquantity ,
                            inum ,
                            cmemo ,
                            ( CASE WHEN ISNULL(iarrqty, 0) <> 0
                                   THEN ISNULL(iarrqty, 0)
                                   ELSE ISNULL(ireceivedqty, 0)
                              END ) AS ireceivedqty ,
                            ( (ISNULL(iquantity, 0)
                              - ( CASE WHEN ISNULL(iarrqty, 0) <> 0
                                       THEN ISNULL(iarrqty, 0)
                                       ELSE ISNULL(ireceivedqty, 0)
                                  END )) ) AS iqty ,
                            modetailsid ,
                            ufts ,
                            om_mohead.moid ,
                            iordertype
                    FROM    om_mohead WITH ( NOLOCK )
                            INNER JOIN om_mobody ON om_mohead.moid = om_mobody.moid
                            INNER JOIN ( SELECT DISTINCT
                                                M_ID AS did
                                         FROM   #STPDARefOMIDs
                                       ) om_momaterialsbody ON om_mobody.modetailsid = om_momaterialsbody.did
                    WHERE   ( CASE WHEN ISNULL(cchanger, N'') <> N''
                                   THEN ISNULL(cchangeverifier, N'')
                                   ELSE ISNULL(cverifier, N'')
                              END ) <> N''
                            AND ISNULL(cbcloser, N'') = N''
                            AND modetailsid IN ( SELECT DISTINCT
                                                        M_ID AS did
                                                 FROM   #STPDARefOMIDs )
                    ORDER BY ccode;        
                        
                 --查询表体
                    IF ( @GetType = N'DETAIL' )
                        BEGIN
                            SELECT  a.momaterialsid AS bodyautoid ,
                                    '' AS selcol ,
                                    a.* ,
                                    ( (ISNULL(isendqty, 0)
                                      - ISNULL(icomplementqty, 0)) ) AS isendqty ,
                                    ( (ISNULL(iquantity, 0) - ISNULL(isendqty,
                                                              0)
                                      + ISNULL(icomplementqty, 0)) ) AS iqty ,
                                    ( ftransqty ) AS ftransqty ,
                                    ( ftransnum ) AS ftransnum ,
                                    ( CONVERT(DECIMAL(38, 6), NULL) ) AS fstockanum ,
                                    ( CONVERT(DECIMAL(38, 6), NULL) ) AS fstockaqty ,
                                    ( CONVERT(DECIMAL(38, 6), NULL) ) AS fstocknum ,
                                    ( CONVERT(DECIMAL(38, 6), NULL) ) AS fstockqty ,
                                    b.bFree1 AS bfree1 ,
                                    b.bFree2 AS bfree2 ,
                                    b.bFree3 AS bfree3 ,
                                    b.bFree4 AS bfree4 ,
                                    b.bFree5 AS bfree5 ,
                                    b.bFree6 AS bfree6 ,
                                    b.bFree7 AS bfree7 ,
                                    b.bFree8 AS bfree8 ,
                                    b.bFree9 AS bfree9 ,
                                    b.bFree10 AS bfree10 ,
                                    b.bSerial AS bserial ,
                                    b.bBarCode AS bbarcode ,
                                    0 AS iscanedquantity ,
                                    0 AS iscanednum ,
                                    om_mohead.ufts,om_mohead.ccode as csrccode
                            FROM    om_momaterialsbody a WITH ( NOLOCK )
                                    LEFT JOIN Inventory b ON b.cInvCode = a.cinvcode
                                    INNER JOIN om_mohead ON a.moid = om_mohead.moid
                            WHERE   modetailsid IN ( SELECT DISTINCT
                                                            M_ID AS did
                                                     FROM   #STPDARefOMIDs )
                                    AND a.momaterialsid IN ( SELECT DISTINCT
                                                              S_ID AS did
                                                             FROM
                                                              #STPDARefOMIDs )
                            ORDER BY a.moid ,
                                    a.modetailsid ,
                                    a.momaterialsid;                    
                  --删除临时表
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDARefOMIDs') IS NULL )
                                DROP TABLE #STPDARefOMIDs;
                --IF EXISTS ( SELECT  0
                --            WHERE   NOT OBJECT_ID('tempdb..#STPDARefID') IS NULL )
                --    DROP TABLE #STPDARefID;
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDATempOMDIDs') IS NULL )
                                DROP TABLE #STPDATempOMDIDs;
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDATempWhs') IS NULL )
                                DROP TABLE #STPDATempWhs;
                        END;        
                            
                END;
            ELSE
                IF ( @OperType = N'2' )--参照调拨申请单生成调拨单  todo
                    BEGIN
                --调拨申请单主表ID
                        DECLARE @TransAppIds NVARCHAR(1000);
                
                        BEGIN
                
                            SET @TransAppIds = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'TransAppIds',
                                                              DEFAULT, DEFAULT);
                            IF ( @TransAppIds <> N'' )
                                BEGIN                             
                                    IF EXISTS ( SELECT  0
                                                WHERE   NOT OBJECT_ID('tempdb..#STPDATempTransAppIDs') IS NULL )
                                        DROP TABLE #STPDATempTransAppIDs;
                    
                                    CREATE   TABLE #STPDATempTransAppIDs ( AppId
                                                              INT );
                                    INSERT  INTO #STPDATempTransAppIDs
                                            EXEC proc_ts_SplitParamString @TransAppIds;
                                END;
                                                              
                        END;

						--调拨申请单单号
                        DECLARE @cAppCode NVARCHAR(30);
                        SET @cAppCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cCode',
                                                              DEFAULT, DEFAULT);
						--调拨申请单日期FROM
                        DECLARE @dAppDateFrom VARCHAR(10);
                        SET @dAppDateFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dDateFrom',
                                                              DEFAULT, DEFAULT);
						--调拨申请单日期TO
                        DECLARE @dAppDateTo VARCHAR(10);
                        SET @dAppDateTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dDateTo',
                                                              DEFAULT, DEFAULT);
						--调拨申请单申请人编码
                        DECLARE @cAppPersonCode NVARCHAR(20);
                        SET @cAppPersonCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cPersonCode',
                                                              DEFAULT, DEFAULT);
						--调拨申请单申请人名称
                        DECLARE @cAppPersonName NVARCHAR(40);
                        SET @cAppPersonName = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cPersonName',
                                                              DEFAULT, DEFAULT);
						--出库类别编码
                        DECLARE @cORdCode NVARCHAR(5);
                        SET @cORdCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cORdCode',
                                                              DEFAULT, DEFAULT);
						--入库类别编码
                        DECLARE @cIRdCode NVARCHAR(12);
                        SET @cIRdCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cIRdCode',
                                                              DEFAULT, DEFAULT);
						
						--转出部门编码
                        DECLARE @cODepCode NVARCHAR(20);
                        SET @cODepCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cODepCode',
                                                              DEFAULT, DEFAULT);
                                                              
                        --转入部门编码
                        DECLARE @cIDepCode NVARCHAR(12);
                        SET @cIDepCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cIDepCode',
                                                              DEFAULT, DEFAULT);                                      
                        --转出仓库编码
                        DECLARE @cOWhCode NVARCHAR(20);
                        SET @cOWhCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cOWhCode',
                                                              DEFAULT, DEFAULT);
                                                              
                        --转入仓库编码
                        DECLARE @cIWhCode NVARCHAR(12);
                        SET @cIWhCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cIWhCode',
                                                              DEFAULT, DEFAULT); 
                        SET NOCOUNT ON;
                   
                        IF EXISTS ( SELECT  0
                                    WHERE   NOT OBJECT_ID('tempdb..#STPDARefTransAppIDs') IS NULL )
                            DROP TABLE #STPDARefTransAppIDs;
                        SELECT  IDENTITY( INT ) AS tmpId ,
                                CONVERT(INT, 0) AS App_ID ,--调拨申请单表头ID
                                CONVERT(MONEY, ufts) AS ufts ,
                                CONVERT(INT, 0) AS APP_AutoID --调拨申请单表体ID
                        INTO    #STPDARefTransAppIDs
                        FROM    dbo.kctransrequestlist
                        WHERE   1 = 0; 
                        CREATE CLUSTERED INDEX ix_STPDARefIDs_tmpid_813 ON #STPDARefTransAppIDs( App_ID,tmpId,APP_AutoID ); 
 
                        SET @SqlCommand = N'INSERT INTO #STPDARefTransAppIDs
								( App_ID ,
								  ufts,
								  APP_AutoID
								)
								SELECT DISTINCT  
										id ,
										ufts ,
										autoid
								 FROM   kctransrequestlist
								 WHERE  ( 1 = 1 ';
                
                        IF ( @cAppCode <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + N' AND ( ctvcode=@cAppCode )';
                        IF ( @TransAppIds <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (id IN  (SELECT DISTINCT AppId FROM #STPDATempTransAppIDs)) ';
                        IF ( @dAppDateFrom <> N''
                             AND @dAppDateTo <> N''
                           )
                            SET @SqlCommand = @SqlCommand
                                + ' AND ((dtvdate >= @dAppDateFrom )
                            AND ( dtvdate <= @dAppDateTo )) ';
                        IF ( @cODepCode <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (codepcode=@cODepCode) ';
                        IF ( @cIDepCode <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (cidepcode=@cIDepCode) ';
                        IF ( @cAppPersonCode <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (cpersoncode = @cAppPersonCode) ';
                        IF ( @cAppPersonName <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (cpersonname = @cAppPersonName) ';
                        IF ( @cOWhCode <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (cowhcode = @cOWhCode) '; 
                        IF ( @cIWhCode <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (ciwhcode = @cIWhCode) '; 
                        IF ( @cMaker <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (cmaker = @cMaker) '; 
                        IF ( @cORdCode <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (cordcode = @cORdCode) '; 
                        IF ( @cIRdCode <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (cirdcode = @cIRdCode) '; 
                        IF ( @MaterialInvCode <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (cinvcode=@MaterialInvCode) ';
                        IF ( @MaterialInvName <> N''
                             AND @MaterialInvName <> N'%%'
                           )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (cinvname LIKE @MaterialInvName) ';
                        IF ( @MaterialInvAddCode <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (cinvaddcode =@MaterialInvAddCode) ';
                        IF ( @MaterialInvStd <> N''
                             AND @MaterialInvStd <> N'%%'
                           )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (cinvstd LIKE @MaterialInvStd) ';
                        SET @SqlCommand = @SqlCommand
                            + N' )  AND ( ISNULL(cverifyperson, '''') <> ''''
                          AND ISNULL(cbcloser, '''') = ''''
                          AND ( ISNULL(itvchkquantity, 0) <> 0
                                OR ISNULL(itvchknum, 0) <> 0))
                    AND ISNULL(cbustype, '''') <> N''退货申请''
                    AND ISNULL(bislsquery, 0) = 0
                    AND ISNULL(isbh, 0) = 0
                    AND 1 = 1 ';
                        IF ( @ShowClosed = N'0' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND ( CONVERT(DECIMAL(38, 6), ABS(ISNULL(itvchkquantity, 0))
                          - ABS(ISNULL(itvsumquantity, 0))) > 0
                          OR ( igrouptype = 2 AND CONVERT(DECIMAL(38, 6), ABS(ISNULL(itvchknum,0))
                               - ABS(ISNULL(itvsumnum, 0))) > 0)) ';
                        --PRINT @SqlCommand;
                        SET @ParmList = '@cAppCode				NVARCHAR(30),
									   @MaterialInvCode			NVARCHAR(60),
									   @MaterialInvAddCode      NVARCHAR(255), 
									   @MaterialInvName			NVARCHAR(255),
									   @MaterialInvStd			NVARCHAR(255),
									   @dAppDateFrom			VARCHAR(10),
									   @dAppDateTo				VARCHAR(10),
									   @cODepCode				NVARCHAR(12),
									   @cIDepCode				NVARCHAR(12),
									   @cOWhCode				NVARCHAR(20),
									   @cIWhCode				NVARCHAR(20),
									   @cMaker					NVARCHAR(30),
									   @cAppPersonCode			NVARCHAR(20),
									   @cAppPersonName			NVARCHAR(40),
									   @cIRdCode				VARCHAR(5),
									   @cORdCode				VARCHAR(5)';

                        EXEC sp_executesql @SqlCommand, @ParmList,
                            @cAppCode = @cAppCode,
                            @MaterialInvCode = @MaterialInvCode,
                            @MaterialInvAddCode = @MaterialInvAddCode,
                            @MaterialInvName = @MaterialInvName,
                            @MaterialInvStd = @MaterialInvStd,
                            @dAppDateFrom = @dAppDateFrom,
                            @dAppDateTo = @dAppDateTo, @cIDepCode = @cIDepCode,
                            @cODepCode = @cODepCode,
                            @cAppPersonCode = @cAppPersonCode,
                            @cAppPersonName = @cAppPersonName,
                            @cOWhCode = @cOWhCode, @cIWhCode = @cIWhCode,
                            @cMaker = @cMaker, @cIRdCode = @cIRdCode,
                            @cORdCode = @cORdCode;
                        SET NOCOUNT OFF;
						--查询调拨申请单列表（表头） 
						
                        SELECT  '' AS SelCol ,
                                CONVERT(VARCHAR(100), dtvdate, 23) AS ddate ,
                                ctvcode AS ccode ,
                                codepcode ,
                                cidepcode ,
                                cirdcode ,
                                cordcode ,
                                cpersoncode ,
                                cowhcode ,
                                ciwhcode ,
                                WhOut.cwhname AS cowhname ,
                                WhOut.bWhPos as bowhpos,
                                cwhname_1 AS ciwhname ,
                                WhIn.bWhPos as biwhpos,
                                cdepname_1 AS codepname ,
                                cdepname AS cidepname ,
                                crdname AS cirdname ,
                                crdname_1 AS cordname ,
                                cpersonname ,
                                cmaker ,
                                ctvmemo AS cmemo ,
                                vt_id ,
                                cverifyperson ,
                                CONVERT(VARCHAR(100), dverifydate, 23) AS dverifydate ,
                                cdefine1 ,
                                cdefine2 ,
                                cdefine3 ,
                                cdefine4 ,
                                cdefine5 ,
                                cdefine6 ,
                                cdefine7 ,
                                cdefine8 ,
                                cdefine9 ,
                                cdefine10 ,
                                cdefine11 ,
                                cdefine12 ,
                                cdefine13 ,
                                cdefine14 ,
                                cdefine15 ,
                                cdefine16 ,
                                id ,
                                isbh
                        FROM    transrequestm
                        Left Join Warehouse As WhOut On
							WhOut.cWhCode = cowhcode
						Left Join Warehouse As WhIn On
							WhIn.cWhCode = ciwhcode
                        WHERE   id IN ( SELECT DISTINCT
                                                App_ID
                                        FROM    #STPDARefTransAppIDs );

                   --查询领料申请单材料明细（表体）
                        IF ( @GetType = N'DETAIL' )
                            BEGIN
                                SELECT  a.autoid AS bodyautoid ,
                                        '' AS selcol ,
                                        a.* ,
                                        ( CONVERT(DECIMAL(38, 6), NULL) ) AS fstockanum ,
                                        ( CONVERT(DECIMAL(38, 6), NULL) ) AS fstockaqty ,
                                        ( CONVERT(DECIMAL(38, 6), NULL) ) AS fstocknum ,
                                        ( CONVERT(DECIMAL(38, 6), NULL) ) AS fstockqty ,
                                        Inv.bInvBatch AS binvbatch ,
                                        Inv.bInvQuality AS binvquality ,
                                        Inv.bSerial AS bserial ,
                                        Inv.bBarCode AS bbarcode ,
                                        Inv.bFree1 AS bfree1 ,
                                        Inv.bFree2 AS bfree2 ,
                                        Inv.bFree3 AS bfree3 ,
                                        Inv.bFree4 AS bfree4 ,
                                        Inv.bFree5 AS bfree5 ,
                                        Inv.bFree6 AS bfree6 ,
                                        Inv.bFree7 AS bfree7 ,
                                        Inv.bFree8 AS bfree8 ,
                                        Inv.bFree9 AS bfree9 ,
                                        Inv.bFree10 AS bfree10 ,
                                        0 AS iscanedquantity ,
                                        0 AS iscanednum ,
                                        ( ISNULL(itvchkquantity, 0)
                                          - ISNULL(itvsumquantity, 0) ) AS inquantity ,
                                        ( ISNULL(itvchknum, 0)
                                          - ISNULL(itvsumnum, 0) ) AS innum
                                FROM    kctransrequestlist a WITH ( NOLOCK )
                                        INNER JOIN dbo.Inventory Inv ON a.cinvcode = Inv.cInvCode
                                WHERE   a.id IN (
                                        SELECT DISTINCT
                                                App_ID
                                        FROM    #STPDARefTransAppIDs )
                                        AND a.autoid IN (
                                        SELECT  DISTINCT
                                                APP_AutoID
                                        FROM    #STPDARefTransAppIDs )
                                ORDER BY a.id ,
                                        a.autoid; 
                                                      
								--删除临时表
                                IF EXISTS ( SELECT  0
                                            WHERE   NOT OBJECT_ID('tempdb..#STPDARefTransAppIDs') IS NULL )
                                    DROP TABLE #STPDARefTransAppIDs;
             
                                IF EXISTS ( SELECT  0
                                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempTransAppIDs') IS NULL )
                                    DROP TABLE #STPDATempTransAppIDs;
                                --IF EXISTS ( SELECT  0
                                --            WHERE   NOT OBJECT_ID('tempdb..#STPDATempWhs') IS NULL )
                                --    DROP TABLE #STPDATempWhs;
                            END;
                    END;
                ELSE
                    BEGIN
                        PRINT @OperType;
                    END;
    END;
