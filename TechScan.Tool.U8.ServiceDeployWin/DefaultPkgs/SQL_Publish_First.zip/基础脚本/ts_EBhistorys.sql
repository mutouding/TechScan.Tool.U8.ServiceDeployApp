﻿if not exists (select * from sysobjects where id = object_id('dbo.ts_EBhistorys') and sysstat & 0xf = 3)
BEGIN
CREATE TABLE dbo.ts_EBhistorys
(
  id int IDENTITY(1,1) not null ,
  ctradecode nvarchar(50) null ,
  cexpresscode nvarchar(50) null ,
  createtime datetime  null ,
  cmaker nvarchar(50) null ,
  CONSTRAINT PK_ts_EBhistorys PRIMARY KEY  CLUSTERED
  (
    id
  )
)
END