﻿
/*---------------------------------------------------------------------
* 			Copyright (C) 2017 TECHSCAN 版权所有。
*           www.techscan.cn
*┌──────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．　│
*│　版权所有：上海太迅自动识别技术有限公司 　 　　　　　　　　　　　　│
*└──────────────────────────────────┘
*
* 文件名：   proc_ts_ReferVouch_MaterialOut_Get.SQL
* 功能：     存储过程
* 描述：     ST库存[材料出库单]-获取上游可参照单据信息
* 作者：     马永龙
* 创建时间： 2017-12-21 10:13:31
* 文件版本： V1.0.6

===============================版本履历===============================
* Ver 		变更日期 				负责人 	变更内容
* V1.0.0	2017-12-21 10:13:31		Myl		Create
* V1.0.1	2017-12-30				Myl		增加几个存货数据辅助校验字段
 *											①：bInvQuality 是否保质期管理
 *											②：bInvBatch 是否批次管理
 *											③：bSerial 是否序列号管理
 *											④：bBarCode 是否条码管理
* V1.0.2	2018-01-11				Myl		所有查询到的表头表体字段以小写字母展现
* V1.0.3	2018-01-30				Myl		添加已扫描数量和已扫描件数字段iScanedQuantity和iScanedNum
* V1.0.4	2018-03-11				Myl		①：材料出库参照生产订单时，表体上应发数量字段由inqty变为inquantity
											②：材料出库参照生产订单时，表体上应发件数字段由iunnum变为innum（iunnum AS innum）
											③：材料出库单所有参照类型，表体字段添加bFree1-bFree10等10个自由项字段
* V1.0.5	2018-05-15				Myl		修改所有参照单据中的日期格式为'yyyy-MM-dd'格式（CONVERT(varchar(100), ddate, 23)）
* V1.0.6	2018-07-13				Myl		表体添加统一bodyautoid字段（表体唯一ID的副本字段，前台用）
* V1.0.7    2019-04-12              Leo		修改了委外的参照
* V1.0.8    2019-06-19 DXH  合并生成订单
======================================================================
//--------------------------------------------------------------------*/

--EXEC proc_ts_ReferVouch_MaterialOut_Get '2','DETAIL','ShowClosed:1,ccode:0000000001'
--EXEC proc_ts_ReferVouch_Get '2','DETAIL','ShowClosed:0@@cCode:0000000001@@bRed:0@@cRdCode:04@@MaterialAppIds:1000000002,1000000001@@MaterialDemandDate:2017-10-24'
--EXEC proc_ts_ReferVouch_Get '2','DETAIL','ShowClosed:0@@cCode:0000000001@@bRed:0@@cRdCode:04@@MaterialAppIds:1000000002,1000000001@@MaterialInvName:高温合金'
--EXEC proc_ts_ReferVouch_Get '2','DETAIL','ShowClosed:0@@cCode:0000000001@@bRed:0@@cRdCode:04@@MaterialWhCode:1001,1003'
--EXEC proc_ts_ReferVouch_Get '2','DETAIL','ShowClosed:0@@cCode:0000000001@@bRed:0@@cRdCode:04@@MaterialAppIds:1000000002,1000000001'
--EXEC proc_ts_ReferVouch_Get '1','DETAIL','ShowClosed:1,ccode:0000000001'
--EXEC proc_ts_ReferVouch_Get '0',DEFAULT,'bRed:0@@MoDids:1000000001,1000000003'
--EXEC proc_ts_ReferVouch_Get '0','DETAIL','bRed:0@@MoDids:1000000001,1000000003'
--EXEC proc_ts_ReferVouch_Get '0','bRed:0,MoSeq:2,MoCode:0000000001,MaterialInvStd:BOM01,ProInvName:8891,StartDateFrom:2017-10-16,StartDateTo:2017-10-16,DueDateFrom:2017-10-17,DueDateTo:2017-10-18'
--EXEC proc_ts_ReferVouch_MaterialOut_Get '0','DETAIL','MoCode:0000000001'
--EXEC proc_ts_ReferVouch_MaterialOut_Get '2', 'DETAIL', ''


Create PROC [dbo].[proc_ts_ReferVouch_MaterialOut_Get] 
    (
      @OperType CHAR(1) ,
      --获取类型（'LIST'获取上游参照单据列表;'DETAIL'获取上游参照单据详情（包含表头表体））
      --默认获取上游参照单据列表
      @GetType VARCHAR(10) = N'LIST' ,
      --传入的参数列表字符串
      --默认传空值
      @ParamsList NVARCHAR(2000) = N''
    )
AS
    BEGIN

		--是否参照生产订单（红字）/委外订单（红字）bRed参数
        DECLARE @bRed VARCHAR(1);
        SET @bRed = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                           N'bRed', DEFAULT,
                                                           DEFAULT);
        IF ( @bRed = N'' )
            BEGIN
                SET @bRed = N'0';
            END;

		--生产部门编码（OR 委外订单部门编码 OR 领料申请单部门编码）
        DECLARE @DeptCode NVARCHAR(12);
        SET @DeptCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'DeptCode',
                                                              DEFAULT, DEFAULT);
        --生产部门名称（OR 委外订单部门名称 OR 领料申请单部门名称）
        DECLARE @DeptName NVARCHAR(255);
        SET @DeptName = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'DeptName',
                                                              DEFAULT, DEFAULT);
                                                              
		--产品-存货编码
        DECLARE @ProInvCode NVARCHAR(60);
        SET @ProInvCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ProInvCode',
                                                              DEFAULT, DEFAULT);
            --产品-存货代码
        DECLARE @ProInvAddCode NVARCHAR(255);
        SET @ProInvAddCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ProInvAddCode',
                                                              DEFAULT, DEFAULT);
            --产品-存货名称
        DECLARE @ProInvName NVARCHAR(255);
        SET @ProInvName = '%'
            + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                     N'ProInvName', DEFAULT,
                                                     DEFAULT) + '%';
            --产品-存货规格
        DECLARE @ProInvStd NVARCHAR(255);
        SET @ProInvStd = '%'
            + dbo.func_ts_GetParamValueBySplitString(@ParamsList, N'ProInvStd',
                                                     DEFAULT, DEFAULT) + '%';
                    
        --执行完未关闭是否显示(1:显示/0:不显示;默认不显示)
        DECLARE @ShowClosed CHAR(1);
        SET @ShowClosed = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ShowClosed',
                                                              DEFAULT, DEFAULT);
        IF ( @ShowClosed = N'' )
            BEGIN
                SET @ShowClosed = N'0';
            END;
            
        --材料编码
        DECLARE @MaterialInvCode NVARCHAR(60);
        SET @MaterialInvCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MaterialInvCode',
                                                              DEFAULT, DEFAULT);
          
        --材料存货代码
        DECLARE @MaterialInvAddCode NVARCHAR(255);
        SET @MaterialInvAddCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MaterialInvAddCode',
                                                              DEFAULT, DEFAULT);                      
         --材料存货名称
        DECLARE @MaterialInvName NVARCHAR(255);
        SET @MaterialInvName = '%'
            + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                     N'MaterialInvName',
                                                     DEFAULT, DEFAULT) + '%';
        --材料存货规格
        DECLARE @MaterialInvStd NVARCHAR(255);
        SET @MaterialInvStd = '%'
            + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                     N'MaterialInvStd',
                                                     DEFAULT, DEFAULT) + '%';
       
       --材料需求日期
        DECLARE @MaterialDemandDate NVARCHAR(20);
        SET @MaterialDemandDate = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MaterialDemandDate',
                                                              DEFAULT, DEFAULT);
                                                               
        --材料仓库编码
        DECLARE @MaterialWhCode NVARCHAR(100);
        BEGIN
               
            SET @MaterialWhCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MaterialWhCode',
                                                              DEFAULT, DEFAULT);
            IF ( @MaterialWhCode <> N'' )
                BEGIN
                     
                    IF EXISTS ( SELECT  0
                                WHERE   NOT OBJECT_ID('tempdb..#STPDATempWhs') IS NULL )
                        DROP TABLE #STPDATempWhs;
                    
                    CREATE   TABLE #STPDATempWhs ( cWhCode NVARCHAR(10) );
                    INSERT  INTO #STPDATempWhs
                            EXEC proc_ts_SplitParamString @MaterialWhCode;
                END;
        END;
       
        --材料供应类型(倒冲/工序倒冲/领用)
        DECLARE @WIPType NVARCHAR(10);
        SET @WIPType = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'WIPType',
                                                              DEFAULT, DEFAULT);
        IF ( @WIPType = N'' )
            BEGIN
                SET @WIPType = N'3';
            END;
       
        DECLARE @ParmList NVARCHAR(MAX);set @ParmList = N'';
        DECLARE @SqlCommand NVARCHAR(MAX);set @ParmList = N'';

        IF ( @OperType = N'0' )
        --ST材料出库-参照生产订单
        --(参照生产订单（红字）生成材料退货单时，使用参数'bRed'传递
        --[bRed=0表示普通的参照生产订单生成材料出库单/bRed=1表示参照生产订单（红字）生成材料退货]。参照生产订单和生产订单（红字）的区别是添加查询条件：'AND ISNULL(IssQty, 0) - ISNULL(ReplenishQty, 0) > 0')
            BEGIN
            
            --定义查询参数
            
 
            --制单人
                DECLARE @cMaker NVARCHAR(30);
                SET @cMaker = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cMaker',
                                                              DEFAULT, DEFAULT);
            --生产订单单号
                DECLARE @MoCode NVARCHAR(max);
                SET @MoCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MoCode',
                                                              DEFAULT, DEFAULT);
		 IF(@MoCode <> N'')
            BEGIN                             
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempOUTMOCodes') IS NULL )
                    DROP TABLE #STPDATempOUTMOCodes;
                    
                CREATE   TABLE #STPDATempOUTMOCodes ( MoCode NVARCHAR(30) );
                INSERT  INTO #STPDATempOUTMOCodes
                        EXEC proc_ts_SplitParamString @MoCode;
            END;




            --生产订单行号
                DECLARE @MoSeq NVARCHAR(30);
                SET @MoSeq = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MoSeq',
                                                              DEFAULT, DEFAULT);
            --生产订单子表行号
                DECLARE @MoDids NVARCHAR(1000);
                
                BEGIN
                
                    SET @MoDids = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MoDids',
                                                              DEFAULT, DEFAULT);
                    IF ( @MoDids <> N'' )
                        BEGIN                             
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDATempMODIDs') IS NULL )
                                DROP TABLE #STPDATempMODIDs;
                    
                            CREATE   TABLE #STPDATempMODIDs ( MoDid INT );
                            INSERT  INTO #STPDATempMODIDs
                                    EXEC proc_ts_SplitParamString @MoDids;
                        END;
                                                              
                END;
                
           
            --产品-存货自定义项
            --SELECT cInvDefine2, * FROM dbo.Inventory
            --产品-存货自定义项1
            --DECLARE @ProInvDefine1 NVARCHAR(20)
            --产品-存货自定义项2
            --DECLARE @ProInvDefine2 NVARCHAR(20)
            --客户编码
                DECLARE @CusCode NVARCHAR(20);
                SET @CusCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'CusCode',
                                                              DEFAULT, DEFAULT);
            --客户名称
                DECLARE @CusName NVARCHAR(98);
                SET @CusName = '%'
                    + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                             N'CusName',
                                                             DEFAULT, DEFAULT)
                    + '%';
          
            --工单开工日期FROM
                DECLARE @StartDateFrom VARCHAR(10);
                SET @StartDateFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'StartDateFrom',
                                                              DEFAULT, DEFAULT);
            --工单开工日期TO
                DECLARE @StartDateTo VARCHAR(10);
                SET @StartDateTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'StartDateTo',
                                                              DEFAULT, DEFAULT);
            --工单完工日期FROM
                DECLARE @DueDateFrom VARCHAR(10);
                SET @DueDateFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'DueDateFrom',
                                                              DEFAULT, DEFAULT);
            --工单完工日期TO
                DECLARE @DueDateTo VARCHAR(10);
                SET @DueDateTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'DueDateTo',
                                                              DEFAULT, DEFAULT);
            
             --需求跟踪号
             --DECLARE @SoCode NVARCHAR(30)
             --SET @SoCode =dbo.func_ts_GetParamValueBySplitString(@ParamsList,N'SoCode',DEFAULT,DEFAULT)
             --需求跟踪行号
             --DECLARE @SoSeq NVARCHAR(20)
             --SET @SoSeq =dbo.func_ts_GetParamValueBySplitString(@ParamsList,N'SoSeq',DEFAULT,DEFAULT)
             --销售订单类别
             --DECLARE @OrderType NVARCHAR(20)
             --SET @OrderType =dbo.func_ts_GetParamValueBySplitString(@ParamsList,N'OrderType',DEFAULT,DEFAULT)
             --销售订单号
             --DECLARE @OrderCode NVARCHAR(30)
             --SET @OrderCode =dbo.func_ts_GetParamValueBySplitString(@ParamsList,N'OrderCode',DEFAULT,DEFAULT)
             --销售订单行号
             --DECLARE @OrderSeq NVARCHAR(20)
             --SET @OrderSeq =dbo.func_ts_GetParamValueBySplitString(@ParamsList,N'OrderSeq',DEFAULT,DEFAULT)
             --不良品处理单单号
             --DECLARE @cRejectCode NVARCHAR(30)
             --SET @cRejectCode =dbo.func_ts_GetParamValueBySplitString(@ParamsList,N'cRejectCode',DEFAULT,DEFAULT)
             --手册号
                DECLARE @cCiqbookCode NVARCHAR(30);
                SET @cCiqbookCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cCiqbookCode',
                                                              DEFAULT, DEFAULT);
             --生产批号
                DECLARE @MoLotCode NVARCHAR(60);
                SET @MoLotCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MoLotCode',
                                                              DEFAULT, DEFAULT);
             --服务单号
                DECLARE @cServiceCode NVARCHAR(30);
                SET @cServiceCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cServiceCode',
                                                              DEFAULT, DEFAULT);
            --材料领料部门编码
                DECLARE @MaterialDeptCode NVARCHAR(12);
                SET @MaterialDeptCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MaterialDeptCode',
                                                              DEFAULT, DEFAULT);
            --材料批号
                DECLARE @MaterialLotNo NVARCHAR(255);
                SET @MaterialLotNo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MaterialLotNo',
                                                              DEFAULT, DEFAULT);
 
            --工厂编码
                DECLARE @cFactoryCode NVARCHAR(50);
                SET @cFactoryCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cFactoryCode',
                                                              DEFAULT, DEFAULT);
            
                SET NOCOUNT ON;
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDARefIDs') IS NULL )
                    DROP TABLE #STPDARefIDs;
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDARefID') IS NULL )
                    DROP TABLE #STPDARefID;
                SELECT  IDENTITY( INT ) AS tmpId ,
                        CONVERT(INT, 0) AS M_ID ,
                        CONVERT(INT, 0) AS S_ID ,
                        CONVERT(MONEY, Ufts) AS oriufts ,
                        CONVERT(INT, 0) AS m_ST_moid
                INTO    #STPDARefIDs
                FROM    v_st_mom_orderdetail
                WHERE   1 = 0; 
                CREATE CLUSTERED INDEX ix_STPDARefIDs_tmpid_813 ON #STPDARefIDs( M_ID,S_ID,tmpId ); 

                SET @SqlCommand = ' INSERT INTO #STPDARefIDs
        ( M_ID ,
          S_ID ,
          oriufts ,
          m_ST_moid
        )
        SELECT  v_st_mom_orderdetail.MoDId ,
                AllocateId ,
                CONVERT(MONEY, v_st_mom_orderdetail.Ufts) ,
                v_st_mom_orderdetail.MoId
        FROM    v_mom_orderdetail_st v_st_mom_orderdetail
                LEFT JOIN ( SELECT  MoDId AS m_modid ,
                                    AllocateId ,
                                    crejectcode
                            FROM    v_st_moallocate
                            WHERE	ISNULL(WIPType, 0)= @WIPType 
									AND ISNULL(ByproductFlag, 0) = 0
									AND ISNULL(requisitionflag, 0) = 0 ';

                IF ( @MaterialDeptCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND v_st_moallocate.Dept =@MaterialDeptCode ';
                IF ( @MaterialInvCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND v_st_moallocate.InvCode =@MaterialInvCode ';
                IF ( @MaterialInvAddCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND v_st_moallocate.InvAddCode =@MaterialInvAddCode ';
                IF ( @MaterialInvName <> N''
                     AND @MaterialInvName <> N'%%'
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND v_st_moallocate.InvName LIKE @MaterialInvName ';
                IF ( @MaterialInvStd <> N''
                     AND @MaterialInvStd <> N'%%'
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND v_st_moallocate.InvStd LIKE @MaterialInvStd ';
                IF ( @MaterialLotNo <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND v_st_moallocate.LotNo = @MaterialLotNo ';
                IF ( @ShowClosed = N'0' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND ( ISNULL(Qty, 0) - ISNULL(IssQty, 0)
                                  + ISNULL(ReplenishQty, 0) ) > 0 ';
                --参照生产订单（红字）生成材料退库单                  
                IF ( @bRed = N'1' )
                    SET @SqlCommand = @SqlCommand
                        + N' AND ISNULL(IssQty, 0) - ISNULL(ReplenishQty, 0) > 0 ';
                IF ( @MaterialDeptCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND v_st_moallocate.Dept = @MaterialDeptCode ';
                IF ( @MaterialDemandDate <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND v_st_moallocate.Demdate = @MaterialDemandDate ';
                IF ( @MaterialWhCode <> N'' )
				--现在支持多个仓库（前台传参时仓库编码中间用','隔开）
                    SET @SqlCommand = @SqlCommand
                        --+ ' AND v_st_moallocate.WhCode = @MaterialWhCode ';
                        + ' AND v_st_moallocate.WhCode IN (SELECT DISTINCT cWhCode FROM #STPDATempWhs) ';
                IF ( @cFactoryCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND v_st_moallocate.cfactorycode = @cFactoryCode ';
                IF ( @MoDids <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_moallocate.MoDId IN  (SELECT DISTINCT MoDid FROM #STPDATempMODIDs)) ';
 
                SET @SqlCommand = @SqlCommand
                    + ' ) v_mom_moallocate ON v_st_mom_orderdetail.MoDId = v_mom_moallocate.m_modid
        WHERE   v_st_mom_orderdetail.ByProductFlag = 0
                AND ISNULL(v_st_mom_orderdetail.Status, 0) = 3
                AND ( ISNULL(v_st_mom_orderdetail.bWorkshopTrans, 0) = 0
                      OR ( ISNULL(v_st_mom_orderdetail.bWorkshopTrans, 0) = 1
                           AND ISNULL(v_st_mom_orderdetail.SfcFlag, 0) = 1
                         )
                    )
                AND ISNULL(v_mom_moallocate.m_modid, 0) <> 0 ';
                
                SET @SqlCommand = @SqlCommand + ' AND ( 1=1 ';
 
                IF ( @MoCode <> N'' )
                    --SET @SqlCommand = @SqlCommand
                    --    + ' AND (v_st_mom_orderdetail.MoCode=@MoCode) ';

				  SET @SqlCommand = @SqlCommand+ ' AND (v_st_mom_orderdetail.MoCode in (SELECT DISTINCT MoCode FROM #STPDATempOUTMOCodes)) ';	

                IF ( @MoSeq <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.MoSeq=@MoSeq) ';
                IF ( @cMaker <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.maker=@cMaker) ';
                IF ( @ProInvCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.InvCode=@ProInvCode) ';
                IF ( @ProInvAddCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.InvAddCode=@ProInvAddCode) ';
                IF ( @ProInvName <> N''
                     AND @ProInvName <> N'%%'
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.InvName LIKE @ProInvName) ';
                IF ( @ProInvStd <> N''
                     AND @ProInvStd <> N'%%'
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.InvStd LIKE @ProInvStd) ';
                IF ( @CusCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.Cuscode = @CusCode) ';
                IF ( @CusName <> N''
                     AND @CusName <> N'%%'
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.cusname LIKE @CusName) ';
                IF ( @DeptCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.MDept = @DeptCode) ';
                IF ( @DeptName <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.DeptName = @DeptName) ';
 
                IF ( @StartDateFrom <> N''
                     AND @StartDateTo <> N''
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (( v_st_mom_orderdetail.StartDate >= @StartDateFrom )
                            AND ( v_st_mom_orderdetail.StartDate <= @StartDateTo )) ';
 
                IF ( @DueDateFrom <> N''
                     AND @DueDateTo <> N''
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (( v_st_mom_orderdetail.DueDate >= @DueDateFrom )
                            AND ( v_st_mom_orderdetail.DueDate <= @DueDateTo )) ';
 
                IF ( @MoLotCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.MoLotCode = @MoLotCode) ';
                IF ( @cCiqbookCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.cciqbookcode = @cCiqbookCode) ';
 
                IF ( @cServiceCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.cservicecode = @cServiceCode) ';
 
                IF ( @MoDids <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_mom_orderdetail.MoDId IN  (SELECT DISTINCT MoDid FROM #STPDATempMODIDs) ) ';
 
                SET @SqlCommand = @SqlCommand + ' ) ';
                --PRINT @SqlCommand;
                SET @ParmList = '@WIPType NVARCHAR(10),
				   @MaterialDeptCode        NVARCHAR(12),
				   @MaterialInvCode			NVARCHAR(60),
				   @MaterialInvAddCode      NVARCHAR(255), 
				   @MaterialInvName			NVARCHAR(255),
				   @MaterialInvStd			NVARCHAR(255),
				   @MaterialLotNo			NVARCHAR(255),
				   @MaterialDemandDate      NVARCHAR(20),
				   @cFactoryCode			NVARCHAR(50),
				   @MoCode					NVARCHAR(30),
				   @MoSeq					NVARCHAR(30),
				   @cMaker					NVARCHAR(30),
				   @ProInvCode				NVARCHAR(60),
				   @ProInvAddCode			NVARCHAR(255),
				   @ProInvName				NVARCHAR(255),
				   @ProInvStd				NVARCHAR(255),
				   @CusCode					NVARCHAR(20),
				   @CusName					NVARCHAR(98),
				   @DeptCode				NVARCHAR(12),
				   @DeptName				NVARCHAR(255),
				   @StartDateFrom			VARCHAR(10),
				   @StartDateTo				VARCHAR(10),
				   @DueDateFrom				VARCHAR(10),
				   @DueDateTo				VARCHAR(10),
				   @MoLotCode				NVARCHAR(60),
				   @cCiqbookCode			NVARCHAR(30),
				   @cServiceCode			NVARCHAR(30)';
   
                EXEC sp_executesql @SqlCommand, @ParmList, @WIPType = @WIPType,
                    @MaterialDeptCode = @MaterialDeptCode,
                    @MaterialInvCode = @MaterialInvCode,
                    @MaterialInvAddCode = @MaterialInvAddCode,
                    @MaterialInvName = @MaterialInvName,
                    @MaterialInvStd = @MaterialInvStd,
                    @MaterialLotNo = @MaterialLotNo,
                    @MaterialDemandDate = @MaterialDemandDate,
                    --@MaterialWhCode = @MaterialWhCode,
                    @cFactoryCode = @cFactoryCode, @MoCode = @MoCode,
                    @MoSeq = @MoSeq, @cMaker = @cMaker,
                    @ProInvCode = @ProInvCode, @ProInvAddCode = @ProInvAddCode,
                    @ProInvName = @ProInvName, @ProInvStd = @ProInvStd,
                    @CusCode = @CusCode, @CusName = @CusName,
                    @DeptCode = @DeptCode, @DeptName = @DeptName,
                    @StartDateFrom = @StartDateFrom,
                    @StartDateTo = @StartDateTo, @DueDateFrom = @DueDateFrom,
                    @DueDateTo = @DueDateTo, @MoLotCode = @MoLotCode,
                    @cCiqbookCode = @cCiqbookCode,
                    @cServiceCode = @cServiceCode;	
 
                SELECT  IDENTITY( INT ) AS tmpId ,
                        M_ID ,
                        MAX(oriufts) AS oriufts ,
                        MAX(m_ST_moid) AS m_ST_moid
                INTO    #STPDARefID
                FROM    #STPDARefIDs
                GROUP BY M_ID;
 
                CREATE CLUSTERED INDEX ix_STPDARefID_tmpid_813 ON #STPDARefID( tmpId,M_ID ); 
                SET NOCOUNT OFF;
                --查询列表（表头）
                SELECT DISTINCT
                        '' AS selcol ,
						0 as bOMFirst,
                        SoType AS sotype ,
                        MDept cdepcode ,
                        MoCode AS mocode ,
                        MoSeq AS moseq ,
                        DeptName cdepname ,
                        InvCode AS cinvcode ,
                        InvAddCode AS cinvaddcode ,
                        SoCode AS socode ,
                        InvName AS cinvname ,
                        SoSeq AS soseq ,
                        InvStd AS cinvstd ,
                        Define1 cdefine1 ,
                        Define2 cdefine2 ,
                        Define3 cdefine3 ,
                        Define4 cdefine4 ,
                        Define5 cdefine5 ,
                        Define6 cdefine6 ,
                        Define7 cdefine7 ,
                        Define8 cdefine8 ,
                        Define9 cdefine9 ,
                        Define10 cdefine10 ,
                        Define11 cdefine11 ,
                        Define12 cdefine12 ,
                        Define13 cdefine13 ,
                        Define14 cdefine14 ,
                        Define15 cdefine15 ,
                        Define16 cdefine16 ,
                        InvDefine1 AS hcinvdefine1 ,
                        InvDefine2 AS hcinvdefine2 ,
                        InvDefine3 AS hcinvdefine3 ,
                        InvDefine4 AS hcinvdefine4 ,
                        InvDefine5 AS hcinvdefine5 ,
                        InvDefine6 AS hcinvdefine6 ,
                        InvDefine7 AS hcinvdefine7 ,
                        InvDefine8 AS hcinvdefine8 ,
                        InvDefine9 AS hcinvdefine9 ,
                        InvDefine10 AS hcinvdefine10 ,
                        InvDefine11 AS hcinvdefine11 ,
                        InvDefine12 AS hcinvdefine12 ,
                        InvDefine13 AS hcinvdefine13 ,
                        InvDefine14 AS hcinvdefine14 ,
                        InvDefine15 AS hcinvdefine15 ,
                        InvDefine16 AS hcinvdefine16 ,
                        UnitId AS unitid ,
                        UnitCode AS unitcode ,
                        AuxUnitId AS auxunitid ,
                        AuxUnitCode AS auxunitcode ,
                        Free1 AS cfree1 ,
                        Free2 AS cfree2 ,
                        Free3 AS cfree3 ,
                        Free4 AS cfree4 ,
                        Free5 AS cfree5 ,
                        Free6 AS cfree6 ,
                        Free7 AS cfree7 ,
                        Free8 AS cfree8 ,
                        Free9 AS cfree9 ,
                        Free10 AS cfree10 ,
                        CONVERT(VARCHAR(100), StartDate, 23) AS startdate ,
                        CONVERT(VARCHAR(100), DueDate, 23) AS duedate ,
                        AuxQty AS auxqty ,
                        impqty ,
                        QualifiedInQty AS qualifiedinqty ,
                        ( (ISNULL(impqty, 0) - ISNULL(QualifiedInQty, 0)) ) AS iqty ,
                        maker AS cmaker ,
                        SoDId AS sodid ,
                        MoDId AS modid ,
                        Ufts AS ufts ,
                        MoLotCode AS molotcode ,
                        OrderCode AS ordercode ,
                        OrderDId AS orderdid ,
                        OrderSeq AS orderseq ,
                        OrderType AS ordertype ,
                        cusname ,
                        Cuscode AS cuscode ,
                        CusabbName AS cusabbname ,
                        WhCode cwhcode ,
                        WhName cwhname ,
                        cservicecode ,
                        Remark AS remark ,
                        motypecode ,
                        motypedesc ,
                        csysbarcode ,
                        cbSysBarCode AS cbsysbarcode ,
                        MoId AS moid
                FROM    v_st_mom_orderdetail WITH ( NOLOCK )
                WHERE   orimodid IN ( 
						--生产订单子表ID
                        SELECT DISTINCT
                                M_ID
                        FROM    #STPDARefID --where tmpId > 0 and tmpId < 21 
						--order by m_ST_moid,m_id 
									)
                        AND moid IN (
						--生产订单主表ID
                        SELECT DISTINCT
                                m_ST_moid
                        FROM    #STPDARefID --where tmpId > 0 and tmpId < 21 
						--order by m_ST_moid,m_id
									)
                        AND v_st_mom_orderdetail.ByProductFlag = 0;
                        
                --查询表体
                IF ( @GetType = N'DETAIL' )
                    BEGIN
                        DECLARE @SqlCommandBody NVARCHAR(MAX);set @SqlCommandBody = N'';
						--v_st_moallocate.WcCode 工作中心编码
                        SET @SqlCommandBody = '
						SELECT 
						StartDate,DueDate,
						 AllocateId AS bodyautoid,'''' AS selcol ,0 AS iscanedquantity,0 AS iscanednum,
						v_st_moallocate.WcCode AS wccode,
						v_st_moallocate.WcName AS wcname ,
						v_st_moallocate.WhCode AS cwhcode ,
						v_st_moallocate.WhName AS cwhname ,
						Dept AS cdepcode,
						v_st_moallocate.DeptName AS cdepname,
						v_st_moallocate.InvCode AS cinvcode ,
						v_st_moallocate.InvAddCode AS cinvaddcode ,
						v_st_moallocate.InvName AS cinvname ,
						v_st_moallocate.InvStd AS cinvstd ,
						v_st_moallocate.InvDefine1 AS cinvdefine1 ,
						v_st_moallocate.InvDefine2 AS cinvdefine2 ,
						v_st_moallocate.InvDefine3 AS cinvdefine3 ,
						v_st_moallocate.Ufts AS coufts ,
						v_st_moallocate.InvDefine4 AS cinvdefine4 ,
						( ftransqty ) AS ftransqty ,
						v_st_moallocate.InvDefine5 AS cinvdefine5 ,
						( ftransnum ) AS ftransnum ,
						v_st_moallocate.InvDefine6 AS cinvdefine6 ,
						v_st_moallocate.cmassunit ,
						v_st_moallocate.imassdate ,
						v_st_moallocate.iExpiratDateCalcu AS iexpiratdatecalcu,
						v_st_moallocate.InvDefine7 AS cinvdefine7 ,
						v_st_moallocate.InvDefine8 AS cinvdefine8 ,
						v_st_moallocate.InvDefine9 AS cinvdefine9 ,
						v_st_moallocate.InvDefine10 AS cinvdefine10 ,
						1 AS btaxcost ,
						v_st_moallocate.InvDefine11 AS cinvdefine11 ,
						v_st_moallocate.InvDefine12 AS cinvdefine12 ,
						v_st_moallocate.InvDefine13 AS cinvdefine13 ,
						v_st_moallocate.InvDefine14 AS cinvdefine14 ,
						v_st_moallocate.InvDefine15 AS cinvdefine15 ,
						v_st_moallocate.InvDefine16 AS cinvdefine16 ,
						v_st_moallocate.UnitCode AS cunitcode,
						UnitName AS cunitname,
						UnitName AS cinvm_unit ,
						BomQty AS ibomqty,
						Inv.bFree1 AS bfree1,
						Inv.bFree2 AS bfree2,
						Inv.bFree3 AS bfree3,
						Inv.bFree4 AS bfree4,
						Inv.bFree5 AS bfree5,
						Inv.bFree6 AS bfree6,
						Inv.bFree7 AS bfree7,
						Inv.bFree8 AS bfree8,
						Inv.bFree9 AS bfree9,
						Inv.bFree10 AS bfree10,
						v_st_moallocate.Free1 AS cfree1 ,
						v_st_moallocate.Free2 AS cfree2 ,
						v_st_moallocate.Free3 AS cfree3 ,
						v_st_moallocate.Free4 AS cfree4 ,
						v_st_moallocate.Free5 AS cfree5 ,
						v_st_moallocate.Free6 AS cfree6 ,
						v_st_moallocate.Free7 AS cfree7 ,
						v_st_moallocate.Free8 AS cfree8 ,
						v_st_moallocate.Free9 AS cfree9 ,
						v_st_moallocate.Free10 AS cfree10 ,
						LotNo AS clotno,
						CONVERT(varchar(100),Demdate,23) AS ddemdate,
						v_st_moallocate.Qty AS iqty,
						dbo.v_st_moallocate.IssQty AS oriissqty ,
						dbo.v_st_moallocate.IssQty as ireceivedqty,
						( (ISNULL(IssQty, 0) - ISNULL(ReplenishQty, 0)) ) AS issqty ,
						( (ISNULL(v_st_moallocate.Qty, 0) - ISNULL(IssQty, 0)
						  + ISNULL(ReplenishQty, 0)) ) AS isnqty ,
						( (ISNULL(v_st_moallocate.Qty, 0) - ISNULL(IssQty, 0)
						  + ISNULL(ReplenishQty, 0)) ) AS inquantity 
								';
                
                        IF ( @ShowClosed = N'0' )
                            BEGIN
                                IF ( @bRed = N'1' )
                                    SET @SqlCommandBody = @SqlCommandBody
                                        + N',case Inv.bKCCutMantissa when 1 then convert(decimal(38,6),ceiling( (ISNULL(v_st_moallocate.IssQty, 0) - ISNULL(v_st_moallocate.ReplenishQty, 0)) )) else ( (ISNULL(v_st_moallocate.IssQty, 0) - ISNULL(v_st_moallocate.ReplenishQty, 0)) ) end  AS iquantity ,isnum inum,';
                                ELSE
                                    SET @SqlCommandBody = @SqlCommandBody
                                        + N',case Inv.bKCCutMantissa when 1 then convert(decimal(38,6),ceiling( (ISNULL(v_st_moallocate.Qty, 0) - ISNULL(v_st_moallocate.IssQty, 0) + ISNULL(v_st_moallocate.ReplenishQty, 0)) )) else ( (ISNULL(v_st_moallocate.Qty, 0) - ISNULL(v_st_moallocate.IssQty, 0) + ISNULL(v_st_moallocate.ReplenishQty, 0)) ) end AS iquantity,iunnum inum,';
                            END;
                        ELSE
                            BEGIN
                                IF ( @bRed = N'1' )
                                    SET @SqlCommandBody = @SqlCommandBody
                                        + ',case Inv.bKCCutMantissa when 1 then convert(decimal(38,6),ceiling( ( ISNULL(v_st_moallocate.ReplenishQty, 0)) )) else ( (ISNULL(v_st_moallocate.ReplenishQty, 0)) ) end  AS iquantity,isnum inum,';
                                ELSE
                                    SET @SqlCommandBody = @SqlCommandBody
                                        + 'case Inv.bKCCutMantissa when 1 then convert(decimal(38,6),ceiling( (ISNULL(v_st_moallocate.Qty, 0) - ISNULL(v_st_moallocate.IssQty, 0) + ISNULL(v_st_moallocate.ReplenishQty, 0)) )) else ( (ISNULL(v_st_moallocate.Qty, 0) - ISNULL(v_st_moallocate.IssQty, 0) + ISNULL(v_st_moallocate.ReplenishQty, 0)) ) end AS iquantity,iunnum inum,';
                            END;
                        SET @SqlCommandBody = @SqlCommandBody
                            + '
						v_st_moallocate.OPSeq AS opseq,
						v_st_moallocate.OPSeq AS iopseq,
						OpDecs AS opdecs,
						v_st_moallocate.MoDId AS modid,
						AllocateId AS allocateid,
						v_st_moallocate.Ufts AS ufts,
						v_st_moallocate.WIPType AS wiptype,
						( CASE v_st_moallocate.WIPType
							WHEN 1 THEN ''入库倒冲''
							WHEN 3 THEN ''领料''
							ELSE ''其他''
						  END ) wiptypename ,
						cassunit ,
						cinva_unit ,
						iinvexchrate ,
						itnum ,
						isnum ,
						iunnum AS innum,
						v_st_moallocate.costitemcode ,
						v_st_moallocate.costitemname ,
						( CONVERT(DECIMAL(38, 6), NULL) ) AS fstockanum ,
						( CONVERT(DECIMAL(38, 6), NULL) ) AS fstockaqty ,
						( CONVERT(DECIMAL(38, 6), NULL) ) AS fstocknum ,
						( CONVERT(DECIMAL(38, 6), NULL) ) AS fstockqty ,
						ReplenishQty AS replenishqty,
						v_st_moallocate.Define22 AS cdefine22 ,
						v_st_moallocate.Define23 AS cdefine23 ,
						v_st_moallocate.Define24 AS cdefine24 ,
						v_st_moallocate.Define25 AS cdefine25 ,
						v_st_moallocate.Define26 AS cdefine26 ,
						v_st_moallocate.Define27 AS cdefine27 ,
						v_st_moallocate.Define28 AS cdefine28 ,
						v_st_moallocate.Define29 AS cdefine29 ,
						v_st_moallocate.Define30 AS cdefine30 ,
						v_st_moallocate.Define31 AS cdefine31 ,
						v_st_moallocate.Define32 AS cdefine32 ,
						v_st_moallocate.Define33 AS cdefine33 ,
						v_st_moallocate.Define34 AS cdefine34 ,
						v_st_moallocate.Define35 AS cdefine35 ,
						v_st_moallocate.Define36 AS cdefine36 ,
						v_st_moallocate.Define37 AS cdefine37 ,
						istsodid ,
						istsotype ,
						crejectcode ,
						v_st_moallocate.cciqbookcode ,
						cbatchproperty1 ,
						cbatchproperty2 ,
						cbatchproperty3 ,
						cbatchproperty4 ,
						cbatchproperty5 ,
						cbatchproperty6 ,
						cbatchproperty7 ,
						cbatchproperty8 ,
						cbatchproperty9 ,
						cbatchproperty10 ,
						v_st_moallocate.cbmemo ,
						--Z.MoDId ,
						Z.MDept AS mdept,
						Z.MoCode AS mocode,
						Z.MoSeq AS moseq,
							Z.MoSeq AS imoseq,
						Z.InvCode,
						Z.Invstd,
						Z.InvCode parentinvcode ,
						Z.InvName parentinvname ,
						Z.InvName,
						Z.InvStd parentinvstd ,
						O.SortSeq AS sortseq,
						v_st_moallocate.SoDId AS sodid,
						v_st_moallocate.SoCode AS socode,
						v_st_moallocate.SoSeq AS soseq,
						v_st_moallocate.SoType AS sotype,
						Inv.bInvBatch AS binvbatch,Inv.bInvQuality AS binvquality,Inv.bSerial AS bserial,Inv.bBarCode AS bbarcode,
						z.ordertype as iordertype,z.orderdid as iorderdid,z.ordercode as iordercode,z.orderseq as iorderseq,7 as ipesotype,v_st_moallocate.AllocateId as ipesodid,Z.MoCode cpesocode,Z.MoSeq ipesoseq,csubsysbarcode,Z.MoCode as csrccode
						
				FROM    v_st_moallocate WITH ( NOLOCK )
						INNER JOIN #STPDARefIDs b ON v_st_moallocate.MoDId = b.M_ID
												  AND v_st_moallocate.AllocateId = b.S_ID
						INNER JOIN v_st_mom_orderdetail Z ON v_st_moallocate.MoDId = Z.MoDId
						INNER JOIN mom_orderdetail O ON v_st_moallocate.MoDId = O.MoDId
						INNER
							JOIN dbo.Inventory Inv ON v_st_moallocate.InvCode = Inv.cInvCode;
								 ';
                        EXEC sp_executesql @SqlCommandBody;
                
                    END;
                --删除临时表
				IF EXISTS ( SELECT  0
                WHERE   NOT OBJECT_ID('tempdb..#STPDATempOUTMOCodes') IS NULL )
        DROP TABLE #STPDATempOUTMOCodes;

                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDARefIDs') IS NULL )
                    DROP TABLE #STPDARefIDs;
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDARefID') IS NULL )
                    DROP TABLE #STPDARefID;
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempMODIDs') IS NULL )
                    DROP TABLE #STPDATempMODIDs;
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempWhs') IS NULL )
                    DROP TABLE #STPDATempWhs;
            END;
        ELSE
            IF ( @OperType = N'1' )--根据委外订单（委外订单（红字））
                BEGIN
                    
                --委外订单子表ID
                    DECLARE @MoDetailsIds NVARCHAR(1000);   
                    DECLARE @biscomplement NVARCHAR(1000);
                    
                    BEGIN
                
                        SET @MoDetailsIds = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MoDetailsIds',
                                                              DEFAULT, DEFAULT);
                        SET @biscomplement = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'biscomplement',
                                                              DEFAULT, DEFAULT);
                        if(@biscomplement ='')
                             SET @biscomplement = 0;
                        IF ( @MoDetailsIds <> N'' )
                            BEGIN                             
                                IF EXISTS ( SELECT  0
                                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempOMDIDs') IS NULL )
                                    DROP TABLE #STPDATempOMDIDs;
                    
                                CREATE   TABLE #STPDATempOMDIDs ( MoDetailsId
                                                              INT );
                                INSERT  INTO #STPDATempOMDIDs
                                        EXEC proc_ts_SplitParamString @MoDetailsIds;
                            END;
                                                              
                    END;

                --委外订单单号
                    DECLARE @cCode NVARCHAR(30);
                    SET @cCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cCode',
                                                              DEFAULT, DEFAULT);
				--委外订单日期FROM
                    DECLARE @dDateFrom VARCHAR(10);
                    SET @dDateFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dDateFrom',
                                                              DEFAULT, DEFAULT);
				--委外订单日期TO
                    DECLARE @dDateTo VARCHAR(10);
                    SET @dDateTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dDateTo',
                                                              DEFAULT, DEFAULT);
    --            --委外订单部门编码
    --                DECLARE @DeptCode NVARCHAR(12);
    --                SET @DeptCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
    --                                                          N'DeptCode',
    --                                                          DEFAULT, DEFAULT);
				----委外订单部门名称
    --                DECLARE @DeptName NVARCHAR(255);
    --                SET @DeptName = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
    --                                                          N'DeptName',
    --                                                          DEFAULT, DEFAULT);
                    
                --委外商编码
                    DECLARE @cVenCode NVARCHAR(20);
                    SET @cVenCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cVenCode',
                                                              DEFAULT, DEFAULT);  
                --委外商名称
                    DECLARE @cVenName NVARCHAR(98);
                    SET @cVenName = '%'
                        + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cVenName',
                                                              DEFAULT, DEFAULT)
                        + '%';   
                
                --业务员编码
                    DECLARE @cPersonCode NVARCHAR(20);
                    SET @cPersonCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cPersonCode',
                                                              DEFAULT, DEFAULT);  
                --业务员名称
                    DECLARE @cPersonName NVARCHAR(40);
                    SET @cPersonName = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cPersonName',
                                                              DEFAULT, DEFAULT);   
                
                
    --            --产品-存货编码
    --                DECLARE @ProInvCode NVARCHAR(60);
    --                SET @ProInvCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
    --                                                          N'ProInvCode',
    --                                                          DEFAULT, DEFAULT);
				----产品-存货代码
    --                DECLARE @ProInvAddCode NVARCHAR(255);
    --                SET @ProInvAddCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
    --                                                          N'ProInvAddCode',
    --                                                          DEFAULT, DEFAULT);
				----产品-存货名称
    --                DECLARE @ProInvName NVARCHAR(255);
    --                SET @ProInvName = '%'
    --                    + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
    --                                                          N'ProInvName',
    --                                                          DEFAULT, DEFAULT)
    --                    + '%';
				----产品-存货规格
    --                DECLARE @ProInvStd NVARCHAR(255);
    --                SET @ProInvStd = '%'
    --                    + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
    --                                                          N'ProInvStd',
    --                                                          DEFAULT, DEFAULT)
    --                    + '%';
                --产品-存货自定义项1
                    DECLARE @ProInvDefine1 NVARCHAR(20);
                    SET @ProInvDefine1 = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ProInvDefine1',
                                                              DEFAULT, DEFAULT);
                --产品-自由项1
                    DECLARE @cFree1 NVARCHAR(20);
                    SET @cFree1 = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cFree1',
                                                              DEFAULT, DEFAULT);
                
                --计划下达日期FROM
                    DECLARE @dStartDate VARCHAR(10);
                    SET @dStartDate = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dStartDate',
                                                              DEFAULT, DEFAULT);
                --计划到货日期FROM
                    DECLARE @dArriveDate VARCHAR(10);
                    SET @dArriveDate = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dArriveDate',
                                                              DEFAULT, DEFAULT);

                --委外订单类型('0':标准;'1':非标准)
                    DECLARE @iOrderType VARCHAR(10);
                    SET @iOrderType = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'iOrderType',
                                                              DEFAULT, DEFAULT);
            ----材料需求日期
            --        DECLARE @MaterialDemandDate NVARCHAR(20);
            --        SET @MaterialDemandDate = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
            --                                                  N'MaterialDemandDate',
            --                                                  DEFAULT, DEFAULT);
 
                    SET NOCOUNT ON;
                    IF EXISTS ( SELECT  0
                                WHERE   NOT OBJECT_ID('tempdb..#STPDARefOMIDs') IS NULL )
                        DROP TABLE #STPDARefOMIDs;
                --IF EXISTS ( SELECT  0
                --            WHERE   NOT OBJECT_ID('tempdb..#STPDARefID') IS NULL )
                --    DROP TABLE #STPDARefID;
                    SELECT  IDENTITY( INT ) AS tmpId ,
                            CONVERT(INT, 0) AS M_ID ,--委外订单子表ID（委外订单表体行母件ID）
                            CONVERT(MONEY, corufts) AS oriufts ,
                            CONVERT(INT, 0) AS S_ID --委外用料单子表ID 
                    INTO    #STPDARefOMIDs
                    FROM    dbo.om_mobody
                    WHERE   1 = 0; 
                    CREATE CLUSTERED INDEX ix_STPDARefIDs_tmpid_813 ON #STPDARefOMIDs( M_ID,tmpId ); 

                    --DECLARE @ParmList NVARCHAR(MAX) = N'';
                    --DECLARE @SqlCommand NVARCHAR(MAX) = N'';

                    SET @SqlCommand = 'INSERT INTO #STPDARefOMIDs
								( M_ID ,
								  oriufts,
								  S_ID
								)
								SELECT DISTINCT
										modetailsid,om_mobody.corufts ,momaterialsid
								FROM    om_mohead
										INNER JOIN om_mobody ON om_mohead.moid = om_mobody.moid
										INNER JOIN ( SELECT DISTINCT
															modetailsid AS did,momaterialsid
													 FROM   om_momaterialsbody
													 WHERE  1 = 1 
															AND (ISNULL(iwiptype, 3) = @WIPType )
															AND (ISNULL(bcomsumeom, 0) = 1) 
															AND (ISNULL(om_momaterialsbody.iproducttype,0) = 0) '; 
                    IF ( @MaterialInvCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_momaterialsbody.cinvcode=@MaterialInvCode) ';
                    IF ( @MaterialInvName <> N''
                         AND @MaterialInvName <> N'%%'
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_momaterialsbody.cinvname LIKE @MaterialInvName) ';
                    IF ( @MaterialInvAddCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_momaterialsbody.cinvaddcode =@MaterialInvAddCode) ';
                    IF ( @MaterialInvStd <> N''
                         AND @MaterialInvStd <> N'%%'
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_momaterialsbody.cinvstd LIKE @MaterialInvStd) ';
                    IF ( @MaterialWhCode <> N'' )
				--现在支持多个仓库（前台传参时仓库编码中间用','隔开）
                        SET @SqlCommand = @SqlCommand
                            + ' AND om_momaterialsbody.cWhCode IN (SELECT DISTINCT cWhCode FROM #STPDATempWhs) ';
                    IF ( @MaterialDemandDate <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND om_momaterialsbody.drequireddate = @MaterialDemandDate ';
                    IF ( @ShowClosed = N'0' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND ( ISNULL(iquantity, 0) - ISNULL(isendqty, 0)
                                  + ISNULL(icomplementqty, 0) ) > 0 ';
                                  
                --参照委外订单（红字）生成材料退库单                  
                    IF ( @bRed = N'1' )
                        SET @SqlCommand = @SqlCommand
                            + N' AND ISNULL(isendqty, 0) - ISNULL(icomplementqty, 0) > 0 ';
                    ELSE
                        SET @SqlCommand = @SqlCommand
                            + N' AND (ISNULL(csendtype, ''0'') = ''0'') ';
                    IF ( @MoDetailsIds <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_momaterialsbody.modetailsid IN  (SELECT DISTINCT MoDetailsId FROM #STPDATempOMDIDs) ) ';

                    SET @SqlCommand = @SqlCommand
                        + N' ) om_momaterialsbody ON om_mobody.modetailsid = om_momaterialsbody.did
        WHERE   ( CASE WHEN ISNULL(cchanger, N'''') <> N''''
                       THEN ISNULL(cchangeverifier, N'''')
                       ELSE ISNULL(cverifier, N'''')
                  END ) <> N''''
                AND ISNULL(cbcloser, N'''') = N'''' 
                 AND ( 1 = 1 ';
                
                    IF ( @cCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mohead.ccode=@cCode) ';
                
                    IF ( @dDateFrom <> N''
                         AND @dDateTo <> N''
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND ((om_mohead.ddate >= @dDateFrom )
                            AND ( om_mohead.ddate <= @dDateTo )) ';
                    IF ( @DeptCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mohead.cdepcode=@DeptCode) ';
                    IF ( @DeptName <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mohead.cdepname=@DeptName) ';
                    IF ( @cVenCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mohead.cvencode=@cVenCode) ';    
                    IF ( @cVenName <> N''
                         AND @cVenName <> N'%%'
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mohead.cvenname LIKE @cVenName) '; 
                    IF ( @cPersonCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mohead.cpersoncode = @cPersonCode) '; 
                    IF ( @cPersonName <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mohead.cpersonname = @cPersonName) '; 
                    IF ( @ProInvCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mobody.cinvcode = @ProInvCode) '; 
                    IF ( @ProInvAddCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mobody.cinvaddcode = @ProInvAddCode) '; 
                    IF ( @ProInvName <> N''
                         AND @ProInvName <> N'%%'
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mobody.cinvname LIKE @ProInvName) ';  
                    IF ( @ProInvStd <> N''
                         AND @ProInvStd <> N'%%'
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mobody.cinvstd LIKE @ProInvStd) ';  
                    IF ( @ProInvDefine1 <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mobody.cinvdefine1 = @ProInvDefine1) ';         
                    IF ( @cFree1 <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mobody.cfree1 = @cFree1) ';    
                    IF ( @dStartDate <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mobody.dstartdate = @dStartDate) ';    
                    IF ( @dArriveDate <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mobody.darrivedate = @dArriveDate) ';    
                    IF ( @iOrderType <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (om_mohead.iordertype = @iOrderType) ';     
                            
                    SET @SqlCommand = @SqlCommand + N' );';        
                   --PRINT @SqlCommand
                   
                    SET @ParmList = '@WIPType NVARCHAR(10),
 				   @MaterialInvCode			NVARCHAR(60),
				   @MaterialInvAddCode      NVARCHAR(255), 
				   @MaterialInvName			NVARCHAR(255),
				   @MaterialInvStd			NVARCHAR(255),
				   @MaterialDemandDate      NVARCHAR(20),
				   @cCode					NVARCHAR(30),
				   @dDateFrom				VARCHAR(10),
				   @dDateTo					VARCHAR(10),
				   @DeptCode				NVARCHAR(12),
				   @DeptName				NVARCHAR(255),
				   @cVenCode				VARCHAR(20),
				   @cVenName				VARCHAR(98),
				   @cPersonCode				NVARCHAR(20),
				   @cPersonName				NVARCHAR(40),
				   @ProInvCode				NVARCHAR(60),
				   @ProInvAddCode			NVARCHAR(255),
				   @ProInvName				NVARCHAR(255),
				   @ProInvStd				NVARCHAR(255),
				   @ProInvDefine1			NVARCHAR(20),
				   @cFree1					NVARCHAR(20),
				   @dStartDate				NVARCHAR(10),
				   @dArriveDate				NVARCHAR(10),
				   @iOrderType				VARCHAR(10)
				 ';
   
                    EXEC sp_executesql @SqlCommand, @ParmList,
                        @WIPType = @WIPType,
                        @MaterialInvCode = @MaterialInvCode,
                        @MaterialInvAddCode = @MaterialInvAddCode,
                        @MaterialInvName = @MaterialInvName,
                        @MaterialInvStd = @MaterialInvStd,
                        @MaterialDemandDate = @MaterialDemandDate,
                    --@MaterialWhCode = @MaterialWhCode,
                        @cCode = @cCode, @dDateFrom = @dDateFrom,
                        @dDateTo = @dDateTo, @DeptCode = @DeptCode,
                        @DeptName = @DeptName, @cVenCode = @cVenCode,
                        @cVenName = @cVenName, @cPersonCode = @cPersonCode,
                        @cPersonName = @cPersonName, @ProInvCode = @ProInvCode,
                        @ProInvAddCode = @ProInvAddCode,
                        @ProInvName = @ProInvName, @ProInvStd = @ProInvStd,
                        @ProInvDefine1 = @ProInvDefine1, @cFree1 = @cFree1,
                        @dStartDate = @dStartDate, @dArriveDate = @dArriveDate,
                        @iOrderType = @iOrderType;
                        
                    SET NOCOUNT OFF;
                --查询委外订单列表（表头） 
                    SELECT  '' AS selcol ,
					1 as bOMFirst,
                            irowno ,
                            csocode ,
                            sotype ,
                            ccode ,ccode cmpocode1,
                            CONVERT(VARCHAR(100), ddate, 23) AS ddate ,
                            cdepcode ,
                            cdepname ,
                            cvencode ,
                            cvenabbname ,
                            cpersoncode ,
                            cpersonname ,
                            cmaker ,
                            cverifier ,
                            cinvcode ,
                            cinvaddcode ,
                            cinvname ,
                            cinvstd ,
                            cinvdefine1 AS hcinvdefine1 ,
                            cinvdefine2 AS hcinvdefine2 ,
                            cinvdefine3 AS hcinvdefine3 ,
                            cinvdefine4 AS hcinvdefine4 ,
                            cinvdefine5 AS hcinvdefine5 ,
                            cinvdefine6 AS hcinvdefine6 ,
                            cinvdefine7 AS hcinvdefine7 ,
                            cinvdefine8 AS hcinvdefine8 ,
                            cinvdefine9 AS hcinvdefine9 ,
                            cinvdefine10 AS hcinvdefine10 ,
                            cinvdefine11 AS hcinvdefine11 ,
                            cinvdefine12 AS hcinvdefine12 ,
                            cinvdefine13 AS hcinvdefine13 ,
                            cinvdefine14 AS hcinvdefine14 ,
                            cinvdefine15 AS hcinvdefine15 ,
                            cinvdefine16 AS hcinvdefine16 ,
                            ccomunitcode ,
                            cinvm_unit ,
                            cunitid ,
                            cinva_unit ,
                            citem_class ,
                            citem_name ,
                            citemcode ,
                            citemname ,
                            CONVERT(VARCHAR(100), dstartdate, 23) AS dstartdate ,
                            CONVERT(VARCHAR(100), darrivedate, 23) AS darrivedate ,
                            cfree1 ,
                            cfree2 ,
                            cfree3 ,
                            cfree4 ,
                            cfree5 ,
                            cfree6 ,
                            cfree7 ,
                            cfree8 ,
                            cfree9 ,
                            cfree10 ,
                            iquantity ,
                            inum ,
                            cmemo ,
                            ( CASE WHEN ISNULL(iarrqty, 0) <> 0
                                   THEN ISNULL(iarrqty, 0)
                                   ELSE ISNULL(ireceivedqty, 0)
                              END ) AS ireceivedqty ,
                            ( (ISNULL(iquantity, 0)
                              - ( CASE WHEN ISNULL(iarrqty, 0) <> 0
                                       THEN ISNULL(iarrqty, 0)
                                       ELSE ISNULL(ireceivedqty, 0)
                                  END )) ) AS iqty ,
                            modetailsid ,
                            ufts ,
                            om_mohead.moid,
							'委外订单' as csource,
							'委外发料' as cbustype
                    FROM    om_mohead WITH ( NOLOCK )
                            INNER JOIN om_mobody ON om_mohead.moid = om_mobody.moid
                            INNER JOIN ( SELECT DISTINCT
                                                M_ID AS did
                                         FROM   #STPDARefOMIDs
                                       ) om_momaterialsbody ON om_mobody.modetailsid = om_momaterialsbody.did
                    WHERE   ( CASE WHEN ISNULL(cchanger, N'') <> N''
                                   THEN ISNULL(cchangeverifier, N'')
                                   ELSE ISNULL(cverifier, N'')
                              END ) <> N''
                            AND ISNULL(cbcloser, N'') = N''
                            AND modetailsid IN ( SELECT DISTINCT
                                                        M_ID AS did
                                                 FROM   #STPDARefOMIDs )
                    ORDER BY ccode;        
                        
                 --查询表体
                    IF ( @GetType = N'DETAIL' )
                        BEGIN
                            --SELECT  a.momaterialsid AS bodyautoid ,
                            --        '' AS selcol ,
                            --        a.* ,
                            --        ( (ISNULL(isendqty, 0)
                            --          - ISNULL(icomplementqty, 0)) ) AS isendqty ,
                            --        ( (ISNULL(iquantity, 0) - ISNULL(isendqty,
                            --                                  0)
                            --          + ISNULL(icomplementqty, 0)) ) AS iqty ,
                            --        ( ftransqty ) AS ftransqty ,
                            --        ( ftransnum ) AS ftransnum ,
                            --        ( CONVERT(DECIMAL(38, 6), NULL) ) AS fstockanum ,
                            --        ( CONVERT(DECIMAL(38, 6), NULL) ) AS fstockaqty ,
                            --        ( CONVERT(DECIMAL(38, 6), NULL) ) AS fstocknum ,
                            --        ( CONVERT(DECIMAL(38, 6), NULL) ) AS fstockqty ,
                            --        b.bFree1 AS bfree1 ,
                            --        b.bFree2 AS bfree2 ,
                            --        b.bFree3 AS bfree3 ,
                            --        b.bFree4 AS bfree4 ,
                            --        b.bFree5 AS bfree5 ,
                            --        b.bFree6 AS bfree6 ,
                            --        b.bFree7 AS bfree7 ,
                            --        b.bFree8 AS bfree8 ,
                            --        b.bFree9 AS bfree9 ,
                            --        b.bFree10 AS bfree10 ,
                            --        b.bSerial AS bserial ,
                            --        b.bBarCode AS bbarcode ,
                            --        0 AS iscanedquantity ,
                            --        0 AS iscanednum ,
                            --        om_mohead.ufts
                            --FROM    om_momaterialsbody a WITH ( NOLOCK )
                            --        LEFT JOIN Inventory b ON b.cInvCode = a.cinvcode
                            --        INNER JOIN om_mohead ON a.moid = om_mohead.moid
                             Select distinct '' as selcol,om_momaterialsbody.momaterialsid as bodyautoid, 
                             momaterialsid ipesodid,om_mohead.ccode cpesocode,om_mohead.ccode as csrccode,om_mobody.modetailsid iomodid,
            om_momaterialsbody.momaterialsid,om_momaterialsbody.moid,om_momaterialsbody.modetailsid,
            om_momaterialsbody.cinvcode,om_momaterialsbody.cinvname,om_momaterialsbody.cinvstd,om_momaterialsbody.cinvaddcode,
            om_momaterialsbody.drequireddate,om_momaterialsbody.fbasenumn,om_momaterialsbody.cfree2,
            om_momaterialsbody.cfree1,om_momaterialsbody.ccomunitcode,om_momaterialsbody.cunitid,om_momaterialsbody.cinvm_unit,
            om_momaterialsbody.igrouptype,om_momaterialsbody.cgroupcode,om_momaterialsbody.cinva_unit,om_momaterialsbody.iinvexchrate,
            om_momaterialsbody.iinvauthid,om_momaterialsbody.cinvdefine1,om_momaterialsbody.cinvdefine2,om_momaterialsbody.cinvdefine3,
            om_momaterialsbody.cinvdefine4,om_momaterialsbody.cinvdefine5,om_momaterialsbody.cinvdefine6,om_momaterialsbody.cinvdefine7,
            om_momaterialsbody.cinvdefine8,om_momaterialsbody.cinvdefine9,om_momaterialsbody.cinvdefine10,om_momaterialsbody.cinvdefine11,
            om_momaterialsbody.cinvdefine12,om_momaterialsbody.cinvdefine13,om_momaterialsbody.cinvdefine14,om_momaterialsbody.cinvdefine15,
            om_momaterialsbody.cinvdefine16,om_momaterialsbody.cfree3,om_momaterialsbody.cfree4,om_momaterialsbody.cfree5,om_momaterialsbody.cfree6,
            om_momaterialsbody.cfree7,om_momaterialsbody.cfree8,om_momaterialsbody.cfree9,om_momaterialsbody.cfree10,om_momaterialsbody.cdefine22,
            om_momaterialsbody.cdefine23,om_momaterialsbody.cdefine24,om_momaterialsbody.cdefine25,om_momaterialsbody.cdefine26,
            om_momaterialsbody.cdefine27,om_momaterialsbody.cdefine28,om_momaterialsbody.cdefine29,om_momaterialsbody.cdefine30,
            om_momaterialsbody.cdefine31,om_momaterialsbody.cdefine32,om_momaterialsbody.cdefine33,om_momaterialsbody.cdefine34,
            om_momaterialsbody.cdefine35,om_momaterialsbody.cdefine36,om_momaterialsbody.cdefine37,om_momaterialsbody.cbatch,
            om_momaterialsbody.cwhcode,om_momaterialsbody.cwhname,om_momaterialsbody.isendqty,om_momaterialsbody.iunitquantity,
            om_momaterialsbody.iunitnum,om_momaterialsbody.isendnum,om_momaterialsbody.fbaseqtyn,
            om_momaterialsbody.fbaseqtyd,om_momaterialsbody.fcompscrp,om_momaterialsbody.bfvqty,om_momaterialsbody.iwiptype,
            om_momaterialsbody.opcomponentid,om_momaterialsbody.subflag,om_momaterialsbody.icomplementqty,om_momaterialsbody.icomplementnum,
            om_momaterialsbody.cassunit,om_momaterialsbody.itnum,om_momaterialsbody.isnum,om_momaterialsbody.iunnum,om_momaterialsbody.ccheckatp,
            om_momaterialsbody.iatpqty,om_momaterialsbody.csrpolicy,om_momaterialsbody.bspecialorder,om_momaterialsbody.ftransqty,
            om_momaterialsbody.ftransnum,om_momaterialsbody.funtransqty,om_momaterialsbody.funtransnum,om_momaterialsbody.cbatchproperty1,
            om_momaterialsbody.cbatchproperty2,om_momaterialsbody.cbatchproperty3,om_momaterialsbody.cbatchproperty4,om_momaterialsbody.cbatchproperty5,
            om_momaterialsbody.cbatchproperty6,om_momaterialsbody.cbatchproperty7,om_momaterialsbody.cbatchproperty8,om_momaterialsbody.cbatchproperty9,
            om_momaterialsbody.cbatchproperty10,om_momaterialsbody.sotype,om_momaterialsbody.sodid,om_momaterialsbody.csocode,om_momaterialsbody.irowno,
            om_momaterialsbody.cdemandmemo,om_momaterialsbody.cdetailsdemandcode,om_momaterialsbody.cdetailsdemandmemo,om_momaterialsbody.istsotype,
            om_momaterialsbody.istsodid,om_momaterialsbody.csendtype,om_momaterialsbody.fsendapplyqty,om_momaterialsbody.fsendapplynum,
            om_momaterialsbody.fapplyqty,om_momaterialsbody.fapplynum,om_momaterialsbody.fnosendqty,om_momaterialsbody.fnosendnum,
            om_momaterialsbody.iexpiratdatecalcu,om_momaterialsbody.cmassunit,om_momaterialsbody.imassdate,om_momaterialsbody.binvbatch,
            om_momaterialsbody.binvquality,om_momaterialsbody.bcomsumeom,om_momaterialsbody.cbmemo,om_momaterialsbody.csubsysbarcode,
            om_momaterialsbody.ipickqty,om_momaterialsbody.ipicknum,
             om_momaterialsbody.iquantity as inewquantity,
            om_momaterialsbody.inum as inewnum,'' dvdate,'' dmadedate,fbaseqtyn BomQty,
            
            case when @biscomplement=1
                 then (case when @bRed=1  then isnull(iComplementNum,0)
                       else (case when abs(isnull(om_momaterialsbody.inum,0))>abs(isnull(isendnum,0))-abs(isnull(iComplementNum,0)) then isnull(om_momaterialsbody.inum,0)-isnull(isendnum,0)+isnull(iComplementNum,0) else 0 end)
                 end)
                 else (case when @bRed=1  then (isnull(isendnum,0)-isnull(iComplementNum,0))
                       else (case when abs(isnull(om_momaterialsbody.inum,0))>abs(isnull(isendnum,0))-abs(isnull(iComplementNum,0)) then isnull(om_momaterialsbody.inum,0)-isnull(isendnum,0)+isnull(iComplementNum,0) else 0 end)  
                 end) end  as inum, 
                 
            case when @biscomplement=1
                 then (case when @bRed=1  then isnull(iComplementQty,0)
                       else (case when abs(isnull(om_momaterialsbody.iquantity,0))>abs(isnull(isendqty,0))-abs(isnull(iComplementQty,0)) then isnull(om_momaterialsbody.iquantity,0)-isnull(isendqty,0)+isnull(iComplementQty,0) else 0 end)
                 end)
                 else (case when @bRed=1  then (isnull(isendqty,0)-isnull(iComplementQty,0))
                       else (case when abs(isnull(om_momaterialsbody.iquantity,0))>abs(isnull(isendqty,0))-abs(isnull(iComplementQty,0)) then isnull(om_momaterialsbody.iquantity,0)-isnull(isendqty,0)+isnull(iComplementQty,0) else 0 end)
                 end) end as iquantity,  
            
            om_mobody.cinvcode as cpspcode,om_mobody.cinvname as cpspname,om_mobody.citemcode,om_mobody.citemname,om_mobody.citem_class,
            om_mobody.citem_name,om_mobody.iquantity as imquantity ,om_mohead.ccode,om_mohead.cvencode,om_mohead.cvenabbname,
            om_mohead.cdepcode,om_mohead.cdepname,om_mohead.cPersonCode,om_mohead.cPersonName,om_mohead.cmemo,
            convert(char,convert(money,om_momaterialsbody.matufts),2) as coufts ,om_mohead.cdefine1,om_mohead.cdefine2,om_mohead.cdefine3,
            om_mohead.cdefine4,om_mohead.cdefine5,om_mohead.cdefine6,om_mohead.cdefine7,om_mohead.cdefine8,om_mohead.cdefine9,
            om_mohead.cdefine10,om_mohead.cdefine11,om_mohead.cdefine12,om_mohead.cdefine13,om_mohead.cdefine14,
            om_mohead.cdefine15,om_mohead.cdefine16,om_mobody.fparentscrp as parentscrp,om_mobody.cfree1 as pf1,
            om_mobody.cfree2 as pf2,om_mobody.cfree3 as pf3,om_mobody.cfree4 as pf4,om_mobody.cfree5 as pf5,
            om_mobody.cfree6 as pf6,om_mobody.cfree7 as pf7,om_mobody.cfree8 as pf8,om_mobody.cfree9 as pf9,
            om_mobody.cfree10 as pf10,momaterialsid iomomid,ccode comcode ,
            om_mobody.cdemandcode cdemandcode ,om_mobody.sodid cdemandid,om_mobody.isosid idemandseq,om_mobody.sotype idemandtype ,8 as ipesotype
            From  om_momaterialsbody 
            left join om_mobody on om_momaterialsbody.MODetailsID=om_mobody.MODetailsID  
            inner join om_mohead  on om_mobody.moid=om_mohead.moid  
            where   isnull(cbcloser,N'')=N''and isnull(om_momaterialsbody.iproducttype,0)=0 
            and om_momaterialsbody.moid In(SELECT DISTINCT moid from om_mohead where 1=1 
            --if (modid == "")
            --{
            --    sqlbody += " and ccode='" + ccode + "'";
            --    if (moseq != "")
            --        sqlbody += " and ivouchrowno=" + moseq;
            --}
            --else
                and om_mobody.modetailsid in (SELECT DISTINCT  M_ID AS did  FROM  #STPDARefOMIDs ) and isnull(iwiptype,3)=3 
            ) order by om_momaterialsbody.modetailsid
                            --WHERE   modetailsid IN ( SELECT DISTINCT
                            --                                M_ID AS did
                            --                         FROM   #STPDARefOMIDs )
                            --        AND a.momaterialsid IN ( SELECT DISTINCT
                            --                                  S_ID AS did
                            --                                 FROM
                            --                                  #STPDARefOMIDs ) 
                             --WHERE    om_momaterialsbody.moid IN ( SELECT DISTINCT
                             --                               M_ID AS did
                             --                        FROM   #STPDARefOMIDs )
                             --       AND  om_momaterialsbody.modetailsid IN ( SELECT DISTINCT
                             --                                 S_ID AS did
                             --                                FROM
                             --                                 #STPDARefOMIDs )
                             --                                 order by om_momaterialsbody.modetailsid
                            --ORDER BY a.moid ,
                            --        a.modetailsid ,
                            --        a.momaterialsid;                    
                  --删除临时表
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDARefOMIDs') IS NULL )
                                DROP TABLE #STPDARefOMIDs;
                --IF EXISTS ( SELECT  0
                --            WHERE   NOT OBJECT_ID('tempdb..#STPDARefID') IS NULL )
                --    DROP TABLE #STPDARefID;
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDATempOMDIDs') IS NULL )
                                DROP TABLE #STPDATempOMDIDs;
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDATempWhs') IS NULL )
                                DROP TABLE #STPDATempWhs;
                        END;        
                            
                END;
            ELSE
                IF ( @OperType = N'2' )--参照领料申请单生成材料出库单
                    BEGIN

				 --领料申请单行号
                DECLARE @irowno NVARCHAR(30); SET @irowno=N'';
                SET @irowno = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'irowno',
                                                              DEFAULT, DEFAULT);


                --领料申请单主表ID
                        DECLARE @MaterialAppIds NVARCHAR(1000);
                
                        BEGIN
                
                            SET @MaterialAppIds = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MaterialAppIds',
                                                              DEFAULT, DEFAULT);
                            IF ( @MaterialAppIds <> N'' )
                                BEGIN                             
                                    IF EXISTS ( SELECT  0
                                                WHERE   NOT OBJECT_ID('tempdb..#STPDATempMaterialAppIDs') IS NULL )
                                        DROP TABLE #STPDATempMaterialAppIDs;
                    
                                    CREATE   TABLE #STPDATempMaterialAppIDs ( AppId
                                                              INT );
                                    INSERT  INTO #STPDATempMaterialAppIDs
                                            EXEC proc_ts_SplitParamString @MaterialAppIds;
                                END;
                                                              
                        END;

                --领料申请单单号
                        DECLARE @cAppCode NVARCHAR(max);
                        SET @cAppCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cCode',
                                                              DEFAULT, DEFAULT);
				 IF(@cAppCode <> N'')
            BEGIN                             
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempOUTAppCodes') IS NULL )
                    DROP TABLE #STPDATempOUTAppCodes;
                    
                CREATE   TABLE #STPDATempOUTAppCodes ( cAppCode NVARCHAR(30) );
                INSERT  INTO #STPDATempOUTAppCodes
                        EXEC proc_ts_SplitParamString @cAppCode;
            END;





				--领料申请单日期FROM
                        DECLARE @dAppDateFrom VARCHAR(10);
                        SET @dAppDateFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dDateFrom',
                                                              DEFAULT, DEFAULT);
				--领料申请单日期TO
                        DECLARE @dAppDateTo VARCHAR(10);
                        SET @dAppDateTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dDateTo',
                                                              DEFAULT, DEFAULT);
                --领料申请单申请人编码
                        DECLARE @cAppPersonCode NVARCHAR(20);
                        SET @cAppPersonCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cPersonCode',
                                                              DEFAULT, DEFAULT);  
                --领料申请单申请人名称
                        DECLARE @cAppPersonName NVARCHAR(40);
                        SET @cAppPersonName = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cPersonName',
                                                              DEFAULT, DEFAULT);   
                --材料出库类别编码
                        DECLARE @cRdCode NVARCHAR(5);
                        SET @cRdCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cRdCode',
                                                              DEFAULT, DEFAULT);   
                 --材料出库类别编码
                        DECLARE @cRdName NVARCHAR(12);
                        SET @cRdName = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cRdName',
                                                              DEFAULT, DEFAULT);   
                
                        SET NOCOUNT ON;
                   
                        IF EXISTS ( SELECT  0
                                    WHERE   NOT OBJECT_ID('tempdb..#STPDARefMaterialAppIDs') IS NULL )
                            DROP TABLE #STPDARefMaterialAppIDs;
                        SELECT  IDENTITY( INT ) AS tmpId ,
                                CONVERT(INT, 0) AS App_ID ,--领料申请单表头ID
                                CONVERT(MONEY, ufts) AS ufts ,
                                CONVERT(INT, 0) AS APP_AutoID --领料申请单表体ID
                        INTO    #STPDARefMaterialAppIDs
                        FROM    dbo.kcmaterialapplist
                        WHERE   1 = 0; 
                        CREATE CLUSTERED INDEX ix_STPDARefIDs_tmpid_813 ON #STPDARefMaterialAppIDs( App_ID,tmpId,APP_AutoID ); 
 
                        SET @SqlCommand = N'INSERT INTO #STPDARefMaterialAppIDs
								( App_ID ,
								  ufts,
								  APP_AutoID
								)
								SELECT DISTINCT  
										id ,
										ufts ,
										autoid
								 FROM   kcmaterialapplist
								 WHERE  ( 1 = 1 ';
                
                        IF ( @cAppCode <> N'' )
                            --SET @SqlCommand = @SqlCommand
                            --    + N' AND ( kcmaterialapplist.ccode=@cAppCode )';
		           SET @SqlCommand = @SqlCommand+ ' AND (kcmaterialapplist.ccode in (SELECT DISTINCT cAppCode FROM #STPDATempOUTAppCodes)) ';
        
                        IF ( @MaterialAppIds <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (kcmaterialapplist.id IN  (SELECT DISTINCT AppId FROM #STPDATempMaterialAppIDs)) ';
                        IF ( @dAppDateFrom <> N''
                             AND @dAppDateTo <> N''
                           )
                            SET @SqlCommand = @SqlCommand
                                + ' AND ((kcmaterialapplist.ddate >= @dAppDateFrom )
                            AND ( kcmaterialapplist.ddate <= @dAppDateTo )) ';
                        IF ( @DeptCode <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (kcmaterialapplist.cdepcode=@DeptCode) ';

					     IF ( @irowno <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (kcmaterialapplist.irowno=@irowno) ';



                        IF ( @DeptName <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (kcmaterialapplist.cdepname=@DeptName) ';
                        IF ( @cAppPersonCode <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (kcmaterialapplist.cpersoncode = @cAppPersonCode) '; 
                        IF ( @cAppPersonName <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (kcmaterialapplist.cpersonname = @cAppPersonName) '; 
                        IF ( @MaterialWhCode <> N'' )
                   	--现在支持多个仓库（前台传参时仓库编码中间用','隔开）
                            SET @SqlCommand = @SqlCommand
                                + ' AND kcmaterialapplist.cWhCode IN (SELECT DISTINCT cWhCode FROM #STPDATempWhs) ';
                        IF ( @cRdCode <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (kcmaterialapplist.crdcode = @cRdCode) '; 
                        IF ( @cRdName <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (kcmaterialapplist.crdname = @cRdName) '; 
                        IF ( @MaterialDemandDate <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (kcmaterialapplist.dduedate = @MaterialDemandDate) ';
                        IF ( @MaterialInvCode <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (kcmaterialapplist.cinvcode=@MaterialInvCode) ';
                        IF ( @MaterialInvName <> N''
                             AND @MaterialInvName <> N'%%'
                           )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (kcmaterialapplist.cinvname LIKE @MaterialInvName) ';
                        IF ( @MaterialInvAddCode <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (kcmaterialapplist.cinvaddcode =@MaterialInvAddCode) ';
                        IF ( @MaterialInvStd <> N''
                             AND @MaterialInvStd <> N'%%'
                           )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (kcmaterialapplist.cinvstd LIKE @MaterialInvStd) ';
                   
                        SET @SqlCommand = @SqlCommand
                            + N' )
													 AND ( ISNULL(chandler, '''') <> '''') 
											  AND (ISNULL(cbcloser, '''') = '''')
											  AND ( ISNULL(iquantity, 0) <> 0
													OR ISNULL(inum, 0) <> 0
												  )';
                        IF ( @ShowClosed = N'0'
                             AND @bRed = N'0'
                           )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (( CONVERT(DECIMAL(38, 6), ABS(ISNULL(iquantity, 0))
											  - ABS(ISNULL(foutquantity, 0)))) > 0
											  OR ( igrouptype = 2
												   AND CONVERT(DECIMAL(38, 6), ABS(ISNULL(inum, 0))
												   - ABS(ISNULL(foutnum, 0))) > 0
												 ))  AND  ABS(isnull(funoutquantity,0))>0 ';
			    --参照领料申请单（红字）生成材料退库单                  
                        IF ( @bRed = N'1' )
                            SET @SqlCommand = @SqlCommand
                                + N' AND ( ISNULL(foutquantity, 0) > 0
                              OR ISNULL(foutnum, 0) > 0
                            ) ';
                        --PRINT @SqlCommand;
                        SET @ParmList = '@cAppCode				NVARCHAR(30),
									   @MaterialDemandDate		NVARCHAR(10),
									   @MaterialInvCode			NVARCHAR(60),
									   @MaterialInvAddCode      NVARCHAR(255), 
									   @MaterialInvName			NVARCHAR(255),
									   @MaterialInvStd			NVARCHAR(255),
									   @dAppDateFrom			VARCHAR(10),
									   @dAppDateTo				VARCHAR(10),
									   @DeptCode				NVARCHAR(12),
									   @DeptName				NVARCHAR(255),
									   @cAppPersonCode			NVARCHAR(20),
									   @cAppPersonName			NVARCHAR(40),
									   @cRdCode					VARCHAR(5),
									   @cRdName					VARCHAR(12),
									   @irowno  VARCHAR(30)';

                        EXEC sp_executesql @SqlCommand, @ParmList,
                            @cAppCode = @cAppCode,
                            @MaterialDemandDate = @MaterialDemandDate,
                            @MaterialInvCode = @MaterialInvCode,
                            @MaterialInvAddCode = @MaterialInvAddCode,
                            @MaterialInvName = @MaterialInvName,
                            @MaterialInvStd = @MaterialInvStd,
                            @dAppDateFrom = @dAppDateFrom,
                            @dAppDateTo = @dAppDateTo, @DeptCode = @DeptCode,
                            @DeptName = @DeptName,
                            @cAppPersonCode = @cAppPersonCode,
                            @cAppPersonName = @cAppPersonName,
                            @cRdCode = @cRdCode, @cRdName = @cRdName,@irowno=@irowno;
                          
                        
                        SET NOCOUNT OFF;
                --查询领料申请单列表（表头）  
                        SELECT DISTINCT
                                '' AS selcol ,
                              --   b.cmolotcode ,
                                a.imquantity ,
                                --     b.invcode ,
                                 --    b.cmocode ,
                                a.cdepcode ,
                                a.cpersoncode ,
                                a.crdcode ,
                                a.ccode ,
                                CONVERT(VARCHAR(100), a.ddate, 23) AS ddate ,
                                a.cdepname ,
                                a.cpersonname ,
                                a.crdname ,
                                a.cmemo ,
                                a.cdefine1 ,
                                a.cdefine2 ,
                                a.cdefine3 ,
                                a.cdefine4 ,
                                a.cdefine5 ,
                                a.ccloser ,
                                a.cdefine6 ,
                                a.cdefine7 ,
                                a.cdefine8 ,
                                a.cdefine9 ,
                                a.cdefine10 ,
                                a.cdefine11 ,
                                a.cdefine12 ,
                                a.cdefine13 ,
                                a.cdefine14 ,
                                a.cdefine15 ,
                                a.cdefine16 ,
                                a.cmaker ,
                                a.chandler ,
                                a.dveridate ,
                                a.id ,
                                a.cvencode ,
                                a.cvenabbname ,
                                a.ufts ,
                                a.csysbarcode,(case when a.csource='委外订单' then '委外发料' else '' end ) cbustype
                        FROM    materialappm a WITH ( NOLOCK )
                                LEFT JOIN kcmaterialapplist b ON b.id = a.id
                        WHERE   
						1=1
						--autoid IN ( SELECT  DISTINCT
      --                                              APP_AutoID
      --                                      FROM    #STPDARefMaterialAppIDs )
                                AND a.id IN (
                                SELECT DISTINCT
                                        App_ID
                                FROM    #STPDARefMaterialAppIDs );
                   --查询领料申请单材料明细（表体）
                        IF ( @GetType = N'DETAIL' )
                            BEGIN
                                SELECT  a.autoid AS bodyautoid ,
                                        '' AS selcol ,
                                        a.* ,
										a.foutquantity as ireceivedqty,
                                        ( CONVERT(DECIMAL(38, 6), NULL) ) AS fstockanum ,
                                        ( CONVERT(DECIMAL(38, 6), NULL) ) AS fstockaqty ,
                                        ( CONVERT(DECIMAL(38, 6), NULL) ) AS fstocknum ,
                                        ( CONVERT(DECIMAL(38, 6), NULL) ) AS fstockqty ,
                                        Inv.bInvBatch AS binvbatch ,
                                        Inv.bInvQuality AS binvquality ,
                                        Inv.bSerial AS bserial ,
                                        Inv.bBarCode AS bbarcode ,
                                        Inv.bFree1 AS bfree1 ,
                                        Inv.bFree2 AS bfree2 ,
                                        Inv.bFree3 AS bfree3 ,
                                        Inv.bFree4 AS bfree4 ,
                                        Inv.bFree5 AS bfree5 ,
                                        Inv.bFree6 AS bfree6 ,
                                        Inv.bFree7 AS bfree7 ,
                                        Inv.bFree8 AS bfree8 ,
                                        Inv.bFree9 AS bfree9 ,
                                        Inv.bFree10 AS bfree10 ,
                                        0 AS iscanedquantity ,
                                        0 AS iscanednum ,
                                        funoutquantity AS inquantity ,
                                        funoutnum AS innum
                                FROM    kcmaterialapplist a WITH ( NOLOCK )
                                        INNER JOIN dbo.Inventory Inv ON a.cinvcode = Inv.cInvCode
                                WHERE   a.id IN (
                                        SELECT DISTINCT
                                                App_ID
                                        FROM    #STPDARefMaterialAppIDs )
                                        AND a.autoid IN (
                                        SELECT  DISTINCT
                                                APP_AutoID
                                        FROM    #STPDARefMaterialAppIDs )
                                ORDER BY a.id ,
                                        a.autoid; 
                       

					   
					   
					   
					   
					                                  
                  --删除临时表

				  	IF EXISTS ( SELECT  0
                WHERE   NOT OBJECT_ID('tempdb..#STPDATempOUTAppCodes') IS NULL )
                DROP TABLE #STPDATempOUTAppCodes;

                                IF EXISTS ( SELECT  0
                                            WHERE   NOT OBJECT_ID('tempdb..#STPDARefMaterialAppIDs') IS NULL )
                                    DROP TABLE #STPDARefMaterialAppIDs;
             
                                IF EXISTS ( SELECT  0
                                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempMaterialAppIDs') IS NULL )
                                    DROP TABLE #STPDATempMaterialAppIDs;
                                IF EXISTS ( SELECT  0
                                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempWhs') IS NULL )
                                    DROP TABLE #STPDATempWhs;
                            END;
                    END;
                ELSE
                    BEGIN
                        PRINT @OperType;
                    END;
    END;
