﻿/*---------------------------------------------------------------------
* 			Copyright (C) 2018 TECHSCAN 版权所有。
*           www.techscan.cn
*┌────────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．      │
*│　版权所有：上海太迅自动识别技术有限公司 　 　　　　　　　　　　　　    │
*└────────────────────────────────────┘
*
* 文件名：   proc_ts_BarCodeScanCheck.SQL
* 功能：     存储过程
* 描述：     条码在库状态
* 作者：     dxh
* 创建时间： 2019-11-18 15:54:12
* 文件版本： V1.0.0

===============================版本履历===============================
* Ver 		变更日期 				负责人 	变更内容
* V1.0.0	2019-11-18 15:54:12		DXH		Create
--排除单据无效性，获取最新一条扫描记录，这里可能和允许重复扫描冲突，不支持出库数量不等于入库数量的情况
======================================================================
*/
CREATE PROC [dbo].Proc_ts_barcodestatus (@cBarCode NVARCHAR(120))
-- WITH ENCRYPTION
AS
  BEGIN
      DECLARE @cAllowMutipleScanAccValue NVARCHAR(200);

      BEGIN
          DECLARE @hyVouchType NVARCHAR(30);
          DECLARE @bredvouch bit;
		  
          SELECT top 1 @hyVouchType = cvouchtype,
                 @bredvouch = bredvouch
          FROM   (SELECT DISTINCT scan.id,
                                  barcode,
                                  keyval,
                                  scan.cvouchtype,
                                  ( CASE
                                      WHEN scan.cvouchtype = '01' THEN Isnull(R01.cCode, '不存在')
                                      WHEN scan.cvouchtype = '08' THEN Isnull(R08.cCode, '不存在')
                                      WHEN scan.cvouchtype = '09' THEN Isnull(R09.cCode, '不存在')
                                      WHEN scan.cvouchtype = '10' THEN Isnull(R10.cCode, '不存在')
                                      WHEN scan.cvouchtype = '11' THEN Isnull(R11.cCode, '不存在')
                                      WHEN scan.cvouchtype = '32' THEN Isnull(R32.cCode, '不存在')
                                      WHEN scan.cvouchtype = '18' THEN Isnull(R18.cCVCode, '不存在')
                                      ELSE keyval
                                    END ) AS cCode,
                                  ( CASE
                                      WHEN scan.cvouchtype = '01' THEN Isnull(R01.bredvouch, 0)
                                      WHEN scan.cvouchtype = '08' THEN Isnull(R08.bredvouch, 0)
                                      WHEN scan.cvouchtype = '09' THEN Isnull(R09.bredvouch, 0)
                                      WHEN scan.cvouchtype = '10' THEN Isnull(R10.bredvouch, 0)
                                      WHEN scan.cvouchtype = '11' THEN Isnull(R11.bredvouch, 0)
                                      WHEN scan.cvouchtype = '32' THEN Isnull(R32.bredvouch, 0)
                                      ELSE 0
                                    END ) AS bredvouch
                  FROM   hy_bar_scandetails scan WITH ( NOLOCK )
                         LEFT JOIN (select distinct  cCode,(case when rdrecords01.iQuantity<0 then 1 else 0 end) bredvouch from  RdRecord01  WITH ( NOLOCK )
left join rdrecords01   WITH ( NOLOCK ) on rdrecords01.id=RdRecord01.ID) R01
                                ON scan.cvouchtype = '01'
                                   AND scan.keyval = R01.cCode
                         LEFT JOIN (select distinct  cCode,(case when rdrecords08.iQuantity<0 then 1 else 0 end) bredvouch from  RdRecord08  WITH ( NOLOCK )
left join rdrecords08   WITH ( NOLOCK ) on rdrecords08.id=RdRecord08.ID) R08
                                ON scan.cvouchtype = '08'
                                   AND scan.keyval = R08.cCode
                         LEFT JOIN (select distinct  cCode,(case when rdrecords09.iQuantity<0 then 1 else 0 end) bredvouch from  RdRecord09  WITH ( NOLOCK )
left join rdrecords09   WITH ( NOLOCK ) on rdrecords09.id=RdRecord09.ID) R09
                                ON scan.cvouchtype = '09'
                                   AND scan.keyval = R09.cCode
                         LEFT JOIN (select distinct  cCode,(case when rdrecords10.iQuantity<0 then 1 else 0 end) bredvouch from  RdRecord10  WITH ( NOLOCK )
left join rdrecords10   WITH ( NOLOCK ) on rdrecords10.id=RdRecord10.ID) R10
                                ON scan.cvouchtype = '10'
                                   AND scan.keyval = R10.cCode
                         LEFT JOIN (select distinct  cCode,(case when rdrecords11.iQuantity<0 then 1 else 0 end) bredvouch from  RdRecord11  WITH ( NOLOCK )
left join rdrecords11   WITH ( NOLOCK ) on rdrecords11.id=RdRecord11.ID) R11
                                ON scan.cvouchtype = '11'
                                   AND scan.keyval = R11.cCode
                         LEFT JOIN (select distinct  cCode,(case when rdrecords32.iQuantity<0 then 1 else 0 end) bredvouch from  RdRecord32  WITH ( NOLOCK )
left join rdrecords32   WITH ( NOLOCK ) on rdrecords32.id=RdRecord32.ID) R32
                                ON scan.cvouchtype = '32'
                                   AND scan.keyval = R32.cCode
                         LEFT JOIN CheckVouch R18 WITH ( NOLOCK )
                                ON scan.cvouchtype = '18'
                                   AND scan.keyval = R18.cCVCode
                  WHERE  barcode <> cinvcode)A
          WHERE  A.cCode <> '不存在'
                 AND barcode = @cBarCode
          ORDER  BY ID DESC;

          IF ( @@ROWCOUNT = 0 )
            BEGIN
                select  '新建';
                return;
            END;

          IF ( @hyVouchType = '01'
                OR @hyVouchType = '10'
                OR @hyVouchType = '08'
                OR @hyVouchType = '18' )
            BEGIN
                IF( @bredvouch = 0 )
                  select '入库';
                ELSE
                  select '出库';
                   return;
            END;
          ELSE IF ( @hyVouchType = '32'
                OR @hyVouchType = '11'
                OR @hyVouchType = '09' )
            BEGIN
                IF( @bredvouch = 0 )
                  select '出库';
                ELSE
                  select '入库';
                   return;
            END;
          ELSE
            select '入库'; return;
      END;
  END; 
