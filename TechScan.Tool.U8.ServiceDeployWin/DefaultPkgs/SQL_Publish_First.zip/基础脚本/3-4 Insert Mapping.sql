﻿delete  ts_VoucherFields_Mapping where 1=1
--*********采购到货:BCArr************
--来源：采购订单
insert into ts_VoucherFields_Mapping values('H','cpocode','BCArrH','itaxrate','itaxrate',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','cpocode','BCArrH','cordercode','cpocode',NULL,1,NULL)

--insert into ts_VoucherFields_Mapping values('B','cpocode','BCArrD','bgsp','bgsp',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cpocode','BCArrD','cordercode','cordercode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cpocode','BCArrD','corufts','ufts_source',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cpocode','BCArrD','itaxprice','iOriTaxCost',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cpocode','BCArrD','iunitprice','iOriCost',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cpocode','BCArrD','itaxrate','itaxrate',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cpocode','BCArrD','id','iposid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('D','cpocode','BCArrD','cPayCode','cPayCode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('D','cpocode','BCArrD','fPoValidNum','fValidNum',NULL,1,NULL)

--对应扫描明细的来源单号 dxh 191216
insert into ts_VoucherFields_Mapping values('B','cpocode','BCArrD','ccode','csrccode',NULL,1,NULL)

--来源：拒收单
insert into ts_VoucherFields_Mapping values('B','refusecode','BCArrD','iposid','iposid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','refusecode','BCArrD','cordercode','cordercode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','refusecode','BCArrD','irowno','irowno',NULL,1,NULL)   
insert into ts_VoucherFields_Mapping values('B','refusecode','BCArrD','corufts','corufts',NULL,1,NULL)       
insert into ts_VoucherFields_Mapping values('B','refusecode','BCArrD','bgift','bgift',NULL,1,NULL)    
insert into ts_VoucherFields_Mapping values('B','refusecode','BCArrD','iordertype','iordertype',NULL,1,NULL)      
insert into ts_VoucherFields_Mapping values('B','refusecode','BCArrD','iorderdid','iorderdid', NULL,1,NULL)     
insert into ts_VoucherFields_Mapping values('B','refusecode','BCArrD','iorderseq','iorderseq',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','refusecode','BCArrD','csoordercode','csoordercode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','refusecode','BCArrD','csocode','csocode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','refusecode','BCArrD','sodid','sodid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','refusecode','BCArrD','sotype','sotype',NULL,1,NULL)      
insert into ts_VoucherFields_Mapping values('B','refusecode','BCArrD','bexigency','bexigency',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','refusecode','BCArrD','iexpiratdatecalcu','iexpiratdatecalcu',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','refusecode','BCArrD','autoid','icorid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','refusecode','BCArrD','ccode','carrivalcode',NULL,1,NULL)

--对应扫描明细的来源单号 dxh 191216
insert into ts_VoucherFields_Mapping values('B','refusecode','BCArrD','ccode','csrccode',NULL,1,NULL)


--*********委外到货:BCWWArr************
--来源：委外订单
insert into ts_VoucherFields_Mapping values('H','cpocode','BCWWArrH','ccode','cpocode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','cpocode','BCWWArrH','cexch_name','cexch_name',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','cpocode','BCWWArrH','iexchrate','iexchrate',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','cpocode','BCWWArrH','itaxrate','itaxrate',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('D','cpocode','BCWWArrH','cPayCode','cPayCode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('D','cpocode','BCWWArrH','cDefine7','cDefine7',NULL,1,NULL)

insert into ts_VoucherFields_Mapping values('B','cpocode','BCWWArrD','modetailsid','iposid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cpocode','BCWWArrD','sotype','sotype',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cpocode','BCWWArrD','ccode','cordercode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cpocode','BCWWArrD','iexpiratdatecalcu','iexpiratdatecalcu',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cpocode','BCWWArrD','iordertype','iordertype',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cpocode','BCWWArrD','iorderseq','iorderseq',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cpocode','BCWWArrD','csoordercode','csoordercode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cpocode','BCWWArrD','iorderdid','iorderdid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cpocode','BCWWArrD','iproducttype','iproducttype',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cpocode','BCWWArrD','isourcemocode','isourcemocode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cpocode','BCWWArrD','isourcemodetailsid','isourcemodetailsid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cpocode','BCWWArrD','btaxcost','btaxcost',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cpocode','BCWWArrD','itaxrate','itaxrate',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cpocode','BCWWArrD','itaxprice','ioritaxcost',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cpocode','BCWWArrD','iunitprice','ioricost',NULL,1,NULL)
-- insert into ts_VoucherFields_Mapping values('B','cpocode','BCWWArrD','bgsp','bgsp',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('D','cpocode','BCWWArrD','cDefine26','cDefine26',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('D','cpocode','BCWWArrD','cDefine27','cDefine27',NULL,1,NULL)

--对应扫描明细的来源单号 dxh 191216
insert into ts_VoucherFields_Mapping values('B','cpocode','BCWWArrD','ccode','csrccode',NULL,1,NULL)



--*********采购入库:BCPur************
--来源：采购订单
insert into ts_VoucherFields_Mapping values('H','cordercode','BCPurH','poid','ipurorderid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','cordercode','BCPurH','cvencode','cvencode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','cordercode','BCPurH','nflat','iexchrate',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','cordercode','BCPurH','cDepCode','cDepCode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','cordercode','BCPurH','cPTCode','cPTCode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','cordercode','BCPurH','cpoid','cOrderCode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','cordercode','BCPurH','itaxrate','itaxrate',NULL,1,NULL)

insert into ts_VoucherFields_Mapping values('B','cordercode','BCPurD','ipertaxrate','itaxrate',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cordercode','BCPurD','iUnitPrice','iOriCost',NULL,1,NULL)

--对应扫描明细的来源单号 dxh 191216
insert into ts_VoucherFields_Mapping values('B','cordercode','BCPurD','ccode','csrccode',NULL,1,NULL)


-- 暂估单价 dxh 190426
insert into ts_VoucherFields_Mapping values('B','cordercode','BCPurD','iUnitPrice','fACost',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cordercode','BCPurD','iTaxPrice','iOriTaxCost',NULL,1,NULL)
Insert Into ts_VoucherFields_Mapping values('B','cordercode','BCPurD','SoDid','iorderdid',null,1,null)
Insert Into ts_VoucherFields_Mapping values('B','cordercode','BCPurD','csocode','iordercode',null,1,null)
Insert Into ts_VoucherFields_Mapping values('B','cordercode','BCPurD','irowno','iorderseq',null,1,null)
Insert Into ts_VoucherFields_Mapping values('B','cordercode','BCPurD','SoDid','isodid',null,1,null)
Insert Into ts_VoucherFields_Mapping values('B','cordercode','BCPurD','SOType','isotype',null,1,null)
Insert Into ts_VoucherFields_Mapping values('B','cordercode','BCPurD','irowno','isoseq',null,1,null)
insert into ts_VoucherFields_Mapping values('B','cordercode','BCPurD','id','iposid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cordercode','BCPurD','ccode','cPOID',NULL,1,NULL)

--来源：委外订单
insert into ts_VoucherFields_Mapping values('H','Outsourcing','BCPurH','nflat','iexchrate',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','Outsourcing','BCPurH','ccode','cordercode',NULL,1,NULL)

-- insert into ts_VoucherFields_Mapping values('H','Outsourcing','BCPurH','ccode','ipurorderid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','Outsourcing','BCPurH','moid','ipurorderid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','Outsourcing','BCPurH','itaxrate','itaxrate',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','Outsourcing','BCPurH','cexch_name','cexch_name',NULL,1,NULL)

-- insert into ts_VoucherFields_Mapping values('B','Outsourcing','BCPurD','moid','iomodid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','Outsourcing','BCPurD','modetailsid','iomodid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','Outsourcing','BCPurD','coufts','coufts',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','Outsourcing','BCPurD','ipertaxrate','itaxrate',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','Outsourcing','BCPurD','ccode','comcode',NULL,1,NULL)
--加工费

--加工单价
insert into ts_VoucherFields_Mapping values('B','Outsourcing','BCPurD','iunitprice','iProcessCost',NULL,1,NULL)
--对应扫描明细的来源单号 dxh 191216
insert into ts_VoucherFields_Mapping values('B','Outsourcing','BCPurD','ccode','csrccode',NULL,1,NULL)

--


--来源：采购到货
insert into ts_VoucherFields_Mapping values('H','carvcode','BCPurH','cptcode','cptcode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','carvcode','BCPurH','cDepCode','cDepCode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','carvcode','BCPurH','cPTCode','cPTCode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','carvcode','BCPurH','ID','ipurarriveid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','carvcode','BCPurH','itaxrate','itaxrate',NULL,1,NULL)

insert into ts_VoucherFields_Mapping values('B','carvcode','BCPurD','iposid','iposid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','carvcode','BCPurD','autoid','iarrsid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','carvcode','BCPurD','ipertaxrate','itaxrate',NULL,1,NULL)
Insert Into ts_VoucherFields_Mapping values('B','carvcode','BCPurD','SoDid','iorderdid',null,1,null)		
Insert Into ts_VoucherFields_Mapping values('B','carvcode','BCPurD','csocode','iordercode',null,1,null)	
Insert Into ts_VoucherFields_Mapping values('B','carvcode','BCPurD','irowno','iorderseq',null,1,null)	
Insert Into ts_VoucherFields_Mapping values('B','carvcode','BCPurD','SoDid','isodid',null,1,null)	
Insert Into ts_VoucherFields_Mapping values('B','carvcode','BCPurD','SOType','isotype',null,1,null)
Insert Into ts_VoucherFields_Mapping values('B','carvcode','BCPurD','irowno','isoseq',null,1,null)	
--对应扫描明细的来源单号 dxh 191216
insert into ts_VoucherFields_Mapping values('B','carvcode','BCPurD','ccode','csrccode',NULL,1,NULL)



--来源：委外到货
insert into ts_VoucherFields_Mapping values('H','OutsourcingArrival','BCPurH','ccode','carvcode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','OutsourcingArrival','BCPurH','iexchrate','iexchrate',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','OutsourcingArrival','BCPurH','cexch_name','cexch_name',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','OutsourcingArrival','BCPurH','itaxrate','itaxrate',NULL,1,NULL)

insert into ts_VoucherFields_Mapping values('B','OutsourcingArrival','BCPurD','autoid','iarrsid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','OutsourcingArrival','BCPurD','iposid','iomodid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','OutsourcingArrival','BCPurD','ipertaxrate','itaxrate',NULL,1,NULL)
--加工费

--加工单价
insert into ts_VoucherFields_Mapping values('B','OutsourcingArrival','BCPurD','iunitprice','iProcessCost',NULL,1,NULL)

--对应扫描明细的来源单号 dxh 191216
insert into ts_VoucherFields_Mapping values('B','OutsourcingArrival','BCPurD','ccode','csrccode',NULL,1,NULL)

--来源：检验单
insert into ts_VoucherFields_Mapping values('H','cchkcode','BCPurH','sourcecode','cARVCode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','cchkcode','BCPurH','sourceautoid','iArrsid ',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','cchkcode','BCPurH','ccheckcode','cChkCode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','cchkcode','BCPurH','crdcode','crdcode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','cchkcode','BCPurH','cptcode','cptcode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','cchkcode','BCPurH','cinspectdepcode','cDepCode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','cchkcode','BCPurH','cvenpuomprotocol','cvenpuomprotocol',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','cchkcode','BCPurH','titaxrate','itaxrate',NULL,1,NULL)
--insert into ts_VoucherFields_Mapping values('H','cchkcode','BCPurH','itaxrate','itaxrate',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','cchkcode','BCPurH','cpocode','cOrderCode',NULL,1,NULL)

insert into ts_VoucherFields_Mapping values('B','cchkcode','BCPurD','bodyautoid','iCheckIdBaks',NULL,1,NULL)
-- 检验日期
--insert into ts_VoucherFields_Mapping values('B','cchkcode','BCPurD','ddate','dCheckDate',NULL,1,NULL)
--到货日期
--insert into ts_VoucherFields_Mapping values('B','cchkcode','BCPurD','darrivaldate','dbarvdate',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cchkcode','BCPurD','iposid','iposid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cchkcode','BCPurD','sourceautoid','iarrsid',NULL,1,NULL)
-- insert into ts_VoucherFields_Mapping values('B','cchkcode','BCPurD','bodyautoid','imergecheckautoid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cchkcode','BCPurD','cpocode','cpoid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cchkcode','BCPurD','sourcecode','cbarvcode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cchkcode','BCPurD','ccheckpersoncode','ccheckpersoncode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cchkcode','BCPurD','bitaxrate','itaxrate',NULL,1,NULL)

--对应扫描明细的来源单号 dxh 191216
insert into ts_VoucherFields_Mapping values('B','cchkcode','BCPurD','ccheckcode','csrccode',NULL,1,NULL)


--*********产成品入库:BCPrdIn************
--来源：生产订单
insert into ts_VoucherFields_Mapping values('H','cmpocode','BCPrdInH','moid','iproorderid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','cmpocode','BCPrdInH','mocode','cmpocode',NULL,1,NULL)


insert into ts_VoucherFields_Mapping values('B','cmpocode','BCPrdInD','modid','impoids',NULL,1,NULL)
-- dxh  增加生产订单号返回
insert into ts_VoucherFields_Mapping values('B','cmpocode','BCPrdInD','ccode','cmocode',NULL,1,NULL)
Insert Into ts_VoucherFields_Mapping values('B','cmpocode','BCPrdInD','SoDid','iorderdid',null,1,null)		
Insert Into ts_VoucherFields_Mapping values('D','cmpocode','BCPrdInD','cSoCode','iordercode',null,1,null)	
Insert Into ts_VoucherFields_Mapping values('D','cmpocode','BCPrdInD','iSoSeq','iorderseq',null,1,null)	
Insert Into ts_VoucherFields_Mapping values('D','cmpocode','BCPrdInD','SoDid','isodid',null,1,null)	
Insert Into ts_VoucherFields_Mapping values('D','cmpocode','BCPrdInD','csocode','csocode',null,1,null)	
Insert Into ts_VoucherFields_Mapping values('D','cmpocode','BCPrdInD','iSoSeq','isoseq',null,1,null)	
Insert Into ts_VoucherFields_Mapping values('D','cmpocode','BCPrdInD','SoType','isotype',null,1,null)	
Insert Into ts_VoucherFields_Mapping values('D','cmpocode','BCPrdInD','SoType','iordertype',null,1,null)
insert into ts_VoucherFields_Mapping values('D','cmpocode','BCPrdInD','OrderDId','iorderdid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('D','cmpocode','BCPrdInD','OrderType','iordertype',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('D','cmpocode','BCPrdInD','SoType','isotype',NULL,1,NULL)	
--dxh add 换算率 时间戳190425

insert into ts_VoucherFields_Mapping values('D','cmpocode','BCPrdInD','changerate','iinvexchrate',NULL,1,NULL)	
insert into ts_VoucherFields_Mapping values('D','cmpocode','BCPrdInD','ufts','corufts',NULL,1,NULL)	


--对应扫描明细的来源单号 dxh 191216
insert into ts_VoucherFields_Mapping values('B','cmpocode','BCPrdInD','ccode','csrccode',NULL,1,NULL)


--*********销售出库:BCSaleOut************
--来源：发货单
insert into ts_VoucherFields_Mapping values('H','iarriveid','BCSaleOutH','caddcode','caddcode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','iarriveid','BCSaleOutH','cbillname','csource',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','iarriveid','BCSaleOutH','dlid','cdlcode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','iarriveid','BCSaleOutH','cstcode','cstcode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','iarriveid','BCSaleOutH','cshipaddress','cshipaddress',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','iarriveid','BCSaleOutH','cinvoicecompany','cinvoicecompany','',1,NULL)
insert into ts_VoucherFields_Mapping values('H','iarriveid','BCSaleOutH','cgcroutecode','cgcroutecode','',1,NULL)
insert into ts_VoucherFields_Mapping values('H','iarriveid','BCSaleOutH','cgcroutename','cgcroutename','',1,NULL)
insert into ts_VoucherFields_Mapping values('H','iarriveid','BCSaleOutH','cinvoicecompanyabbname','cinvoicecompanyabbname','',1,NULL)
insert into ts_VoucherFields_Mapping values('H','iarriveid','BCSaleOutH','cdlcode','cbuscode',NULL,1,NULL)

insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','idlsid','idlsid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','iexpiratdatecalcu','iexpiratdatecalcu',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','citemcode','citemcode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','citem_class','citem_class',NULL,1,NULL)
--insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','isosid','iorderdid',NULL,1,NULL)
--insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','isotype','iordertype',NULL,1,NULL)
--insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','isocode','iordercode',NULL,1,NULL)
--insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','iorderrowno','iorderseq',NULL,1,NULL)
--insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','IDcdemandid','isodid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','cdemandcode','csocode ',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','idemandseq','isoseq ',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','bneedbill','bneedbill',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','idemandtype','isotype',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','cbdlcode','cbdlcode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','cbdlcode','csrccode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','corufts','corufts',NULL,1,NULL)
--insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','iordertype','iordertype',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','ipesodid','ipesodid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','ipesotype','ipesotype',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','cpesocode','cpesocode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','ipesoseq','ipesoseq',NULL,1,NULL)
--insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','isodemandtype','isotype',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','bgsp','bgsp',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','cvmivencode','cvmivencode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','cvmivenname','cvmivenname',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','ccusinvcode','ccusinvcode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','ccusinvname','ccusinvname',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('D','iarriveid','BCSaleOutH','cDefine7','cDefine7',NULL,1,NULL)
--Insert Into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','iorderdid','iorderdid',null,1,null)		
--Insert Into ts_VoucherFields_Mapping values('D','iarriveid','BCSaleOutD','iordertype','iordertype',null,1,null)	
--Insert Into ts_VoucherFields_Mapping values('D','iarriveid','BCSaleOutD','iordercode','iordercode',null,1,null)	
--Insert Into ts_VoucherFields_Mapping values('D','iarriveid','BCSaleOutD','iorderseq','iorderseq',null,1,null)	
--Insert Into ts_VoucherFields_Mapping values('D','iarriveid','BCSaleOutD','iorderdid','isodid',null,1,null)	
Insert Into ts_VoucherFields_Mapping values('D','iarriveid','BCSaleOutD','iordercode','cSoCode',null,1,null)	
Insert Into ts_VoucherFields_Mapping values('D','iarriveid','BCSaleOutD','iorderseq','isoseq',null,1,null)	

--对应扫描明细的来源单号 dxh 191216
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','csocode','csrccode',NULL,1,NULL)


-- 戈尔德 190907 需求跟踪  待研究部分
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','cdemandid','isodid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','isosid','iorderdid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','isotype','iordertype',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','csocode','iordercode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','csocode','isocode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','iarriveid','BCSaleOutD','iorderrowno','iorderseq',NULL,1,NULL)
--end

--Insert Into ts_VoucherFields_Mapping values('D','iarriveid','BCSaleOutD','iordertype','isotype',null,1,null)	

--*********材料出库:BCMaOut************
--来源：生产订单
insert into ts_VoucherFields_Mapping values('H','cmpocode','BCMaOutH','moid','iproorderid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','cmpocode','BCMaOutH','mocode','cmpocode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','cmpocode','BCMaOutH','cinvcode','cPsPcode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','cmpocode','BCMaOutH','impqty','iMQuantity',NULL,1,NULL)

insert into ts_VoucherFields_Mapping values('B','cmpocode','BCMaOutD','allocateid','impoids',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','cmpocode','BCMaOutD','mocode','cmocode',NULL,1,NULL)
--Insert Into ts_VoucherFields_Mapping values('B','cmpocode','BCMaOutD','SoDid','iorderdid',null,1,null)
Insert Into ts_VoucherFields_Mapping values('B','cmpocode','BCMaOutD','SoDid','isodid',null,1,null)
--insert into ts_VoucherFields_Mapping values('D','cmpocode','BCMaOutD','SoDId','ipesodid',NULL,1,NULL)
Insert Into ts_VoucherFields_Mapping values('B','cmpocode','BCMaOutD','socode','csocode',null,1,null)
--Insert Into ts_VoucherFields_Mapping values('B','cmpocode','BCMaOutD','SoCode','iordercode',null,1,null)
--insert into ts_VoucherFields_Mapping values('D','cmpocode','BCMaOutD','SoCode','cpesocode',NULL,1,NULL)
--Insert Into ts_VoucherFields_Mapping values('B','cmpocode','BCMaOutD','SoSeq','iorderseq',null,1,null)
Insert Into ts_VoucherFields_Mapping values('B','cmpocode','BCMaOutD','SoSeq','isoseq',null,1,null)
--insert into ts_VoucherFields_Mapping values('D','cmpocode','BCMaOutD','SoSeq','ipesoseq',NULL,1,NULL)
Insert Into ts_VoucherFields_Mapping values('B','cmpocode','BCMaOutD','SoType','isotype',null,1,null)
--Insert Into ts_VoucherFields_Mapping values('B','cmpocode','BCMaOutD','SoType','iordertype',null,1,null)
insert into ts_VoucherFields_Mapping values('D','cmpocode','BCMaOutD','ipesotype','ipesotype',NULL,1,NULL)
--insert into ts_VoucherFields_Mapping values('D','cmpocode','BCMaOutD','SortSeq','imoseq',NULL,1,NULL)
--insert into ts_VoucherFields_Mapping values('D','cmpocode','BCMaOutD','OrderDId','iorderdid',NULL,1,NULL)
--insert into ts_VoucherFields_Mapping values('D','cmpocode','BCMaOutD','OrderType','iordertype',NULL,1,NULL)
--insert into ts_VoucherFields_Mapping values('D','cmpocode','BCMaOutD','InvCode','InvCode',NULL,1,NULL)

--来源：委外订单
insert into ts_VoucherFields_Mapping values('H','Outsourcing','BCMaOutH','ccode','cbuscode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','Outsourcing','BCMaOutH','iqty','imquantity',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','Outsourcing','BCMaOutH','cinvcode','cpspcode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','Outsourcing','BCMaOutH','cmpocode1','cmpocode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','Outsourcing','BCMaOutH','moid','iproorderid',NULL,1,NULL)

insert into ts_VoucherFields_Mapping values('B','Outsourcing','BCMaOutD','iomodid','iomodid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','Outsourcing','BCMaOutD','momaterialsid','iomomid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','Outsourcing','BCMaOutD','cpspcode','invcode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','Outsourcing','BCMaOutD','ordertype','iordertype',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','Outsourcing','BCMaOutD','orderdid','iorderdid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','Outsourcing','BCMaOutD','ordercode','iordercode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','Outsourcing','BCMaOutD','orderseq','iorderseq',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','Outsourcing','BCMaOutD','idemandtype','isotype',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','Outsourcing','BCMaOutD','cdemandid','isodid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','Outsourcing','BCMaOutD','cdemandcode','csocode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','Outsourcing','BCMaOutD','idemandseq','isoseq',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','Outsourcing','BCMaOutD','ipesodid','ipesodid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','Outsourcing','BCMaOutD','cpesocode','cpesocode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','Outsourcing','BCMaOutD','ccode','comcode',NULL,1,NULL)

--来源：领料申请单
insert into ts_VoucherFields_Mapping values('H','MaterialApp','BCMaOutH','ccode','cbuscode',NULL,1,NULL)

insert into ts_VoucherFields_Mapping values('B','MaterialApp','BCMaOutD','autoid','imaids',NULL,1,NULL)

--对应扫描明细的来源单号 dxh 191216
insert into ts_VoucherFields_Mapping values('B','MaterialApp','BCMaOutD','csocode','csrccode',NULL,1,NULL)

--*********调拨:BCTrans************
insert into ts_VoucherFields_Mapping values('B','ctranrequestcode','BCTransD','autoid','itrids',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','ctranrequestcode','BCTransD','ctvcode','csrccode',NULL,1,NULL)
 

--*********盘点:BCStocktackH************
insert into ts_VoucherFields_Mapping values('H','ccvcode','BCStocktackH','id','id',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','ccvcode','BCStocktackH','ccvtype','ccvtype',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','ccvcode','BCStocktackH','checkvouchtype','checkvouchtype',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','ccvcode','BCStocktackH','bposcheck','bposcheck',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','ccvcode','BCStocktackH','buploaded','buploaded',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','ccvcode','BCStocktackH','dacdate','dacdate',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('H','ccvcode','BCStocktackH','dcvdate','dcvdate',NULL,1,NULL)

insert into ts_VoucherFields_Mapping values('B','ccvcode','BCStocktackD','ccvcode','ccvcode',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','ccvcode','BCStocktackD','autoid','autoid',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','ccvcode','BCStocktackD','id','id',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','ccvcode','BCStocktackD','cbufts','cbufts',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','ccvcode','BCStocktackD','icvquantity','icvquantity',NULL,1,NULL)
insert into ts_VoucherFields_Mapping values('B','ccvcode','BCStocktackD','icvnum','icvnum',NULL,1,NULL)