﻿ /*---------------------------------------------------------------------
* 			Copyright (C) 2018 TECHSCAN 版权所有。
*           www.techscan.cn
*┌────────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．      │
*│　版权所有：上海太迅自动识别技术有限公司 　 　　　　　　　　　　　　    │
*└────────────────────────────────────┘
*
* 文件名：   proc_ts_KC_BoxSplit.SQL
* 功能：     存储过程
* 描述：     KC条码模块-拆箱操作
* 作者：     马永龙
* 创建时间： 2018-11-18 15:04:23
* 文件版本： V1.0.0

===============================版本履历===============================
* Ver 		变更日期 				负责人 	变更内容
* V1.0.0	2018-11-18 15:04:23		Myl		Create

======================================================================
//--------------------------------------------------------------------*/
 CREATE PROC [dbo].[proc_ts_KC_BoxSplit]
    (
      --拆箱类型（0：箱子内拆存货；1：箱子内拆箱子）
      --@iSplitType TINYINT = 0 ,
      @cBoxCode NVARCHAR(120) ,
      @cBarCode NVARCHAR(120) ,
      @iUnBoxQty DECIMAL = 0 ,
      @iUnBoxNum DECIMAL = 0
      --@bAllUnBoxed TINYINT = 0
    )
 AS
    BEGIN

        IF ( @cBoxCode = N'' )
            RAISERROR ('未提供箱码！',16, 1 );
        IF ( @cBarCode = N'' )
            RAISERROR ('未提供条码！',16, 1 );
        DECLARE @bMultiLayer TINYINT;
        DECLARE @BoxID BIGINT;
        SELECT DISTINCT TOP 1
                @BoxID = ID
        FROM    dbo.KC_BoxUps WITH ( NOLOCK )
        WHERE   cBoxCode = @cBoxCode order by ID desc ;
        IF ( @@ROWCOUNT = 0 )
            BEGIN
                RAISERROR('系统中未找到箱码%s对应的装箱单内容！',16,1, @cBoxCode);
            END;
        SELECT  @bMultiLayer = ISNULL(bMultiLayer, 0)
        FROM    dbo.KC_BoxUp WITH ( NOLOCK )
        WHERE   ID = @BoxID order by ID desc;
        
        --Memo：目前U8装箱单，多层装箱时，必定是箱子内装箱子，所以如果是多层装箱的情况下拆箱，必定是将大箱子内的小箱子整个拆出
        --Myl 20181118
        IF ( @bMultiLayer = 1 )
            BEGIN
            --多层装箱
                UPDATE  dbo.KC_BoxUps
                SET     iUnBoxQty = iQuantity ,
                        iUnBoxNum = iNum ,
                        bAllUnBoxed = 1
                WHERE   ID = @BoxID
                        AND cBoxCode = @cBoxCode
                        AND isnull(KC_BoxUps.iUnBoxQty,0)<KC_BoxUps.iQuantity
                        AND (cBarCode = @cBarCode OR (cBarCode is null and cinvcode=@cBarCode)) ;
            END;
        ELSE
            BEGIN
            --单层装箱
                IF ( @iUnBoxQty <= 0 )
                    BEGIN
                        RAISERROR ('未提供有效的拆箱数量！',16, 1 );
                    END;
            
                UPDATE  dbo.KC_BoxUps
                SET     iUnBoxQty = ISNULL(iUnBoxQty, 0) + @iUnBoxQty ,
                        iUnBoxNum = ISNULL(iUnBoxNum, 0)
                        + ( CASE WHEN I.iGroupType = 0 THEN NULL
                                 WHEN I.iGroupType = 1
                                 THEN @iUnBoxQty / KC_BoxUps.iinvexchrate
                                 ELSE @iUnBoxNum
                            END ) ,
                        bAllUnBoxed = ( CASE WHEN ISNULL(iUnBoxQty, 0)
                                                  + @iUnBoxQty = iQuantity
                                             THEN 1
                                             ELSE 0
                                        END )
                FROM    dbo.Inventory I  WITH (NOLOCK) 
                WHERE   KC_BoxUps.cInvCode = I.cInvCode
                        AND KC_BoxUps.ID = @BoxID
                        AND KC_BoxUps.cBoxCode = @cBoxCode
                        AND isnull(KC_BoxUps.iUnBoxQty,0)<KC_BoxUps.iQuantity
                        AND (KC_BoxUps.cBarCode = @cBarCode OR (KC_BoxUps.cBarCode is null and KC_BoxUps.cInvCode=@cBarCode));
            END;
 
    END;