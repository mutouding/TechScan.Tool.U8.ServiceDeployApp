﻿/*---------------------------------------------------------------------
* 			Copyright (C) 2018 TECHSCAN 版权所有。
*           www.techscan.cn
*┌──────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．　│
*│　版权所有：上海太迅自动识别技术有限公司 　 　　　　　　　　　　　　│
*└──────────────────────────────────┘
*
* 文件名：   BatchGetVoucherList
* 功能描述： 批量查询单据列表SQL脚本片段
* 作者：     马永龙
* CLR版本：  4.0.30319.42000
* 创建时间： 2018-02-09 11:32:12
* 文件版本： V1.0.0

===============================版本履历===============================
* Ver 		变更日期 			负责人 	变更内容
* V1.0.0	2018-02-09 11:32:12	Myl		Create
*
======================================================================
//--------------------------------------------------------------------*/
 

--批量查询单据列表SQL脚本片段
--Myl 20180209

--批量查询单据列表SQL脚本片段
--Myl 20180209

DECLARE @ParmList NVARCHAR(MAX);
DECLARE @SqlCommand NVARCHAR(MAX) ;
DECLARE @dDateFrom NCHAR(10);
DECLARE @dDateTo NCHAR(10) ;
DECLARE @cMaker NVARCHAR(20) ;
DECLARE @cWhCode NVARCHAR(10) ;
DECLARE @cCodeFrom NVARCHAR(30) ;
DECLARE @cCodeTo NVARCHAR(30);
DECLARE @cDepCode NVARCHAR(12);
DECLARE @cVoucherStatus NVARCHAR(20)
--单据列表视图名称
--DECLARE @VoucherListViewName NVARCHAR(20) = N'recordoutlist';
DECLARE @cVoucherType NCHAR(2);

SET @ParmList = N'';
SET @SqlCommand  = N'';
SET @dDateFrom = N'';
SET @dDateTo = N'';
SET @cMaker = N'demo';
SET @cWhCode  = N'1001';
SET @cCodeFrom = N'';
SET @cCodeTo = N'';
SET @cDepCode  = N'';
SET @cVoucherStatus = N'';
SET @cVoucherType = N'11';





SET @SqlCommand = 'SELECT  * FROM  recordoutlist WITH (NOLOCK) WHERE cvouchtype=@cVoucherType AND 1=1 ';
IF @dDateFrom <> N''
    AND @dDateTo <> N''
    SET @SqlCommand = @SqlCommand
        + ' AND ((ddate>=@dDateFrom) AND (ddate<=@dDateTo)) ';
IF @cMaker <> N''
    SET @SqlCommand = @SqlCommand + ' AND (cMaker=@cMaker) ';
IF @cWhCode <> N''
    SET @SqlCommand = @SqlCommand + ' AND (cwhcode=@cWhCode) ';	
IF @cCodeFrom <> N''
    AND @cCodeTo <> N''
    SET @SqlCommand = @SqlCommand
        + ' AND ((ccode>=@cCodeFrom) AND (ccode<=@cCodeTo)) ';	
IF @cDepCode <> N''
    SET @SqlCommand = @SqlCommand + ' AND (cdepcode=@cDepCode) ';		
IF @cVoucherStatus <> N''
    SET @SqlCommand = @SqlCommand + ' AND (cvoucherstate=@cVoucherStatus) ';	
SET @SqlCommand = @SqlCommand + N'ORDER BY autoid;';
	--PRINT @SqlCommand
SET @ParmList = '@dDateFrom NCHAR(10),
				 @dDateTo NCHAR(10),
				 @cMaker NVARCHAR(20),
				 @cWhCode NVARCHAR(10),
				 @cCodeFrom NVARCHAR(30),
				 @cCodeTo NVARCHAR(30),
				 @cDepCode NVARCHAR(12),
				 @cVoucherStatus NVARCHAR(20),
				 @cVoucherType NCHAR(2)';
	
EXEC sp_executesql @SqlCommand, @ParmList,
    @dDateFrom = @dDateFrom,@dDateTo = @dDateTo, @cMaker = @cMaker, @cWhCode = @cWhCode,
    @cCodeFrom = @cCodeFrom, @cCodeTo = @cCodeTo, @cDepCode = @cDepCode,
    @cVoucherStatus = @cVoucherStatus, @cVoucherType = @cVoucherType;
	
	
	

	/*
	    AND cbustype <> N'假退料'
        AND cbustype <> N'假退料'
        AND ISNULL(bomfirst, 0) <> 1
        AND ISNULL(bisstqc, 0) <> 1
        AND ISNULL(bpufirst, 0) <> 1
        AND ISNULL(biafirst, 0) <> 1
        AND ISNULL(bomfirst, 0) <> 1

	*/