﻿/*---------------------------------------------------------------------
* 			Copyright (C) 2018 TECHSCAN 版权所有。
*           www.techscan.cn
*┌──────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．　│
*│　版权所有：上海太迅自动识别技术有限公司 　 　　　　　　　　　　　　│
*└──────────────────────────────────┘
*
* 文件名：   proc_ts_ReferVouch_PU_Arrival_Get.SQL
* 功能：     存储过程
* 描述：     采购OR委外[到货单/退货单]-获取上游可参照单据信息
* 作者：     马永龙
* 创建时间： 2018-05-03 16:00:16
* 文件版本： V1.0.9

===============================版本履历===============================
* Ver 		变更日期 				负责人 	变更内容
* V1.0.0	2018-05-03 16:00:16		Myl		Create
* V1.0.1	2018-05-04				Myl		添加采购退货参照采购订单和参照到货单
* V1.0.2	2018-05-07				Myl		1）采购退货参照到货单，添加本次可退货数量/件数字段（inquantity/innum）
											2）添加PU到货拒收单-参照到货单SQL（@OperType=4）
* V1.0.3	2018-05-08				Myl		1）添加OM委外到货单-参照委外订单SQL（@OperType=5）
											2）添加OM委外退货单-参照委外订单SQL（@OperType=6）
											3）添加OM委外退货单-参照委外到货单SQL（@OperType=7）
											4）添加OM委外到货拒收单-参照委外到货单SQL（@OperType=8）
* V1.0.4	2018-05-15				Myl		修改所有参照单据中的日期格式为'yyyy-MM-dd'格式（CONVERT(varchar(100), ddate, 23)）
* V1.0.5	2018-05-29				Myl		委外到货/退货单参照委外订单时，表体上添加委外订单主表ID字段（moid）
* V1.0.6	2018-06-01				Myl		所有获取到的表体数据中添加已扫描数量和已扫描件数字段iScanedQuantity和iScanedNum
* V1.0.7	2018-06-06				Myl		参照类型为委外订单时，表头上添加税率itaxrate字段
* V1.0.8	2018-06-19				Myl		参照类型为采购订单时@OperType=0，表头上添加税率itaxrate字段
* V1.0.9	2018-07-13				Myl		表体添加统一bodyautoid字段（表体唯一ID的副本字段，前台用）
* V1.0.10	2019-03-26				dxh		采购订单表体按照计划到货日期排序
* V1.1.1	2019-04-12				dxh		支持多采购订单到货
* V1.1.2	2019-04-25			    dxh		来源单据增加部门
* V1.1.3	2019-05-16			    dxh		增加采购类型业务类型筛选
* V1.1.4	2019-07-16			    dxh		支持多采购订单到货

======================================================================
//--------------------------------------------------------------------*/
--EXEC proc_ts_ReferVouch_PU_Arrival_Get '8','DETAIL',''
--EXEC proc_ts_ReferVouch_PU_Arrival_Get '1','DETAIL','ShowClosed:1@@poids:1000000003@@cmaker:demo@@cVenCode:100000002@@cvenabbname:上海@@cPoCode:0000000003@@PoDateFrom:2017-11-29'
--EXEC proc_ts_ReferVouch_PU_Arrival_Get '1','DETAIL',''
--EXEC proc_ts_ReferVouch_PU_Arrival_Get '1','DETAIL','cmaker:dem1o'
--EXEC proc_ts_ReferVouch_PU_Arrival_Get '4','DETAIL','cmaker:demo'
--EXEC proc_ts_ReferVouch_PU_Arrival_Get '5','DETAIL','cmaker:demo'
--EXEC proc_ts_ReferVouch_PU_Arrival_Get '6','DETAIL','cmaker:demo@@cvencode:WX000001'
--EXEC proc_ts_ReferVouch_PU_Arrival_Get '7','DETAIL','cmaker:demo'

create PROC [dbo].[proc_ts_ReferVouch_PU_Arrival_Get]
    (
      @OperType CHAR(1) ,
      --@OperType=0：PU采购到货单-参照采购订单
	  --@OperType=1：PU采购退货单-参照采购订单
      --@OperType=2：PU采购退货单-参照到货单（到货单做过入库数量，可退货数量=合格入库数量-已退货数量）
      --@OperType=3：PU采购退货单-参照在库不良品处理单(这个地方还没有做 20180507 todo)
      --@OperType=4：PU到货拒收单-参照到货单

      --@OperType=5：OM委外到货单-参照委外订单
      --@OperType=6：OM委外退货单-参照委外订单
      --@OperType=7：OM委外退货单-参照委外到货单
      --@OperType=8：OM委外到货拒收单-参照委外到货单
      
      --获取类型（'LIST'获取上游参照单据列表;'DETAIL'获取上游参照单据详情（包含表头表体））
      --默认获取上游参照单据列表
      @GetType VARCHAR(10) = N'LIST' ,
      --传入的参数列表字符串
      --默认传空值
      @ParamsList NVARCHAR(2000) = N''
    )
    --WITH ENCRYPTION
AS
    BEGIN

	--采购类型
        DECLARE @cptcode NVARCHAR(30);
        SET @cptcode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                             N'cptcode',
                                                             DEFAULT, DEFAULT);

		--业务类型
        DECLARE @cbustype NVARCHAR(30);
        SET @cbustype = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                             N'cbustype',
                                                             DEFAULT, DEFAULT);													 


		--制单人
        DECLARE @cMaker NVARCHAR(30);
        SET @cMaker = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                             N'cMaker',
                                                             DEFAULT, DEFAULT);
                                                              
		--是否参照生产订单（红字）/委外订单（红字）bRed参数
        DECLARE @bRed VARCHAR(1);set @bRed= N'';
        --SET @bRed = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
        --                                                   N'bRed', DEFAULT,
        --                                                   DEFAULT);
        IF ( @bRed = N'' )
            BEGIN
                SET @bRed = N'0';
            END;
   
        --已经完成的采购订单是否显示(1:显示/0:不显示;默认不显示)
        DECLARE @ShowClosed CHAR(1);
        SET @ShowClosed = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ShowClosed',
                                                              DEFAULT, DEFAULT);
        IF ( @ShowClosed = N'' )
            BEGIN
                SET @ShowClosed = N'0';
            END;
        DECLARE @ParmList NVARCHAR(MAX);set @ParmList  = N'';
        DECLARE @SqlCommand NVARCHAR(MAX);set @SqlCommand = N'';
        IF ( @OperType = N'0'--采购到货单参照采购订单
             OR @OperType = N'1'--采购退货单参照采购订单
           )
			--@OperType=0：PU采购到货单-参照采购订单
			--@OperType=1：PU采购退货单-参照采购订单
            BEGIN
            --定义查询参数
            
				--订单日期FROM
                DECLARE @PoDateFrom VARCHAR(10);
                SET @PoDateFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'PoDateFrom',
                                                              DEFAULT, DEFAULT);
				--订单日期TO
                DECLARE @PoDateTo VARCHAR(10);
                SET @PoDateTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'PoDateTo',
                                                              DEFAULT, DEFAULT);
                IF ( @PoDateTo = N'' )
                    SET @PoDateTo = @PoDateFrom;
				--计划到货日期FROM
                DECLARE @ArriveDateFrom VARCHAR(10);
                SET @ArriveDateFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ArriveDateFrom',
                                                              DEFAULT, DEFAULT);
				--计划到货日期TO
                DECLARE @ArriveDateTo VARCHAR(10);
                SET @ArriveDateTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ArriveDateTo',
                                                              DEFAULT, DEFAULT);
                IF ( @ArriveDateTo = N'' )
                    SET @ArriveDateTo = @ArriveDateFrom;
                --供应商编码
                DECLARE @cVenCode NVARCHAR(20);
                SET @cVenCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cVenCode',
                                                              DEFAULT, DEFAULT);
				--供应商简称
                DECLARE @cVenAbbName NVARCHAR(98);
                SET @cVenAbbName = '%'
                    + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                             N'cVenAbbName',
                                                             DEFAULT, DEFAULT)
                    + '%';
                    
                --部门编码
                DECLARE @cDepCode NVARCHAR(12);
                SET @cDepCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cDepCode',
                                                              DEFAULT, DEFAULT);
                --部门名称
                DECLARE @cDepName NVARCHAR(255);
                SET @cDepName = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cDepName',
                                                              DEFAULT, DEFAULT);
                --业务员编码
                DECLARE @cPersonCode NVARCHAR(20);
                SET @cPersonCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cPersonCode',
                                                              DEFAULT, DEFAULT);   
                --存货编码
                DECLARE @cInvCode NVARCHAR(60);
                SET @cInvCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cInvCode',
                                                              DEFAULT, DEFAULT);
				--订单单号
                DECLARE @cPoCode NVARCHAR(30);
                SET @cPoCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cPoCode',
                                                              DEFAULT, DEFAULT);
				IF(@cPoCode <> N'')
            BEGIN                             
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempArrPOCodes') IS NULL )
                    DROP TABLE #STPDATempArrPOCodes;
                    
                CREATE   TABLE #STPDATempArrPOCodes ( PoCode NVARCHAR(30) );
                INSERT  INTO #STPDATempArrPOCodes
                        EXEC proc_ts_SplitParamString @cPoCode;
            END;



				--币种
                DECLARE @cExchName NVARCHAR(8);
                SET @cExchName = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cExchName',
                                                              DEFAULT, DEFAULT);
				--采购订单主表ID
                DECLARE @PoIds NVARCHAR(1000);                
                BEGIN
                
                    SET @PoIds = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'PoIds',
                                                              DEFAULT, DEFAULT);
                    IF ( @PoIds <> N'' )
                        BEGIN                             
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDATempPUPOIDs') IS NULL )
                                DROP TABLE #STPDATempPUPOIDs;
                    
                            CREATE   TABLE #STPDATempPUPOIDs ( PoId INT );
                            INSERT  INTO #STPDATempPUPOIDs
                                    EXEC proc_ts_SplitParamString @PoIds;
                        END;
                                                              
                END;
                
                --采购订单子表ID
                DECLARE @PoDids NVARCHAR(1000);
                BEGIN
                    SET @PoDids = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'PoDids',
                                                              DEFAULT, DEFAULT);
                    IF ( @PoDids <> N'' )
                        BEGIN                             
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDATempPUPODIDs') IS NULL )
                                DROP TABLE #STPDATempPUPODIDs;
                    
                            CREATE   TABLE #STPDATempPUPODIDs ( PoDid INT );
                            INSERT  INTO #STPDATempPUPODIDs
                                    EXEC proc_ts_SplitParamString @PoDids;
                        END;
                END;
                
                SET NOCOUNT ON;
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDARefIDs') IS NULL )
                    DROP TABLE #STPDARefIDs;
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDARefID') IS NULL )
                    DROP TABLE #STPDARefID;
                    
                SELECT  --IDENTITY( INT ) AS tmpId ,
                        CONVERT(NVARCHAR(30), N'') AS cordercode ,
                        CONVERT(INT, 0) AS id
                INTO    #STPDARefIDs
                FROM    copypolist
                WHERE   1 = 0; 
                --CREATE CLUSTERED INDEX ix_STPDARefIDs_tmpid_813 ON #STPDARefIDs( M_ID,S_ID,tmpId ); 
 
                IF ( @OperType = N'0' )
                    BEGIN
                        SET @SqlCommand = ' INSERT INTO #STPDARefIDs (cordercode,id)
									SELECT cordercode,id
									FROM copypolist WHERE bposourcearr = 1 AND bservice <> 1 AND binvtype <> 1 AND ISNULL(ireceivedqty,0) = 0
        AND ISNULL(cbustype,'''') <> N''直运采购'' AND ((ISNULL(cVerifier,'''') <> '''' AND ISNULL(cchanger,'''') = '''') OR (ISNULL(cchangverifier,'''') <> ''''))
        -- AND ( iordertype = N''0'' ) 订单类型（标准 非标准）
		 AND ISNULL(cbustype, '''') <> N''委外加工''
        AND idiscounttaxtype = 0 
		-- AND ISNULL(iflowid, 0) = ''0'' 
		AND 1 = 1 ';
        
                        IF ( @ShowClosed = '0' )
                            BEGIN
                                SET @SqlCommand = @SqlCommand
                                    + ' AND (ISNULL(iquantity,0) > ISNULL(iarrqty,0) OR (ISNULL(inum,0) > ISNULL(iarrnum,0) AND igrouptype =2)) ';
                            END;
                        ELSE
                            BEGIN
                                SET @SqlCommand = @SqlCommand
                                    + ' AND ((ISNULL(iquantity,0) > ISNULL(iarrqty,0)
                OR CONVERT(DECIMAL(38,2), ISNULL(iquantity,0) * (1+ ISNULL(fInExcess,0))) > CONVERT(DECIMAL(38,2), ISNULL(iarrqty,0)))
              OR ((ISNULL(inum,0) > ISNULL(iarrnum,0) OR CONVERT(DECIMAL(38,2), ISNULL(inum,0) * (1+ISNULL(fInExcess,0))) > CONVERT(DECIMAL(38,2), ISNULL(iarrnum,0)))) AND igrouptype = 2) ';
                            END;
                    END;
                ELSE
                    BEGIN
                        SET @SqlCommand = ' INSERT INTO #STPDARefIDs (cordercode,id)
									SELECT cordercode,id
									FROM copypolist WHERE bposourceret = 1
        AND bservice <> 1 AND binvtype <> 1 AND ISNULL(ireceivedqty,0) = 0
        AND (ISNULL(iarrqty,0) > 0 OR (ISNULL(iarrnum,0) > 0 AND igrouptype = 2 ))
        AND ISNULL(cbustype,'''') <> N''直运采购''
        AND ((ISNULL(cVerifier,'''') <> '''' AND ISNULL(cchanger,'''') = '''') OR (ISNULL(cchangverifier,'''') <> ''''))
        AND ISNULL(cbustype, '''') <> N''直运采购''
        AND ISNULL(cbustype, '''') <> N''委外加工''
        AND idiscounttaxtype = 0
      --  AND ISNULL(iflowid, 0) = ''0''
		 AND 1 = 1 ';
                    END;
               
			    IF ( @cptcode <> N'' )
                    SET @SqlCommand = @SqlCommand + ' AND (cptcode=@cptcode) ';

					
			    IF ( @cbustype <> N'' )
                    SET @SqlCommand = @SqlCommand + ' AND (cbustype=@cbustype) ';

                IF ( @cMaker <> N'' )
                    SET @SqlCommand = @SqlCommand + ' AND (cmaker=@cMaker) ';
                IF ( @cVenCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (cvencode = @cVenCode) ';
                IF ( @cVenAbbName <> N''
                     AND @cVenAbbName <> N'%%'
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (cvenabbname LIKE @cVenAbbName) ';
                IF ( @cDepCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (cdepcode = @cDepCode) ';
                IF ( @cDepName <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (cdepname = @cDepName) ';
                IF ( @PoDateFrom <> N''
                     AND @PoDateTo <> N''
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND ((dpodate >= @PoDateFrom)
                            AND (dpodate <= @PoDateTo)) ';
                IF ( @ArriveDateFrom <> N''
                     AND @ArriveDateTo <> N''
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND ((darrivedate >= @ArriveDateFrom)
                            AND (darrivedate <= @ArriveDateTo)) ';
                IF ( @cPersonCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (cpersoncode = @cPersonCode) ';
                IF ( @cPoCode <> N'' )
                    --SET @SqlCommand = @SqlCommand
                    --    + ' AND (cordercode = @cPoCode) '; 
                SET @SqlCommand = @SqlCommand
            + ' AND (cordercode IN (SELECT DISTINCT PoCode FROM #STPDATempArrPOCodes))';

                IF ( @cInvCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (cinvcode = @cInvCode) ';
                IF ( @cExchName <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (cexch_name = @cExchName) ';
                IF ( @PoIds <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (poid IN (SELECT DISTINCT PoId FROM #STPDATempPUPOIDs)) ';
                IF ( @PoDids <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (id IN (SELECT DISTINCT PoDid FROM #STPDATempPUPODIDs)) ';
               
                SET @ParmList = '@cMaker			NVARCHAR(30),
				@cptcode			NVARCHAR(30),
				@cbustype			NVARCHAR(30),
				   @cVenCode			NVARCHAR(20),
				   @cVenAbbName			NVARCHAR(60),
				   @cDepCode			NVARCHAR(12),
				   @cDepName			NVARCHAR(255),
				   @PoDateFrom			VARCHAR(10),
				   @PoDateTo			VARCHAR(10),
				   @ArriveDateFrom		VARCHAR(10),
				   @ArriveDateTo		VARCHAR(10),
				   @cPersonCode			NVARCHAR(20),
				   @cPoCode				NVARCHAR(30),
				   @cInvCode			NVARCHAR(60),
				   @cExchName			NVARCHAR(8)';
                --PRINT @SqlCommand;
                EXEC sp_executesql @SqlCommand, @ParmList, @cMaker = @cMaker,@cptcode=@cptcode
				,@cbustype=@cbustype,
                    @cVenCode = @cVenCode, @cVenAbbName = @cVenAbbName,
                    @cDepCode = @cDepCode, @cDepName = @cDepName,
                    @PoDateFrom = @PoDateFrom, @PoDateTo = @PoDateTo,
                    @ArriveDateFrom = @ArriveDateFrom,
                    @ArriveDateTo = @ArriveDateTo, @cPersonCode = @cPersonCode,
                    @cPoCode = @cPoCode, @cInvCode = @cInvCode,
                    @cExchName = @cExchName;
 
                SELECT  DISTINCT
                        cordercode
                INTO    #STPDARefID
                FROM    #STPDARefIDs;
                
                CREATE CLUSTERED INDEX ix_STPDARefID_tmpid_PU_813 ON #STPDARefID( cordercode ); 
                SET NOCOUNT OFF;
                --查询列表（表头）
                 
                SELECT DISTINCT
                        '' AS selcol ,
                        copypolist.poid ,
                        copypolist.ufts ,
                        copypolist.cmaker ,
                       -- ( ISNULL(copypolist.ipertaxrate, 0) ) AS itaxrate ,
                        ( copypolist.iflowid ) AS iflowid ,
                        ( copypolist.cflowname ) AS cflowname ,
                        ( copypolist.cbustype ) AS cbustype ,
                        ( copypolist.cordercode ) AS cordercode ,
                        ( CONVERT(VARCHAR(100), copypolist.dpodate, 23) ) AS dpodate ,
                        ( copypolist.cvencode ) AS cvencode ,
						Vendor.cvenname,
                        ( copypolist.cvenabbname ) AS cvenabbname ,
                        ( copypolist.cdepcode ) AS cdepcode ,
                        ( copypolist.cdepname ) AS cdepname ,
                        ( copypolist.cpersoncode ) AS cpersoncode ,
                        ( copypolist.cpersonname ) AS cpersonname ,
                        ( copypolist.csccode ) AS csccode ,
                        ( copypolist.cscname ) AS cscname ,
                        ( copypolist.cmemo ) AS cmemo ,
                        ( copypolist.cptcode ) AS cptcode ,
                        ( copypolist.cptname ) AS cptname ,
                        ( copypolist.cpaycode ) AS cpaycode ,
                        ( copypolist.cpayname ) AS cpayname ,
                        ( copypolist.cdefine1 ) AS cdefine1 ,
                        ( copypolist.cdefine2 ) AS cdefine2 ,
                        ( copypolist.cdefine3 ) AS cdefine3 ,
                        ( copypolist.cdefine4 ) AS cdefine4 ,
                        ( copypolist.cdefine5 ) AS cdefine5 ,
                        ( copypolist.cdefine6 ) AS cdefine6 ,
                        ( copypolist.cdefine7 ) AS cdefine7 ,
                        ( copypolist.cdefine8 ) AS cdefine8 ,
                        ( copypolist.cdefine9 ) AS cdefine9 ,
                        ( copypolist.cdefine10 ) AS cdefine10 ,
                        ( copypolist.cdefine11 ) AS cdefine11 ,
                        ( copypolist.cdefine12 ) AS cdefine12 ,
                        ( copypolist.cdefine13 ) AS cdefine13 ,
                        ( copypolist.cdefine14 ) AS cdefine14 ,
                        ( copypolist.cdefine15 ) AS cdefine15 ,
                        ( copypolist.cdefine16 ) AS cdefine16 ,
                        ( copypolist.cexch_name ) AS cexch_name ,
                        ( copypolist.cvenpuomprotocol ) AS cvenpuomprotocol ,
                        ( copypolist.cvenpuomprotocolname ) AS cvenpuomprotocolname,
						( CASE WHEN @OperType = N'0' THEN 0 ELSE 1 END ) AS bNegative ,
                          ( CASE WHEN @OperType = N'0' THEN 0 ELSE 1 END ) AS iBillType 
                FROM    copypolist
				left join Vendor on Vendor.cvencode=copypolist.cvencode
                        INNER JOIN #STPDARefID ON #STPDARefID.cordercode = copypolist.cordercode
                ORDER BY cordercode;
                 
                --查询表体
                IF ( @GetType = N'DETAIL' )
                    BEGIN
                        SELECT  
						
						cdepcode,cdepname, 
			 copypolist.cordercode as ccode,cbsysbarcode,
			 copypolist.cvencode,cvenname,

						( copypolist.id ) AS bodyautoid ,
                                '' AS selcol ,
                                ( copypolist.poid ) AS poid ,
                                ( copypolist.ufts ) AS corufts ,
                                ( copypolist.cvencode ) AS cvencode ,
                                ( copypolist.nflat ) AS iexchrate ,
                                ( copypolist.id ) AS id ,
                                ( copypolist.btaxcost ) AS btaxcost ,
                                ( copypolist.cinvcode ) AS cinvcode ,
                                ( copypolist.cinvaddcode ) AS cinvaddcode ,
                                ( copypolist.cinvname ) AS cinvname ,
                                ( copypolist.cinvstd ) AS cinvstd ,
                                ( copypolist.cinvm_unit ) AS cinvm_unit ,
                                ( copypolist.bgsp ) AS bgsp ,
                                ( copypolist.imassdate ) AS imassdate ,
                                ( ISNULL(copypolist.iquantity, 0) ) AS iquantity ,
                                ( ISNULL(copypolist.iarrqty, 0) ) AS iarrqty ,
								 ( ISNULL(copypolist.iarrqty, 0) )as ireceivedqty,
                                ( CASE WHEN @OperType = N'0'
                                       THEN ( ISNULL(copypolist.iquantity, 0)
                                              - ISNULL(copypolist.iarrqty, 0) )
                                       ELSE ( ISNULL(copypolist.iarrqty, 0) )
                                  END ) AS inquantity ,
                                ( copypolist.iinvexchrate ) AS iinvexchrate ,
                                ( ISNULL(copypolist.inum, 0) ) AS inum ,
                                ( ISNULL(copypolist.iarrnum, 0) ) AS iarrnum ,
                                ( CASE WHEN @OperType = N'0'
                                       THEN ( ISNULL(copypolist.inum, 0)
                                              - ISNULL(copypolist.iarrnum, 0) )
                                       ELSE ( ISNULL(copypolist.iarrnum, 0) )
                                  END ) AS innum ,
                                ( copypolist.iunitprice ) AS iunitprice ,
                                ( copypolist.itaxprice ) AS itaxprice ,
                                ( copypolist.imoney ) AS imoney ,
                                ( copypolist.itax ) AS itax ,
                                ( copypolist.isum ) AS isum ,
                                ( copypolist.inatunitprice ) AS inatunitprice ,
                                ( copypolist.inatmoney ) AS inatmoney ,
                                ivouchrowno ,
                                ( copypolist.inattax ) AS inattax ,
                                ( copypolist.inatsum ) AS inatsum ,
                                ( ISNULL(copypolist.ipertaxrate, 0) ) AS itaxrate ,
                                ( copypolist.igrouptype ) AS igrouptype ,
                                ( copypolist.bInvEntrust ) AS binventrust ,
                                ( copypolist.cunitid ) AS cunitid ,
                                ( copypolist.cinva_unit ) AS cinva_unit ,
                                ( copypolist.cfree1 ) AS cfree1 ,
                                ( copypolist.cfree2 ) AS cfree2 ,
                                ( copypolist.cfree3 ) AS cfree3 ,
                                ( copypolist.cfree4 ) AS cfree4 ,
                                ( copypolist.cfree5 ) AS cfree5 ,
                                ( copypolist.cfree6 ) AS cfree6 ,
                                ( copypolist.cfree7 ) AS cfree7 ,
                                ( copypolist.cfree8 ) AS cfree8 ,
                                ( copypolist.cfree9 ) AS cfree9 ,
                                ( copypolist.cfree10 ) AS cfree10 ,
                                ( copypolist.cdefine22 ) AS cdefine22 ,
                                ( copypolist.cdefine23 ) AS cdefine23 ,
                                ( copypolist.cdefine24 ) AS cdefine24 ,
                                ( copypolist.cdefine25 ) AS cdefine25 ,
                                ( copypolist.cdefine26 ) AS cdefine26 ,
                                ( copypolist.cdefine27 ) AS cdefine27 ,
                                ( copypolist.cdefine28 ) AS cdefine28 ,
                                ( copypolist.cdefine29 ) AS cdefine29 ,
                                ( copypolist.cdefine30 ) AS cdefine30 ,
                                ( copypolist.cdefine31 ) AS cdefine31 ,
                                ( copypolist.cdefine32 ) AS cdefine32 ,
                                ( copypolist.cdefine33 ) AS cdefine33 ,
                                ( copypolist.cdefine34 ) AS cdefine34 ,
                                ( copypolist.cdefine35 ) AS cdefine35 ,
                                ( copypolist.cdefine36 ) AS cdefine36 ,
                                ( copypolist.cdefine37 ) AS cdefine37 ,
                                ( copypolist.citemcode ) AS citemcode ,
                                ( copypolist.citemname ) AS citemname ,
                                ( copypolist.citem_class ) AS citem_class ,
                                ( copypolist.citem_name ) AS citem_name ,
                                ( copypolist.cinvdefine1 ) AS cinvdefine1 ,
                                ( copypolist.cinvdefine2 ) AS cinvdefine2 ,
                                ( copypolist.cinvdefine3 ) AS cinvdefine3 ,
                                ( copypolist.cinvdefine4 ) AS cinvdefine4 ,
                                ( copypolist.cinvdefine5 ) AS cinvdefine5 ,
                                ( copypolist.cinvdefine6 ) AS cinvdefine6 ,
                                ( copypolist.cinvdefine7 ) AS cinvdefine7 ,
                                ( copypolist.cinvdefine8 ) AS cinvdefine8 ,
                                ( copypolist.cinvdefine9 ) AS cinvdefine9 ,
                                ( copypolist.cinvdefine10 ) AS cinvdefine10 ,
                                ( copypolist.cinvdefine11 ) AS cinvdefine11 ,
                                ( copypolist.cinvdefine12 ) AS cinvdefine12 ,
                                ( copypolist.cinvdefine13 ) AS cinvdefine13 ,
                                ( copypolist.cinvdefine14 ) AS cinvdefine14 ,
                                ( copypolist.cinvdefine15 ) AS cinvdefine15 ,
                                ( copypolist.cinvdefine16 ) AS cinvdefine16 ,
                                ( copypolist.contractcode ) AS contractcode ,
                                ( copypolist.contractrowno ) AS contractrowno ,
                                ( copypolist.contractrowguid ) AS contractrowguid ,
                                ( copypolist.irowno ) AS irowno ,
                                ( copypolist.csocode ) AS csocode ,
                                ( copypolist.sotype ) AS sotype ,
                                ( copypolist.sodid ) AS sodid ,
                                ( copypolist.cmassunit ) AS cmassunit ,
                                ( copypolist.cwhcode ) AS cwhcode ,
                                ( copypolist.cwhname ) AS cwhname ,
                                ( copypolist.iinvmpcost ) AS iinvmpcost ,
                                ( copypolist.cordercode ) AS cordercode ,
                                ( copypolist.darrivedate ) AS darrivedate ,
                                ( copypolist.iorderdid ) AS iorderdid ,
                                ( copypolist.iordertype ) AS iordertype ,
                                ( copypolist.csoordercode ) AS csoordercode ,
                                ( copypolist.iorderseq ) AS iorderseq ,
                                ( copypolist.cdemandmemo ) AS cdemandmemo ,
                                ( copypolist.iexpiratdatecalcu ) AS iexpiratdatecalcu ,
                                ( copypolist.cbmemo ) AS cbmemo ,
                                ( copypolist.planlotnumber ) AS planlotnumber ,
                                bgift ,
                                '' AS cfactorycode ,
                                '' AS cfactoryname ,
                                0.0 AS iscanedquantity ,
                                0.0 AS iscanednum
                        FROM    copypolist
                                INNER JOIN #STPDARefIDs ON #STPDARefIDs.id = copypolist.id
								left join Vendor on Vendor.cvencode=copypolist.cvencode
                        WHERE   copypolist.cordercode IN ( SELECT DISTINCT
                                                              cordercode
                                                           FROM
                                                              #STPDARefID ) order By copypolist.darrivedate asc; 
                            
                        
                    END;
                --删除临时表

				   IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempArrPOCodes') IS NULL )
                    DROP TABLE #STPDATempArrPOCodes;
				
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDARefIDs') IS NULL )
                    DROP TABLE #STPDARefIDs;
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDARefID') IS NULL )
                    DROP TABLE #STPDARefID;
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempPUPOIDs') IS NULL )
                    DROP TABLE #STPDATempPUPOIDs;
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempPUPODIDs') IS NULL )
                    DROP TABLE #STPDATempPUPODIDs;
            END;
        ELSE
            IF ( @OperType = N'2'
                 OR @OperType = N'4'
               )
				--@OperType=2：PU-参照到货单做采购退货单
				--@OperType=4：PU-参照到货单做到货拒收单
                BEGIN
					--到货单日期FROM
                    DECLARE @ArriveOrderDateFrom VARCHAR(10);
                    SET @ArriveOrderDateFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ArriveDateFrom',
                                                              DEFAULT, DEFAULT);
					--到货单日期TO
                    DECLARE @ArriveOrderDateTo VARCHAR(10);
                    SET @ArriveOrderDateTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ArriveDateTo',
                                                              DEFAULT, DEFAULT);
                    IF ( @ArriveOrderDateTo = N'' )
                        SET @ArriveOrderDateTo = @ArriveOrderDateFrom;
					--供应商编码
                    DECLARE @cVenCodeArr NVARCHAR(20);
                    SET @cVenCodeArr = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cVenCode',
                                                              DEFAULT, DEFAULT);
					--供应商简称
                    DECLARE @cVenAbbNameArr NVARCHAR(98);
                    SET @cVenAbbNameArr = '%'
                        + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cVenAbbName',
                                                              DEFAULT, DEFAULT)
                        + '%';
					--部门编码
                    DECLARE @cDepCodeArr NVARCHAR(12);
                    SET @cDepCodeArr = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cDepCode',
                                                              DEFAULT, DEFAULT);
					--部门名称
                    DECLARE @cDepNameArr NVARCHAR(255);
                    SET @cDepNameArr = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cDepName',
                                                              DEFAULT, DEFAULT);
					--业务员编码
                    DECLARE @cPersonCodeArr NVARCHAR(20);
                    SET @cPersonCodeArr = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cPersonCode',
                                                              DEFAULT, DEFAULT);   
					--存货编码
                    DECLARE @cInvCodeArr NVARCHAR(60);
                    SET @cInvCodeArr = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cInvCode',
                                                              DEFAULT, DEFAULT);
					--到货单单号
                    DECLARE @cArrCode NVARCHAR(30);
                    SET @cArrCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cArrCode',
                                                              DEFAULT, DEFAULT);
					--到货单主表ID
                    DECLARE @ArrIds NVARCHAR(1000);                
                    BEGIN
                
                        SET @ArrIds = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ArrIds',
                                                              DEFAULT, DEFAULT);
                        IF ( @ArrIds <> N'' )
                            BEGIN                             
                                IF EXISTS ( SELECT  0
                                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempPUARRIDs') IS NULL )
                                    DROP TABLE #STPDATempPUARRIDs;
                    
                                CREATE   TABLE #STPDATempPUARRIDs ( ArrId INT );
                                INSERT  INTO #STPDATempPUARRIDs
                                        EXEC proc_ts_SplitParamString @ArrIds;
                            END;
                                                              
                    END;
                
					--到货单子表ID
                    DECLARE @ArrDids NVARCHAR(1000);
                    BEGIN
                        SET @ArrDids = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ArrDids',
                                                              DEFAULT, DEFAULT);
                        IF ( @ArrDids <> N'' )
                            BEGIN                             
                                IF EXISTS ( SELECT  0
                                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempPUARRDIDs') IS NULL )
                                    DROP TABLE #STPDATempPUARRDIDs;
                    
                                CREATE   TABLE #STPDATempPUARRDIDs ( ArrDid
                                                              INT );
                                INSERT  INTO #STPDATempPUARRDIDs
                                        EXEC proc_ts_SplitParamString @ArrDids;
                            END;
                    END;
                
                    SET NOCOUNT ON;
                    IF EXISTS ( SELECT  0
                                WHERE   NOT OBJECT_ID('tempdb..#STPDARefArrIDs') IS NULL )
                        DROP TABLE #STPDARefArrIDs;
                    IF EXISTS ( SELECT  0
                                WHERE   NOT OBJECT_ID('tempdb..#STPDARefArrID') IS NULL )
                        DROP TABLE #STPDARefArrID;
                    
                    SELECT  --IDENTITY( INT ) AS tmpId ,
                            CONVERT(NVARCHAR(30), N'') AS cCode ,
                            CONVERT(INT, 0) AS autoid
                    INTO    #STPDARefArrIDs
                    FROM    copyarrlist
                    WHERE   1 = 0; 
                    IF ( @OperType = N'2' )--PU-参照到货单做采购退货单
                        BEGIN
                
                            SET @SqlCommand = 'INSERT INTO #STPDARefArrIDs (cCode,autoid)
									SELECT cCode,autoid
									FROM copyarrlist WHERE bNegative = 0
        AND copyarrlist.cbustype <> ''委外加工'' AND ISNULL(cvouchtype,'''') <> N''IM25'' AND barrsourceret = 1
        AND ISNULL(cverifier,'''') <> '''' AND ISNULL(cvouchtype,'''') <> N''IM26'' 
        AND ((bInvEntrust = 0 AND ISNULL(cbustype, '''') IN ( N''普通采购'', N''固定资产'', N''代管采购'' ))
              OR (bInvEntrust = 1 AND ISNULL(cbustype, '''') = N''受托代销''))
       -- AND ISNULL(iflowid, 0) = ''0''
        AND idiscounttaxtype = 0  AND 1 = 1 ';
                            SET @SqlCommand = @SqlCommand
                                + ' AND (ISNULL(fvalidinquan, 0) - ABS(ISNULL(fretquantity, 0)) > 0) ';
                        
                        /*跟踪的代码
                         AND ( ( ISNULL(fvalidinquan, 0) - ABS(ISNULL(fretquantity, 0)) > 0
                AND igrouptype <> 2
              )
              OR ( ( ( ISNULL(fvalidinquan, 0) - ABS(ISNULL(fretquantity, 0)) ) > 0
                     OR ( ISNULL(fvalidinquan, 0) - ABS(ISNULL(fretquantity, 0)) ) > 0
                   )
                   AND igrouptype = 2
                 )
            )
                        */
                        END;
                    ELSE--PU-参照到货单做到货拒收单
                        BEGIN
                            SET @SqlCommand = ' INSERT INTO #STPDARefArrIDs (cCode,autoid)
									SELECT cCode,autoid
									FROM copyarrlist WHERE bNegative = 0  AND copyarrlist.cbustype <> ''委外加工''
        AND ISNULL(cvouchtype, '''') <> N''IM25'' AND ISNULL(cverifier, '''') <> ''''
        AND ( ISNULL(cvouchtype, '''') <> N''IM27'' AND ISNULL(copyarrlist.cbcloser, '''') = ''''
              AND ( ( ISNULL(irefuseqty, 0) > 0 AND igrouptype <> 2)
                    OR ( ( ISNULL(irefuseqty, 0) > 0 OR ISNULL(irefusenum, 0) > 0) AND igrouptype = 2))) AND ( isshow = N''0'' )
        AND ( ( bInvEntrust = 0 AND ISNULL(cbustype, '''') IN ( N''普通采购'', N''固定资产'', N''代管采购'' ) ) 
        OR ( bInvEntrust = 1 AND ISNULL(cbustype, '''') = N''受托代销'')) AND idiscounttaxtype = 0 AND 1 = 1 ';
                        END;
                        
                    IF ( @cMaker <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (cmaker=@cMaker) ';
                    IF ( @cVenCodeArr <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (cvencode = @cVenCodeArr) ';
                    IF ( @cVenAbbNameArr <> N''
                         AND @cVenAbbNameArr <> N'%%'
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (cvenabbname LIKE @cVenAbbNameArr) ';
                    IF ( @cDepCodeArr <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (cdepcode = @cDepCodeArr) ';
                    IF ( @cDepNameArr <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (cdepname = @cDepNameArr) ';
                    IF ( @ArriveOrderDateFrom <> N''
                         AND @ArriveOrderDateTo <> N''
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND ((ddate >= @ArriveOrderDateFrom)
                            AND (ddate <= @ArriveOrderDateTo)) ';
                    IF ( @cPersonCodeArr <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (cpersoncode = @cPersonCodeArr) ';
                    IF ( @cArrCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (cCode = @cArrCode) '; 
                    IF ( @cInvCodeArr <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (cinvcode = @cInvCodeArr) ';
                    IF ( @ArrIds <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (id IN (SELECT DISTINCT ArrId FROM #STPDATempPUARRIDs)) ';
                    IF ( @ArrDids <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (autoid IN (SELECT DISTINCT ArrDid FROM #STPDATempPUARRDIDs)) ';
                    IF ( @ShowClosed = '0' )
                        BEGIN
                            SET @SqlCommand = @SqlCommand
                                + ' AND ( isshow = N''0'' ) '; 
                                --isshow:单据是否关闭
                        END;

                    SET @ParmList = '@cMaker			NVARCHAR(30),
				   @cVenCodeArr				NVARCHAR(20),
				   @cVenAbbNameArr			NVARCHAR(60),
				   @cDepCodeArr				NVARCHAR(12),
				   @cDepNameArr				NVARCHAR(255),
				   @ArriveOrderDateFrom		VARCHAR(10),
				   @ArriveOrderDateTo		VARCHAR(10),
				   @cPersonCodeArr			NVARCHAR(20),
				   @cArrCode				NVARCHAR(30),
				   @cInvCodeArr				NVARCHAR(60)';
                    --PRINT @SqlCommand;
                    EXEC sp_executesql @SqlCommand, @ParmList,
                        @cMaker = @cMaker, @cVenCodeArr = @cVenCodeArr,
                        @cVenAbbNameArr = @cVenAbbNameArr,
                        @cDepCodeArr = @cDepCodeArr,
                        @cDepNameArr = @cDepNameArr,
                        @ArriveOrderDateFrom = @ArriveOrderDateFrom,
                        @ArriveOrderDateTo = @ArriveOrderDateTo,
                        @cPersonCodeArr = @cPersonCodeArr,
                        @cArrCode = @cArrCode, @cInvCodeArr = @cInvCodeArr;	 
                    SELECT  DISTINCT
                            cCode
                    INTO    #STPDARefArrID
                    FROM    #STPDARefArrIDs;

                    CREATE CLUSTERED INDEX ix_STPDARefID_tmpid_PU_813 ON #STPDARefArrID( cCode ); 
                    SET NOCOUNT OFF;
                    
					--查询列表（表头）
                
                    SELECT DISTINCT
                            '' AS selcol ,
                            ( copyarrlist.ibilltype ) AS ibilltype ,
                            ( copyarrlist.iflowid ) AS iflowid ,
                            ( copyarrlist.cflowname ) AS cflowname ,
                            ( copyarrlist.cCode ) AS ccode ,
                            ( CONVERT(VARCHAR(100), copyarrlist.ddate, 23) ) AS ddate ,
                            ( copyarrlist.cvencode ) AS cvencode ,
                            ( copyarrlist.cvenabbname ) AS cvenabbname ,
                            ( copyarrlist.cdepcode ) AS cdepcode ,
                            ( copyarrlist.cdepname ) AS cdepname ,
                            ( copyarrlist.cpersoncode ) AS cpersoncode ,
                            ( copyarrlist.cpersonname ) AS cpersonname ,
                            ( copyarrlist.cmemo ) AS cmemo ,
                            ( copyarrlist.cptcode ) AS cptcode ,
                            ( copyarrlist.cptname ) AS cptname ,
                            ( copyarrlist.csccode ) AS csccode ,
                            ( copyarrlist.cscname ) AS cscname ,
                            ( copyarrlist.cpaycode ) AS cpaycode ,
                            ( copyarrlist.cpayname ) AS cpayname ,
                            ( copyarrlist.cdefine1 ) AS cdefine1 ,
                            ( copyarrlist.cdefine2 ) AS cdefine2 ,
                            ( copyarrlist.cdefine3 ) AS cdefine3 ,
                            ( copyarrlist.cdefine4 ) AS cdefine4 ,
                            ( copyarrlist.cdefine5 ) AS cdefine5 ,
                            ( copyarrlist.cdefine6 ) AS cdefine6 ,
                            ( copyarrlist.cdefine7 ) AS cdefine7 ,
                            ( copyarrlist.cdefine8 ) AS cdefine8 ,
                            ( copyarrlist.cdefine9 ) AS cdefine9 ,
                            ( copyarrlist.cdefine10 ) AS cdefine10 ,
                            ( copyarrlist.cdefine11 ) AS cdefine11 ,
                            ( copyarrlist.cdefine12 ) AS cdefine12 ,
                            ( copyarrlist.cdefine13 ) AS cdefine13 ,
                            ( copyarrlist.cdefine14 ) AS cdefine14 ,
                            ( copyarrlist.cdefine15 ) AS cdefine15 ,
                            ( copyarrlist.cdefine16 ) AS cdefine16 ,
                            ( copyarrlist.cexch_name ) AS cexch_name ,
                            ( copyarrlist.iexchrate ) AS iexchrate ,
                            ( copyarrlist.cmaker ) AS cmaker ,
                            ( copyarrlist.cverifier ) AS cverifier ,
                            ccloser ,
                            ( copyarrlist.cvenpuomprotocol ) AS cvenpuomprotocol ,
                            ( copyarrlist.cvenpuomprotocolname ) AS cvenpuomprotocolname ,
                            cbustype
                    FROM    copyarrlist
                            INNER JOIN #STPDARefArrID ON #STPDARefArrID.cCode = copyarrlist.cCode
                    ORDER BY ccode;
                
                    IF ( @GetType = N'DETAIL' )
                        BEGIN
                            SELECT 
							cdepcode,cdepname, 
			 copyarrlist.ccode as ccode,cbsysbarcode,
			copyarrlist.cvencode,cvenname,
							 ( copyarrlist.autoid ) AS bodyautoid ,
                                    '' AS selcol ,
									(CASE WHEN @OperType = N'2' then
                                    ( ISNULL(copyarrlist.frealquantity, 0.0) )
									ELSE
									NULL END)
									 AS frealquantity ,--实收数量
                                  	(CASE WHEN @OperType = N'2' then  ( ISNULL(copyarrlist.frealnum, 0.0) ) 
									ELSE NULL END)
									AS frealnum ,--实收件数
                                    ( ISNULL(copyarrlist.fsumrefusequantity,
                                             0.0) ) AS fsumrefusequantity ,--合计拒收数量
                                    ( ISNULL(copyarrlist.fsumrefusenum, 0.0) ) AS fsumrefusenum ,--合计拒收件数
                                    ( ISNULL(copyarrlist.fvalidinquan, 0.0) ) AS fvalidinquan ,--合格入库数量
                                    ( ISNULL(copyarrlist.fvalidinnum, 0.0) ) AS fvalidinnum ,--合格入库件数
                                    ( ISNULL(copyarrlist.iquantity, 0.0) ) AS iquantity ,--到货数量
                                    ( copyarrlist.iinvexchrate ) AS iinvexchrate ,--换算率
                                    ( ISNULL(copyarrlist.inum, 0.0) ) AS inum ,--到货件数
                                    ( ISNULL(copyarrlist.fretquantity, 0.0) ) AS fretquantity ,--已退货数量
									 ( ISNULL(copyarrlist.fretquantity, 0.0) ) as ireceivedqty,
                                    ( copyarrlist.fretnum ) AS fretnum ,--已退货件数
                                    ( CASE WHEN @OperType = N'2'
                                           THEN ( ISNULL(copyarrlist.fvalidinquan,
                                                         0.0)
                                                  - ISNULL(copyarrlist.fretquantity,
                                                           0.0) )
                                           ELSE ( ISNULL(copyarrlist.irefuseqty,
                                                         0.0) )
                                      END ) AS inquantity ,--本次可退货数量
                                    ( CASE WHEN @OperType = N'2'
                                           THEN ( ISNULL(copyarrlist.fvalidinnum,
                                                         0.0)
                                                  - ISNULL(copyarrlist.fretnum,
                                                           0.0) )
                                           ELSE ISNULL(copyarrlist.irefusenum,
                                                       0.0)
                                      END ) AS innum ,--本次可退货件数
                                    ( ISNULL(copyarrlist.fRefuseQuantity, 0.0) ) AS frefusequantity ,--已拒收数量
                                    ( ISNULL(copyarrlist.fRefuseNum, 0.0) ) AS frefusenum ,--已拒收件数
                                    ( ISNULL(copyarrlist.irefuseqty, 0.0) ) AS irefuseqty ,--剩余可拒收数量
                                    ( ISNULL(copyarrlist.irefusenum, 0.0) ) AS irefusenum ,--剩余可拒收件数
                                    ( copyarrlist.autoid ) AS autoid ,
                                    ( copyarrlist.btaxcost ) AS btaxcost ,
                                    ( copyarrlist.iposid ) AS iposid ,
                                    ( copyarrlist.cinvcode ) AS cinvcode ,
                                    ( copyarrlist.cinvname ) AS cinvname ,
                                    ( copyarrlist.cinvstd ) AS cinvstd ,
                                    ( copyarrlist.cinvm_unit ) AS cinvm_unit ,
                                    ( copyarrlist.icost ) AS icost ,
                                    ( copyarrlist.imoney ) AS imoney ,
                                    ( copyarrlist.itaxprice ) AS itaxprice ,
                                    ( copyarrlist.isum ) AS isum ,
                                    ( copyarrlist.ioricost ) AS ioricost ,
                                    ( copyarrlist.ioritaxcost ) AS ioritaxcost ,
                                    ( copyarrlist.iorimoney ) AS iorimoney ,
                                    ( copyarrlist.ioritaxprice ) AS ioritaxprice ,
                                    ivouchrowno ,
                                    ( copyarrlist.iorisum ) AS iorisum ,
                                    ( ISNULL(copyarrlist.itaxrate, 0) ) AS itaxrate ,
                                    ( copyarrlist.igrouptype ) AS igrouptype ,
                                    ( copyarrlist.bInvEntrust ) AS binventrust ,
                                    ( copyarrlist.cunitid ) AS cunitid ,
                                    ( copyarrlist.cinva_unit ) AS cinva_unit ,
                                    ( copyarrlist.cwhcode ) AS cwhcode ,
                                    ( copyarrlist.cwhname ) AS cwhname ,
                                    ( copyarrlist.cbatch ) AS cbatch ,
                                    ( copyarrlist.bgsp ) AS bgsp ,
                                    ( copyarrlist.imassdate ) AS imassdate ,
                                    ( copyarrlist.dpdate ) AS dpdate ,
                                    ( copyarrlist.dvdate ) AS dvdate ,
                                    ( copyarrlist.cfree1 ) AS cfree1 ,
                                    ( copyarrlist.cfree2 ) AS cfree2 ,
                                    ( copyarrlist.cfree3 ) AS cfree3 ,
                                    ( copyarrlist.cfree4 ) AS cfree4 ,
                                    ( copyarrlist.cfree5 ) AS cfree5 ,
                                    ( copyarrlist.cfree6 ) AS cfree6 ,
                                    ( copyarrlist.cfree7 ) AS cfree7 ,
                                    ( copyarrlist.cfree8 ) AS cfree8 ,
                                    ( copyarrlist.cfree9 ) AS cfree9 ,
                                    ( copyarrlist.cfree10 ) AS cfree10 ,
                                    ( copyarrlist.cdefine22 ) AS cdefine22 ,
                                    ( copyarrlist.cdefine23 ) AS cdefine23 ,
                                    ( copyarrlist.cdefine24 ) AS cdefine24 ,
                                    ( copyarrlist.cdefine25 ) AS cdefine25 ,
                                    ( copyarrlist.cdefine26 ) AS cdefine26 ,
                                    ( copyarrlist.cdefine27 ) AS cdefine27 ,
                                    ( copyarrlist.cdefine28 ) AS cdefine28 ,
                                    ( copyarrlist.cdefine29 ) AS cdefine29 ,
                                    ( copyarrlist.cdefine30 ) AS cdefine30 ,
                                    ( copyarrlist.cdefine31 ) AS cdefine31 ,
                                    ( copyarrlist.cdefine32 ) AS cdefine32 ,
                                    ( copyarrlist.cdefine33 ) AS cdefine33 ,
                                    ( copyarrlist.cdefine34 ) AS cdefine34 ,
                                    ( copyarrlist.cdefine35 ) AS cdefine35 ,
                                    ( copyarrlist.cdefine36 ) AS cdefine36 ,
                                    ( copyarrlist.cdefine37 ) AS cdefine37 ,
                                    ( copyarrlist.cbatchproperty1 ) AS cbatchproperty1 ,
                                    ( copyarrlist.cbatchproperty2 ) AS cbatchproperty2 ,
                                    ( copyarrlist.cbatchproperty3 ) AS cbatchproperty3 ,
                                    ( copyarrlist.cbatchproperty4 ) AS cbatchproperty4 ,
                                    ( copyarrlist.cbatchproperty5 ) AS cbatchproperty5 ,
                                    ( copyarrlist.cbatchproperty6 ) AS cbatchproperty6 ,
                                    ( copyarrlist.cbatchproperty7 ) AS cbatchproperty7 ,
                                    ( copyarrlist.cbatchproperty8 ) AS cbatchproperty8 ,
                                    ( copyarrlist.cbatchproperty9 ) AS cbatchproperty9 ,
                                    ( copyarrlist.cbatchproperty10 ) AS cbatchproperty10 ,
                                    ( copyarrlist.citemcode ) AS citemcode ,
                                    ( copyarrlist.citemname ) AS citemname ,
                                    ( copyarrlist.citem_class ) AS citem_class ,
                                    ( copyarrlist.citem_name ) AS citem_name ,
                                    ( copyarrlist.cinvaddcode ) AS cinvaddcode ,
                                    ( copyarrlist.cinvdefine1 ) AS cinvdefine1 ,
                                    ( copyarrlist.cinvdefine2 ) AS cinvdefine2 ,
                                    ( copyarrlist.cinvdefine3 ) AS cinvdefine3 ,
                                    ( copyarrlist.cinvdefine4 ) AS cinvdefine4 ,
                                    ( copyarrlist.cinvdefine5 ) AS cinvdefine5 ,
                                    ( copyarrlist.cinvdefine6 ) AS cinvdefine6 ,
                                    ( copyarrlist.cinvdefine7 ) AS cinvdefine7 ,
                                    ( copyarrlist.cinvdefine8 ) AS cinvdefine8 ,
                                    ( copyarrlist.cinvdefine9 ) AS cinvdefine9 ,
                                    ( copyarrlist.cinvdefine10 ) AS cinvdefine10 ,
                                    ( copyarrlist.cinvdefine11 ) AS cinvdefine11 ,
                                    ( copyarrlist.cinvdefine12 ) AS cinvdefine12 ,
                                    ( copyarrlist.cinvdefine13 ) AS cinvdefine13 ,
                                    ( copyarrlist.cinvdefine14 ) AS cinvdefine14 ,
                                    ( copyarrlist.cinvdefine15 ) AS cinvdefine15 ,
                                    ( copyarrlist.cinvdefine16 ) AS cinvdefine16 ,
                                    ( copyarrlist.cordercode ) AS cordercode ,
                                    ( copyarrlist.contractcode ) AS contractcode ,
                                    ( copyarrlist.contractrowno ) AS contractrowno ,
                                    ( copyarrlist.contractrowguid ) AS contractrowguid ,
                                    ( copyarrlist.bexigency ) AS bexigency ,
                                    ( copyarrlist.cmassunit ) AS cmassunit ,
                                    ( copyarrlist.irowno ) AS irowno ,
                                    ( copyarrlist.sotype ) AS sotype ,
                                    ( copyarrlist.sodid ) AS sodid ,
                                    ( copyarrlist.csocode ) AS csocode ,
                                    cbcloser ,
                                    ( copyarrlist.ufts ) AS corufts ,
                                    ( copyarrlist.iinvmpcost ) AS iinvmpcost ,
                                    ( copyarrlist.cCode ) AS ccode ,
                                    ( copyarrlist.iexpiratDateCalcu ) AS iexpiratdatecalcu ,
                                    ( copyarrlist.cexpirationdate ) AS cexpirationdate ,
                                    ( copyarrlist.dexpirationdate ) AS dexpirationdate ,
                                    ( copyarrlist.cdemandmemo ) AS cdemandmemo ,
                                    ( copyarrlist.iorderdid ) AS iorderdid ,
                                    ( copyarrlist.iordertype ) AS iordertype ,
                                    ( copyarrlist.csoordercode ) AS csoordercode ,
                                    ( copyarrlist.iorderseq ) AS iorderseq ,
                                    ( copyarrlist.cbmemo ) AS cbmemo ,
                                    ( copyarrlist.planlotnumber ) AS planlotnumber ,
                                    bgift ,
                                    '' AS cfactorycode ,
                                    '' AS  cfactoryname ,
                                    0.0 AS iscanedquantity ,
                                    0.0 AS iscanednum
                            FROM    copyarrlist
                                    INNER JOIN #STPDARefArrIDs ON #STPDARefArrIDs.autoid = copyarrlist.autoid
					        left join Vendor on Vendor.cvencode=copyarrlist.cvencode
                            WHERE   copyarrlist.cCode IN ( SELECT DISTINCT
                                                              cCode
                                                           FROM
                                                              #STPDARefArrID ); 
                        END;
					--删除临时表
                    IF EXISTS ( SELECT  0
                                WHERE   NOT OBJECT_ID('tempdb..#STPDARefArrIDs') IS NULL )
                        DROP TABLE #STPDARefArrIDs;
                    IF EXISTS ( SELECT  0
                                WHERE   NOT OBJECT_ID('tempdb..#STPDARefArrID') IS NULL )
                        DROP TABLE #STPDARefArrID;
                    IF EXISTS ( SELECT  0
                                WHERE   NOT OBJECT_ID('tempdb..#STPDATempPUARRIDs') IS NULL )
                        DROP TABLE #STPDATempPUARRIDs;
                    IF EXISTS ( SELECT  0
                                WHERE   NOT OBJECT_ID('tempdb..#STPDATempPUARRDIDs') IS NULL )
                        DROP TABLE #STPDATempPUARRDIDs;
                END;
            ELSE
                IF ( @OperType = N'3' )--PU-参照在库不良品处理单做采购退货单
                    BEGIN
                        RAISERROR('采购退货单暂不支持参照单据类型[在库不良品处理单]，参照类型编码：%s. ',16,1, @OperType);
                    END;
                ELSE
                    IF ( @OperType = N'5'
                         OR @OperType = N'6'
                       )
                    --@OperType = N'5'：OM委外到货单-参照委外订单
                    --@OperType = N'6': OM委外退货单-参照委外订单
                        BEGIN

						
							--订单单号
                DECLARE @cCode NVARCHAR(30);
                SET @cCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cPoCode',
                                                              DEFAULT, DEFAULT);

							--委外订单日期FROM
                            DECLARE @OmOrderDateFrom VARCHAR(10);
                            SET @OmOrderDateFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dDateFrom',
                                                              DEFAULT, DEFAULT);
							--委外订单日期TO
                            DECLARE @OmOrderDateTo VARCHAR(10);
                            SET @OmOrderDateTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dDateTo',
                                                              DEFAULT, DEFAULT);
                            IF ( @OmOrderDateTo = N'' )
                                SET @OmOrderDateTo = @OmOrderDateFrom;
                            --委外订单计划到货日期FROM
                            DECLARE @OmOrderArriveDateFrom VARCHAR(10);
                            SET @OmOrderArriveDateFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dArriveDateFrom',
                                                              DEFAULT, DEFAULT);
							--委外订单计划到货日期TO
                            DECLARE @OmOrderArriveDateTo VARCHAR(10);
                            SET @OmOrderArriveDateTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dArriveDateTo',
                                                              DEFAULT, DEFAULT);
                            IF ( @OmOrderArriveDateTo = N'' )
                                SET @OmOrderArriveDateTo = @OmOrderArriveDateFrom;
							--外协供应商编码
                            DECLARE @cVenCodeOm NVARCHAR(20);
                            SET @cVenCodeOm = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cVenCode',
                                                              DEFAULT, DEFAULT);
							--外协供应商简称
                            DECLARE @cVenAbbNameOm NVARCHAR(98);
                            SET @cVenAbbNameOm = '%'
                                + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cVenAbbName',
                                                              DEFAULT, DEFAULT)
                                + '%';
							--部门编码
                            DECLARE @cDepCodeOm NVARCHAR(12);
                            SET @cDepCodeOm = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cDepCode',
                                                              DEFAULT, DEFAULT);
							--部门名称
                            DECLARE @cDepNameOm NVARCHAR(255);
                            SET @cDepNameOm = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cDepName',
                                                              DEFAULT, DEFAULT);
							--业务员编码
                            DECLARE @cPersonCodeOm NVARCHAR(20);
                            SET @cPersonCodeOm = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cPersonCode',
                                                              DEFAULT, DEFAULT);   
							--存货编码
                            DECLARE @cInvCodeOm NVARCHAR(60);
                            SET @cInvCodeOm = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cInvCode',
                                                              DEFAULT, DEFAULT);
							--委外订单单号
                            DECLARE @cOmOrderCode NVARCHAR(max);
                            SET @cOmOrderCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cCode',
                                                              DEFAULT, DEFAULT);
			IF(@cOmOrderCode <> N'')
            BEGIN                             
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempOmOrderCodes') IS NULL )
                    DROP TABLE #STPDATempOmOrderCodes;
                    
                CREATE   TABLE #STPDATempOmOrderCodes ( cOmOrderCode NVARCHAR(30) );
                INSERT  INTO #STPDATempOmOrderCodes
                        EXEC proc_ts_SplitParamString @cOmOrderCode;
            END;



                            --币种
                            DECLARE @cExchNameOm NVARCHAR(8);
                            SET @cExchNameOm = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cExchName',
                                                              DEFAULT, DEFAULT);
							--委外订单主表ID
                            DECLARE @OmIds NVARCHAR(1000);                
                            BEGIN
                
                                SET @OmIds = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'OmIds',
                                                              DEFAULT, DEFAULT);
                                IF ( @OmIds <> N'' )
                                    BEGIN                             
                                        IF EXISTS ( SELECT  0
                                                    WHERE   NOT OBJECT_ID('tempdb..#STPDATempOmIDs') IS NULL )
                                            DROP TABLE #STPDATempOmIDs;
                    
                                        CREATE   TABLE #STPDATempOmIDs ( OmId
                                                              INT );
                                        INSERT  INTO #STPDATempOmIDs
                                                EXEC proc_ts_SplitParamString @OmIds;
                                    END;
                                                              
                            END;
                
							--委外订单子表ID
                            DECLARE @OmDids NVARCHAR(1000);
                            BEGIN
                                SET @OmDids = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'OmDids',
                                                              DEFAULT, DEFAULT);
                                IF ( @OmDids <> N'' )
                                    BEGIN                             
                                        IF EXISTS ( SELECT  0
                                                    WHERE   NOT OBJECT_ID('tempdb..#STPDATempOmDIDs') IS NULL )
                                            DROP TABLE #STPDATempOmDIDs;
                    
                                        CREATE   TABLE #STPDATempOmDIDs ( OmDid
                                                              INT );
                                        INSERT  INTO #STPDATempOmDIDs
                                                EXEC proc_ts_SplitParamString @OmDids;
                                    END;
                            END;
                
                            SET NOCOUNT ON;
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDARefOmIDs') IS NULL )
                                DROP TABLE #STPDARefOmIDs;
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDARefOmID') IS NULL )
                                DROP TABLE #STPDARefOmID;
                    
                            SELECT  --IDENTITY( INT ) AS tmpId ,
                                    CONVERT(NVARCHAR(30), N'') AS ccode ,
                                    CONVERT(INT, 0) AS MODetailsID
                            INTO    #STPDARefOmIDs
                            FROM    copyommolist
                            WHERE   1 = 0; 
                            IF ( @OperType = N'5' )
                            --委外到货单参照委外订单
                                BEGIN
                                    SET @SqlCommand = 'INSERT INTO #STPDARefOmIDs (ccode,MODetailsID)
									SELECT cCode,MODetailsID
									FROM copyommolist WHERE ISNULL(ireceivedqty,0) = 0
        AND ISNULL(iquantity,0) > ISNULL(iarrqty,0)
        AND ((ISNULL(copyommolist.cVerifier,N'''') <> N'''' AND ISNULL(copyommolist.cchanger,N'''') = N''''
                AND ISNULL(copyommolist.cchangeverifier,N'''') = N'''')
              OR ( ISNULL(copyommolist.cVerifier,N'''') <> N'''' AND ISNULL(copyommolist.cchanger,N'''') <> N''''
                   AND ISNULL(copyommolist.cchangeverifier,N'''') <> N''''))
        AND ISNULL(copyommolist.cbCloser,'''') = '''' AND 1 = 1 ';
                                END;
                            ELSE
                                BEGIN
                                 --委外退货单参照委外订单
                                    SET @SqlCommand = 'INSERT INTO #STPDARefOmIDs (ccode,MODetailsID)
									SELECT cCode,MODetailsID FROM copyommolist WHERE ISNULL(iproducttype,0) = 0
        AND ISNULL(ireceivedqty,0) = 0 AND ISNULL(iarrqty,0) > 0
        AND ((ISNULL(copyommolist.cVerifier,N'''') <> N'''' AND ISNULL(copyommolist.cchanger,N'''') = N''''
                AND ISNULL(copyommolist.cchangeverifier,N'''') = N'''')
              OR (ISNULL(copyommolist.cVerifier,N'''') <> N''''
                   AND ISNULL(copyommolist.cchanger,N'''') <> N''''
                   AND ISNULL(copyommolist.cchangeverifier,N'''') <> N''''))
        AND ISNULL(copyommolist.cbCloser,'''') = '''' AND 1 = 1 ';
                                END;
                            IF ( @cMaker <> N'' )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND (cmaker=@cMaker) ';
                            IF ( @cExchNameOm <> N'' )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND (cexch_name=@cExchNameOm) ';
                            IF ( @cVenCodeOm <> N'' )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND (cvencode = @cVenCodeOm) ';
                            IF ( @cVenAbbNameOm <> N''
                                 AND @cVenAbbNameOm <> N'%%'
                               )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND (cvenabbname LIKE @cVenAbbNameOm) ';
                            IF ( @cDepCodeOm <> N'' )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND (cdepcode = @cDepCodeOm) ';
                            IF ( @cDepNameOm <> N'' )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND (cdepname = @cDepNameOm) ';
                            IF ( @OmOrderDateFrom <> N''
                                 AND @OmOrderDateTo <> N''
                               )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND ((ddate >= @OmOrderDateFrom)
                            AND (ddate <= @OmOrderDateTo)) ';
                            IF ( @OmOrderArriveDateFrom <> N''
                                 AND @OmOrderArriveDateTo <> N''
                               )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND ((dArriveDate >= @OmOrderArriveDateFrom)
                            AND (dArriveDate <= @OmOrderArriveDateTo)) ';
                            
                            IF ( @cPersonCodeOm <> N'' )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND (cpersoncode = @cPersonCodeOm) ';
							--委外订单并单
                            IF ( @cOmOrderCode <> N'' )

							   SET @SqlCommand = @SqlCommand
            + ' AND (cCode IN (SELECT DISTINCT cOmOrderCode FROM #STPDATempOmOrderCodes))';


                                --SET @SqlCommand = @SqlCommand
                                --    + ' AND (cCode = @cOmOrderCode) '; 
                            IF ( @cInvCodeOm <> N'' )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND (cinvcode = @cInvCodeOm) ';
                            IF ( @OmIds <> N'' )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND (MoId IN (SELECT DISTINCT OmId FROM #STPDATempOmIDs)) ';
                            IF ( @OmDids <> N'' )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND (MODetailsID IN (SELECT DISTINCT OmDid FROM #STPDATempOmDIDs)) ';


									  IF ( @cCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (cCode = @cCode) '; 

                            /*
                             AND ( sotype = N'1' )--需求跟踪方式
							AND ( iordertype = N'0' )--订单类型（标准 OR 非标准）
                            */
                            
                            --IF ( @ShowClosed = '0' )
                            --    BEGIN
                            --        SET @SqlCommand = @SqlCommand
                            --            + ' AND ( isshow = N''0'' ) '; 
                                
                            --    END;

                            SET @ParmList = '@cMaker			NVARCHAR(30),
                   @cExchNameOm				NVARCHAR(8),
				   @cVenCodeOm				NVARCHAR(20),
				   @cVenAbbNameOm			NVARCHAR(60),
				   @cDepCodeOm				NVARCHAR(12),
				   @cDepNameOm				NVARCHAR(255),
				   @OmOrderDateFrom			VARCHAR(10),
				   @OmOrderDateTo			VARCHAR(10),
				   @OmOrderArriveDateFrom	VARCHAR(10),
				   @OmOrderArriveDateTo		VARCHAR(10),
				   @cPersonCodeOm			NVARCHAR(20),
				   @cOmOrderCode			NVARCHAR(30),
				   @cInvCodeOm				NVARCHAR(60),
				   @cCode    NVARCHAR(60) ';
                            --PRINT @SqlCommand;
                            EXEC sp_executesql @SqlCommand, @ParmList,
                                @cMaker = @cMaker, @cExchNameOm = @cExchNameOm,
                                @cVenCodeOm = @cVenCodeOm,
                                @cVenAbbNameOm = @cVenAbbNameOm,
                                @cDepCodeOm = @cDepCodeOm,
                                @cDepNameOm = @cDepNameOm,
                                @OmOrderDateFrom = @OmOrderDateFrom,
                                @OmOrderDateTo = @OmOrderDateTo,
                                @OmOrderArriveDateFrom = @OmOrderArriveDateFrom,
                                @OmOrderArriveDateTo = @OmOrderArriveDateTo,
                                @cPersonCodeOm = @cPersonCodeOm,
                                @cOmOrderCode = @cOmOrderCode,
                                @cInvCodeOm = @cInvCodeOm,
								@cCode = @cCode;	 
                            SELECT  DISTINCT
                                    ccode
                            INTO    #STPDARefOmID
                            FROM    #STPDARefOmIDs;

                            CREATE CLUSTERED INDEX ix_STPDARefID_tmpid_PU_813 ON #STPDARefOmID( ccode ); 
                            SET NOCOUNT OFF;
                    
							--查询列表（表头）
                            SELECT DISTINCT
                                    '' AS selcol ,
                                    ( copyommolist.cCode ) AS ccode ,
                                    ( copyommolist.cbustype ) AS cbustype ,
                                    ( CONVERT(VARCHAR(100), copyommolist.dDate, 23) ) AS ddate ,
                                    ( copyommolist.cvencode ) AS cvencode ,
                                    ( copyommolist.cvenabbname ) AS cvenabbname ,
                                    ( copyommolist.cdepcode ) AS cdepcode ,
                                    ( copyommolist.cdepname ) AS cdepname ,
                                    ( copyommolist.cpersoncode ) AS cpersoncode ,
                                    ( copyommolist.cpersonname ) AS cpersonname ,
                                    ( copyommolist.csccode ) AS csccode ,
                                    ( copyommolist.cscname ) AS cscname ,
                                    ( copyommolist.cmemo ) AS cmemo ,
                                    ( copyommolist.ipertaxrate ) AS itaxrate ,
                                    ( copyommolist.cptcode ) AS cptcode ,
                                    ( copyommolist.cptname ) AS cptname ,
                                    ( copyommolist.cpaycode ) AS cpaycode ,
                                    ( copyommolist.cpayname ) AS cpayname ,
                                    ( copyommolist.cdefine1 ) AS cdefine1 ,
                                    ( copyommolist.cdefine2 ) AS cdefine2 ,
                                    ( copyommolist.cdefine3 ) AS cdefine3 ,
                                    ( copyommolist.cdefine4 ) AS cdefine4 ,
                                    ( copyommolist.cdefine5 ) AS cdefine5 ,
                                    ( copyommolist.cdefine6 ) AS cdefine6 ,
                                    ( copyommolist.cdefine7 ) AS cdefine7 ,
                                    ( copyommolist.cdefine8 ) AS cdefine8 ,
                                    ( copyommolist.cdefine9 ) AS cdefine9 ,
                                    ( copyommolist.cdefine10 ) AS cdefine10 ,
                                    ( copyommolist.cdefine11 ) AS cdefine11 ,
                                    ( copyommolist.cdefine12 ) AS cdefine12 ,
                                    ( copyommolist.cdefine13 ) AS cdefine13 ,
                                    ( copyommolist.cdefine14 ) AS cdefine14 ,
                                    ( copyommolist.cdefine15 ) AS cdefine15 ,
                                    ( copyommolist.cdefine16 ) AS cdefine16 ,
                                    ( copyommolist.cexch_name ) AS cexch_name ,
                                    ( copyommolist.nflat ) AS iexchrate ,
                                    ( copyommolist.MOID ) AS moid ,
                                    ( copyommolist.cvenpuomprotocol ) AS cvenpuomprotocol ,
                                    ( copyommolist.cvenpuomprotocolname ) AS cvenpuomprotocolname ,
                                    ( copyommolist.csysbarcode ) AS csysbarcode ,
                                    ( copyommolist.iordertype ) AS iwwordertype
                            FROM    copyommolist
                                    INNER JOIN #STPDARefOmID ON #STPDARefOmID.ccode = copyommolist.cCode
                            ORDER BY ccode;
                
                            IF ( @GetType = N'DETAIL' )
                                BEGIN
                                    SELECT  
				cdepcode,cdepname,copyommolist.ccode,cbsysbarcode,cvencode,cvenabbname as cvenname,
									
									( copyommolist.MODetailsID ) AS bodyautoid ,
                                            '' AS selcol ,
                                            ( copyommolist.ufts ) AS corufts ,
                                            copyommolist.MOID AS moid ,
                                            ( copyommolist.MODetailsID ) AS modetailsid ,
                                            ( copyommolist.btaxcost ) AS btaxcost ,
                                            ( copyommolist.cinvcode ) AS cinvcode ,
                                            ( copyommolist.cinvaddcode ) AS cinvaddcode ,
                                            ( copyommolist.cinvname ) AS cinvname ,
                                            ( copyommolist.cinvstd ) AS cinvstd ,
                                            ( copyommolist.cinvm_unit ) AS cinvm_unit ,
                                            ( copyommolist.bgsp ) AS bgsp ,
                                            ( copyommolist.imassdate ) AS imassdate ,
                                            ( ISNULL(copyommolist.iquantity, 0) ) AS iquantity ,
                                            ( ISNULL(copyommolist.iarrqty, 0) ) AS iarrqty ,
											 ( ISNULL(copyommolist.iarrqty, 0) ) as ireceivedqty,
                                            ( CASE WHEN @OperType = N'5'
                                                   THEN ( ISNULL(copyommolist.iquantity,
                                                              0)
                                                          - ISNULL(copyommolist.iarrqty,
                                                              0) )
                                                   ELSE ISNULL(copyommolist.iarrqty,
                                                              0)
                                              END ) AS inquantity ,
                                            ( CASE WHEN @OperType = N'5'
                                                   THEN ( ISNULL(copyommolist.inum,
                                                              0)
                                                          - ISNULL(copyommolist.iarrnum,
                                                              0) )
                                                   ELSE ISNULL(copyommolist.iarrnum,
                                                              0)
                                              END ) AS innum ,
                                            ( ISNULL(copyommolist.iinvexchrate,
                                                     0) ) AS iinvexchrate ,
                                            ( ISNULL(copyommolist.inum, 0) ) AS inum ,
                                            ( copyommolist.iunitprice ) AS iunitprice ,
                                            ( copyommolist.itaxprice ) AS itaxprice ,
                                            ( copyommolist.imoney ) AS imoney ,
                                            ( copyommolist.itax ) AS itax ,
                                            ( copyommolist.isum ) AS isum ,
                                            ( copyommolist.inatunitprice ) AS inatunitprice ,
                                            ( copyommolist.inatmoney ) AS inatmoney ,
                                            ( copyommolist.inattax ) AS inattax ,
                                            ( copyommolist.inatsum ) AS inatsum ,
                                            ( copyommolist.igrouptype ) AS igrouptype ,
                                            ( copyommolist.bInvEntrust ) AS binventrust ,
                                            ( copyommolist.cunitid ) AS cunitid ,
                                            ( copyommolist.cinva_unit ) AS cinva_unit ,
                                            ( copyommolist.cfree1 ) AS cfree1 ,
                                            ( copyommolist.cfree2 ) AS cfree2 ,
                                            ( copyommolist.cfree3 ) AS cfree3 ,
                                            ( copyommolist.cfree4 ) AS cfree4 ,
                                            ( copyommolist.cfree5 ) AS cfree5 ,
                                            ( copyommolist.cfree6 ) AS cfree6 ,
                                            ( copyommolist.cfree7 ) AS cfree7 ,
                                            ( copyommolist.cfree8 ) AS cfree8 ,
                                            ( copyommolist.cfree9 ) AS cfree9 ,
                                            ( copyommolist.cfree10 ) AS cfree10 ,
                                            ( copyommolist.cdefine22 ) AS cdefine22 ,
                                            ( copyommolist.cdefine23 ) AS cdefine23 ,
                                            ( copyommolist.cdefine24 ) AS cdefine24 ,
                                            ( copyommolist.cdefine25 ) AS cdefine25 ,
                                            ( copyommolist.cdefine26 ) AS cdefine26 ,
                                            ( copyommolist.cdefine27 ) AS cdefine27 ,
                                            ( copyommolist.cdefine28 ) AS cdefine28 ,
                                            ( copyommolist.cdefine29 ) AS cdefine29 ,
                                            ( copyommolist.cdefine30 ) AS cdefine30 ,
                                            ( copyommolist.cdefine31 ) AS cdefine31 ,
                                            ( copyommolist.cdefine32 ) AS cdefine32 ,
                                            ( copyommolist.cdefine33 ) AS cdefine33 ,
                                            ( copyommolist.cdefine34 ) AS cdefine34 ,
                                            ( copyommolist.cdefine35 ) AS cdefine35 ,
                                            ( copyommolist.cdefine36 ) AS cdefine36 ,
                                            ( copyommolist.cdefine37 ) AS cdefine37 ,
                                            ( copyommolist.citemcode ) AS citemcode ,
                                            ( copyommolist.citemname ) AS citemname ,
                                            ( copyommolist.citem_class ) AS citem_class ,
                                            ( copyommolist.citem_name ) AS citem_name ,
                                            ( copyommolist.cinvdefine1 ) AS cinvdefine1 ,
                                            ( copyommolist.cinvdefine2 ) AS cinvdefine2 ,
                                            ( copyommolist.cinvdefine3 ) AS cinvdefine3 ,
                                            ( copyommolist.cinvdefine4 ) AS cinvdefine4 ,
                                            ( copyommolist.cinvdefine5 ) AS cinvdefine5 ,
                                            ( copyommolist.cinvdefine6 ) AS cinvdefine6 ,
                                            ( copyommolist.cinvdefine7 ) AS cinvdefine7 ,
                                            ( copyommolist.cinvdefine8 ) AS cinvdefine8 ,
                                            ( copyommolist.cinvdefine9 ) AS cinvdefine9 ,
                                            ( copyommolist.cinvdefine10 ) AS cinvdefine10 ,
                                            ( copyommolist.cinvdefine11 ) AS cinvdefine11 ,
                                            ( copyommolist.cinvdefine12 ) AS cinvdefine12 ,
                                            ( copyommolist.cinvdefine13 ) AS cinvdefine13 ,
                                            ( copyommolist.cinvdefine14 ) AS cinvdefine14 ,
                                            ( copyommolist.cinvdefine15 ) AS cinvdefine15 ,
                                            ( copyommolist.cinvdefine16 ) AS cinvdefine16 ,
                                            ( copyommolist.sotype ) AS sotype ,
                                            ( copyommolist.sodid ) AS sodid ,
                                            ( copyommolist.iinvqty ) AS iinvqty ,
                                            ( copyommolist.csocode ) AS csocode ,
                                            ( copyommolist.irowno ) AS irowno ,
                                            ( copyommolist.cmassunit ) AS cmassunit ,
                                            ( copyommolist.dStartDate ) AS dstartdate ,
                                            ( copyommolist.dArriveDate ) AS darrivedate ,
                                            ( copyommolist.cwhcode ) AS cwhcode ,
                                            ( copyommolist.cwhname ) AS cwhname ,
                                            ( copyommolist.cCode ) AS ccode ,
                                            ( copyommolist.ipertaxrate ) AS itaxrate ,
                                            ( copyommolist.iarrnum ) AS iarrnum ,
                                            ( copyommolist.cdemandmemo ) AS cdemandmemo ,
                                            ( copyommolist.iexpiratdatecalcu ) AS iexpiratdatecalcu ,
                                            ( copyommolist.ivouchrowno ) AS ivouchrowno ,
                                            ( copyommolist.cbmemo ) AS cbmemo ,
                                            ( copyommolist.cbsysbarcode ) AS cbsysbarcode ,
                                            ( copyommolist.freworkquantity ) AS freworkquantity ,
                                            ( copyommolist.freworknum ) AS freworknum ,
                                            ( copyommolist.isourcemocode ) AS isourcemocode ,
                                            ( copyommolist.isourcemodetailsid ) AS isourcemodetailsid ,
                                            ( copyommolist.iproducttype ) AS iproducttype ,
                                            ( copyommolist.cmaininvcode ) AS cmaininvcode ,
                                            ( copyommolist.imainmodetailsid ) AS imainmodetailsid ,
                                            ( copyommolist.isoordertype ) AS iordertype ,
                                            ( copyommolist.csoordercode ) AS csoordercode ,
                                            ( copyommolist.iorderseq ) AS iorderseq ,
                                            ( copyommolist.iorderdid ) AS iorderdid ,
                                            ( copyommolist.cplanlotnumber ) AS planlotnumber ,
                                            '' AS cfactorycode ,
                                            '' AS cfactoryname ,
                                            0.0 AS iscanedquantity ,
                                            0.0 AS iscanednum
                                    FROM    copyommolist
                                            INNER JOIN #STPDARefOmIDs ON #STPDARefOmIDs.MODetailsID = copyommolist.MODetailsID
                                    WHERE   copyommolist.cCode IN (
                                            SELECT DISTINCT
                                                    ccode
                                            FROM    #STPDARefOmID )  order By copyommolist.darrivedate asc; 
                                END;
							--删除临时表

							 IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDATempOmOrderCodes') IS NULL )
                                DROP TABLE #STPDATempOmOrderCodes;

                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDARefOmIDs') IS NULL )
                                DROP TABLE #STPDARefOmIDs;
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDARefOmID') IS NULL )
                                DROP TABLE #STPDARefOmID;
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDATempOmIDs') IS NULL )
                                DROP TABLE #STPDATempOmIDs;
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDATempOmDIDs') IS NULL )
                                DROP TABLE #STPDATempOmDIDs;
                        END;
                    ELSE
                        IF ( @OperType = N'7'
                             OR @OperType = N'8'
                           )
						--@OperType=7：OM-参照到货单做委外退货单
						--@OperType=8：OM-参照到货单做委外到货拒收单
                            BEGIN
								--委外到货单日期FROM
                                DECLARE @ArriveOrderDateFromOm VARCHAR(10);
                                SET @ArriveOrderDateFromOm = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ArriveDateFrom',
                                                              DEFAULT, DEFAULT);
								--委外到货单日期TO
                                DECLARE @ArriveOrderDateToOm VARCHAR(10);
                                SET @ArriveOrderDateToOm = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ArriveDateTo',
                                                              DEFAULT, DEFAULT);
                                IF ( @ArriveOrderDateToOm = N'' )
                                    SET @ArriveOrderDateToOm = @ArriveOrderDateFromOm;
								--供应商编码
                                DECLARE @cVenCodeArrOm NVARCHAR(20);
                                SET @cVenCodeArrOm = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cVenCode',
                                                              DEFAULT, DEFAULT);
								--供应商简称
                                DECLARE @cVenAbbNameArrOm NVARCHAR(98);
                                SET @cVenAbbNameArrOm = '%'
                                    + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cVenAbbName',
                                                              DEFAULT, DEFAULT)
                                    + '%';
								--部门编码
                                DECLARE @cDepCodeArrOm NVARCHAR(12);
                                SET @cDepCodeArrOm = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cDepCode',
                                                              DEFAULT, DEFAULT);
								--部门名称
                                DECLARE @cDepNameArrOm NVARCHAR(255);
                                SET @cDepNameArrOm = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cDepName',
                                                              DEFAULT, DEFAULT);
								--业务员编码
                                DECLARE @cPersonCodeArrOm NVARCHAR(20);
                                SET @cPersonCodeArrOm = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cPersonCode',
                                                              DEFAULT, DEFAULT);   
								--存货编码
                                DECLARE @cInvCodeArrOm NVARCHAR(60);
                                SET @cInvCodeArrOm = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cInvCode',
                                                              DEFAULT, DEFAULT);
								--到货单单号
                                DECLARE @cArrCodeOm NVARCHAR(30);
                                SET @cArrCodeOm = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cArrCode',
                                                              DEFAULT, DEFAULT);
								--到货单主表ID
                                DECLARE @ArrOmIds NVARCHAR(1000);                
                                BEGIN
                
                                    SET @ArrOmIds = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ArrIds',
                                                              DEFAULT, DEFAULT);
                                    IF ( @ArrOmIds <> N'' )
                                        BEGIN                             
                                            IF EXISTS ( SELECT
                                                              0
                                                        WHERE NOT OBJECT_ID('tempdb..#STPDATempOMARRIDs') IS NULL )
                                                DROP TABLE #STPDATempOMARRIDs;
                    
                                            CREATE   TABLE #STPDATempOMARRIDs ( ArrId
                                                              INT );
                                            INSERT  INTO #STPDATempOMARRIDs
                                                    EXEC proc_ts_SplitParamString @ArrOmIds;
                                        END;
                                                              
                                END;
                
								--到货单子表ID
                                DECLARE @ArrOmDids NVARCHAR(1000);
                                BEGIN
                                    SET @ArrOmDids = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ArrOmDids',
                                                              DEFAULT, DEFAULT);
                                    IF ( @ArrOmDids <> N'' )
                                        BEGIN                             
                                            IF EXISTS ( SELECT
                                                              0
                                                        WHERE NOT OBJECT_ID('tempdb..#STPDATempOMARRDIDs') IS NULL )
                                                DROP TABLE #STPDATempOMARRDIDs;
                    
                                            CREATE   TABLE #STPDATempOMARRDIDs ( ArrDid
                                                              INT );
                                            INSERT  INTO #STPDATempOMARRDIDs
                                                    EXEC proc_ts_SplitParamString @ArrOmDids;
                                        END;
                                END;

                                SET NOCOUNT ON;
                                IF EXISTS ( SELECT  0
                                            WHERE   NOT OBJECT_ID('tempdb..#STPDARefArrOmIDs') IS NULL )
                                    DROP TABLE #STPDARefArrOmIDs;
                                IF EXISTS ( SELECT  0
                                            WHERE   NOT OBJECT_ID('tempdb..#STPDARefArrOmID') IS NULL )
                                    DROP TABLE #STPDARefArrOmID;
                    
                                SELECT  --IDENTITY( INT ) AS tmpId ,
                                        CONVERT(NVARCHAR(30), N'') AS cCode ,
                                        CONVERT(INT, 0) AS autoid
                                INTO    #STPDARefArrOmIDs
                                FROM    copyarrlist
                                WHERE   1 = 0; 
                                IF ( @OperType = N'7' )--OM-参照到货单做委外退货单
                                    BEGIN
                                        SET @SqlCommand = 'INSERT INTO #STPDARefArrOmIDs (cCode,autoid)
									SELECT cCode,autoid
									FROM copyarrlist WHERE bNegative = 0
        AND copyarrlist.cbustype = N''委外加工'' AND ISNULL(copyarrlist.cverifier, N'''') <> N''''
        AND ISNULL(iproducttype, 0) = 0 AND ISNULL(cvouchtype, '''') <> N''IM26'' AND 1 = 1 ';
                                        SET @SqlCommand = @SqlCommand
                                            + ' AND (ISNULL(fvalidinquan, 0) - ABS(ISNULL(fretquantity, 0)) > 0) ';
                        
                        /*跟踪的代码
                         AND ( ( ISNULL(fvalidinquan, 0) - ABS(ISNULL(fretquantity, 0)) > 0
                AND igrouptype <> 2
              )
              OR ( ( ( ISNULL(fvalidinquan, 0) - ABS(ISNULL(fretquantity, 0)) ) > 0
                     OR ( ISNULL(fvalidinquan, 0) - ABS(ISNULL(fretquantity, 0)) ) > 0
                   )
                   AND igrouptype = 2
                 )
            )
                        */
                                    END;
                                ELSE--OM-参照到货单做委外到货拒收单
                                    BEGIN
                                        SET @SqlCommand = 'INSERT INTO #STPDARefArrOmIDs (cCode,autoid)
									SELECT cCode,autoid FROM copyarrlist WHERE bNegative = 0
        AND copyarrlist.cbustype = N''委外加工'' AND ISNULL(copyarrlist.cverifier,N'''') <> N''''
        AND ( ISNULL(cvouchtype,'''') <> N''IM27'' AND ISNULL(copyarrlist.cbcloser,'''') = ''''
              AND ((ISNULL(irefuseqty,0) > 0 AND igrouptype <> 2)
        OR ((ISNULL(irefuseqty,0) > 0 OR ISNULL(irefusenum,0) > 0) AND igrouptype = 2))) AND 1 = 1 ';
                                    END;
                        
                                IF ( @cMaker <> N'' )
                                    SET @SqlCommand = @SqlCommand
                                        + ' AND (cmaker=@cMaker) ';
                                IF ( @cVenCodeArrOm <> N'' )
                                    SET @SqlCommand = @SqlCommand
                                        + ' AND (cvencode = @cVenCodeArrOm) ';
                                IF ( @cVenAbbNameArrOm <> N''
                                     AND @cVenAbbNameArrOm <> N'%%'
                                   )
                                    SET @SqlCommand = @SqlCommand
                                        + ' AND (cvenabbname LIKE @cVenAbbNameArrOm) ';
                                IF ( @cDepCodeArrOm <> N'' )
                                    SET @SqlCommand = @SqlCommand
                                        + ' AND (cdepcode = @cDepCodeArrOm) ';
                                IF ( @cDepNameArrOm <> N'' )
                                    SET @SqlCommand = @SqlCommand
                                        + ' AND (cdepname = @cDepNameArrOm) ';
                                IF ( @ArriveOrderDateFromOm <> N''
                                     AND @ArriveOrderDateToOm <> N''
                                   )
                                    SET @SqlCommand = @SqlCommand
                                        + ' AND ((ddate >= @ArriveOrderDateFromOm) AND (ddate <= @ArriveOrderDateToOm)) ';
                                IF ( @cPersonCodeArrOm <> N'' )
                                    SET @SqlCommand = @SqlCommand
                                        + ' AND (cpersoncode = @cPersonCodeArrOm) ';
                                IF ( @cArrCodeOm <> N'' )
                                    SET @SqlCommand = @SqlCommand
                                        + ' AND (cCode = @cArrCodeOm) '; 
                                IF ( @cInvCodeArrOm <> N'' )
                                    SET @SqlCommand = @SqlCommand
                                        + ' AND (cinvcode = @cInvCodeArrOm) ';
                                IF ( @ArrOmIds <> N'' )
                                    SET @SqlCommand = @SqlCommand
                                        + ' AND (id IN (SELECT DISTINCT ArrId FROM #STPDATempOMARRIDs)) ';
                                IF ( @ArrOmDids <> N'' )
                                    SET @SqlCommand = @SqlCommand
                                        + ' AND (autoid IN (SELECT DISTINCT ArrDid FROM #STPDATempOMARRDIDs)) ';
                                IF ( @ShowClosed = '0' )
                                    BEGIN
                                        SET @SqlCommand = @SqlCommand
                                            + ' AND ( isshow = N''0'' ) '; 
									--isshow:单据是否关闭
                                    END;

                                SET @ParmList = '@cMaker			NVARCHAR(30),
				   @cVenCodeArrOm				NVARCHAR(20),
				   @cVenAbbNameArrOm			NVARCHAR(60),
				   @cDepCodeArrOm				NVARCHAR(12),
				   @cDepNameArrOm				NVARCHAR(255),
				   @ArriveOrderDateFromOm		VARCHAR(10),
				   @ArriveOrderDateToOm			VARCHAR(10),
				   @cPersonCodeArrOm			NVARCHAR(20),
				   @cArrCodeOm					NVARCHAR(30),
				   @cInvCodeArrOm				NVARCHAR(60)';
                    --PRINT @SqlCommand;
                                EXEC sp_executesql @SqlCommand, @ParmList,
                                    @cMaker = @cMaker,
                                    @cVenCodeArrOm = @cVenCodeArrOm,
                                    @cVenAbbNameArrOm = @cVenAbbNameArrOm,
                                    @cDepCodeArrOm = @cDepCodeArrOm,
                                    @cDepNameArrOm = @cDepNameArrOm,
                                    @ArriveOrderDateFromOm = @ArriveOrderDateFromOm,
                                    @ArriveOrderDateToOm = @ArriveOrderDateToOm,
                                    @cPersonCodeArrOm = @cPersonCodeArrOm,
                                    @cArrCodeOm = @cArrCodeOm,
                                    @cInvCodeArrOm = @cInvCodeArrOm;	 
                                SELECT  DISTINCT
                                        cCode
                                INTO    #STPDARefArrOmID
                                FROM    #STPDARefArrOmIDs;

                                CREATE CLUSTERED INDEX ix_STPDARefID_tmpid_PU_813 ON #STPDARefArrOmID( cCode ); 
                                SET NOCOUNT OFF;
                    
								--查询列表（表头）
                                SELECT DISTINCT
                                        '' AS selcol ,
                                        ( copyarrlist.ibilltype ) AS ibilltype ,
                                        ( copyarrlist.iflowid ) AS iflowid ,
                                        ( copyarrlist.cflowname ) AS cflowname ,
                                        ( copyarrlist.cCode ) AS ccode ,
                                        ( CONVERT(VARCHAR(100), copyarrlist.ddate, 23) ) AS ddate ,
                                        ( copyarrlist.cvencode ) AS cvencode ,
                                        ( copyarrlist.cvenabbname ) AS cvenabbname ,
                                        ( copyarrlist.cdepcode ) AS cdepcode ,
                                        ( copyarrlist.cdepname ) AS cdepname ,
                                        ( copyarrlist.cpersoncode ) AS cpersoncode ,
                                        ( copyarrlist.cpersonname ) AS cpersonname ,
                                        ( copyarrlist.cmemo ) AS cmemo ,
                                        ( copyarrlist.cptcode ) AS cptcode ,
                                        ( copyarrlist.cptname ) AS cptname ,
                                        ( copyarrlist.csccode ) AS csccode ,
                                        ( copyarrlist.cscname ) AS cscname ,
                                        ( copyarrlist.cpaycode ) AS cpaycode ,
                                        ( copyarrlist.cpayname ) AS cpayname ,
                                        ( copyarrlist.cdefine1 ) AS cdefine1 ,
                                        ( copyarrlist.cdefine2 ) AS cdefine2 ,
                                        ( copyarrlist.cdefine3 ) AS cdefine3 ,
                                        ( copyarrlist.cdefine4 ) AS cdefine4 ,
                                        ( copyarrlist.cdefine5 ) AS cdefine5 ,
                                        ( copyarrlist.cdefine6 ) AS cdefine6 ,
                                        ( copyarrlist.cdefine7 ) AS cdefine7 ,
                                        ( copyarrlist.cdefine8 ) AS cdefine8 ,
                                        ( copyarrlist.cdefine9 ) AS cdefine9 ,
                                        ( copyarrlist.cdefine10 ) AS cdefine10 ,
                                        ( copyarrlist.cdefine11 ) AS cdefine11 ,
                                        ( copyarrlist.cdefine12 ) AS cdefine12 ,
                                        ( copyarrlist.cdefine13 ) AS cdefine13 ,
                                        ( copyarrlist.cdefine14 ) AS cdefine14 ,
                                        ( copyarrlist.cdefine15 ) AS cdefine15 ,
                                        ( copyarrlist.cdefine16 ) AS cdefine16 ,
                                        ( copyarrlist.cexch_name ) AS cexch_name ,
                                        ( copyarrlist.iexchrate ) AS iexchrate ,
                                        ( copyarrlist.cmaker ) AS cmaker ,
                                        ( copyarrlist.cverifier ) AS cverifier ,
                                        ccloser ,
                                        ( copyarrlist.cvenpuomprotocol ) AS cvenpuomprotocol ,
                                        ( copyarrlist.cvenpuomprotocolname ) AS cvenpuomprotocolname ,
                                        cbustype
                                FROM    copyarrlist
                                        INNER JOIN #STPDARefArrOmID ON #STPDARefArrOmID.cCode = copyarrlist.cCode
                                ORDER BY ccode;
                
                                IF ( @GetType = N'DETAIL' )
                                    BEGIN
                                        SELECT  
										
											cdepcode,cdepname, 
			 copyarrlist.ccode as ccode,cbsysbarcode,
			copyarrlist.cvencode,copyarrlist.cvenabbname as cvenname,
										
										( copyarrlist.autoid ) AS bodyautoid ,
                                                '' AS selcol ,
                                                ( ISNULL(copyarrlist.frealquantity,
                                                         0.0) ) AS frealquantity ,--实收数量
                                                ( ISNULL(copyarrlist.frealnum,
                                                         0.0) ) AS frealnum ,--实收件数
                                                ( ISNULL(copyarrlist.fsumrefusequantity,
                                                         0.0) ) AS fsumrefusequantity ,--合计拒收数量
                                                ( ISNULL(copyarrlist.fsumrefusenum,
                                                         0.0) ) AS fsumrefusenum ,--合计拒收件数
                                                ( ISNULL(copyarrlist.fvalidinquan,
                                                         0.0) ) AS fvalidinquan ,--合格入库数量
                                                ( ISNULL(copyarrlist.fvalidinnum,
                                                         0.0) ) AS fvalidinnum ,--合格入库件数
                                                ( ISNULL(copyarrlist.iquantity,
                                                         0.0) ) AS iquantity ,--到货数量
                                                ( copyarrlist.iinvexchrate ) AS iinvexchrate ,--换算率
                                                ( ISNULL(copyarrlist.inum, 0.0) ) AS inum ,--到货件数
                                                ( ISNULL(copyarrlist.fretquantity,
                                                         0.0) ) AS fretquantity ,--已退货数量
 ( ISNULL(copyarrlist.fretquantity,0.0) ) as ireceivedqty,

                                                ( copyarrlist.fretnum ) AS fretnum ,--已退货件数
                                                ( CASE WHEN @OperType = N'7'
                                                       THEN ( ISNULL(copyarrlist.fvalidinquan,
                                                              0.0)
                                                              - ISNULL(copyarrlist.fretquantity,
                                                              0.0) )
                                                       ELSE ( ISNULL(copyarrlist.irefuseqty,
                                                              0.0) )
                                                  END ) AS inquantity ,--本次可退货数量
                                                ( CASE WHEN @OperType = N'7'
                                                       THEN ( ISNULL(copyarrlist.fvalidinnum,
                                                              0.0)
                                                              - ISNULL(copyarrlist.fretnum,
                                                              0.0) )
                                                       ELSE ISNULL(copyarrlist.irefusenum,
                                                              0.0)
                                                  END ) AS innum ,--本次可退货件数
                                                ( ISNULL(copyarrlist.fRefuseQuantity,
                                                         0.0) ) AS frefusequantity ,--已拒收数量
                                                ( ISNULL(copyarrlist.fRefuseNum,
                                                         0.0) ) AS frefusenum ,--已拒收件数
                                                ( ISNULL(copyarrlist.irefuseqty,
                                                         0.0) ) AS irefuseqty ,--剩余可拒收数量
                                                ( ISNULL(copyarrlist.irefusenum,
                                                         0.0) ) AS irefusenum ,--剩余可拒收件数
                                                ( copyarrlist.autoid ) AS autoid ,
                                                ( copyarrlist.btaxcost ) AS btaxcost ,
                                                ( copyarrlist.iposid ) AS iposid ,
                                                ( copyarrlist.cinvcode ) AS cinvcode ,
                                                ( copyarrlist.cinvname ) AS cinvname ,
                                                ( copyarrlist.cinvstd ) AS cinvstd ,
                                                ( copyarrlist.cinvm_unit ) AS cinvm_unit ,
                                                ( copyarrlist.icost ) AS icost ,
                                                ( copyarrlist.imoney ) AS imoney ,
                                                ( copyarrlist.itaxprice ) AS itaxprice ,
                                                ( copyarrlist.isum ) AS isum ,
                                                ( copyarrlist.ioricost ) AS ioricost ,
                                                ( copyarrlist.ioritaxcost ) AS ioritaxcost ,
                                                ( copyarrlist.iorimoney ) AS iorimoney ,
                                                ( copyarrlist.ioritaxprice ) AS ioritaxprice ,
                                                ivouchrowno ,
                                                ( copyarrlist.iorisum ) AS iorisum ,
                                                ( ISNULL(copyarrlist.itaxrate,
                                                         0) ) AS itaxrate ,
                                                ( copyarrlist.igrouptype ) AS igrouptype ,
                                                ( copyarrlist.bInvEntrust ) AS binventrust ,
                                                ( copyarrlist.cunitid ) AS cunitid ,
                                                ( copyarrlist.cinva_unit ) AS cinva_unit ,
                                                ( copyarrlist.cwhcode ) AS cwhcode ,
                                                ( copyarrlist.cwhname ) AS cwhname ,
                                                ( copyarrlist.cbatch ) AS cbatch ,
                                                ( copyarrlist.bgsp ) AS bgsp ,
                                                ( copyarrlist.imassdate ) AS imassdate ,
                                                ( copyarrlist.dpdate ) AS dpdate ,
                                                ( copyarrlist.dvdate ) AS dvdate ,
                                                ( copyarrlist.cfree1 ) AS cfree1 ,
                                                ( copyarrlist.cfree2 ) AS cfree2 ,
                                                ( copyarrlist.cfree3 ) AS cfree3 ,
                                                ( copyarrlist.cfree4 ) AS cfree4 ,
                                                ( copyarrlist.cfree5 ) AS cfree5 ,
                                                ( copyarrlist.cfree6 ) AS cfree6 ,
                                                ( copyarrlist.cfree7 ) AS cfree7 ,
                                                ( copyarrlist.cfree8 ) AS cfree8 ,
                                                ( copyarrlist.cfree9 ) AS cfree9 ,
                                                ( copyarrlist.cfree10 ) AS cfree10 ,
                                                ( copyarrlist.cdefine22 ) AS cdefine22 ,
                                                ( copyarrlist.cdefine23 ) AS cdefine23 ,
                                                ( copyarrlist.cdefine24 ) AS cdefine24 ,
                                                ( copyarrlist.cdefine25 ) AS cdefine25 ,
                                                ( copyarrlist.cdefine26 ) AS cdefine26 ,
                                                ( copyarrlist.cdefine27 ) AS cdefine27 ,
                                                ( copyarrlist.cdefine28 ) AS cdefine28 ,
                                                ( copyarrlist.cdefine29 ) AS cdefine29 ,
                                                ( copyarrlist.cdefine30 ) AS cdefine30 ,
                                                ( copyarrlist.cdefine31 ) AS cdefine31 ,
                                                ( copyarrlist.cdefine32 ) AS cdefine32 ,
                                                ( copyarrlist.cdefine33 ) AS cdefine33 ,
                                                ( copyarrlist.cdefine34 ) AS cdefine34 ,
                                                ( copyarrlist.cdefine35 ) AS cdefine35 ,
                                                ( copyarrlist.cdefine36 ) AS cdefine36 ,
                                                ( copyarrlist.cdefine37 ) AS cdefine37 ,
                                                ( copyarrlist.cbatchproperty1 ) AS cbatchproperty1 ,
                                                ( copyarrlist.cbatchproperty2 ) AS cbatchproperty2 ,
                                                ( copyarrlist.cbatchproperty3 ) AS cbatchproperty3 ,
                                                ( copyarrlist.cbatchproperty4 ) AS cbatchproperty4 ,
                                                ( copyarrlist.cbatchproperty5 ) AS cbatchproperty5 ,
                                                ( copyarrlist.cbatchproperty6 ) AS cbatchproperty6 ,
                                                ( copyarrlist.cbatchproperty7 ) AS cbatchproperty7 ,
                                                ( copyarrlist.cbatchproperty8 ) AS cbatchproperty8 ,
                                                ( copyarrlist.cbatchproperty9 ) AS cbatchproperty9 ,
                                                ( copyarrlist.cbatchproperty10 ) AS cbatchproperty10 ,
                                                ( copyarrlist.citemcode ) AS citemcode ,
                                                ( copyarrlist.citemname ) AS citemname ,
                                                ( copyarrlist.citem_class ) AS citem_class ,
                                                ( copyarrlist.citem_name ) AS citem_name ,
                                                ( copyarrlist.cinvaddcode ) AS cinvaddcode ,
                                                ( copyarrlist.cinvdefine1 ) AS cinvdefine1 ,
                                                ( copyarrlist.cinvdefine2 ) AS cinvdefine2 ,
                                                ( copyarrlist.cinvdefine3 ) AS cinvdefine3 ,
                                                ( copyarrlist.cinvdefine4 ) AS cinvdefine4 ,
                                                ( copyarrlist.cinvdefine5 ) AS cinvdefine5 ,
                                                ( copyarrlist.cinvdefine6 ) AS cinvdefine6 ,
                                                ( copyarrlist.cinvdefine7 ) AS cinvdefine7 ,
                                                ( copyarrlist.cinvdefine8 ) AS cinvdefine8 ,
                                                ( copyarrlist.cinvdefine9 ) AS cinvdefine9 ,
                                                ( copyarrlist.cinvdefine10 ) AS cinvdefine10 ,
                                                ( copyarrlist.cinvdefine11 ) AS cinvdefine11 ,
                                                ( copyarrlist.cinvdefine12 ) AS cinvdefine12 ,
                                                ( copyarrlist.cinvdefine13 ) AS cinvdefine13 ,
                                                ( copyarrlist.cinvdefine14 ) AS cinvdefine14 ,
                                                ( copyarrlist.cinvdefine15 ) AS cinvdefine15 ,
                                                ( copyarrlist.cinvdefine16 ) AS cinvdefine16 ,
                                                ( copyarrlist.cordercode ) AS cordercode ,
                                                ( copyarrlist.contractcode ) AS contractcode ,
                                                ( copyarrlist.contractrowno ) AS contractrowno ,
                                                ( copyarrlist.contractrowguid ) AS contractrowguid ,
                                                ( copyarrlist.bexigency ) AS bexigency ,
                                                ( copyarrlist.cmassunit ) AS cmassunit ,
                                                ( copyarrlist.irowno ) AS irowno ,
                                                ( copyarrlist.sotype ) AS sotype ,
                                                ( copyarrlist.sodid ) AS sodid ,
                                                ( copyarrlist.csocode ) AS csocode ,
                                                cbcloser ,
                                                ( copyarrlist.ufts ) AS corufts ,
                                                ( copyarrlist.iinvmpcost ) AS iinvmpcost ,
                                                ( copyarrlist.cCode ) AS ccode ,
                                                ( copyarrlist.iexpiratDateCalcu ) AS iexpiratdatecalcu ,
                                                ( copyarrlist.cexpirationdate ) AS cexpirationdate ,
                                                ( copyarrlist.dexpirationdate ) AS dexpirationdate ,
                                                ( copyarrlist.cdemandmemo ) AS cdemandmemo ,
                                                ( copyarrlist.iorderdid ) AS iorderdid ,
                                                ( copyarrlist.iordertype ) AS iordertype ,
                                                ( copyarrlist.csoordercode ) AS csoordercode ,
                                                ( copyarrlist.iorderseq ) AS iorderseq ,
                                                ( copyarrlist.cbmemo ) AS cbmemo ,
                                                ( copyarrlist.planlotnumber ) AS planlotnumber ,
                                                bgift ,
                                                '' AS cfactorycode ,
                                                '' AS cfactoryname ,
                                                0.0 AS iscanedquantity ,
                                                0.0 AS iscanednum
                                        FROM    copyarrlist
                                                INNER JOIN #STPDARefArrOmIDs ON #STPDARefArrOmIDs.autoid = copyarrlist.autoid
                                        WHERE   copyarrlist.cCode IN (
                                                SELECT DISTINCT
                                                        cCode
                                                FROM    #STPDARefArrOmID ); 
                                    END;
								--删除临时表
                                IF EXISTS ( SELECT  0
                                            WHERE   NOT OBJECT_ID('tempdb..#STPDARefArrOmIDs') IS NULL )
                                    DROP TABLE #STPDARefArrOmIDs;
                                IF EXISTS ( SELECT  0
                                            WHERE   NOT OBJECT_ID('tempdb..#STPDARefArrOmID') IS NULL )
                                    DROP TABLE #STPDARefArrOmID;
                                IF EXISTS ( SELECT  0
                                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempOMARRIDs') IS NULL )
                                    DROP TABLE #STPDATempOMARRIDs;
                                IF EXISTS ( SELECT  0
                                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempOMARRDIDs') IS NULL )
                                    DROP TABLE #STPDATempOMARRDIDs;
                            END;
                        ELSE
                            BEGIN
                                PRINT @OperType;
                            END;
    END;