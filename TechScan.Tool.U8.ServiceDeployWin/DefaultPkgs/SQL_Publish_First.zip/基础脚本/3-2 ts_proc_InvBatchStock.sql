﻿/*---------------------------------------------------------------------
* 			Copyright (C) 2018 TECHSCAN 版权所有。
*           www.techscan.cn
*┌────────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．      │
*│　版权所有：上海太迅自动识别技术有限公司 　 　　　　　　　　　　　　    │
*└────────────────────────────────────┘
*
* 文件名：   ts_proc_InvBatchStock.SQL
* 功能：     存储过程
* 描述：     存货批次库存获取
* 作者：     马永龙
* 创建时间： 2018-06-21 13:11:28
* 文件版本： V1.0.0

===============================版本履历===============================
* Ver 		变更日期 				负责人 	变更内容
* V1.0.0	2018-06-21 13:11:28		Myl		Create

======================================================================
//--------------------------------------------------------------------*/

--ts_proc_InvBatchStock '1', 'BOM0000003', '1001', '1805170A' ,0
--ts_proc_InvBatchStock '0', 'BOM0000003', '1001', '1805170A', 0 

Create PROC ts_proc_InvBatchStock
    (
      --出入库类别
	  --0：出库批次库存查询
	  --1：入库批次库存查询
      @cRdCode CHAR(1) ,
      --存货编码
      @cInvCode NVARCHAR(60) ,
      --仓库编码
      @cWhCode NVARCHAR(10) ,
      --批次
      @cBatch NVARCHAR(60) ,
      --是否显示零结存数据
      @bShowZeroStock BIT = 0
    )
    WITH ENCRYPTION
AS
    BEGIN
        IF ( @cRdCode <> N'0'
             AND @cRdCode <> N'1'
           )
            BEGIN
                RAISERROR ('出入库类别参数传输错误[cRdCode]！',16, 1 );
                RETURN;
            END;
        IF ( @cWhCode = N'' )
            BEGIN
                RAISERROR ('未传入有效的仓库编码[cWhCode]！',16, 1 );
                RETURN;
            END;
        IF ( @cInvCode = N'' )
            BEGIN
                RAISERROR ('未传入有效的存货编码[cInvCode]！',16, 1 );
                RETURN;
            END;
        DECLARE @ParmList NVARCHAR(MAX) = N'';
        DECLARE @SqlCommand NVARCHAR(MAX) = N'';
        IF ( @cRdCode = N'1' )
            BEGIN
                SET @SqlCommand = N'SELECT DISTINCT
                                cWhCode AS cwhcode ,
                                cInvCode AS cinvcode ,
                                cBatch AS cbatch ,
                                CurrentStock.cVMIVenCode AS cvmivencode ,
                                Vendor.cVenName AS cvenname ,
                                Vendor.cVenAbbName AS cvenabbname ,
                                CurrentStock.iQuantity AS iquantity ,
                                CurrentStock.iNum AS inum ,
                                dVDate AS dvdate ,
                                dMdate AS dmdate ,
                                iMassDate AS imassdate ,
                                cExpirationdate AS cexpirationdate ,
                                dExpirationdate AS dexpirationdate ,
                                cFree1 AS cfree1 ,
                                cFree2 AS cfree2 ,
                                cFree3 AS cfree3 ,
                                cFree4 AS cfree4 ,
                                cFree5 AS cfree5 ,
                                cFree6 AS cfree6 ,
                                cFree7 AS cfree7 ,
                                cFree8 AS cfree8 ,
                                cFree9 AS cfree9 ,
                                cFree10 AS cfree10
                        FROM    CurrentStock
                                LEFT JOIN Vendor ON CurrentStock.cVMIVenCode = Vendor.cVenCode
                        WHERE   ISNULL(cbatch, N'''') <> N''''
                                AND cinvcode = @cInvCode
                                AND cwhcode = @cWhCode ';
                IF ( @cBatch <> N'' )
                    BEGIN
                        SET @SqlCommand = @SqlCommand
                            + N' AND ISNULL(cbatch, N'''')=@cBatch ';
                    END;
                IF ( @bShowZeroStock = 0 )
                    BEGIN
             --不显示0库存
                        SET @SqlCommand = @SqlCommand
                            + N' AND ISNULL(CurrentStock.iQuantity, 0) > 0 ';
                    END;
                SET @SqlCommand = @SqlCommand + N' ORDER BY cbatch; ';
                PRINT @SqlCommand;
                SET @ParmList = '@cInvCode			NVARCHAR(60),
								 @cWhCode				NVARCHAR(10),
								 @cBatch				NVARCHAR(60)';
   
                EXEC sp_executesql @SqlCommand, @ParmList,
                    @cInvCode = @cInvCode, @cWhCode = @cWhCode,
                    @cBatch = @cBatch;
            END;
        ELSE
            BEGIN                
                SET @SqlCommand = N'SELECT * FROM (SELECT cWhCode AS cwhcode,batch.cBatchProperty1 AS cbatchproperty1 ,
batch.cBatchProperty2 AS cbatchproperty2,batch.cBatchProperty3 AS cbatchproperty3 ,
batch.cBatchProperty4 AS cbatchproperty4,batch.cBatchProperty5 AS cbatchproperty5,
batch.cBatchProperty6 AS cbatchproperty6,batch.cBatchProperty7 AS cbatchproperty7,
batch.cBatchProperty8 AS cbatchproperty8,batch.cBatchProperty9 AS cbatchproperty9,
batch.cBatchProperty10 AS cbatchproperty10,V_CurrentStock.cFree1 AS cfree1 ,
V_CurrentStock.cFree2 AS cfree2,V_CurrentStock.cFree3 AS cfree3,
V_CurrentStock.cFree4 AS cfree4,V_CurrentStock.cFree5 AS cfree5,
V_CurrentStock.cFree6 AS cfree6,V_CurrentStock.cFree7 AS cfree7,
V_CurrentStock.cFree8 AS cfree8,V_CurrentStock.cFree9 AS cfree9,
V_CurrentStock.cFree10 AS cfree10,V_CurrentStock.cMassUnit AS cmassunit,
(CASE V_CurrentStock.cMassUnit WHEN 0 THEN N'''' WHEN 1 THEN N''年'' WHEN 2 THEN N''月'' WHEN 3 THEN N''日'' ELSE NULL END) AS 保质期单位,
V_CurrentStock.cBatch AS 批号,V_CurrentStock.cBatch AS cbatch,
iQuantity + ISNULL(fInQuantity,0) - ISNULL(fOutQuantity,0)- ISNULL(fStopQuantity,0) AS 结存数量,
inum + ISNULL(finnum,0) - ISNULL(foutnum,0)- ISNULL(fStopNum,0) AS 结存件数,
iQuantity AS 出库数量,inum AS 出库件数,dMdate AS 生产日期,dMdate AS dmdate,iMassDate AS 保质期,iMassDate AS imassdate,
dVDate AS 失效日期,dVDate AS dvdate,v1.EnumName AS 有效期推算方式,cexpirationdate AS 有效期至 ,
cexpirationdate,dexpirationdate AS 有效期计算项,dexpirationdate,'''' AS 订单结存数量,'''' AS 订单结存件数,
V_CurrentStock.cvmivencode AS 代管商编码,v.cVenAbbName AS 代管商
FROM V_CurrentStock
LEFT JOIN Vendor v ON v.cVenCode = V_CurrentStock.cvmivencode
LEFT JOIN v_aa_enum v1 ON v1.EnumCode = V_CurrentStock.iexpiratdatecalcu AND v1.EnumType = N''SCM.ExpiratDateCalcu''
LEFT JOIN AA_BatchProperty batch ON batch.cInvCode = V_CurrentStock.cInvCode
AND ISNULL(batch.cBatch,N'''') = ISNULL(V_CurrentStock.cBatch,N'''')
AND ISNULL(batch.cFree1,N'''') = ISNULL(V_CurrentStock.cFree1,N'''')
AND ISNULL(batch.cFree2,N'''') = ISNULL(V_CurrentStock.cFree2,N'''')
AND ISNULL(batch.cFree3,N'''') = ISNULL(V_CurrentStock.cFree3,N'''')
AND ISNULL(batch.cFree4,N'''') = ISNULL(V_CurrentStock.cFree4,N'''')
AND ISNULL(batch.cFree5,N'''') = ISNULL(V_CurrentStock.cFree5,N'''')
AND ISNULL(batch.cFree6,N'''') = ISNULL(V_CurrentStock.cFree6,N'''')
AND ISNULL(batch.cFree7,N'''') = ISNULL(V_CurrentStock.cFree7,N'''')
AND ISNULL(batch.cFree8,N'''') = ISNULL(V_CurrentStock.cFree8,N'''')
AND ISNULL(batch.cFree9,N'''') = ISNULL(V_CurrentStock.cFree9,N'''')
AND ISNULL(batch.cFree10,N'''') = ISNULL(V_CurrentStock.cFree10,N'''')
WHERE 1=1 
AND V_CurrentStock.cInvCode =@cInvCode AND V_CurrentStock.cWhCode = @cWhCode
AND ISNULL(V_CurrentStock.cBatch,N'''') <> N'''' AND ISNULL(bStopFlag, 0) = 0
AND (ISNULL(iSoType,0) = 0 AND ISNULL(isodid,N'''') = N'''')) A
WHERE 1=1 ';
                IF ( @cBatch <> N'' )
                    BEGIN
                        SET @SqlCommand = @SqlCommand
                            + N' AND cbatch=@cBatch ';
                    END;
                IF ( @bShowZeroStock = 0 )
                    BEGIN
                        SET @SqlCommand = @SqlCommand + N' AND 结存数量>0 ';
                    END;
                SET @SqlCommand = @SqlCommand
                    + N' ORDER BY A.dvdate,A.cbatch;';
                            
                SET @ParmList = '@cInvCode			NVARCHAR(60),
								 @cWhCode				NVARCHAR(10),
								 @cBatch				NVARCHAR(60)';
   
                EXEC sp_executesql @SqlCommand, @ParmList,
                    @cInvCode = @cInvCode, @cWhCode = @cWhCode,
                    @cBatch = @cBatch;
            END;
        
    END;
