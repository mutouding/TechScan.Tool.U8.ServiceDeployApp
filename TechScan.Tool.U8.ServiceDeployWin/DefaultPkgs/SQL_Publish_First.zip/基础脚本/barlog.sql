﻿if not  exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'barlog'))
begin
CREATE TABLE [dbo].[barlog](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Date] [datetime] NOT NULL,
	[SPID] [nvarchar](50) NULL,
	[Thread] [varchar](100) NULL,
	[Level] [varchar](100) NULL,
	[Logger] [varchar](200) NULL,
	[Message] [text] NULL,
	[Exception] [text] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
end