﻿/*---------------------------------------------------------------------  
*    Copyright (C) 2018 TECHSCAN 版权所有。  
*           www.techscan.cn  
*┌────────────────────────────────────┐  
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．      │  
*│　版权所有：上海太迅自动识别技术有限公司 　 　　　　　　　　　　　　    │  
*└────────────────────────────────────┘  
*  
* 文件名：   proc_ts_ReferVouch_BoxUp_Get.SQL  
* 功能：     存储过程  
* 描述：     ST条码管理[装箱单]-获取上游可参照单据信息  （装箱单目前支持上游单据为生产订单和发货单）
* 作者：     马永龙  
* 创建时间： 2018-11-27 17:28:13  
* 文件版本： V1.0.0
  
===============================版本履历===============================  
* Ver		变更日期				负责人		变更内容  
* V1.0.0	2018-11-27 17:28:13  Myl		Create  
* V1.0.1	2018-11-28			 Myl		添加销售发货单参照类型  

======================================================================  
//--------------------------------------------------------------------*/  

CREATE PROC proc_ts_ReferVouch_BoxUp_Get
    (
      --0：参照生产订单
      --1：参照销售发货单
      @OperType CHAR(1) ,
      --获取类型（'LIST'获取上游参照单据列表;'DETAIL'获取上游参照单据详情（包含表头表体））  
      --默认获取上游参照单据列表  
      @GetType VARCHAR(10) = N'LIST' ,  
      --传入的参数列表字符串  
      --默认传空值  
      @ParamsList NVARCHAR(2000) = N''  
    )
AS
    BEGIN  
		--单据条码
        DECLARE @cSysBarcode NVARCHAR(60);  
        SET @cSysBarcode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cSysBarcode',
                                                              DEFAULT, DEFAULT);  
        --生产订单单据起始日期
        DECLARE @dDateFrom NVARCHAR(20);
        SET @dDateFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dDateFrom',
                                                              DEFAULT, DEFAULT);
        --生产订单单据截止日期
        DECLARE @dDateTo NVARCHAR(20);
        SET @dDateTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dDateTo',
                                                              DEFAULT, DEFAULT);
        IF ( @dDateTo = N'' )
            BEGIN
                SET @dDateTo = @dDateFrom;
            END;
        DECLARE @cMaker NVARCHAR(30);
        SET @cMaker = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                             N'cMaker',
                                                             DEFAULT, DEFAULT);

		DECLARE @ParmList NVARCHAR(MAX);
        DECLARE @SqlCommand NVARCHAR(MAX);
		
		SET @ParmList=N'';
		SET @SqlCommand=N'';

        IF ( @OperType = N'0' )
        --装箱单参照生产订单
            BEGIN
				--生产订单单号
                DECLARE @cMoCode NVARCHAR(30);  
                SET @cMoCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cMoCode',
                                                              DEFAULT, DEFAULT);
                SET NOCOUNT ON;
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDARefIDs') IS NULL )
                    DROP TABLE #STPDARefIDs;
                SELECT  DISTINCT TOP 1
                        MoId ,
                        MoCode ,
                        maker ,
                        MakeDate
                INTO    #STPDARefIDs
                FROM    v_st_mom_orderdetailH WITH ( NOLOCK )
                WHERE   1 = 0; 
                SET @SqlCommand = @SqlCommand
                    + ' INSERT INTO #STPDARefIDs ( MoId,MoCode,maker,MakeDate) 
                select moid,mocode,maker,Convert(varchar(10),makedate,120) as makedate from (
                select distinct MoCode,maker,MakeDate,ModifyUser,ModifyDate,define1,define2,define3,define4,define5,
                define6,define7,define8,define9,define10,define11,define12,define13,define14,define15,define16,a.MoId 
                from v_st_mom_orderdetailH a with (nolock) inner join 
                (select MoId FROM  v_st_mom_orderdetail with (nolock)  
                Where  ( 1>0 ) and  (case when ISNULL(SfcFlag,0)=1 then iquantity+QualifiedInQty else 1 end)<>0  
                and ISNULL(Status,0) = 3   and (ISNULL(iQuantity,0))>0
                and isnull(MrpQty,0)<>0 ';
                IF ( @cMoCode <> N'' )
                    SET @SqlCommand = @SqlCommand + ' AND MoCode =@cMoCode ';
                IF ( @dDateFrom <> N''
                     AND @dDateTo <> N''
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (( MakeDate >= @dDateFrom )
                            AND ( MakeDate <= @dDateTo )) ';
                IF ( @cMaker <> N'' )
                    BEGIN
                        SET @SqlCommand = @SqlCommand
                            + ' AND (maker=@cMaker) ';
                    END;
                IF ( @cSysBarcode <> N'' )
                    BEGIN
                        SET @SqlCommand = @SqlCommand
                            + ' AND (csysbarcode=@cSysBarcode) ';
                    END;
                SET @SqlCommand = @SqlCommand
                    + ' ) as b on a.MoId=b.moid ) as tab';     
                    
                SET @ParmList = '@cMoCode       NVARCHAR(30),
								   @dDateFrom	NVARCHAR(20),
								   @dDateTo     NVARCHAR(20), 
								   @cMaker		NVARCHAR(30),
								   @cSysBarcode		NVARCHAR(60)';

                EXEC sp_executesql @SqlCommand, @ParmList, @cMoCode = @cMoCode,
                    @dDateFrom = @dDateFrom, @dDateTo = @dDateTo,
                    @cMaker = @cMaker, @cSysBarcode = @cSysBarcode;
                SET NOCOUNT OFF;
              
                --查询列表（表头）
                SELECT DISTINCT
                        MoCode AS cmocode ,
                        maker AS cmaker ,
                        ( CONVERT(VARCHAR(100), MakeDate, 23) ) AS ddate ,
                        ModifyUser AS cmodifyuser ,
                        ModifyDate AS dmodifydate ,
                        Define1 AS cdefine1 ,
                        Define2 AS cdefine2 ,
                        Define3 AS cdefine3 ,
                        Define4 AS cdefine4 ,
                        Define5 AS cdefine5 ,
                        Define6 AS cdefine6 ,
                        Define7 AS cdefine7 ,
                        Define8 AS cdefine8 ,
                        Define9 AS cdefine9 ,
                        Define10 AS cdefine10 ,
                        Define11 AS cdefine11 ,
                        Define12 AS cdefine12 ,
                        Define13 AS cdefine13 ,
                        Define14 AS cdefine14 ,
                        Define15 AS cdefine15 ,
                        Define16 AS cdefine16 ,
                        a.MoId AS moid ,
                        a.csysbarcode ,
                        MoCode AS sourcecode ,
                        a.MoId AS iorderid
                FROM    v_st_mom_orderdetail a WITH ( NOLOCK )
                        INNER JOIN ( SELECT MoId
                                     FROM   v_st_mom_orderdetail WITH ( NOLOCK )
                                     WHERE  ( CASE WHEN ISNULL(SfcFlag, 0) = 1
                                                   THEN iQuantity
                                                        + QualifiedInQty
                                                   ELSE 1
                                              END ) <> 0
                                            AND ISNULL(Status, 0) = 3
                                            AND ISNULL(MrpQty, 0) <> 0
                                   ) AS b ON a.MoId = b.MoId
                                             AND a.MoId IN (
                                             SELECT DISTINCT
                                                    MoId
                                             FROM   #STPDARefIDs WITH ( NOLOCK ) );
                --查询表体
                IF ( @GetType = N'DETAIL' )
                    BEGIN
                        SELECT  '' AS selcol ,
                                a.MoDId AS bodyautoid ,
                                SoType idemandtype ,
                                MDept AS mdept ,
                                MoLotCode AS molotcode ,
                                '' AS cbatch ,
                                MoSeq AS imoseq ,
                                InvCode AS cinvcode ,
                                InvAddCode AS invaddcode ,
                                InvName AS cinvname ,
                                InvStd AS cinvstd ,
                                InvDefine1 AS cinvdefine1 ,
                                InvDefine2 AS cinvdefine2 ,
                                MoLotCode AS cprobatch ,
                                InvDefine3 AS cinvdefine3 ,
                                InvDefine4 AS cinvdefine4 ,
                                InvDefine5 AS cinvdefine5 ,
                                InvDefine6 AS cinvdefine6 ,
                                InvDefine7 AS cinvdefine7 ,
                                InvDefine8 AS cinvdefine8 ,
                                InvDefine9 AS cinvdefine9 ,
                                InvDefine10 AS cinvdefine10 ,
                                InvDefine11 AS cinvdefine11 ,
                                InvDefine12 AS cinvdefine12 ,
                                InvDefine13 AS cinvdefine13 ,
                                InvDefine14 AS cinvdefine14 ,
                                InvDefine15 AS cinvdefine15 ,
                                InvDefine16 AS cinvdefine16 ,
                                UnitId AS unitid ,
                                UnitCode AS unitcode ,
                                AuxUnitId AS auxunitid ,
                                AuxUnitCode AS auxunitcode ,
                                Free1 AS cfree1 ,
                                Free2 AS cfree2 ,
                                Free3 AS cfree3 ,
                                Free4 AS cfree4 ,
                                Free5 AS cfree5 ,
                                Free6 AS cfree6 ,
                                Free7 AS cfree7 ,
                                Free8 AS cfree8 ,
                                Free9 AS cfree9 ,
                                Free10 AS cfree10 ,
                                Qty AS inqty ,
                                ISNULL(Qty, 0) - ISNULL(QualifiedInQty, 0) AS qty ,
                                ISNULL(Qty, 0) - ISNULL(QualifiedInQty, 0) AS iquantity ,
                                CASE WHEN ISNULL(ChangeRate, 0) <> 0
                                     THEN ( ( ISNULL(Qty, 0)
                                              - ISNULL(QualifiedInQty, 0) )
                                            / ChangeRate )
                                     ELSE 0
                                END AS inum ,
                                CASE WHEN ISNULL(ChangeRate, 0) <> 0
                                     THEN ( Qty / ChangeRate )
                                     ELSE 0
                                END AS innum ,
                                CASE WHEN ISNULL(ChangeRate, 0) <> 0
                                     THEN ( ( ISNULL(Qty, 0)
                                              - ISNULL(QualifiedInQty, 0) )
                                            / ChangeRate )
                                     ELSE 0
                                END AS num ,
                                QualifiedInQty AS qualifiedinqty ,
                                MDept AS cdepcode ,
                                DeptName AS cdepname ,
                                StartDate AS startdate ,
                                DueDate AS duedate ,
                                SoCode cdemandcode ,
                                SoSeq idemandseq ,
                                OpSeq AS opseq ,
                                [Description] AS cdescription ,
                                WcCode AS wccode ,
                                WcName AS wcname ,
                                WhCode AS cwhcode ,
                                WhName AS cwhname ,
                                SoDId cdemandid ,
                                a.MoDId AS modid ,
                                Ufts AS ufts ,
                                a.ByProductFlag AS byproductflag ,
                                Define22 AS cdefine22 ,
                                Define23 AS cdefine23 ,
                                Define24 AS cdefine24 ,
                                Define2 AS cdefine25 ,
                                Define26 AS cdefine26 ,
                                Define27 AS cdefine27 ,
                                Define28 AS cdefine28 ,
                                Define29 AS cdefine29 ,
                                Define30 AS cdefine30 ,
                                Define31 AS cdefine31 ,
                                Define32 AS cdefine32 ,
                                Define33 AS cdefine33 ,
                                Define34 AS cdefine34 ,
                                Define35 AS cdefine35 ,
                                Define36 AS cdefine36 ,
                                Define37 AS cdefine37 ,
                                AuxQty AS auxqty ,
                                AuxQualifiedInQty AS auxqualifiedinqty ,
                                ChangeRate AS ichangerate ,
                                ChangeRate AS changerate ,
                                ChangeRate iinvexchrate ,
                                a.MoId AS moid ,
                                OrderCode AS ordercode ,
                                OrderDId AS orderdid ,
                                OrderSeq AS orderseq ,
                                OrderType AS ordertype ,
                                cciqbookcode ,
                                Cuscode AS cuscode ,
                                cusname ,
                                CusabbName AS cusabbname ,
                                Remark AS remark ,
                                cservicecode ,
                                motypecode ,
                                motypedesc ,
                                ISNULL(ItemClass, '') AS itemclass ,
                                ISNULL(ItemName, '') AS itemname ,
                                ISNULL(CostItemCode, '') AS costitemcode ,
                                ISNULL(CostItemName, '') AS costitemname ,
                                cbSysBarCode AS cbsysbarcode ,
                                b.MoDId AS impoids ,
                                b.MoDId AS isourceids ,
                                b.MoCode AS cmocode ,
                                b.MoCode AS csourcecode ,
                                iMassDate AS imassdate ,
                                cMassUnit AS cmassunit ,
                                NULL AS dmadedate ,
                                NULL AS dvdate ,
                                QcFlag AS bgsp ,
                                PAllocateId AS pallocateid ,
                                Define1 AS cbatchproperty1 ,
                                Define2 AS cbatchproperty2 ,
                                Define3 AS cbatchproperty3 ,
                                Define4 AS cbatchproperty4 ,
                                Define5 AS cbatchproperty5 ,
                                Define6 AS cbatchproperty6 ,
                                Define7 AS cbatchproperty7 ,
                                Define8 AS cbatchproperty8 ,
                                Define9 AS cbatchproperty9 ,
                                Define10 AS cbatchproperty10 ,
                                ISNULL(ItemClass, '') AS citemclass ,
                                ISNULL(ItemName, '') AS citemcname ,
                                ISNULL(CostItemCode, '') AS citemcode ,
                                ISNULL(CostItemName, '') AS citemname --U82017020800005 ：生产订单做入库增加项目大类和项目编码需求 add by gr170209
                        FROM    v_st_mom_orderdetail a WITH ( NOLOCK )
                                LEFT JOIN ( SELECT  PAllocateId ,
                                                    MoDId
                                            FROM    mom_orderdetail with (nolock) 
                                          ) c ON a.MoDId = c.MoDId --同步：集合订单扫码不需将直接供应的子件带入扫描任务 modify by gr161201
                                LEFT JOIN ( SELECT  iMassDate ,
                                                    cInvCode ,
                                                    cMassUnit
                                            FROM    Inventory  with (nolock) 
                                          ) x1 ON x1.cInvCode = a.InvCode
                                INNER JOIN ( SELECT MoId ,
                                                    MoDId ,
                                                    Status ,
                                                    MoCode ,
                                                    ByProductFlag
                                             FROM   v_st_mom_orderdetail WITH ( NOLOCK )
                                             WHERE  ( ( 1 > 0 )
                                                      AND ( 1 > 0 )
                                                    )
                                                    AND ( 1 > 0 )
                                                    AND ( CASE
                                                              WHEN ISNULL(SfcFlag,
                                                              0) = 1
                                                              THEN iQuantity
                                                              + QualifiedInQty
                                                              ELSE 1
                                                          END ) <> 0
                                                    AND ISNULL(Status, 0) = 3
                                                    AND ISNULL(MrpQty, 0) <> 0
                                           ) AS b ON a.Status = b.Status
                                                     AND a.MoId = b.MoId
                                                     AND a.MoDId = b.MoDId
                        WHERE   ISNULL(a.SourceQCVouchType, 0) <> 1
                                AND a.MoId IN (
                                SELECT DISTINCT
                                        MoId
                                FROM    #STPDARefIDs WITH ( NOLOCK ) )
                                AND a.ByProductFlag = b.ByProductFlag
                                AND ISNULL(pallocateid, '') = ''; --同步：集合订单扫码不需将直接供应的子件带入扫描任务 modify by gr161201
                    END;
                --删除临时表
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDARefIDs') IS NULL )
                    DROP TABLE #STPDARefIDs;
            END;  
        ELSE
            IF ( @OperType = '1' )
				--装箱单参照销售发货单
                BEGIN
                    --发货单单号
                    DECLARE @cDlCode NVARCHAR(30);  
                    SET @cDlCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cDLCode',
                                                              DEFAULT, DEFAULT);
                    --客户编码
                    DECLARE @cCusCode NVARCHAR(20);  
                    SET @cCusCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cCusCode',
                                                              DEFAULT, DEFAULT);
                	--客户名称
                    DECLARE @cCusName NVARCHAR(120);
                    SET @cCusName = '%'
                        + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cCusName',
                                                              DEFAULT, DEFAULT)
                        + '%';
                    SET NOCOUNT ON;
                    IF EXISTS ( SELECT  0
                                WHERE   NOT OBJECT_ID('tempdb..#STPDADispatchRefIDs') IS NULL )
                        DROP TABLE #STPDADispatchRefIDs;
                    SELECT  DISTINCT TOP 1
                            cDLCode ,
                            DLID
                    INTO    #STPDADispatchRefIDs
                    FROM    DispatchList WITH ( NOLOCK )
                    WHERE   1 = 0; 
                    SET @SqlCommand = @SqlCommand
                        + ' INSERT INTO #STPDADispatchRefIDs (cDLCode,DLID) SELECT DISTINCT DispatchList.cDLCode, DispatchList.DLID FROM DispatchList  with (nolock) 
        INNER JOIN DispatchLists  with (nolock) ON DispatchList.DLID = DispatchLists.DLID INNER JOIN Inventory  with (nolock) ON DispatchLists.cInvCode = Inventory.cInvCode
		WHERE ( DispatchList.cVouchType = ''05'' OR DispatchList.cVouchType = ''06'')
        AND (( ISNULL(DispatchList.cSaleOut, '''') = '''' OR ISNULL(bQANeedCheck,0) = 1) OR DispatchList.cSaleOut = ''ST'')
        AND NOT ( ISNULL(DispatchList.bFirst, 0) = 1 AND ISNULL(DispatchLists.bIsSTQc, 0) = 0)
        AND ( ( ABS(ISNULL(( CASE WHEN ( ISNULL(DispatchLists.bQANeedCheck, 0) = 1 AND DispatchLists.iQuantity > 0 ) THEN DispatchLists.iQAQuantity
        ELSE DispatchLists.iQuantity END ), 0)) - ABS(ISNULL(DispatchLists.fOutQuantity, 0)) ) >= 0.01
        OR ( iGroupType = 2 AND ( ABS(ISNULL(( CASE WHEN ( ISNULL(DispatchLists.bQANeedCheck,0) = 1 AND DispatchLists.iQuantity > 0) THEN DispatchLists.iQANum ELSE DispatchLists.iNum END ),0))
        - ABS(ISNULL(DispatchLists.fOutNum, 0)) ) >= 0.01))
        AND ( ISNULL(DispatchLists.cWhCode, '''') <> '''' ) AND bInvType = 0 AND bService = 0 AND DispatchList.bReturnFlag = ''''
        AND ( ( ISNULL(DispatchLists.bSettleAll, 0) = 0 AND DispatchList.cVouchType = ''05'' ) OR DispatchList.cVouchType = ''06'')
        AND ISNULL(DispatchList.cVerifier, '''') <> '''' AND ( 1 > 0 ) ';
                    IF ( @cDlCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND cDLCode =@cDlCode ';
                    IF ( @dDateFrom <> N''
                         AND @dDateTo <> N''
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (( dDate >= @dDateFrom )
                            AND ( dDate <= @dDateTo )) ';
                    IF ( @cMaker <> N'' )
                        BEGIN
                            SET @SqlCommand = @SqlCommand
                                + ' AND (cMaker=@cMaker) ';
                        END;
                    IF ( @cCusCode <> N'' )
                        BEGIN
                            SET @SqlCommand = @SqlCommand
                                + ' AND (cCusCode=@cCusCode) ';
                        END;
                    IF ( @cCusName <> N''
                         AND @cCusName <> N'%%'
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (cCusName LIKE @cCusName) ';
                    IF ( @cSysBarcode <> N'' )
                        BEGIN
                            SET @SqlCommand = @SqlCommand
                                + ' AND (csysbarcode=@cSysBarcode) ';
                        END;
                    SET @ParmList = '@cDlCode       NVARCHAR(30),
								   @dDateFrom	NVARCHAR(20),
								   @dDateTo     NVARCHAR(20), 
								   @cMaker		NVARCHAR(30),
								   @cCusCode	NVARCHAR(20),
								   @cCusName	NVARCHAR(120),
								   @cSysBarcode	NVARCHAR(60)';

                    EXEC sp_executesql @SqlCommand, @ParmList,
                        @cDlCode = @cDlCode, @dDateFrom = @dDateFrom,
                        @dDateTo = @dDateTo, @cMaker = @cMaker,
                        @cCusCode = @cCusCode, @cCusName = @cCusName,
                        @cSysBarcode = @cSysBarcode;

                    SET NOCOUNT OFF;
					--查询列表（表头）
                    SELECT  '' AS selcol ,
                            iExchRate AS iexchrate ,
                            cexch_name ,
                            cBillName AS cbillname ,
                            cDLCode AS cdlcode ,
                            cSBVCode AS csbvcode ,
                            ( CONVERT(VARCHAR(100), dDate, 23) ) AS ddate ,
                            cSTCode AS cstcode ,
                            cSTName AS cstname ,
                            cBusType AS cbustype ,
                            cCusCode AS ccuscode ,
                            cCusName AS ccusname ,
                            cCusAbbName AS ccusabbname ,
                            cDepCode AS cdepcode ,
                            cDepName AS cdepname ,
                            cPersonCode AS cpersoncode ,
                            cPersonName AS cpersonname ,
                            cMaker AS cmaker ,
                            cVerifier AS cverifier ,
                            cDefine1 AS cdefine1 ,
                            cDefine2 AS cdefine2 ,
                            cDefine3 AS cdefine3 ,
                            cDefine4 AS cdefine4 ,
                            cDefine5 AS cdefine5 ,
                            cDefine6 AS cdefine6 ,
                            cDefine7 AS cdefine7 ,
                            cDefine8 AS cdefine8 ,
                            cDefine9 AS cdefine9 ,
                            cDefine10 AS cdefine10 ,
                            cDefine11 AS cdefine11 ,
                            cDefine12 AS cdefine12 ,
                            cDefine13 AS cdefine13 ,
                            cDefine14 AS cdefine14 ,
                            cDefine15 AS cdefine15 ,
                            cDefine16 AS cdefine16 ,
                            cMemo AS cmemo ,
                            SBVID AS sbvid ,
                            ufts ,
                            DLID AS dlid ,
                            cShipAddress AS cshipaddress ,
                            cBillType AS cbilltype ,
                            caddcode ,
                            iswfcontrolled ,
                            iverifystate ,
                            iflowid ,
                            cflowname ,
                            cSysBarCode AS csysbarcode ,
                            cEBExpressCode AS cebexpresscode ,
                            cSTName AS cstname ,
                            cinvoicecompany ,
                            cRdName AS crdname ,
                            cRdCode AS crdcode
                    FROM    ( SELECT DISTINCT
                                        DispatchList.iExchRate ,
                                        DispatchList.caddcode ,
                                        DispatchList.cexch_name ,
                                        ( CASE WHEN ISNULL(DispatchList.cSBVCode,
                                                           '') <> ''
                                               THEN SaleBillVouch.cVouchType
                                               ELSE DispatchList.cVouchType
                                          END ) AS cBillType ,
                                        VouchType.cVouchName AS cBillName ,
                                        DispatchList.cDLCode ,
                                        DispatchList.SBVID ,
                                        DispatchList.cSBVCode ,
                                        DispatchList.dDate ,
                                        DispatchList.cBusType ,
                                        DispatchList.DLID AS DLID ,
                                        DispatchList.cSTCode ,
                                        Rd_Style.cRdName ,
                                        SaleType.cRdCode ,
                                        SaleType.cSTName ,
                                        DispatchList.cCusCode ,
                                        Customer.cCusAbbName ,
                                        Customer.cCusName ,
                                        DispatchList.cDepCode ,
                                        Department.cDepName ,
                                        DispatchList.cPersonCode ,
                                        person.cPersonName ,
                                        DispatchList.cMaker ,
                                        DispatchList.cVerifier ,
                                        DispatchList.iswfcontrolled ,
                                        DispatchList.iverifystate ,
                                        DispatchList.cShipAddress ,
                                        CONVERT(CHAR, CONVERT(MONEY, DispatchList.ufts), 2) AS ufts ,
                                        DispatchList.cinvoicecompany ,
                                        DispatchList.cDefine1 ,
                                        DispatchList.cDefine2 ,
                                        DispatchList.cDefine3 ,
                                        DispatchList.cDefine4 ,
                                        DispatchList.cDefine5 ,
                                        DispatchList.cDefine6 ,
                                        DispatchList.cDefine7 ,
                                        DispatchList.cDefine8 ,
                                        DispatchList.cDefine9 ,
                                        DispatchList.cDefine10 ,
                                        DispatchList.cDefine11 ,
                                        DispatchList.cDefine12 ,
                                        DispatchList.cDefine13 ,
                                        DispatchList.cDefine14 ,
                                        DispatchList.cDefine15 ,
                                        DispatchList.cDefine16 ,
                                        DispatchList.cMemo ,
                                        DispatchList.iflowid ,
                                        SABizFlow.cSalesProcessDescribes AS cflowname ,
                                        DispatchList.cSysBarCode ,
                                        DispatchList.cEBExpressCode
                              FROM      DispatchList  with (nolock) 
                                        INNER JOIN DispatchLists  with (nolock) ON DispatchList.DLID = DispatchLists.DLID
                                        INNER JOIN Inventory  with (nolock) ON DispatchLists.cInvCode = Inventory.cInvCode
                                        LEFT JOIN ComputationUnit  with (nolock) ON Inventory.cComUnitCode = ComputationUnit.cComunitCode
                                        INNER JOIN Warehouse  with (nolock) ON DispatchLists.cWhCode = Warehouse.cWhCode
                                        LEFT OUTER JOIN SaleType  with (nolock) ON DispatchList.cSTCode = SaleType.cSTCode
                                        LEFT OUTER JOIN ( SELECT
                                                              cPersonCode AS cpersoncode2 ,
                                                              cPersonName
                                                          FROM
                                                              Person  with (nolock) 
                                                        ) person ON DispatchList.cPersonCode = person.cpersoncode2
                                        LEFT OUTER JOIN Customer  with (nolock) ON DispatchList.cCusCode = Customer.cCusCode
                                        LEFT OUTER JOIN Department  with (nolock) ON DispatchList.cDepCode = Department.cDepCode
                                        LEFT JOIN SaleBillVouch  with (nolock) ON SaleBillVouch.SBVID = dbo.DispatchList.SBVID
                                        LEFT JOIN VouchType  with (nolock) ON VouchType.cVouchType = CASE
                                                              WHEN SaleBillVouch.SBVID IS NULL
                                                              THEN DispatchList.cVouchType
                                                              ELSE SaleBillVouch.cVouchType
                                                              END
                                        LEFT JOIN SABizFlow  with (nolock) ON SABizFlow.iFlowID = DispatchList.iflowid
                                        LEFT JOIN Vendor v1  with (nolock) ON v1.cVenCode = DispatchLists.cvmivencode
                                        LEFT JOIN Rd_Style  with (nolock) ON Rd_Style.cRdCode = SaleType.cRdCode
                              WHERE     ( DispatchList.cVouchType = '05'
                                          OR DispatchList.cVouchType = '06'
                                        )
                                        AND NOT ( ISNULL(DispatchList.bFirst,
                                                         0) = 1
                                                  AND ISNULL(DispatchLists.bIsSTQc,
                                                             0) = 0
                                                )
                                        AND ( ( ABS(ISNULL(( CASE
                                                              WHEN ( ISNULL(DispatchLists.bQANeedCheck,
                                                              0) = 1
                                                              AND DispatchLists.iQuantity > 0
                                                              )
                                                              THEN DispatchLists.iQAQuantity
                                                              ELSE DispatchLists.iQuantity
                                                             END ), 0))
                                                - ABS(ISNULL(DispatchLists.fOutQuantity,
                                                             0)) ) >= 0.01
                                              OR ( iGroupType = 2
                                                   AND ( ABS(ISNULL(( CASE
                                                              WHEN ( ISNULL(DispatchLists.bQANeedCheck,
                                                              0) = 1
                                                              AND DispatchLists.iQuantity > 0
                                                              )
                                                              THEN DispatchLists.iQANum
                                                              ELSE DispatchLists.iNum
                                                              END ), 0))
                                                         - ABS(ISNULL(DispatchLists.fOutNum,
                                                              0)) ) >= 0.01
                                                 )
                                            ) 
                                            --AND DATEDIFF(day,DispatchList.dDate,'2010-01-01')<=0 
                                        AND ( ISNULL(DispatchLists.cWhCode, '') <> '' )
                                        AND bInvType = 0
                                        AND bService = 0
                                        AND ( ( ISNULL(DispatchLists.bSettleAll,
                                                       0) = 0
                                                AND DispatchList.cVouchType = '05'
                                              )
                                              OR DispatchList.cVouchType = '06'
                                            )
                                        AND ISNULL(DispatchList.cVerifier, '') <> ''
                                        AND ( ( 1 > 0 )
                                              AND ( 1 > 0 )
                                            )
                                        AND ( 1 > 0 )
                                        AND ( ( CASE WHEN ISNULL(DispatchLists.bQANeedCheck,
                                                              0) = 1
                                                          AND ISNULL(DispatchLists.iQuantity,
                                                              0) > 0
                                                     THEN DispatchLists.iQAQuantity
                                                     ELSE DispatchLists.iQuantity
                                                END ) <> 0
                                              OR ( CASE WHEN ISNULL(DispatchLists.bQANeedCheck,
                                                              0) = 1
                                                             AND ISNULL(DispatchLists.iNum,
                                                              0) > 0
                                                        THEN DispatchLists.iQANum
                                                        ELSE DispatchLists.iNum
                                                   END ) <> 0
                                            )
                                        AND DispatchList.bReturnFlag = 0
                                        AND DispatchList.cBusType IN ( '普通销售',
                                                              N'分期收款' )
                            ) AS tab
                    WHERE   tab.DLID IN (
                            SELECT DISTINCT
                                    DLID
                            FROM    #STPDADispatchRefIDs WITH ( NOLOCK ) );
					--查询表体
                    IF ( @GetType = N'DETAIL' )
                        BEGIN
                            SELECT  '' AS selcol ,
                                    iDLsID AS bodyautoid ,
                                    cInvCCode AS cinvccode ,
                                    cWhCode AS cwhcode ,
                                    cWhName AS cwhname ,
                                    cInvCode AS cinvcode ,
                                    cInvAddCode AS cinvaddcode ,
                                    cInvName AS cinvname ,
                                    cInvStd AS cinvstd ,
                                    cInvDefine1 AS cinvdefine1 ,
                                    cInvDefine2 AS cinvdefine2 ,
                                    cInvDefine3 AS cinvdefine3 ,
                                    cInvDefine4 AS cinvdefine4 ,
                                    cInvDefine5 AS cinvdefine5 ,
                                    cInvDefine6 AS cinvdefine6 ,
                                    cInvDefine7 AS cinvdefine7 ,
                                    cInvDefine8 AS cinvdefine8 ,
                                    cInvDefine9 AS cinvdefine8 ,
                                    cInvDefine10 AS cinvdefine10 ,
                                    cInvDefine11 AS cinvdefine11 ,
                                    cInvDefine12 AS cinvdefine12 ,
                                    cInvDefine13 AS cinvdefine13 ,
                                    cInvDefine14 AS cinvdefine14 ,
                                    cInvDefine15 AS cinvdefine15 ,
                                    cInvDefine16 AS cinvdefine16 ,
                                    cComUnitCode AS ccomunitcode ,
                                    cinvm_unit ,
                                    cUnitID AS cunitid ,
                                    cinva_unit ,
                                    iInvExchRate AS iinvexchrate ,
                                    cFree1 AS cfree1 ,
                                    cFree2 AS cfree2 ,
                                    cFree3 AS cfree3 ,
                                    cFree4 AS cfree4 ,
                                    cFree5 AS cfree5 ,
                                    cFree6 AS cfree6 ,
                                    cFree7 AS cfree7 ,
                                    cFree8 AS cfree8 ,
                                    cFree9 AS cfree9 ,
                                    cFree10 AS cfree10 ,
                                    cBatch AS cbatch ,
                                    dMadeDate AS dmadedate ,
                                    iMassDate AS imassdate ,
                                    dvDate AS dvdate ,
                                    ( cCode ) AS cinvouchcode ,
                                    cItem_class ,
                                    ( cItem_CName ) AS citemcname ,
                                    cItemCode AS citemcode ,
                                    ( cItemName ) AS cname ,
                                    ABS(iquantity) inewquantity ,
                                    ABS(inum) inewnum ,
                                    fOutQuantity AS foutquantity ,
                                    fOutNum AS foutnum ,
                                    cDLCode AS cbdlcode ,
                                    cDLCode AS csourcecode ,
                                    ( ((CASE WHEN ABS(ISNULL(iquantity, 0)) > ABS(ISNULL(fOutQuantity,
                                                              0))
                                             THEN ( ISNULL(iquantity, 0)
                                                    - ISNULL(fOutQuantity, 0) )
                                             ELSE 0
                                        END)) ) AS iquantity ,
                                    ABS(( (CASE WHEN ( ABS(ISNULL(inum, 0)) > ABS(ISNULL(fOutNum,
                                                              0)) )
                                                THEN ( ISNULL(inum, 0)
                                                       - ISNULL(fOutNum, 0) )
                                                ELSE 0
                                           END) )) AS inum ,
                                    AutoID AS autoid ,
                                    bQANeedCheck AS bqaneedcheck ,
                                    cvmivencode ,
                                    cvmivenname ,
                                    ( (CASE WHEN ABS(ISNULL(iquantity, 0)) > ABS(ISNULL(fOutQuantity,
                                                              0))
                                            THEN ( ISNULL(iquantity, 0)
                                                   - ISNULL(fOutQuantity, 0) )
                                            ELSE 0
                                       END) ) AS fcurqty ,
                                    ( (CASE WHEN ( ABS(ISNULL(inum, 0)) > ABS(ISNULL(fOutNum,
                                                              0)) )
                                            THEN ( ISNULL(inum, 0)
                                                   - ISNULL(fOutNum, 0) )
                                            ELSE 0
                                       END) ) AS fcurnum ,
                                    tab.DLID AS dlid ,
                                    cSoCode AS csocode ,
                                    cMassUnit AS cmassunit ,
                                    fOutExcess AS foutexcess ,
                                    iDLsID AS idlsid ,
                                    iDLsID AS isourceids ,
                                    iBatch AS ibatch ,
                                    iRowNo AS irowno ,
                                    iSOsID AS isosid ,
                                    iNatMoney AS inatmoney ,
                                    iNatUnitPrice AS inatunitprice ,
                                    iGroupType AS igrouptype ,
                                    bQuanSign AS bquansign ,
                                    bGsp AS bgsp ,
                                    cContractID AS ccontractid ,
                                    cDefine22 AS cdefine22 ,
                                    cDefine23 AS cdefine23 ,
                                    cDefine24 AS cdefine24 ,
                                    cDefine25 AS cdefine25 ,
                                    cDefine26 AS cdefine26 ,
                                    cDefine27 AS cdefine27 ,
                                    cDefine28 AS cdefine28 ,
                                    cDefine29 AS cdefine29 ,
                                    cDefine30 AS cdefine30 ,
                                    cDefine31 AS cdefine31 ,
                                    cDefine32 AS cdefine32 ,
                                    cDefine33 AS cdefine33 ,
                                    cDefine34 AS cdefine34 ,
                                    cDefine35 AS cdefine35 ,
                                    cDefine36 AS cdefine36 ,
                                    cDefine37 AS cdefine37 ,
                                    cCode AS ccode ,
                                    cContractTagCode AS ccontracttagcode ,
                                    cContractRowGuid AS ccontractrowguid ,
                                    cdemandcode ,
                                    cdemandid ,
                                    cCusInvCode AS ccusinvcode ,
                                    cCusInvName AS ccusinvname ,
                                    idemandseq ,
                                    idemandtype ,
                                    iExpiratDateCalcu AS iexpiratdatecalcu ,
                                    cExpirationdate AS cexpirationdate ,
                                    dExpirationdate AS dexpirationdate ,
                                    cbatchproperty1 ,
                                    cbatchproperty2 ,
                                    cbatchproperty3 ,
                                    cbatchproperty4 ,
                                    cbatchproperty5 ,
                                    cbatchproperty6 ,
                                    cbatchproperty7 ,
                                    cbatchproperty8 ,
                                    cbatchproperty9 ,
                                    cbatchproperty10 ,
                                    cbmemo ,
                                    ivouchrowno ,
                                    cbSysBarCode AS cbsysbarcode ,
                                    iorderrowno ,
                                    iQuotedPrice AS iquotedprice ,
                                    bgift ,
                                    cEBExpressCode AS cebexpresscode ,
                                    cSRPolicy AS csrpolicy--销售订单预留问题 modify by gr161204
                            FROM    ( SELECT    DispatchLists.AutoID ,
                                                iorderrowno ,
                                                DispatchLists.cWhCode ,
                                                Warehouse.cWhName ,
                                                DispatchList.cDLCode ,
                                                DispatchLists.DLID ,
                                                DispatchLists.iCorID ,
                                                DispatchLists.cInvCode ,
                                                Inventory.cInvAddCode ,
                                                Inventory.cInvName ,
                                                Inventory.cInvStd ,
                                                DispatchLists.iQuotedPrice ,
                                                DispatchLists.cCusInvCode ,
                                                DispatchLists.cCusInvName ,
                                                DispatchLists.iExpiratDateCalcu ,
                                                DispatchLists.cExpirationdate ,
                                                DispatchLists.dExpirationdate ,
                                                DispatchLists.iUnitPrice ,
                                                DispatchLists.iTaxUnitPrice ,
                                                DispatchLists.iMoney ,
                                                DispatchLists.iTax ,
                                                DispatchLists.iDisCount ,
                                                DispatchLists.iSum ,
                                                DispatchLists.iNatUnitPrice ,
                                                DispatchLists.iNatMoney ,
                                                DispatchLists.iNatTax ,
                                                DispatchLists.iNatSum ,
                                                DispatchLists.iNatDisCount ,
                                                DispatchLists.iSettleNum ,
                                                DispatchLists.iSettleQuantity ,
                                                DispatchLists.iBatch ,
                                                ComputationUnit.cComUnitName AS cinvm_unit ,
                                                ComputationUnit_1.cComUnitName AS cinva_unit ,
                                                DispatchLists.iInvExchRate ,
                                                DispatchLists.cBatch ,
                                                DispatchLists.bSettleAll ,
                                                DispatchLists.cvmivencode ,
                                                v1.cVenAbbName AS cvmivenname ,
                                                DispatchLists.cFree1 ,
                                                DispatchLists.cFree2 ,
                                                DispatchLists.iTB ,
                                                DispatchLists.dMDate AS dMadeDate ,
                                                DispatchLists.dvDate ,
                                                DispatchLists.cMassUnit ,
                                                DispatchLists.iMassDate ,
                                                DispatchLists.TBQuantity ,
                                                DispatchLists.TBNum ,
                                                DispatchLists.iSOsID ,
                                                DispatchLists.iDLsID ,
                                                DispatchLists.KL ,
                                                DispatchLists.iTaxRate ,
                                                DispatchLists.KL2 ,
                                                DispatchLists.cDefine22 ,
                                                DispatchLists.cDefine23 ,
                                                DispatchLists.cDefine24 ,
                                                DispatchLists.cDefine25 ,
                                                DispatchLists.cDefine26 ,
                                                DispatchLists.cDefine27 ,
                                                CONVERT(INT, 1) AS isotype ,
                                                DispatchLists.iSOsID AS isodid ,
                                                DispatchLists.idemandtype ,
                                                DispatchLists.cdemandcode ,
                                                DispatchLists.cdemandid ,
                                                DispatchLists.idemandseq ,
                                                DispatchLists.cItemCode ,
                                                DispatchLists.cItem_class ,
                                                DispatchLists.fSaleCost ,
                                                DispatchLists.fSalePrice ,
                                                DispatchLists.cVenAbbName ,
                                                DispatchLists.cItemName ,
                                                DispatchLists.cContractID ,
                                                DispatchLists.cContractTagCode ,
                                                DispatchLists.cContractRowGuid ,
                                                DispatchLists.cItem_CName ,
                                                DispatchLists.cFree3 ,
                                                DispatchLists.cFree4 ,
                                                DispatchLists.cFree5 ,
                                                DispatchLists.cFree6 ,
                                                DispatchLists.cFree7 ,
                                                DispatchLists.cFree8 ,
                                                DispatchLists.cFree9 ,
                                                DispatchLists.cFree10 ,
                                                DispatchLists.cbatchproperty1 ,
                                                DispatchLists.cbatchproperty2 ,
                                                DispatchLists.cbatchproperty3 ,
                                                DispatchLists.bIsSTQc ,
                                                DispatchLists.cbatchproperty4 ,
                                                DispatchLists.cbatchproperty5 ,
                                                DispatchLists.cbatchproperty6 ,
                                                DispatchLists.cbatchproperty7 ,
                                                DispatchLists.cbatchproperty8 ,
                                                DispatchLists.cbatchproperty9 ,
                                                DispatchLists.cbatchproperty10 ,
                                                DispatchLists.cUnitID ,
                                                DispatchLists.cCode ,
                                                DispatchLists.iRetQuantity ,
                                                DispatchLists.fEnSettleQuan ,
                                                DispatchLists.fEnSettleSum ,
                                                DispatchLists.iSettlePrice ,
                                                DispatchLists.cDefine28 ,
                                                DispatchLists.cDefine29 ,
                                                DispatchLists.cDefine30 ,
                                                DispatchLists.cDefine31 ,
                                                DispatchLists.cDefine32 ,
                                                DispatchLists.cDefine33 ,
                                                DispatchLists.cDefine34 ,
                                                DispatchLists.cDefine35 ,
                                                DispatchLists.cDefine36 ,
                                                DispatchLists.cDefine37 ,
                                                DispatchLists.bQANeedCheck AS bGsp ,
                                                DispatchLists.cGspState ,
                                                DispatchLists.bQANeedCheck ,
                                                DispatchLists.irowno AS ivouchrowno ,
                                                DispatchLists.cSoCode ,
                                                DispatchLists.cMemo AS cbmemo ,
                                                DispatchList.iflowid ,
                                                SABizFlow.cSalesProcessDescribes AS cflowname ,
                                                SaleType.cSTCode ,
                                                SaleType.cSTName ,
                                                SA_SORowNo.iRowNo ,
                                                Inventory.cInvCCode ,
                                                Inventory.cVenCode ,
                                                Inventory.cReplaceItem ,
                                                Inventory.cPosition ,
                                                Inventory.bSale ,
                                                Inventory.bPurchase ,
                                                Inventory.bSelf ,
                                                Inventory.bComsume ,
                                                Inventory.bProducing ,
                                                Inventory.bService ,
                                                Inventory.bAccessary ,
                                                Inventory.iInvWeight ,
                                                Inventory.iVolume ,
                                                Inventory.iInvRCost ,
                                                Inventory.iInvSPrice ,
                                                Inventory.iInvSCost ,
                                                Inventory.iInvLSCost ,
                                                Inventory.iInvNCost ,
                                                Inventory.iInvAdvance ,
                                                Inventory.iInvBatch ,
                                                Inventory.iSafeNum ,
                                                Inventory.iTopSum ,
                                                Inventory.iLowSum ,
                                                Inventory.iOverStock ,
                                                Inventory.cInvABC ,
                                                Inventory.bInvQuality ,
                                                Inventory.bInvBatch ,
                                                Inventory.bInvEntrust ,
                                                Inventory.bInvOverStock ,
                                                Inventory.dSDate ,
                                                Inventory.dEDate ,
                                                Inventory.bFree1 ,
                                                Inventory.bFree2 ,
                                                Inventory.cInvDefine1 ,
                                                Inventory.cInvDefine2 ,
                                                Inventory.cInvDefine3 ,
                                                Inventory.I_id ,
                                                Inventory.bInvType ,
                                                Inventory.iInvMPCost ,
                                                Inventory.cQuality ,
                                                Inventory.iInvSaleCost ,
                                                Inventory.iInvSCost1 ,
                                                Inventory.iInvSCost2 ,
                                                Inventory.iInvSCost3 ,
                                                Inventory.bFree3 ,
                                                Inventory.bFree4 ,
                                                Inventory.bFree5 ,
                                                Inventory.bFree6 ,
                                                Inventory.bFree7 ,
                                                Inventory.bFree8 ,
                                                Inventory.bFree9 ,
                                                Inventory.bFree10 ,
                                                Inventory.cCreatePerson ,
                                                Inventory.cModifyPerson ,
                                                Inventory.dModifyDate ,
                                                Inventory.fSubscribePoint ,
                                                Inventory.fVagQuantity ,
                                                Inventory.cValueType ,
                                                Inventory.bFixExch ,
                                                Inventory.fOutExcess ,
                                                Inventory.fInExcess ,
                                                Inventory.iWarnDays ,
                                                Inventory.fExpensesExch ,
                                                Inventory.bTrack ,
                                                Inventory.bSerial ,
                                                Inventory.bBarCode ,
                                                Inventory.iId ,
                                                Inventory.cBarCode ,
                                                Inventory.cInvDefine4 ,
                                                Inventory.cInvDefine5 ,
                                                Inventory.cInvDefine6 ,
                                                Inventory.cInvDefine7 ,
                                                Inventory.cInvDefine8 ,
                                                Inventory.cInvDefine9 ,
                                                Inventory.cInvDefine10 ,
                                                Inventory.cInvDefine11 ,
                                                Inventory.cInvDefine12 ,
                                                Inventory.cInvDefine13 ,
                                                Inventory.cInvDefine14 ,
                                                Inventory.cInvDefine15 ,
                                                Inventory.cInvDefine16 ,
                                                CONVERT(BIT, 0) AS bQuanSign ,
                                                Inventory.iGroupType ,
                                                Inventory.cGroupCode ,
                                                Inventory.cAssComUnitCode ,
                                                Inventory.cSAComUnitCode ,
                                                Inventory.cPUComUnitCode ,
                                                Inventory.cSTComUnitCode ,
                                                Inventory.cComUnitCode ,
                                                Inventory.cCAComUnitCode ,
                                                Inventory.cFrequency ,
                                                Inventory.iFrequency ,
                                                Inventory.iDays ,
                                                Inventory.dLastDate ,
                                                Inventory.iWastage ,
                                                Inventory.bSolitude ,
                                                Inventory.cEnterprise ,
                                                Inventory.cAddress ,
                                                Inventory.cFile ,
                                                Inventory.cLabel ,
                                                Inventory.cCheckOut ,
                                                Inventory.cLicence ,
                                                Inventory.bSpecialties ,
                                                Inventory.cDefWareHouse ,
                                                Inventory.iHighPrice ,
                                                Inventory.cPriceGroup ,
                                                Inventory.iExpSaleRate ,
                                                Inventory.cOfferGrade ,
                                                Inventory.iOfferRate ,
                                                Inventory.cMonth ,
                                                Inventory.iAdvanceDate ,
                                                Inventory.cCurrencyName ,
                                                Inventory.cProduceAddress ,
                                                Inventory.cProduceNation ,
                                                Inventory.cRegisterNo ,
                                                Inventory.cEnterNo ,
                                                Inventory.cPackingType ,
                                                Inventory.cEnglishName ,
                                                Inventory.bPropertyCheck ,
                                                Inventory.cPreparationType ,
                                                Inventory.cCommodity ,
                                                Inventory.iRecipeBatch ,
                                                Inventory.cNotPatentName ,
                                                Inventory.pubufts ,
                                                cbSysBarCode ,
                                                DispatchList.cEBExpressCode ,
                                                ( CASE WHEN ( ISNULL(DispatchLists.bQANeedCheck,
                                                              0) = 1
                                                              AND DispatchLists.iQuantity > 0
                                                            )
                                                       THEN ISNULL(DispatchLists.iQAQuantity,
                                                              0)
                                                       ELSE ISNULL(DispatchLists.iQuantity,
                                                              0)
                                                  END ) AS iquantity ,
                                                ( CASE WHEN ( ISNULL(DispatchLists.bQANeedCheck,
                                                              0) = 1
                                                              AND DispatchLists.iNum > 0
                                                            )
                                                       THEN ISNULL(DispatchLists.iQANum,
                                                              0)
                                                       ELSE ISNULL(DispatchLists.iNum,
                                                              0)
                                                  END ) AS inum ,
                                                ISNULL(DispatchLists.fOutQuantity,
                                                       0) AS fOutQuantity ,
                                                bgift ,
                                                Inventory.cSRPolicy ,--销售订单预留问题 modify by gr161204
                                                ISNULL(CASE WHEN Inventory.iGroupType = 1
                                                            THEN DispatchLists.fOutQuantity
                                                              / DispatchLists.iInvExchRate
                                                            ELSE DispatchLists.fOutNum
                                                       END, 0) AS fOutNum
                                      FROM      dbo.DispatchList
                                                INNER JOIN DispatchLists ON DispatchList.DLID = DispatchLists.DLID
                                                INNER JOIN Inventory ON DispatchLists.cInvCode = Inventory.cInvCode
                                                INNER JOIN Warehouse ON DispatchLists.cWhCode = Warehouse.cWhCode
                                                INNER JOIN ComputationUnit ON Inventory.cComUnitCode = ComputationUnit.cComunitCode
                                                LEFT OUTER JOIN Department ON DispatchList.cDepCode = Department.cDepCode
                                                LEFT OUTER JOIN ComputationUnit ComputationUnit_1 ON DispatchLists.cUnitID = ComputationUnit_1.cComunitCode
                                                LEFT JOIN SA_SORowNo ON DispatchLists.iSOsID = SA_SORowNo.iSOsID
                                                LEFT JOIN SaleType ON DispatchList.cSTCode = SaleType.cSTCode
                                                LEFT JOIN Vendor v1 ON v1.cVenCode = DispatchLists.cvmivencode
                                                LEFT JOIN Customer ON Customer.cCusCode = DispatchList.cCusCode
                                                LEFT JOIN ( SELECT
                                                              cPersonCode AS cpersoncode2 ,
                                                              cPersonName
                                                            FROM
                                                              Person
                                                          ) person ON person.cpersoncode2 = DispatchList.cPersonCode
                                                LEFT JOIN SaleBillVouch ON SaleBillVouch.SBVID = DispatchList.SBVID
                                                LEFT JOIN VouchType ON VouchType.cVouchType = CASE
                                                              WHEN SaleBillVouch.SBVID IS NULL
                                                              THEN DispatchList.cVouchType
                                                              ELSE SaleBillVouch.cVouchType
                                                              END
                                                LEFT JOIN SABizFlow ON SABizFlow.iFlowID = DispatchList.iflowid
                                      WHERE     ( DispatchList.cVouchType = '05'
                                                  OR DispatchList.cVouchType = '06'
                                                )
                                                AND NOT ( ISNULL(DispatchList.bFirst,
                                                              0) = 1
                                                          AND ISNULL(DispatchLists.bIsSTQc,
                                                              0) = 0
                                                        )
                                                AND ( ( ABS(ISNULL(( CASE
                                                              WHEN ( ISNULL(DispatchLists.bQANeedCheck,
                                                              0) = 1
                                                              AND DispatchLists.iQuantity > 0
                                                              )
                                                              THEN DispatchLists.iQAQuantity
                                                              ELSE DispatchLists.iQuantity
                                                              END ), 0))
                                                        - ABS(ISNULL(DispatchLists.fOutQuantity,
                                                              0)) ) >= 0.01
                                                      OR ( iGroupType = 2
                                                           AND ( ABS(ISNULL(( CASE
                                                              WHEN ( ISNULL(DispatchLists.bQANeedCheck,
                                                              0) = 1
                                                              AND DispatchLists.iQuantity > 0
                                                              )
                                                              THEN DispatchLists.iQANum
                                                              ELSE DispatchLists.iNum
                                                              END ), 0))
                                                              - ABS(ISNULL(DispatchLists.fOutNum,
                                                              0)) ) >= 0.01
                                                         )
                                                    ) 
												--AND DATEDIFF(day,DispatchList.dDate,'2010-01-01')<=0 
                                                AND ( ISNULL(DispatchLists.cWhCode,
                                                             '') <> '' )
                                                AND bInvType = 0
                                                AND bService = 0
                                                AND ( ( ISNULL(DispatchLists.bSettleAll,
                                                              0) = 0
                                                        AND DispatchList.cVouchType = '05'
                                                      )
                                                      OR DispatchList.cVouchType = '06'
                                                    )
                                                AND ISNULL(DispatchList.cVerifier,
                                                           '') <> ''
                                                AND ( ( 1 > 0 )
                                                      AND ( 1 > 0 )
                                                    )
                                                AND ( 1 > 0 )
                                                AND ( ( CASE WHEN ISNULL(DispatchLists.bQANeedCheck,
                                                              0) = 1
                                                              AND ISNULL(DispatchLists.iQuantity,
                                                              0) > 0
                                                             THEN DispatchLists.iQAQuantity
                                                             ELSE DispatchLists.iQuantity
                                                        END ) <> 0
                                                      OR ( CASE
                                                              WHEN ISNULL(DispatchLists.bQANeedCheck,
                                                              0) = 1
                                                              AND ISNULL(DispatchLists.iNum,
                                                              0) > 0
                                                              THEN DispatchLists.iQANum
                                                              ELSE DispatchLists.iNum
                                                           END ) <> 0
                                                    )
                                                AND DispatchList.bReturnFlag = 0
                                                AND DispatchList.cBusType IN (
                                                '普通销售', N'分期收款' )
                                    ) tab
                            WHERE   tab.DLID IN (
                                    SELECT DISTINCT
                                            DLID
                                    FROM    #STPDADispatchRefIDs WITH ( NOLOCK ) );
                        END;
					--删除临时表
                    IF EXISTS ( SELECT  0
                                WHERE   NOT OBJECT_ID('tempdb..#STPDADispatchRefIDs') IS NULL )
                        DROP TABLE #STPDADispatchRefIDs;
                END;
            ELSE
                BEGIN
                    RAISERROR ('装箱单不支持的参照类型！',16, 1 );
                END;
    END;
