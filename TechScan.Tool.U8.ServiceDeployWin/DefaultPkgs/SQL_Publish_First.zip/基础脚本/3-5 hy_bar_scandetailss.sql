if not  exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'hy_bar_scandetailss'))
begin
CREATE TABLE [dbo].[hy_bar_scandetailss](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[keyval] [nvarchar](50) NULL,
	[barcode] [nvarchar](120) NULL,
	[cvouchtype] [nvarchar](30) NULL,
	[csrccode] [nvarchar](50) NULL,
	[csource] [nvarchar](50) NULL,
	[cwhcode] [nvarchar](20) NULL,
	[cinvcode] [nvarchar](60) NULL,
	[iquantity] [decimal](38, 8) NULL,
	[cfree1] [nvarchar](20) NULL,
	[cfree2] [nvarchar](20) NULL,
	[cfree3] [nvarchar](20) NULL,
	[cfree4] [nvarchar](20) NULL,
	[cfree5] [nvarchar](20) NULL,
	[cfree6] [nvarchar](20) NULL,
	[cfree7] [nvarchar](20) NULL,
	[cfree8] [nvarchar](20) NULL,
	[cfree9] [nvarchar](20) NULL,
	[cfree10] [nvarchar](20) NULL,
	[cbatch] [nvarchar](60) NULL,
	[cmaker] [nvarchar](20) NULL,
	[dmaketime] [datetime] NULL,
	[computername] [nvarchar](200) NULL,
	[ip] [nvarchar](30) NULL,
	[VoucherID] [nvarchar](30) NULL,
	[SourceID] [nvarchar](30) NULL,
	[scantype] [tinyint] NULL,
	[ccusbarcode] [nvarchar](240) NULL,
	[cposcode] [nvarchar](50) NULL,
	[cposname] [nvarchar](200) NULL,
 CONSTRAINT [PK_hy_bar_scandetailss] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]



EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'hy_bar_scandetailss', @level2type=N'COLUMN',@level2name=N'ID'


EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'���ݺ�' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'hy_bar_scandetailss', @level2type=N'COLUMN',@level2name=N'keyval'


EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'hy_bar_scandetailss', @level2type=N'COLUMN',@level2name=N'barcode'


EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��������' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'hy_bar_scandetailss', @level2type=N'COLUMN',@level2name=N'cvouchtype'


EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��Դ����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'hy_bar_scandetailss', @level2type=N'COLUMN',@level2name=N'csrccode'


EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��Դ��������' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'hy_bar_scandetailss', @level2type=N'COLUMN',@level2name=N'csource'


EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�ֿ����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'hy_bar_scandetailss', @level2type=N'COLUMN',@level2name=N'cwhcode'


EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�������' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'hy_bar_scandetailss', @level2type=N'COLUMN',@level2name=N'cinvcode'


EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'ɨ������' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'hy_bar_scandetailss', @level2type=N'COLUMN',@level2name=N'iquantity'


EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'������1' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'hy_bar_scandetailss', @level2type=N'COLUMN',@level2name=N'cfree1'


EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'������2' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'hy_bar_scandetailss', @level2type=N'COLUMN',@level2name=N'cfree2'


EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'������3' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'hy_bar_scandetailss', @level2type=N'COLUMN',@level2name=N'cfree3'


EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��λ����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'hy_bar_scandetailss', @level2type=N'COLUMN',@level2name=N'cposcode'


EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��λ����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'hy_bar_scandetailss', @level2type=N'COLUMN',@level2name=N'cposname'

end



