﻿
/*===================================== StordProc proc_ts_ReferVouch_Picking_Get ===================================*/
--print 'proc_ts_ReferVouch_Picking_Get' 
--if exists (select * from sysobjects where id = object_id(N'[dbo].[proc_ts_ReferVouch_Picking_Get]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
--     drop procedure [dbo].[proc_ts_ReferVouch_Picking_Get]
--GO

/*---------------------------------------------------------------------  
*    Copyright (C) 2018 TECHSCAN 版权所有。  
*           www.techscan.cn  
*┌────────────────────────────────────┐  
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．      │  
*│　版权所有：上海太迅自动识别技术有限公司 　 　　　　　　　　　　　　    │  
*└────────────────────────────────────┘  
*  
* 文件名：   proc_ts_ReferVouch_Packing_Get.SQL  
* 功能：     存储过程  
* 描述：     ST条码管理[拣货]-获取上游可参照单据信息
* 作者：     丁兴辉  
* 创建时间： 2019-05-28 08:56  
* 文件版本： V1.0.0
  
===============================版本履历===============================  
* Ver		变更日期				负责人		变更内容  
* V1.0.0	2019-05-28 08:56  DXH		Create 
* V1.0.1	2019-06-17   DXH		去除红字出库单   
======================================================================  
//--------------------------------------------------------------------*/
CREATE PROC [dbo].[proc_ts_ReferVouch_Picking_Get] (
--11：参照材料出库
--32：参照销售出库单
--09：参照其他出库单
--100：拣货单
@OperType VARCHAR (3),
--获取类型（'LIST'获取上游参照单据列表;'DETAIL'获取上游参照单据详情（包含表头表体））  
--默认获取上游参照单据列表  
@GetType VARCHAR (10) = N'LIST',
--传入的参数列表字符串  
--默认传空值  
@ParamsList NVARCHAR (2000) = N''
) AS
BEGIN
--单据条码
DECLARE @cSysBarcode NVARCHAR (60) ;
SET @cSysBarcode = dbo.func_ts_GetParamValueBySplitString (@ParamsList,N'cSysBarcode',DEFAULT,DEFAULT) ;

DECLARE @cMaker NVARCHAR (30) ;
SET @cMaker = dbo.func_ts_GetParamValueBySplitString (@ParamsList,N'cMaker',DEFAULT,DEFAULT) ; 

--材料、销售、其他出库/拣货单号
DECLARE @cCode NVARCHAR (30) ;
SET @cCode = dbo.func_ts_GetParamValueBySplitString (@ParamsList,N'cCode',DEFAULT,DEFAULT) ;
IF (@cCode <> N'')
BEGIN

IF EXISTS (SELECT 0 WHERE NOT OBJECT_ID('tempdb..#STPDATempRDCodes') IS NULL) 
DROP TABLE #STPDATempRDCodes ; 
CREATE TABLE #STPDATempRDCodes (cCode NVARCHAR(30)) ; 
INSERT INTO #STPDATempRDCodes EXEC proc_ts_SplitParamString @cCode ;

END ;

DECLARE @ParmList NVARCHAR (MAX);
SET  @ParmList= N'' ;

DECLARE @SqlCommand NVARCHAR (MAX)  ;
SET  @SqlCommand= N'' ;

DECLARE @SqlCommandBody NVARCHAR (MAX) ;
SET  @SqlCommandBody= N'' ;

DECLARE @SqlCommandPosition NVARCHAR (MAX) ;
SET  @SqlCommandPosition= N'' ;

  DECLARE @bRed VARCHAR(1);
  SET @bRed = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                     N'bRed', DEFAULT,
                                                     DEFAULT);
        IF ( @bRed = N'' )
            BEGIN
                SET @bRed = N'0';
            END;




IF (@OperType = N'32' OR @OperType = N'11' OR @OperType = N'09' OR @OperType = N'01' OR @OperType = N'10' OR @OperType = N'08') 
--参照材料出库、销售出库单、其他出库单 采购入库、成品入库、其他入库
BEGIN

SET @SqlCommand = @SqlCommand + 'select distinct rdrecord' +@OperType + '.ID,Warehouse.cWhName,Warehouse.cWhCode,dDate,cCode,cRdCode,Department.cDepName,Department.cDepCode,cCusAbbName cCusName,Person.cPersonName,Person.cPersonCode,cVenName,rdrecord' +@OperType +'.cVenCode,rdrecord' +@OperType + '.cMemo,
cDefine1,cDefine2,cDefine3,cDefine4,cDefine5,cDefine6,cDefine7,cDefine8,cDefine9,
cDefine10,cDefine11,cDefine12,cDefine13,cDefine14,cDefine15,cDefine16
from rdrecord' +@OperType + ' 
inner  join (select cWhCode from  Position  group by cWhCode  ) pos on pos.cWhCode=rdrecord' +@OperType + '.cWhCode
inner join rdrecords' +@OperType + ' on rdrecord' +@OperType + '.ID=rdrecords' +@OperType + '.ID
left join Vendor on Vendor.cVenCode=rdrecord' +@OperType + '.cVenCode
left join Warehouse on Warehouse.cWhCode=rdrecord' +@OperType + '.cWhCode
left join Department on Department.cDepCode=rdrecord' +@OperType + '.cDepCode
left join Person on Person.cPersonCode=rdrecord' +@OperType + '.cPersonCode
left join Customer on Customer.cCusCode=rdrecord' +@OperType + '.cCusCode
left join (select rdsid,rdid,SUM(iquantity) down from InvPosition group by rdsid,rdid) InvPosition on InvPosition.RdID=rdrecords' +@OperType + '.ID and InvPosition.RdsID=AutoID
where  Warehouse.bWhPos=1 and   isnull(cHandler,N'''')=N'''' and isnull(dVeriDate ,N'''')=N'''' and Abs(isnull(down,0))<ABS(iQuantity)' ;

IF (@cCode <> N'')
SET @SqlCommand = @SqlCommand + ' AND cCode  in ( SELECT DISTINCT cCode from tempdb..#STPDATempRDCodes ) ' ;

 

IF (@bRed =N'1')
BEGIN
SET @SqlCommand = @SqlCommand + ' AND rdrecords'+@OperType+'.iQuantity<0 ' ;
END ;

IF (@bRed =N'0')
BEGIN
SET @SqlCommand = @SqlCommand + ' AND rdrecords'+@OperType+'.iQuantity>0 ' ;
END ;






IF (@cMaker <> N'')
BEGIN

SET @SqlCommand = @SqlCommand + ' AND (maker=@cMaker) ' ;
END ;

IF (@cSysBarcode <> N'')
BEGIN

SET @SqlCommand = @SqlCommand + ' AND (csysbarcode=@cSysBarcode) ' ;
END ;

SET @ParmList = '@cCode     NVARCHAR(30),
@bRed NVARCHAR(1),
					@cMaker	NVARCHAR(30),
					@cSysBarcode		NVARCHAR(60)' ; 
EXEC sp_executesql @SqlCommand,
@ParmList,
@cCode = @cCode,
@bRed = @bRed,
@cMaker = @cMaker,
@cSysBarcode = @cSysBarcode ;

IF (@GetType = N'DETAIL')
BEGIN
SET @SqlCommandBody = N'' ;
SET @SqlCommandBody = 'select cCode,csysbarcode,cbsysbarcode,rdrecords' +@OperType + '.cinvcode,Inventory.cinvname,abs(rdrecords' +@OperType + '.inum) inewnum,abs(rdrecords' +@OperType + '.iquantity) inewquantity,rdrecords' +@OperType + '.cbatch,rdrecords' +@OperType + '.cposition,cposname,rdrecord' +@OperType + '.cwhcode,Warehouse.cwhname,Vendor.cVenName cvmivenname,
cdefine22,cdefine23,cdefine24,cdefine25,cdefine26,cdefine27,cVouchType ,rdrecords' +@OperType + '.ID,0 isdid,cAssUnit,iinvexchrate,inventory.cinvstd,bserial,irowno icorrowno,irowno,cbMemo,binvbatch,cvouchcode,           cinvdefine1,cinvdefine2 ,cinvdefine3,cinvdefine4,cinvdefine5 ,cinvdefine6 ,cinvdefine7 ,cinvdefine8 ,cinvdefine9,bfree1,bfree10,bfree2,bfree3,bfree4,bfree5,bfree6,bfree7,bfree8,bfree9,           cinvdefine10,cinvdefine11,cinvdefine12,cinvdefine13,cinvdefine14,cinvdefine15,cinvdefine16,cbatchproperty1,cbatchproperty10,cbatchproperty2,cbatchproperty3,cbatchproperty4,cbatchproperty5,cbatchproperty6,cbatchproperty7,cbatchproperty8,cbatchproperty9,bbatchcreate,bbatchproperty1,bbatchproperty10, bbatchproperty2,bbatchproperty3,bbatchproperty4,bbatchproperty5,bbatchproperty6,bbatchproperty7,bbatchproperty8,bbatchproperty9,'''' cdemandmemo, isoseq,isotype
cdefine1,cdefine2,cdefine3,cdefine4,cdefine5,cdefine6,cdefine7,cdefine8,cdefine9,cdefine10,btracksalebill,'''' irate,
cdefine11,cdefine12,cdefine13,cdefine14,cdefine15,cdefine16,inventory.imassdate,inventory.cmassunit,rdrecords' +@OperType + '.iexpiratdatecalcu,dexpirationdate ,cexpirationdate,
c.cComUnitName cinva_unit,ComputationUnit.cComunitCode cunitid,iChangRate,igrouptype,cassunit AssUnitCode,ComputationUnit.cComUnitName cunit,cbsysbarcode csbsysbarcode,'''' barcode,'''' ibarcodetype,'''' cbarcode,
cdefine28,cdefine29,cdefine30,cdefine31,cdefine32,cdefine33,cdefine34,cdefine35,cdefine36,cdefine37,rdrecords' +@OperType + '.cfree1,rdrecords' +@OperType + '.cfree2,rdrecords' +@OperType + '.cfree3,rdrecords' +@OperType + '.cfree4,rdrecords' +@OperType + '.cfree5,
rdrecords' +@OperType + '.cfree6,rdrecords' +@OperType + '.cfree7,rdrecords' +@OperType + '.cfree8,rdrecords' +@OperType + '.cfree9,rdrecords' +@OperType + '.cfree10,rdrecords' +@OperType + '.autoid,dmadedate,dvdate,isnull(down,0) down,N''0'' doScan,1 freeze, ''''as BoxBarcode,'''' as cposition ,'''' as cposname,
binvtype,cinvaddcode,cvenabbname,'''' cinvsn,inventory.cgroupcode,0 istatus,cvmivencode,cinvouchtype,binvquality,cinvouchcode,bproxywh,btrack,csrpolicy,';
IF(@bRed =N'0')
Begin
 SET @SqlCommandBody=@SqlCommandBody+' (iQuantity)-ISNULL(down,0) iquantity,(iNum) -ISNULL(downnum,0) inum ,';
 END;
IF(@bRed =N'1')
Begin
 SET @SqlCommandBody=@SqlCommandBody+' 0-((iQuantity)-ISNULL(down,0)) iquantity,0-((iNum) -ISNULL(downnum,0)) inum ,';
 END;

 SET @SqlCommandBody=@SqlCommandBody+' isoseq idemandseq,isotype idemandtype,csocode cdemandcode,isodid cdemandid 
from rdrecords' +@OperType + '
inner join rdrecord' +@OperType + ' on rdrecord' +@OperType + '.ID=rdrecords' +@OperType + '.ID
inner  join (select cWhCode from  Position  group by cWhCode  ) pos on pos.cWhCode=rdrecord' +@OperType + '.cWhCode
inner join Warehouse on Warehouse.cWhCode=rdrecord' +@OperType + '.cWhCode
left join Position on Position.cPosCode=rdrecords' +@OperType + '.cPosition and Position.cWhCode =rdrecord' +@OperType + '.cWhCode 
inner join Inventory on Inventory.cInvCode=rdrecords' +@OperType + '.cInvCode
LEFT  JOIN Inventory_Sub  ON Inventory.cInvCode = Inventory_Sub.cInvSubCode 
left join (select rdsid,rdid,SUM(iquantity) down,SUM(inum) downnum from InvPosition group by rdsid,rdid) InvPosition on InvPosition.RdID=rdrecords' +@OperType + '.ID and InvPosition.RdsID=AutoID
left join ComputationUnit on  ComputationUnit.cGroupCode=inventory.cGroupCode 
and ComputationUnit.cComunitCode=inventory.cComUnitCode
left join 
(select AutoID,cComUnitName from rdrecords' +@OperType + '
inner join ComputationUnit on rdrecords' +@OperType + '.cAssUnit=ComputationUnit.cComunitCode) 
c on c.AutoID=rdrecords' +@OperType + '.AutoID
left join Vendor on Vendor.cVenCode=rdrecords' +@OperType + '.cBVencode
where isnull(cHandler,'''')='''' and isnull(dVeriDate ,'''')='''' and Abs(isnull(down,0)) < ABS(iquantity)' ;

IF (@cCode <> N'')
SET @SqlCommandBody = @SqlCommandBody + ' AND cCode  in ( SELECT DISTINCT cCode from tempdb..#STPDATempRDCodes ) ' ;


IF (@bRed =N'1')
BEGIN
SET @SqlCommand = @SqlCommand + ' AND rdrecords'+@OperType+'.iQuantity<0 ' ;
END ;

IF (@bRed =N'0')
BEGIN
SET @SqlCommand = @SqlCommand + ' AND rdrecords'+@OperType+'.iQuantity>0 ' ;
END ;



EXEC sp_executesql @SqlCommandBody ;
END ; 

--删除临时表
IF EXISTS (SELECT 0 WHERE NOT OBJECT_ID('tempdb..#STPDATempRDCodes') IS NULL)
DROP TABLE #STPDATempRDCodes ;

END ;
ELSE
IF ( @OperType = '100' )
--拣货单
BEGIN
SET @SqlCommand='select distinct KC_V_SaleOutOrderH.id,csysbarcode,dDate,KC_V_SaleOutOrderH.cCode,'''' cRdCode,'''' cVenCode,cMemo,
                cDefine1,cDefine2,cDefine3,cDefine4,cDefine5,cDefine6,convert(decimal,cDefine7) cDefine7,cDefine8,cDefine9,'''' cVouchType,
                cMaker,cverifier,dverifydate,dnmaketime,dmodifydate,dnmodifytime,dverifysystime,vt_id3 vt_id4,ufts,
                0 icurquantity,0 icurnum,
                cDefine10,cDefine11,cDefine12,cDefine13,cDefine14,cDefine15,convert(decimal,cDefine16) cDefine16,csubid,csource,cdepcode,cdepname
                from KC_V_SaleOutOrderH
				        left join KC_SaleOutOrders on KC_V_SaleOutOrderH.id=KC_SaleOutOrders.id
                where isnull(cverifier,'''')<>'''' and isnull(dverifydate ,'''')<>'''' and isnull(fxjquantity,0)<iquantity ';

IF (@cCode <> N'')
BEGIN
SET @SqlCommand = @SqlCommand + ' AND KC_V_SaleOutOrderH.cCode  in ( SELECT DISTINCT cCode from tempdb..#STPDATempRDCodes ) ' ;
END; 

IF (@cMaker <> N'')
BEGIN
SET @SqlCommand = @SqlCommand + ' AND (KC_V_SaleOutOrderH.maker=@cMaker) ' ;
END ;

IF (@cSysBarcode <> N'')
BEGIN
SET @SqlCommand = @SqlCommand + ' AND (KC_V_SaleOutOrderH.csysbarcode=@cSysBarcode) ' ;
END ;

SET @ParmList = '@cCode     NVARCHAR(30),
	@cMaker	NVARCHAR(30),
	@cSysBarcode		NVARCHAR(60)' ; 

EXEC sp_executesql @SqlCommand,
@ParmList,
@cCode = @cCode,
@cMaker = @cMaker,
@cSysBarcode = @cSysBarcode ;

IF (@GetType = N'DETAIL')
BEGIN
SET @SqlCommandBody = N'' ;
SET @SqlCommandBody = N'select distinct M.cinvcode,M.inum inewnum,M.iquantity inewquantity,M.cbatch,M.cwhcode,cwhname,
                                            M.cdefine22,M.cdefine23,M.cdefine24,M.cdefine25,M.cdefine26,M.cdefine27,
                                            M.ID,M.autoid isdid,M.cAssUnit,M.iinvexchrate,cinvstd,bserial,M.irowno icorrowno,M.irowno,
                                            M.cbMemo,binvbatch,cinvdefine1,cinvdefine2 ,cinvdefine3,cinvdefine4,cinvdefine5 ,cinvdefine6 ,
                                            cinvdefine7 ,cinvdefine8 ,cinvdefine9,bfree1,bfree10,bfree2,bfree3,bfree4,bfree5,bfree6,bfree7,bfree8,bfree9,
                                            cinvdefine10,cinvdefine11,cinvdefine12,cinvdefine13,cinvdefine14,cinvdefine15,cinvdefine16,
                                            M.cbatchproperty1,M.cbatchproperty10,M.cbatchproperty2,M.cbatchproperty3,M.cbatchproperty4,
                                            M.cbatchproperty5,M.cbatchproperty6,M.cbatchproperty7,M.cbatchproperty8,M.cbatchproperty9,
                                            M.cdemandmemo,idemandseq isoseq,idemandtype isotype,fxjquantity,fxjnum,cinvname,M.autoid,
                                            M.cdemandcode,cdemandid isodid,M.imassdate,M.cmassunit,M.iexpiratdatecalcu,M.dexpirationdate ,M.cexpirationdate,
                                            M.iinvexchrate,M.cassunit AssUnitCode,csysbarcode,
											-- '''' barcode,'''' ibarcodetype,'''' cbarcode,

                                            M.cdefine28,M.cdefine29,M.cdefine30,M.cdefine31,M.cdefine32,M.cdefine33,M.cdefine34,M.cdefine35,
                                            M.cdefine36,M.cdefine37,M.cfree1,M.cfree2,M.cfree3,M.cfree4,M.cfree5,M.cfree6,M.cfree7,M.cfree8,
                                            M.cfree9,M.cfree10,M.autoid,dmdate dmadedate ,M.dvdate,isnull(fxjquantity,0) down,''0'' doScan,1 freeze,'''' irate,
                                            M.cinvsn,cgroupcode,0 istatus,M.cvmivencode,binvquality,bproxywh,btrack,
                                            csrpolicy,M.cbsysbarcode,M.iquantity -isnull(fxjquantity,0) as iquantity ,M.inum-isnull(fxjnum,0) as inum,idemandtype,idemandseq,M.cdemandcode,cdemandid,M.SeparateID,
                                    KC_SaleOutOrderGuide.cvouchcode,KC_SaleOutOrderGuide.cinvouchcode,KC_SaleOutOrderGuide.cinvouchtype,cinvaddcode
-- ,isnull(KC_SaleOutOrderGuide.cposition,N'''') as cjyposition,isnull(KC_SaleOutOrderGuide.iquantity,0) as cjyposqty
                                            from KC_SaleOutOrders M
                                            left join inventory on inventory.cinvcode=M.cinvcode
                                            left join Warehouse on Warehouse.cWhCode=M.cwhcode
                                            left join KC_SaleOutOrder on M.id=KC_SaleOutOrder.id 
                                            left join KC_SaleOutOrderGuide on M.autoid=KC_SaleOutOrderGuide.isdid 
                                            where isnull(fxjquantity,0)<M.iquantity ';

IF (@cCode <> N'')
SET @SqlCommandBody = @SqlCommandBody + ' AND KC_SaleOutOrder.cCode  in ( SELECT DISTINCT cCode from tempdb..#STPDATempRDCodes ) ' ;

EXEC sp_executesql @SqlCommandBody ;
 
 SET @SqlCommandPosition=N'';
 SET @SqlCommandPosition='select  distinct aa.cwhcode,aa.cinvcode,cinvname,cinvstd,cposition,aa.cposname,aa.cbsysbarcode,aa.cfree1,aa.cfree2,aa.cfree3,aa.cfree4,aa.cfree5,
aa.cfree6,aa.cfree7,aa.cfree8,aa.cfree9,aa.cfree10,aa.cbatch,dmadedate,aa.dvdate,aa.cdefine22,aa.cdefine23,aa.cdefine24,aa.cdefine25,aa.cdefine26,
aa.cdefine27,aa.cdefine28,aa.cdefine29,aa.cdefine30,aa.cdefine31,aa.cdefine32,aa.cdefine33,aa.cdefine34,aa.cdefine35,aa.cdefine36,aa.cdefine37,isdid,
aa.iquantity,aa.inum,aa.iinvexchrate ,idemandseq,idemandtype,aa.cdemandcode,cdemandid,csrpolicy
from KC_V_SaleOutOrderGuideB aa
left join KC_SaleOutOrders cc on cc.id=aa.id
left join KC_SaleOutOrder bb on aa.id=bb.id 
where isnull(aa.fxjquantity,0)<aa.iquantity ';
IF (@cCode <> N'')
SET @SqlCommandPosition = @SqlCommandPosition + ' AND bb.cCode  in ( SELECT DISTINCT cCode from tempdb..#STPDATempRDCodes ) ' ;

EXEC sp_executesql @SqlCommandPosition ;
 


END;
--删除临时表
IF EXISTS (SELECT 0 WHERE NOT OBJECT_ID('tempdb..#STPDATempRDCodes') IS NULL) 
DROP TABLE #STPDATempRDCodes ;

END;
ELSE
BEGIN
RAISERROR ('拣货不支持的参照类型！',16, 1 );
END;
END;
