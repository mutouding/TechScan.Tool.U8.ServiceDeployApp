CREATE  FUNCTION f_ts_SplitParamString
    (
      @ParamString VARCHAR(2000) ,
      @split VARCHAR(2) = N','
    )
RETURNS @tReturn TABLE ( cValue VARCHAR(20) )
AS
    BEGIN     

        WHILE ( CHARINDEX(@split, @ParamString) <> 0 )
            BEGIN   

                INSERT  @tReturn
                        ( cValue
                        )
                VALUES  ( SUBSTRING(@ParamString, 1,
                                    CHARINDEX(@split, @ParamString) - 1)
                        );   

                SET @ParamString = STUFF(@ParamString, 1,
                                         CHARINDEX(@split, @ParamString), '');   

            END;   

        INSERT  @tReturn
                ( cValue )
        VALUES  ( @ParamString );   

        RETURN;   

    END;