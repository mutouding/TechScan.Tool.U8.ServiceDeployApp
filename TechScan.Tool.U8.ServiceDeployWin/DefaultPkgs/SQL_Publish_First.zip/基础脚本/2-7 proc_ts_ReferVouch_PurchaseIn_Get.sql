﻿/*---------------------------------------------------------------------
* 			Copyright (C) 2018 TECHSCAN 版权所有。
*           www.techscan.cn
*┌────────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．      │
*│　版权所有：上海太迅自动识别技术有限公司 　 　　　　　　　　　　　　    │
*└────────────────────────────────────┘
*
* 文件名：   proc_ts_ReferVouch_PurchaseIn_Get.SQL
* 功能：     存储过程
* 描述：     ST库存[采购入库单]-获取上游可参照单据信息
* 作者：     马永龙
* 创建时间： 2018-03-29 14:33:31
* 文件版本： V1.0.8

===============================版本履历===============================
* Ver 		变更日期 				负责人 	变更内容
* V1.0.0	2018-03-29 14:33:31		Myl		Create(采购订单（红蓝字）--->采购入库单)
								说明：如果是红字生单（bRed='1'），即参照采购订单红字做采购退货，则前台可输入数量不允许超出该订单已入库数量，即不允许大于表体上的ireceivedqty字段值
* V1.0.1	2018-05-17				Myl		1)添加(采购到货单（红蓝字）--->采购入库单)
								2)添加（委外订单（红蓝字）--->采购入库单）	
* V1.0.2	2018-05-18				Myl		1)添加(委外到货单（红蓝字）--->采购入库单)
* V1.0.3	2018-05-21				Myl		1)添加(来料检验单--->采购入库单)
								2)添加（来料不良品处理单--->采购入库单)
* V1.0.4	2018-06-14				Myl		1)参照采购到货单生单表体数据添加iscanedquantity和isanednum字段
* V1.0.5	2018-06-21				Myl		1)参照来料检验单生单表体数据添加iscanedquantity和isanednum字段（@OperType=4）
* V1.0.6	2018-07-05				Myl		1)修改参照检验单的Bug
								2)参照检验单添加供应商简称
* V1.0.7	2018-07-13				Myl		表体添加统一bodyautoid字段（表体唯一ID的副本字段，前台用）
* V1.0.8	2018-08-14				Myl		1)参照检验单（OperType=4）时添加是否合并检验字段返回
								2)参照1），当合并检验时，使用另外的SQL查询（SQL来源LEO）返回，对应的OperType=9
* V1.0.9	2019-01-21				Zjh		1)增加通过供应商和存货编码，来找到采购到货单
* V1.0.10	2019-04-12				Dxh		1)多张采购订单、采购到货单、委外订单生成采购入库
* V1.0.11	2019-04-23				Dxh		1)采购订单、采购到货单表体增加单据号、单据行条码、供应商编码、供应商名称
* V1.0.12	2019-04-24				Dxh		1)增加cdepcode,cdepname
* V1.0.12	2019-04-24				Dxh		1)采购订单穿透来料检验单入库
* V1.0.12	2019-04-29				Dxh		1)去除采购订单穿透来料检验单入库，直接用质检单4

* V1.0.12	2019-07-10			Dxh		穿透质检单  到货单、采购订单允许并单，表体增加是否质检标志返回


======================================================================
//--------------------------------------------------------------------*/
--EXEC proc_ts_ReferVouch_PurchaseIn_Get '2','DETAIL','ShowClosed:0@@cmaker:demo@@Ids:12,1@@cRejectCodeFrom:0000000001'
--EXEC proc_ts_ReferVouch_PurchaseIn_Get '5','DETAIL' ,'bRed:0'
--EXEC proc_ts_ReferVouch_PurchaseIn_Get '2','DETAIL' ,'bRed:0@@cvencode:WX000001@@OmIds:1000000002'
--EXEC proc_ts_ReferVouch_PurchaseIn_Get '1','DETAIL' ,'bred:1@@cinvcode:BOM0000004@@arrids:1000000036,1000000037'
--EXEC proc_ts_ReferVouch_PurchaseIn_Get '3','DETAIL' ,'bRed:0@@OmArrIds:1000000037@@OmArrdIds:1000000046@@cvencode:WX000001'
--EXEC proc_ts_ReferVouch_PurchaseIn_Get '4','LIST' ,''
--EXEC proc_ts_ReferVouch_PurchaseIn_Get '4','DETAIL' ,'dDateFrom:2017-11-29@@cCodeFrom:0000000001@@cCheckPersonCode:HR_PU_001@@dArrDateFrom:2017-11-29@@cvencode:200000001@@cdeptcode:001@@cPoCodeFrom:0000000004@@cArrCodeFrom:0000000038@@IDS:1,2,3' 
--EXEC proc_ts_ReferVouch_PurchaseIn_Get '5','DETAIL' ,'IDS:1,2,4@@cRejectCodeFrom:0000000001'
--EXEC proc_ts_ReferVouch_PurchaseIn_Get '5','DETAIL' ,''
--EXEC proc_ts_ReferVouch_PurchaseIn_Get '9','DETAIL' ,'ccodes:0000000001,0000000002'
--exec proc_ts_ReferVouch_PurchaseIn_Get N'A','LIST','csysbarcode:||GS01|0000000001'
CREATE PROC [dbo].[Proc_ts_refervouch_purchasein_get] (
  --0：参照采购订单（红蓝字）
  --1：采购到货单（红蓝字）
  --2：委外订单（红蓝字）
  --3：委外到货单（红蓝字）
  --4：材料检验单
  --5：材料不良品处理单
  --6：进口订单（红蓝字）
  --7：进口到货单（红蓝字）
  --8：采购订单穿透来料检验单入库
  --A:入库验收单
  --B:处理通知单
  @OperType   CHAR(1),

  --获取类型（'LIST'获取上游参照单据列表;'DETAIL'获取上游参照单据详情（包含表头表体））
  --默认获取上游参照单据列表
  @GetType    VARCHAR(10) = N'LIST',

  --传入的参数列表字符串
  --默认传空值
  @ParamsList NVARCHAR(2000) = N'')
AS
  BEGIN
      --是否参照生产订单（红字）bRed参数
      DECLARE @bRed VARCHAR(1);

      SET @bRed = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'bRed', DEFAULT, DEFAULT);

      IF ( @bRed = N'' )
        BEGIN
            SET @bRed = N'0';
        END;

      --部门编码（OR 委外订单部门编码 OR 领料申请单部门编码）
      DECLARE @DeptCode NVARCHAR(12);

      SET @DeptCode = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cDeptCode', DEFAULT, DEFAULT);

      -- 单据条码
      DECLARE @CSYSBARCODE NVARCHAR(1000);

      SET @CSYSBARCODE = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'csysbarcode', DEFAULT, DEFAULT);

      --部门名称（OR 委外订单部门名称 OR 领料申请单部门名称）
      DECLARE @DeptName NVARCHAR(255);

      SET @DeptName = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cDeptName', DEFAULT, DEFAULT);

      --存货编码
      DECLARE @cInvCode NVARCHAR(60);

      SET @cInvCode = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cInvCode', DEFAULT, DEFAULT);

      --存货代码
      DECLARE @cInvAddCode NVARCHAR(255);

      SET @cInvAddCode = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cInvAddCode', DEFAULT, DEFAULT);

      --存货名称
      DECLARE @cInvName NVARCHAR(255);

      SET @cInvName = '%'
                      + dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cInvName', DEFAULT, DEFAULT)
                      + '%';

      --存货规格
      DECLARE @cInvStd NVARCHAR(255);

      SET @cInvStd = '%'
                     + dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cInvStd', DEFAULT, DEFAULT)
                     + '%';

      --制单人
      DECLARE @cMaker NVARCHAR(30);

      SET @cMaker = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cMaker', DEFAULT, DEFAULT);

      --业务员编码
      DECLARE @cPersonCode NVARCHAR(20);

      SET @cPersonCode = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cPersonCode', DEFAULT, DEFAULT);

      --业务员名称
      DECLARE @cPersonName NVARCHAR(40);

      SET @cPersonName = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cPersonName', DEFAULT, DEFAULT);

      --执行完未关闭是否显示(1:显示/0:不显示;默认不显示)
      DECLARE @ShowClosed CHAR(1);

      SET @ShowClosed = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'ShowClosed', DEFAULT, DEFAULT);

      --计划到货日期FROM
      DECLARE @ArriveDateFrom VARCHAR(10);

      SET @ArriveDateFrom = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'ArriveDateFrom', DEFAULT, DEFAULT);

      --计划到货日期TO
      DECLARE @ArriveDateTo VARCHAR(10);

      SET @ArriveDateTo = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'ArriveDateTo', DEFAULT, DEFAULT);

      -- 响应要求，去除默认赋值，获取所有单据
      --IF ( @ShowClosed = N'' )
      --BEGIN
      --    SET @ShowClosed = N'0';
      --END;
      --业务类型(普通采购/固定资产)
      DECLARE @cBusType NVARCHAR(8);

      SET @cBusType = N'';

      --供应商编码
      DECLARE @cVenCode NVARCHAR(20);

      SET @cVenCode = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cVenCode', DEFAULT, DEFAULT);

      --供应商名称
      DECLARE @cVenName NVARCHAR(98);

      SET @cVenName = '%'
                      + dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cVenName', DEFAULT, DEFAULT)
                      + '%';

      --供应商简称
      DECLARE @cVenAbbName NVARCHAR(98);

      SET @cVenAbbName = '%'
                         + dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cVenAbbName', DEFAULT, DEFAULT)
                         + '%';

      DECLARE @ParmList NVARCHAR(MAX);

      SET @ParmList = N'';

      DECLARE @SqlCommand NVARCHAR(MAX);

      SET @SqlCommand = N'';

      DECLARE @SqlBODYCommand NVARCHAR(MAX);
      DECLARE @SqlHEADCommand NVARCHAR(MAX);

      SET @SqlBODYCommand = N'';
      SET @SqlHEADCommand = N'';

      IF ( @OperType = N'0' )
        --ST采购入库-参照采购订单
        --(参照采购订单（红字）生成采购退货时，使用参数'bRed'传递
        --[bRed=0表示普通的参照采购订单生成采购入库单/bRed=1表示参照采购订单（红字）生成采购退货]。参照采购订单和采购订单（红字）的区别是添加查询条件：'AND (ISNULL(ireceivedqty,0)>0 OR ISNULL(ireceivednum,0)>0)'，即需要已经入过库才能退
        BEGIN
            --定义查询参数
            --采购订单单号起始@@ 
            DECLARE @cPoCodeFrom NVARCHAR(MAX);

            SET @cPoCodeFrom = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cPoCodeFrom', DEFAULT, DEFAULT);

            IF( @cPoCodeFrom <> N'' )
              BEGIN
                  IF EXISTS (SELECT 0
                             WHERE  NOT Object_id('tempdb..#STPDATempPUPOCodes') IS NULL)
                    DROP TABLE #STPDATempPUPOCodes;

                  CREATE TABLE #STPDATempPUPOCodes
                    (
                       PoCode NVARCHAR(30)
                    );

                  INSERT INTO #STPDATempPUPOCodes
                  EXEC Proc_ts_splitparamstring
                    @cPoCodeFrom;
              END;

            ----采购订单单号截至@@
            --            DECLARE @cPoCodeTo NVARCHAR(30);
            --            SET @cPoCodeTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
            --                                                          N'cPoCodeTo',
            --                                                          DEFAULT, DEFAULT);
            --            IF ( @cPoCodeTo = N'' )
            --                BEGIN
            --                    SET @cPoCodeTo = @cPoCodeFrom;
            --                END; 
            --计划到货日期开始
            DECLARE @dArriveDateFrom NVARCHAR(20);

            SET @dArriveDateFrom = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'dArriveDateFrom', DEFAULT, DEFAULT);

            --计划到货日期截至
            DECLARE @dArriveDateTo NVARCHAR(20);

            SET @dArriveDateTo = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'dArriveDateTo', DEFAULT, DEFAULT);

            IF ( @dArriveDateTo = N'' )
              BEGIN
                  SET @dArriveDateTo = @dArriveDateFrom;
              END;

            --采购订单主表ID
            DECLARE @PoIds NVARCHAR(1000);

            BEGIN
                SET @PoIds = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'PoIds', DEFAULT, DEFAULT);

                IF ( @PoIds <> N'' )
                  BEGIN
                      IF EXISTS (SELECT 0
                                 WHERE  NOT Object_id('tempdb..#STPDATempPOIDs') IS NULL)
                        DROP TABLE #STPDATempPOIDs;

                      CREATE TABLE #STPDATempPOIDs
                        (
                           PoId INT
                        );

                      INSERT INTO #STPDATempPOIDs
                      EXEC Proc_ts_splitparamstring
                        @PoIds;
                  END;
            END;

            --采购订单日期起始
            DECLARE @dPoDateFrom NVARCHAR(20);

            SET @dPoDateFrom = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'dPoDateFrom', DEFAULT, DEFAULT);

            --采购订单日期截至
            DECLARE @dPoDateTo NVARCHAR(20);

            SET @dPoDateTo = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'dPoDateTo', DEFAULT, DEFAULT);

            IF ( @dPoDateTo = N'' )
              BEGIN
                  SET @dPoDateTo = @dPoDateFrom;
              END;

            SET NOCOUNT ON;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDAPurchaseINRefIDs') IS NULL)
              DROP TABLE #STPDAPurchaseINRefIDs;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDAPurchaseINRefID') IS NULL)
              DROP TABLE #STPDAPurchaseINRefID;

            SELECT IDENTITY(INT)        AS tmpId,
                   CONVERT(INT, 0)      AS M_ID,
                   CONVERT(INT, 0)      AS S_ID,
                   CONVERT(MONEY, ufts) AS oriufts
            INTO   #STPDAPurchaseINRefIDs
            FROM   zpurpoheader
            WHERE  1 = 0;

            CREATE CLUSTERED INDEX ix_STPDAPurchaseINRefIDs_tmpid_813
              ON #STPDAPurchaseINRefIDs( M_ID, S_ID, tmpId );

            SET @SqlCommand = 'INSERT INTO #STPDAPurchaseINRefIDs ( M_ID ,S_ID ,oriufts)
SELECT zpurpoheader.poid,zpurpotail.id,CONVERT(MONEY,zpurpoheader.ufts)
FROM zpurpoheader WITH ( NOLOCK )
INNER JOIN zpurpotail WITH ( NOLOCK ) ON zpurpoheader.poid = zpurpotail.poid
LEFT JOIN (SELECT cInvCode AS cInvCode1,bService,iId,iMassDate ,cMassUnit,bInvType
        FROM Inventory WITH ( NOLOCK )) Inventory ON zpurpotail.cinvcode = Inventory.cInvCode1
    LEFT JOIN ( SELECT cInvSubCode,iExpiratDateCalcu FROM Inventory_Sub
                ) inventory_sub ON zpurpotail.cinvcode = inventory_sub.cInvSubCode
WHERE ( 1 > 0 ) AND (ISNULL(cbustype, '''') <> ''委外加工'')
AND ((CASE WHEN ISNULL(cchanger,N'''') <> N'''' THEN ISNULL(cchangverifier,N'''') ELSE ISNULL(cverifier,N'''') END ) <> N''''
    AND ISNULL(cbcloser,N'''') = N'''' AND ISNULL(cbustype,N'''') <> N''直运采购'')
AND ISNULL(Inventory.bService,0) <> 1 AND ISNULL(Inventory.bInvType,0) = 0
AND ISNULL(bgsp,0) = 0
 AND ISNULL(iarrqty,0) = 0 AND ISNULL(iarrnum,0) = 0
AND ISNULL(bstorageorder,1) = 1 ';

            --U812.5 没有这个字段
            -- AND ISNULL(bGCTransforming,0) = 0 
            --采购订单单号
            IF ( @cPoCodeFrom <> N'' )
              --SET @SqlCommand = @SqlCommand
              --    + ' AND ((cpoid >= @cPoCodeFrom) AND (cpoid <= @cPoCodeTo))';
              SET @SqlCommand = @SqlCommand
                                + ' AND (cpoid IN (SELECT DISTINCT PoCode FROM #STPDATempPUPOCodes))';

            --采购订单日期
            IF ( @dPoDateFrom <> N''
                 AND @dPoDateTo <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND ((dpodate >= @dPoDateFrom)
                AND (dpodate <= @dPoDateTo)) ';

            IF ( @cBusType <> N'' )
              SET @SqlCommand = @SqlCommand + ' AND (cbustype =@cBusType) ';

            IF ( @cVenCode <> N'' )
              SET @SqlCommand = @SqlCommand + ' AND (cvencode =@cVenCode) ';

            IF ( @cVenName <> N''
                 AND @cVenName <> N'%%' )
              SET @SqlCommand = @SqlCommand
                                + ' AND cvenname LIKE @cVenName ';

            IF ( @cVenAbbName <> N''
                 AND @cVenAbbName <> N'%%' )
              SET @SqlCommand = @SqlCommand
                                + ' AND cvenabbname LIKE @cVenAbbName ';

            IF ( @DeptCode <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cdepcode = @DeptCode) ';

            IF ( @DeptName <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cdepname = @DeptName) ';

            IF ( @cPersonCode <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cpersoncode = @cPersonCode) ';

            IF ( @cPersonName <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cpersonname = @cPersonName) ';

            --计划到货日期
            IF ( @dArriveDateFrom <> N''
                 AND @dArriveDateTo <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND ((darrivedate >= @dArriveDateFrom) AND (darrivedate <= @dArriveDateTo)) ';

            --    AND ( ( cinvdefine1 >= N'蓝色' )
            --      AND ( cinvdefine1 <= N'蓝色' )
            --    )
            --AND ( ( cinvdefine2 >= N'S' )
            --      AND ( cinvdefine2 <= N'S' )
            --    )
            --AND ( ( cfree1 >= N'广州' )
            --      AND ( cfree1 <= N'广州' )
            --    )
            IF ( @PoIds <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (zpurpoheader.poid IN ( SELECT DISTINCT PoId FROM #STPDATempPOIDs)) ';

            IF ( @bRed = N'1' )
              BEGIN
                  SET @SqlCommand = @SqlCommand
                                    + ' AND (ISNULL(ireceivedqty,0)>0 OR ISNULL(ireceivednum,0)>0) ';
              END;

            IF ( @ShowClosed = N'0'
                  OR @ShowClosed = N'' )
              BEGIN
                  SET @SqlCommand = @SqlCommand
                                    + ' AND (ABS(ISNULL(iquantity,0)) - ABS(ISNULL(ireceivedqty,0)) > 0 OR (igrouptype = 2 AND (ABS(ISNULL(inum,0))- ABS(ISNULL(ireceivednum,0)))> 0)) ';
              END;

            IF ( @cMaker <> N'' )
              SET @SqlCommand = @SqlCommand + ' AND (cmaker=@cMaker) ';

            --PRINT @SqlCommand;
            SET @ParmList = '@cPoCodeFrom			NVARCHAR(30),
						--@cPoCodeTo				NVARCHAR(30),
						@cMaker				NVARCHAR(30),
						@cVenCode				NVARCHAR(20),
						@cVenName				NVARCHAR(98),
						@cVenAbbName			NVARCHAR(98),
						@DeptCode				NVARCHAR(12),
						@DeptName				NVARCHAR(255),
						@dPoDateFrom			NVARCHAR(20),
						@dPoDateTo				NVARCHAR(20),
						@dArriveDateFrom		NVARCHAR(20),
						@dArriveDateTo			NVARCHAR(20),
						@cBusType              NVARCHAR(8),
						@cPersonCode			NVARCHAR(20),
						@cPersonName			NVARCHAR(20)';

            EXEC Sp_executesql
              @SqlCommand,
              @ParmList,
              @cPoCodeFrom = @cPoCodeFrom,
              @cMaker = @cMaker,
              @cVenCode = @cVenCode,
              @cVenName = @cVenName,
              @cVenAbbName = @cVenAbbName,
              @DeptCode = @DeptCode,
              @DeptName = @DeptName,
              @dPoDateFrom = @dPoDateFrom,
              @dPoDateTo = @dPoDateTo,
              @dArriveDateFrom = @dArriveDateFrom,
              @dArriveDateTo = @dArriveDateTo,
              @cBusType = @cBusType,
              @cPersonCode = @cPersonCode,
              @cPersonName = @cPersonName;

            SELECT IDENTITY(INT) AS tmpId,
                   M_ID,
                   Max(oriufts)  AS oriufts
            INTO   #STPDAPurchaseINRefID
            FROM   #STPDAPurchaseINRefIDs
            GROUP  BY M_ID;

            CREATE CLUSTERED INDEX ix_STPDARefID_tmpid_813
              ON #STPDAPurchaseINRefID( tmpId, M_ID );

            SET NOCOUNT OFF;

            --查询列表（表头）
            SELECT ''                                 AS selcol,
                   '采购订单'                             AS csource,
                   cpoid,
                   CONVERT(VARCHAR(100), dpodate, 23) AS ddate,
                   cptcode,
                   cptname,
                   cbustype,
                   cvencode,
                   cvenname,
                   cvenabbname,
                   cdepcode,
                   cdepname,
                   cpersoncode,
                   cpersonname,
                   cmaker,
                   cverifier,
                   cexch_name,
                   nflat,
                   cdefine1,
                   cdefine2,
                   cdefine3,
                   cdefine4,
                   cdefine5,
                   cdefine6,
                   cdefine7,
                   cdefine8,
                   cdefine9,
                   cdefine10,
                   cdefine11,
                   cdefine12,
                   cdefine13,
                   cdefine14,
                   cdefine15,
                   cdefine16,
                   cmemo,
                   idiscounttaxtype,
                   ''                                 AS coufts,
                   poid,
                   itaxrate,
                   cvenpuomprotocol,
                   cvenpuomprotocolname,
                   ( Isnull(iflowid, 0) )             AS iflowid,
                   cflowname
            FROM   zpurpoheader WITH ( NOLOCK )
            WHERE  poid IN (SELECT M_ID
                            FROM   #STPDAPurchaseINRefID --WHERE     tmpId > -30
                           --          AND tmpId < 1 
                           );

            --查询表体
            IF ( @GetType = N'DETAIL' )
              BEGIN
                  SELECT cdepcode,
                         cdepname,
                         zpurpoheader.cpoid,
                         zpurpoheader.cpoid                     AS ccode,
                         cbsysbarcode,
                         cvencode,
                         cvenname,
                         id                                     AS bodyautoid,
                         ''                                     AS selcol,
                         cWhCode                                AS cwhcode,
                         cinvcode,
                         cWhName                                AS cwhname,
                         cinvaddcode,
                         cinvname,
                         cinvstd,
                         cinvdefine1,
                         cinvdefine2,
                         cinvdefine3,
                         cinvdefine4,
                         cinvdefine5,
                         cinvdefine6,
                         cinvdefine7,
                         cinvdefine8,
                         cinvdefine9,
                         cinvdefine10,
                         cinvdefine11,
                         cinvdefine12,
                         cinvdefine13,
                         cinvdefine14,
                         cinvdefine15,
                         cinvdefine16,
                         ccomunitcode,
                         cinvm_unit,
                         cunitid,
                         cinva_unit,
                         iinvexchrate,
                         cfree1,
                         cfree2,
                         cfree3,
                         cfree4,
                         cfree5,
                         cfree6,
                         cfree7,
                         cfree8,
                         cfree9,
                         cfree10,
                         citem_class,
                         ( citem_name )                         AS citemcname,
                         citemcode,
                         ''                                     AS cbatch,
                         ''                                     AS dmadedate,
                         ( citemname )                          AS cname,
                         NULL                                   AS dstartdate,
                         iMassDate                              AS imassdate,
                         ''                                     AS dvdate,
                         CONVERT(VARCHAR(100), darrivedate, 23) AS darrivedate,
                         iquantity,
                         ''                                     AS cinvouchcode,
                         inum,
                         ireceivedqty,
                         ireceivednum,
                         ( CASE
                             WHEN Isnull(iquantity, 0) >= Isnull(ireceivedqty, 0) THEN Isnull(iquantity, 0) - Isnull(ireceivedqty, 0)
                             ELSE 0
                           END )                                AS inquantity,
                         ( CASE
                             WHEN Isnull(inum, 0) >= Isnull(ireceivednum, 0) THEN Isnull(inum, 0) - Isnull(ireceivednum, 0)
                             ELSE 0
                           END )                                AS innum,
                         id,
                         ( ufts )                               AS coufts,
                         ( CASE
                             WHEN Isnull(iquantity, 0) >= Isnull(ireceivedqty, 0) THEN Isnull(iquantity, 0) - Isnull(ireceivedqty, 0)
                             ELSE 0
                           END )                                AS fcurqty,
                         ( CASE
                             WHEN Isnull(inum, 0) >= Isnull(ireceivednum, 0) THEN Isnull(inum, 0) - Isnull(ireceivednum, 0)
                             ELSE 0
                           END )                                AS fcurnum,
                         ''                                     AS icorid,
                         contractcode,
                         contractrowno,
                         igrouptype,
                         imoney,
                         inatmoney,
                         inatsum,
                         inattax,
                         inatunitprice,
                         iinvmpcost,
                         isum,
                         itax,
                         itaxprice,
                         iunitprice,
                         sodid,
                         ipertaxrate,
                         zpurpotail.poid,
                         cMassUnit                              AS cmassunit,
                         ''                                     AS bquansign,
                         btaxcost,
                         cdefine22,
                         cdefine23,
                         cdefine24,
                         cdefine25,
                         cdefine26,
                         cdefine27,
                         cdefine28,
                         cdefine29,
                         cdefine30,
                         cdefine31,
                         cdefine32,
                         cdefine33,
                         cdefine34,
                         cdefine35,
                         cdefine36,
                         cdefine37,
                         sotype,
                         sotype                                 AS isotype,
                         csocode,
                         irowno,
                         csoordercode,
                         iorderdid,
                         iorderseq,
                         iordertype,
                         iExpiratDateCalcu                      AS iexpiratdatecalcu,
                         ''                                     AS cexpirationdate,
                         NULL                                   AS dexpirationdate,
                         ''                                     AS cbatchproperty1,
                         ''                                     AS cbatchproperty2,
                         ''                                     AS cbatchproperty3,
                         ''                                     AS cbatchproperty4,
                         ''                                     AS cbatchproperty5,
                         ''                                     AS cbatchproperty6,
                         ''                                     AS cbatchproperty7,
                         ''                                     AS cbatchproperty8,
                         ''                                     AS cbatchproperty9,
                         ''                                     AS cbatchproperty10,
                         bInvBatch                              AS binvbatch,
                         ivouchrowno,
                         ''                                     AS cinvouchtype,
                         ( CONVERT(NVARCHAR(60), '') )          AS cvmivencode,
                         ( CONVERT(NVARCHAR(60), '') )          AS cvmivenname,
                         cdemandmemo,
                         cbmemo,
                         planlotnumber,
                         bgift,
                         ''                                     AS cfactorycode,
                         ''                                     AS cfactoryname,
                         0.0                                    AS iscanedquantity,
                         0.0                                    AS iscanednum,
                         bPropertyCheck
                  FROM   #STPDAPurchaseINRefIDs
                         INNER JOIN zpurpotail WITH ( NOLOCK )
                                 ON #STPDAPurchaseINRefIDs.S_ID = zpurpotail.id
                         INNER JOIN zpurpoheader WITH ( NOLOCK )
                                 ON zpurpoheader.poid = zpurpotail.poid
                         LEFT JOIN (SELECT cInvCode                  AS cInvCode1,
                                           bService,
                                           iId,
                                           iMassDate,
                                           cMassUnit,
                                           bInvType,
                                           bInvBatch                 binvbatch,
                                           Isnull(cDefWareHouse, '') AS cdefwarehouse,
                                           bPropertyCheck
                                    FROM   Inventory WITH ( NOLOCK )) Inventory
                                ON zpurpotail.cinvcode = Inventory.cInvCode1
                         LEFT JOIN (SELECT cInvSubCode,
                                           iExpiratDateCalcu
                                    FROM   Inventory_Sub WITH ( NOLOCK )) inventory_sub
                                ON zpurpotail.cinvcode = inventory_sub.cInvSubCode
                         LEFT JOIN (SELECT cWhCode,
                                           cWhName
                                    FROM   Warehouse WITH ( NOLOCK )) w
                                ON Isnull(w.cWhCode, N'') = Inventory.cdefwarehouse
                  WHERE  #STPDAPurchaseINRefIDs.M_ID IN (SELECT M_ID
                                                         FROM   #STPDAPurchaseINRefID);
              END;

            --删除临时表
            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDATempPUPOCodes') IS NULL)
              DROP TABLE #STPDATempPUPOCodes;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDAPurchaseINRefIDs') IS NULL)
              DROP TABLE #STPDAPurchaseINRefIDs;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDAPurchaseINRefID') IS NULL)
              DROP TABLE #STPDAPurchaseINRefID;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDATempPOIDs') IS NULL)
              DROP TABLE #STPDATempPOIDs;
        END;
      ELSE IF ( @OperType = N'1' )
        --采购到货单（红蓝字）--->采购入库单
        BEGIN
            --采购到货单单号起始@@
            DECLARE @cArrCodeFrom NVARCHAR(MAX);

            SET @cArrCodeFrom = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cArrCodeFrom', DEFAULT, DEFAULT);

            IF( @cArrCodeFrom <> N'' )
              BEGIN
                  IF EXISTS (SELECT 0
                             WHERE  NOT Object_id('tempdb..#STPDATempArrCodes') IS NULL)
                    DROP TABLE #STPDATempArrCodes;

                  CREATE TABLE #STPDATempArrCodes
                    (
                       cArrCode NVARCHAR(30)
                    );

                  INSERT INTO #STPDATempArrCodes
                  EXEC Proc_ts_splitparamstring
                    @cArrCodeFrom;
              END;

            ----采购到货单单号截至@@
            --               DECLARE @cArrCodeTo NVARCHAR(30);
            --               SET @cArrCodeTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
            --                                                         N'cArrCodeTo',
            --                                                         DEFAULT, DEFAULT);
            --               IF ( @cArrCodeTo = N'' )
            --                   BEGIN
            --                       SET @cArrCodeTo = @cArrCodeFrom;
            --                   END; 
            --到货单单据日期开始
            DECLARE @dArrDateFrom NVARCHAR(20);

            SET @dArrDateFrom = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'dArrDateFrom', DEFAULT, DEFAULT);

            --到货单单据日期截至
            DECLARE @dArrDateTo NVARCHAR(20);

            SET @dArrDateTo = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'dArrDateTo', DEFAULT, DEFAULT);

            IF ( @dArrDateTo = N'' )
              BEGIN
                  SET @dArrDateTo = @dArrDateFrom;
              END;

            --采购订单单号起始@@
            DECLARE @cPoCodeFromArr NVARCHAR(30);

            SET @cPoCodeFromArr = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cPoCodeFrom', DEFAULT, DEFAULT);

            --采购订单单号截至@@
            DECLARE @cPoCodeToArr NVARCHAR(30);

            SET @cPoCodeToArr = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cPoCodeTo', DEFAULT, DEFAULT);

            IF ( @cPoCodeToArr = N'' )
              BEGIN
                  SET @cPoCodeToArr = @cPoCodeFromArr;
              END;

            --行条码
            DECLARE @cBsysbarcode NVARCHAR(255);

            SET @cBsysbarcode = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cbsysbarcode', DEFAULT, DEFAULT);

            DECLARE @cWhCodeArr NVARCHAR(10);

            SET @cWhCodeArr = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cWhCode', DEFAULT, DEFAULT);

            DECLARE @cWhNameArr NVARCHAR(20);

            SET @cWhNameArr = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cWhName', DEFAULT, DEFAULT);

            --采购到货单主表ID
            DECLARE @ArrIds NVARCHAR(1000);

            BEGIN
                SET @ArrIds = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'ArrIds', DEFAULT, DEFAULT);

                IF ( @ArrIds <> N'' )
                  BEGIN
                      IF EXISTS (SELECT 0
                                 WHERE  NOT Object_id('tempdb..#STPDATempArrIDs') IS NULL)
                        DROP TABLE #STPDATempArrIDs;

                      CREATE TABLE #STPDATempArrIDs
                        (
                           ArrId INT
                        );

                      INSERT INTO #STPDATempArrIDs
                      EXEC Proc_ts_splitparamstring
                        @ArrIds;
                  END;
            END;

            DECLARE @iBillType TINYINT;

            IF ( @bRed = '0' )
              SET @iBillType = 0;
            ELSE
              SET @iBillType = 1;

            SET NOCOUNT ON;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDAPurchaseINArrRefIDs') IS NULL)
              DROP TABLE #STPDAPurchaseINArrRefIDs;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDAPurchaseINArrRefID') IS NULL)
              DROP TABLE #STPDAPurchaseINArrRefID;

            SELECT IDENTITY(INT)        AS tmpId,
                   CONVERT(INT, 0)      AS M_ID,
                   CONVERT(INT, 0)      AS S_ID,
                   CONVERT(MONEY, ufts) AS oriufts
            INTO   #STPDAPurchaseINArrRefIDs
            FROM   pu_ArrHead
            WHERE  1 = 0;

            CREATE CLUSTERED INDEX ix_STPDAPurchaseINRefIDs_tmpid_813
              ON #STPDAPurchaseINArrRefIDs( M_ID, S_ID, tmpId );

            SET @SqlCommand = 'INSERT INTO #STPDAPurchaseINArrRefIDs ( M_ID ,S_ID ,oriufts)
SELECT  pu_ArrHead.id,pu_arrbody.autoid,CONVERT(MONEY,pu_ArrHead.ufts)
FROM    pu_arrbody
    INNER JOIN pu_ArrHead ON pu_ArrHead.id = pu_arrbody.id
    INNER JOIN ( SELECT cInvCode AS cinvcode1,iId FROM Inventory
                ) inventory ON pu_arrbody.cinvcode = inventory.cinvcode1
WHERE  ISNULL(cbustype, '''') <> ''委外加工''  AND ISNULL(cbcloser, N'''') = N''''
    AND ISNULL(cverifier, '''') <> '''' AND ibilltype = @iBillType
   -- AND ISNULL(bgsp, N'''') = N''0''
    AND ISNULL(cgspstate,'''')=''''
    AND ISNULL(bstoragearrivalorder, 1) = 1 
AND ( 1 = 1 ';

            --红字情况下不需要质检
            IF ( @bRed = '1' )
              BEGIN
                  SET @SqlCommand = @SqlCommand
                                    + ' AND ISNULL(bgsp, N'''') = N''0'' ';
              END;

            --采购到货单号
            IF ( @cArrCodeFrom <> N'' )
              --SET @SqlCommand = @SqlCommand
              --    + ' AND ((ccode >= @cArrCodeFrom) AND (ccode <= @cArrCodeTo))';
              SET @SqlCommand = @SqlCommand
                                + ' AND (ccode in (SELECT DISTINCT cArrCode FROM #STPDATempArrCodes))';

            --采购到货单日期
            IF ( @dArrDateFrom <> N''
                 AND @dArrDateTo <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND ((ddate >= @dArrDateFrom) AND (ddate <= @dArrDateTo)) ';

            IF ( @cBusType <> N'' )
              SET @SqlCommand = @SqlCommand + ' AND (cbustype =@cBusType) ';

            IF ( @cVenCode <> N'' )
              SET @SqlCommand = @SqlCommand + ' AND (cvencode =@cVenCode) ';

            IF ( @cVenName <> N''
                 AND @cVenName <> N'%%' )
              SET @SqlCommand = @SqlCommand
                                + ' AND cvenname LIKE @cVenName ';

            IF ( @cVenAbbName <> N''
                 AND @cVenAbbName <> N'%%' )
              SET @SqlCommand = @SqlCommand
                                + ' AND cvenabbname LIKE @cVenAbbName ';

            IF ( @DeptCode <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cdepcode = @DeptCode) ';

            IF ( @DeptName <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cdepname = @DeptName) ';

            IF ( @cPersonCode <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cpersoncode = @cPersonCode) ';

            IF ( @cPersonName <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cpersonname = @cPersonName) ';

            IF ( @cWhCodeArr <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cwhcode = @cWhCodeArr) ';

            IF ( @cWhNameArr <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cwhname = @cWhNameArr) ';

            IF ( @cInvCode <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cinvcode = @cInvCode) ';

            IF ( @cInvName <> N''
                 AND @cInvName <> N'%%' )
              SET @SqlCommand = @SqlCommand
                                + ' AND cinvname LIKE @cInvName ';

            IF ( @cInvStd <> N''
                 AND @cInvStd <> N'%%' )
              SET @SqlCommand = @SqlCommand + ' AND cinvstd LIKE @cInvStd ';

            IF ( @cInvAddCode <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cinvaddcode = @cInvAddCode) ';

            IF ( @cMaker <> N'' )
              SET @SqlCommand = @SqlCommand + ' AND (cmaker=@cMaker) ';

            IF ( @ArrIds <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (pu_ArrHead.id IN ( SELECT DISTINCT ArrId FROM #STPDATempArrIDs)) ';

            --采购订单单号
            IF ( @cPoCodeFromArr <> N'' )
              BEGIN
                  SET @SqlCommand = @SqlCommand
                                    + ' AND ((cordercode >= @cPoCodeFromArr) AND (cordercode <= @cPoCodeToArr)) ';
              END;

            IF ( @ShowClosed = N'1' )
              BEGIN
                  IF ( @bRed = '1' )
                    BEGIN
                        SET @SqlCommand = @SqlCommand
                                          + ' AND (ISNULL(iquantity,0) < 0 OR ISNULL(inum,0) < 0) ';
                    END;
                  ELSE
                    BEGIN
                        SET @SqlCommand = @SqlCommand
                                          + ' AND ( ISNULL(iquantity, 0) > 0 OR ISNULL(inum, 0) > 0) ';
                    END;
              END;
            ELSE
              BEGIN
                  IF ( @bRed = '1' )
                    BEGIN
                        SET @SqlCommand = @SqlCommand
                                          + ' AND (ISNULL(iquantity,0) - ISNULL(frefusequantity,0) < ISNULL(fvalidinquan,0)
            OR (igrouptype = 2 AND ISNULL(inum,0) - ISNULL(frefusenum,0) < ISNULL(fvalidinnum,0))) ';
                    END;
                  ELSE
                    BEGIN
                        SET @SqlCommand = @SqlCommand
                                          + ' AND (ISNULL(iquantity,0) - ISNULL(frefusequantity,0) > ISNULL(fvalidinquan,0)
            OR ( igrouptype = 2 AND ISNULL(inum,0) - ISNULL(frefusenum,0) > ISNULL(fvalidinnum,0))) ';
                    END;
              END;

            --行条码
            IF ( @cBsysbarcode <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cBsysbarcode=@cBsysbarcode) ';

            SET @SqlCommand = @SqlCommand + ' ) ';
            --PRINT @SqlCommand;
            SET @ParmList = '@iBillType			TINYINT,
						@cArrCodeFrom			NVARCHAR(30),
						-- @cArrCodeTo			NVARCHAR(30),
						@dArrDateFrom			NVARCHAR(10),
						@dArrDateTo			NVARCHAR(10),
						@cMaker				NVARCHAR(30),
						@cVenCode				NVARCHAR(20),
						@cVenName				NVARCHAR(98),
						@cVenAbbName			NVARCHAR(98),
						@DeptCode				NVARCHAR(12),
						@DeptName				NVARCHAR(255),
						@cPoCodeFromArr		NVARCHAR(30),
						@cPoCodeToArr			NVARCHAR(30),
						@cWhCodeArr			NVARCHAR(10),
						@cWhNameArr			NVARCHAR(20),
						@cInvCode				NVARCHAR(60),
						@cInvName				NVARCHAR(255),
						@cInvStd				NVARCHAR(255),
						@cInvAddCode			NVARCHAR(255),
						@cBusType              NVARCHAR(8),
						@cPersonCode			NVARCHAR(20),
						@cPersonName			NVARCHAR(20),
						@cBsysbarcode           NVARCHAR(255) ';

            EXEC Sp_executesql
              @SqlCommand,
              @ParmList,
              @iBillType = @iBillType,
              @cArrCodeFrom = @cArrCodeFrom,
              --  @cArrCodeTo = @cArrCodeTo,
              @dArrDateFrom = @dArrDateFrom,
              @dArrDateTo = @dArrDateTo,
              @cMaker = @cMaker,
              @cVenCode = @cVenCode,
              @cVenName = @cVenName,
              @cVenAbbName = @cVenAbbName,
              @DeptCode = @DeptCode,
              @DeptName = @DeptName,
              @cPoCodeFromArr = @cPoCodeFromArr,
              @cPoCodeToArr = @cPoCodeToArr,
              @cWhCodeArr = @cWhCodeArr,
              @cWhNameArr = @cWhNameArr,
              @cInvCode = @cInvCode,
              @cInvName = @cInvName,
              @cInvStd = @cInvStd,
              @cInvAddCode = @cInvAddCode,
              @cBusType = @cBusType,
              @cPersonCode = @cPersonCode,
              @cPersonName = @cPersonName,
              @cBsysbarcode=@cBsysbarcode;

            SELECT IDENTITY(INT) AS tmpId,
                   M_ID,
                   Max(oriufts)  AS oriufts
            INTO   #STPDAPurchaseINArrRefID
            FROM   #STPDAPurchaseINArrRefIDs
            GROUP  BY M_ID;

            CREATE CLUSTERED INDEX ix_STPDARefID_tmpid_813
              ON #STPDAPurchaseINArrRefID( tmpId, M_ID );

            SET NOCOUNT OFF;

            --查询列表（表头）       
            SELECT ''                               AS selcol,
                   '采购到货单'                          AS csource,
                   ccode,
                   CONVERT(VARCHAR(100), ddate, 23) AS darvdate,
                   CONVERT(VARCHAR(100), ddate, 23) AS ddate,
                   cptcode,
                   cptname,
                   cbustype,
                   cvencode,
                   cvenname,
                   cvenabbname,
                   cdepcode,
                   cdepname,
                   cpersoncode,
                   cpersonname,
                   cmaker,
                   cexch_name,
                   iexchrate,
                   cdefine1,
                   cdefine2,
                   cdefine3,
                   cdefine4,
                   cdefine5,
                   cdefine6,
                   cdefine7,
                   cdefine8,
                   cdefine9,
                   cdefine10,
                   cdefine11,
                   cdefine12,
                   cdefine13,
                   cdefine14,
                   cdefine15,
                   cdefine16,
                   cmemo,
                   ufts,
                   itaxrate,
                   ''                               AS coufts,
                   id,
                   idiscounttaxtype,
                   cvenpuomprotocol,
                   cvenpuomprotocolname,
                   ( Isnull(iflowid, 0) )           AS iflowid,
                   cflowname
            FROM   pu_ArrHead
            WHERE  id IN (SELECT M_ID
                          FROM   #STPDAPurchaseINArrRefID --WHERE   tmpId > -30
                         --        AND tmpId < 1
                         );

            IF ( @GetType = N'DETAIL' )
              BEGIN
                  SELECT cdepcode,
                         cdepname,
                         pu_ArrHead.ccode,
                         cbsysbarcode,
                         cvencode,
                         cvenname,
                         autoid                                      AS bodyautoid,
                         ''                                          AS selcol,
                         cwhcode,
                         cwhname,
                         cinvcode,
                         cinvaddcode,
                         cinvname,
                         cinvstd,
                         cinvdefine1,
                         cinvdefine2,
                         cinvdefine3,
                         cinvdefine4,
                         cinvdefine5,
                         cinvdefine6,
                         cinvdefine7,
                         cinvdefine8,
                         cinvdefine9,
                         cinvdefine10,
                         cinvdefine11,
                         cinvdefine12,
                         cinvdefine13,
                         cinvdefine14,
                         cinvdefine15,
                         cinvdefine16,
                         ccomunitcode,
                         cinvm_unit,
                         cunitid,
                         cinva_unit,
                         iinvexchrate,
                         cfree1,
                         cfree2,
                         cfree3,
                         cfree4,
                         cfree5,
                         cfree6,
                         cfree7,
                         cfree8,
                         cfree9,
                         cfree10,
                         cbatch,
                         ( dpdate )                                  AS dmadedate,
                         imassdate,
                         dvdate,
                         citem_class,
                         ( citem_name )                              AS citemcname,
                         ''                                          AS cinvouchcode,
                         citemcode,
                         ( citemname )                               AS cname,
                         ( CASE
                             WHEN ibilltype = 1 THEN 0 - ( Isnull(iquantity, 0) - Isnull(frefusequantity, 0) )
                             ELSE ( Isnull(iquantity, 0) - Isnull(frefusequantity, 0) )
                           END )                                     AS iquantity,
                         ( Isnull(inum, 0) - Isnull(frefusenum, 0) ) AS inum,
                         fvalidinquan,--已合格入库数量
                         fvalidinquan                                AS ireceivedqty,
                         fvalidinnum,--已合格入库件数
                         ( CASE
                             WHEN Abs(Isnull(iquantity, 0) - Isnull(frefusequantity, 0)) > Abs(Isnull(fvalidinquan, 0)) THEN Isnull(iquantity, 0) - Isnull(frefusequantity, 0) - Isnull(fvalidinquan, 0)
                             ELSE 0
                           END )                                     AS inquantity,--本次剩余可入库数量
                         ( CASE
                             WHEN Abs(Isnull(inum, 0) - Isnull(frefusenum, 0)) > Abs(Isnull(fvalidinnum, 0)) THEN Isnull(inum, 0) - Isnull(frefusenum, 0) - Isnull(fvalidinnum, 0)
                             ELSE 0
                           END )                                     AS innum,--本次剩余可入库件数
                         autoid,
                         ( cordercode )                              AS cpoid,
                         iposid,
                         ( CASE
                             WHEN Abs(Isnull(iquantity, 0) - Isnull(frefusequantity, 0)) > Abs(Isnull(fvalidinquan, 0)) THEN Isnull(iquantity, 0) - Isnull(frefusequantity, 0) - Isnull(fvalidinquan, 0)
                             ELSE 0
                           END )                                     AS fcurqty,--本次入库数量
                         ( CASE
                             WHEN Abs(Isnull(inum, 0) - Isnull(frefusenum, 0)) > Abs(Isnull(fvalidinnum, 0)) THEN Isnull(inum, 0) - Isnull(frefusenum, 0) - Isnull(fvalidinnum, 0)
                             ELSE 0
                           END )                                     AS fcurnum,--本次入库件数
                         frefusenum,
                         frefusequantity,
                         cmassunit,
                         ( CONVERT(INT, NULL) )                      AS icorid,
                         contractcode,
                         contractrowno,
                         igrouptype,
                         iinvmpcost,
                         pu_arrbody.id,
                         ioricost,
                         iorimoney,
                         iorisum,
                         ioritaxcost,
                         ioritaxprice,
                         pu_arrbody.itaxrate                         AS ipertaxrate,
                         isum,
                         itaxprice,
                         sodid,
                         ''                                          AS bquansign,
                         btaxcost,
                         cdefine22,
                         cdefine23,
                         cdefine24,
                         cdefine25,
                         cdefine26,
                         cdefine27,
                         cdefine28,
                         cdefine29,
                         cdefine30,
                         cdefine31,
                         cdefine32,
                         cdefine33,
                         cdefine34,
                         cdefine35,
                         cdefine36,
                         cdefine37,
                         sotype,
                         sotype                                      AS isotype,
                         csocode,
                         irowno,
                         csoordercode,
                         iorderdid,
                         iorderseq,
                         iordertype,
                         iexpiratdatecalcu,
                         cexpirationdate,
                         dexpirationdate,
                         cbatchproperty1,
                         cbatchproperty2,
                         cbatchproperty3,
                         cbatchproperty4,
                         cbatchproperty5,
                         cbatchproperty6,
                         cbatchproperty7,
                         cbatchproperty8,
                         cbatchproperty9,
                         cbatchproperty10,
                         ivouchrowno,
                         ''                                          AS cinvouchtype,
                         ( CONVERT(NVARCHAR(60), '') )               AS cvmivencode,
                         ( CONVERT(NVARCHAR(60), '') )               AS cvmivenname,
                         icost,
                         -- imoney ,
                         cbmemo,
                         iproducttype,
                         cmaininvcode,
                         imainmodetailsid,
                         planlotnumber,
                         bgift,
                         ''                                          AS cfactorycode,
                         ''                                          AS cfactoryname,
                         0.0                                         AS iscanedquantity,
                         0.0                                         AS iscanednum,
                         pu_arrbody.binvbatch,
                         bPropertyCheck,
                         bgsp
                  FROM   #STPDAPurchaseINArrRefIDs
                         INNER JOIN pu_arrbody
                                 ON #STPDAPurchaseINArrRefIDs.S_ID = pu_arrbody.autoid
                         -- and pu_arrbody.bgsp=0
                         INNER JOIN pu_ArrHead
                                 ON pu_ArrHead.id = pu_arrbody.id
                         INNER JOIN (SELECT cInvCode AS cinvcode1,
                                            iId,
                                            bPropertyCheck
                                     FROM   Inventory) inventory
                                 ON pu_arrbody.cinvcode = inventory.cinvcode1
                                    AND #STPDAPurchaseINArrRefIDs.M_ID IN (SELECT M_ID
                                                                           FROM   #STPDAPurchaseINArrRefID);
              END;

            --删除临时表
            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDATempArrCodes') IS NULL)
              DROP TABLE #STPDATempArrCodes;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDAPurchaseINArrRefIDs') IS NULL)
              DROP TABLE #STPDAPurchaseINArrRefIDs;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDAPurchaseINArrRefID') IS NULL)
              DROP TABLE #STPDAPurchaseINArrRefID;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDATempArrIDs') IS NULL)
              DROP TABLE #STPDATempArrIDs;
        END;
      ELSE IF ( @OperType = '2' )
        --ST采购入库-参照委外订单
        BEGIN
            --定义查询参数
            SET @cBusType = '委外加工';

            --委外订单子表ID
            DECLARE @OmDIds NVARCHAR(1000);

            BEGIN
                SET @OmDIds = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'OmDIds', DEFAULT, DEFAULT);

                IF ( @OmDIds <> N'' )
                  BEGIN
                      IF EXISTS (SELECT 0
                                 WHERE  NOT Object_id('tempdb..#STPDATempOMDIDs') IS NULL)
                        DROP TABLE #STPDATempOMDIDs;

                      CREATE TABLE #STPDATempOMDIDs
                        (
                           MoDetailsId INT
                        );

                      INSERT INTO #STPDATempOMDIDs
                      EXEC Proc_ts_splitparamstring
                        @OmDIds;
                  END;
            END;

            --委外订单单号起始
            DECLARE @cOmCodeFrom NVARCHAR(MAX);

            SET @cOmCodeFrom = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cCodeFrom', DEFAULT, DEFAULT);

            IF( @cOmCodeFrom <> N'' )
              BEGIN
                  IF EXISTS (SELECT 0
                             WHERE  NOT Object_id('tempdb..#STPDATempOmCodes') IS NULL)
                    DROP TABLE #SSTPDATempOmCodes;

                  CREATE TABLE #STPDATempOmCodes
                    (
                       omCode NVARCHAR(30)
                    );

                  INSERT INTO #STPDATempOmCodes
                  EXEC Proc_ts_splitparamstring
                    @cOmCodeFrom;
              END;

            ----委外订单单号截至
            --         DECLARE @cOmCodeTo NVARCHAR(30);
            --         SET @cOmCodeTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
            --                                                 N'cCodeTo',
            --                                                 DEFAULT, DEFAULT);
            --         IF ( @cOmCodeTo = N'' )
            --             BEGIN
            --                 SET @cOmCodeTo = @cOmCodeFrom;
            --             END;  
            --委外订单日期FROM
            DECLARE @dOmDateFrom VARCHAR(10);

            SET @dOmDateFrom = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'dDateFrom', DEFAULT, DEFAULT);

            --委外订单日期TO
            DECLARE @dOmDateTo VARCHAR(10);

            SET @dOmDateTo = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'dDateTo', DEFAULT, DEFAULT);

            IF ( @dOmDateTo = '' )
              SET @dOmDateTo = @dOmDateFrom;

            --计划下达日期FROM
            DECLARE @dStartDateFromOm VARCHAR(10);

            SET @dStartDateFromOm = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'dStartDateFrom', DEFAULT, DEFAULT);

            --计划下达日期TO
            DECLARE @dStartDateToOm VARCHAR(10);

            SET @dStartDateToOm = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'dStartDateTo', DEFAULT, DEFAULT);

            IF ( @dStartDateToOm = N'' )
              BEGIN
                  SET @dStartDateToOm = @dStartDateFromOm;
              END;

            --计划到货日期FROM
            DECLARE @dArriveDateFromOm VARCHAR(10);

            SET @dArriveDateFromOm = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'dArriveDateFrom', DEFAULT, DEFAULT);

            --计划到货日期FROM
            DECLARE @dArriveDateToOm VARCHAR(10);

            SET @dArriveDateToOm = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'dArriveDateTo', DEFAULT, DEFAULT);

            IF ( @dStartDateToOm = N'' )
              BEGIN
                  SET @dStartDateToOm = @dArriveDateFromOm;
              END;

            --委外订单类型('0':标准;'1':非标准)
            DECLARE @iOrderType VARCHAR(10);

            SET @iOrderType = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'iOrderType', DEFAULT, DEFAULT);

            --委外订单主表ID
            DECLARE @OmIds NVARCHAR(1000);

            BEGIN
                SET @OmIds = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'OmIds', DEFAULT, DEFAULT);

                IF ( @OmIds <> N'' )
                  BEGIN
                      IF EXISTS (SELECT 0
                                 WHERE  NOT Object_id('tempdb..#STPDATempOmIDs') IS NULL)
                        DROP TABLE #STPDATempOmIDs;

                      CREATE TABLE #STPDATempOmIDs
                        (
                           OmId INT
                        );

                      INSERT INTO #STPDATempOmIDs
                      EXEC Proc_ts_splitparamstring
                        @OmIds;
                  END;
            END;

            --DECLARE @iBillTypeOm TINYINT;
            --IF ( @bRed = '0' )
            --    SET @iBillTypeOm = 0;
            --ELSE
            --    SET @iBillTypeOm = 1;
            SET NOCOUNT ON;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDARefOMIDs') IS NULL)
              DROP TABLE #STPDARefOMIDs;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDARefOMID') IS NULL)
              DROP TABLE #STPDARefOMID;

            SELECT IDENTITY(INT)   AS tmpId,
                   CONVERT(INT, 0) AS MoID,
                   CONVERT(INT, 0) AS MoDetailsID
            INTO   #STPDARefOMIDs
            FROM   om_mohead
            WHERE  1 = 0;

            CREATE CLUSTERED INDEX ix_STPDAOmRefIDs_tmpid_813
              ON #STPDARefOMIDs( MoID, MoDetailsID, tmpId );

            SET @SqlCommand = 'INSERT INTO #STPDARefOMIDs (MoID,MoDetailsID)
SELECT DISTINCT TOP 100 PERCENT om_mohead.moid ,om_mobody.modetailsid FROM om_mohead WITH ( NOLOCK )
INNER JOIN om_mobody WITH ( NOLOCK ) ON om_mohead.moid = om_mobody.moid
LEFT JOIN ( SELECT cInvCode AS cInvCode1,bService,iId,ISNULL(cDefWareHouse,'''') AS cdefwarehouse FROM Inventory
        ) Inventory ON om_mobody.cinvcode = Inventory.cInvCode1
LEFT JOIN ( SELECT cWhCode,cWhName FROM Warehouse WITH ( NOLOCK )) w ON ISNULL(w.cWhCode,N'''') = Inventory.cdefwarehouse WHERE  
(( CASE WHEN ISNULL(cchanger,N'''') <> N'''' THEN ISNULL(cchangeverifier,N'''') ELSE ISNULL(cverifier,N'''') END ) <> N''''
AND ISNULL(cbcloser, N'''') = N'''' AND ISNULL(cbustype,N'''') <> N''直运采购'')
AND ISNULL(Inventory.bService,0) <> 1 AND ISNULL(bgsp,0) = 0
AND ISNULL(iarrqty, 0) = 0 AND ISNULL(iarrnum, 0) = 0 ';

            --委外订单单号
            IF ( @cOmCodeFrom <> N'' )
              --SET @SqlCommand = @SqlCommand
              --    + ' AND ((ccode >= @cOmCodeFrom) AND (ccode <= @cOmCodeTo))';
              SET @SqlCommand = @SqlCommand
                                + ' AND (ccode in (SELECT DISTINCT omcode FROM #STPDATempOmCodes))';

            --委外订单日期
            IF ( @dOmDateFrom <> N''
                 AND @dOmDateTo <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND ((ddate >= @dOmDateFrom) AND (ddate <= @dOmDateTo)) ';

            IF ( @cBusType <> N'' )
              SET @SqlCommand = @SqlCommand + ' AND (cbustype =@cBusType) ';

            IF ( @cVenCode <> N'' )
              SET @SqlCommand = @SqlCommand + ' AND (cvencode =@cVenCode) ';

            IF ( @cVenName <> N''
                 AND @cVenName <> N'%%' )
              SET @SqlCommand = @SqlCommand
                                + ' AND cvenname LIKE @cVenName ';

            IF ( @cVenAbbName <> N''
                 AND @cVenAbbName <> N'%%' )
              SET @SqlCommand = @SqlCommand
                                + ' AND cvenabbname LIKE @cVenAbbName ';

            IF ( @DeptCode <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cdepcode = @DeptCode) ';

            IF ( @DeptName <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cdepname = @DeptName) ';

            IF ( @cPersonCode <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cpersoncode = @cPersonCode) ';

            IF ( @cPersonName <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cpersonname = @cPersonName) ';

            IF ( @dStartDateFromOm <> N''
                 AND @dStartDateToOm <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND ((dstartdate >= @dStartDateFromOm) AND (dstartdate <= @dStartDateToOm)) ';

            IF ( @dArriveDateFromOm <> N''
                 AND @dArriveDateToOm <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND ((darrivedate >= @dArriveDateFromOm) AND (darrivedate <= @dArriveDateToOm)) ';

            IF ( @OmIds <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (om_mohead.moid IN ( SELECT DISTINCT OmId FROM #STPDATempOmIDs)) ';

            IF ( @OmDIds <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (om_mobody.modetailsid IN ( SELECT DISTINCT MoDetailsId FROM #STPDATempOMDIDs)) ';

            IF ( @cMaker <> N'' )
              SET @SqlCommand = @SqlCommand + ' AND (cmaker=@cMaker) ';

            IF ( @cInvCode <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cinvcode = @cInvCode) ';

            IF ( @cInvName <> N''
                 AND @cInvName <> N'%%' )
              SET @SqlCommand = @SqlCommand
                                + ' AND cinvname LIKE @cInvName ';

            IF ( @cInvStd <> N''
                 AND @cInvStd <> N'%%' )
              SET @SqlCommand = @SqlCommand + ' AND cinvstd LIKE @cInvStd ';

            IF ( @cInvAddCode <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cinvaddcode = @cInvAddCode) ';

            IF ( @iOrderType <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (iordertype = @iOrderType) ';

            IF ( @bRed = N'1' )
              BEGIN
                  SET @SqlCommand = @SqlCommand
                                    + '  AND ( ISNULL(ireceivedqty,0) > 0 OR ISNULL(ireceivednum,0) > 0) AND ISNULL(om_mobody.iproducttype,0) = 0';
              END;

			  
            IF ( @bRed = N'0' OR @bRed = N'' )
              BEGIN
                  SET @SqlCommand = @SqlCommand
                                    + ' AND ( CASE WHEN igrouptype <> 2 THEN Abs(Isnull(iQuantity, 0)) - Abs(Isnull(iReceivedQTY, 0))
        ELSE ( CASE WHEN NOT( ( Abs(Isnull(iQuantity, 0)) - Abs(Isnull(iReceivedQTY, 0)) ) <= 0 AND ( Abs(Isnull(iNum, 0)) - Abs(Isnull(iReceivedNum, 0)) ) <= 0 ) THEN 1 ELSE 0  END ) END ) > 0';
              END;

			  IF ( @ShowClosed = N'' )
      BEGIN
          SET @ShowClosed = N'0';
      END;

            IF ( @ShowClosed = N'0' )
              BEGIN
                  SET @SqlCommand = @SqlCommand
                                    + ' AND ( CASE WHEN igrouptype <> 2 THEN ABS(ISNULL(iquantity,0)) - ABS(ISNULL(ireceivedqty,0))
        ELSE ( CASE WHEN NOT ( ( ABS(ISNULL(iquantity,0)) - ABS(ISNULL(ireceivedqty,0)) ) <= 0 AND ( ABS(ISNULL(inum,0))
        - ABS(ISNULL(ireceivednum,0)) ) <= 0 ) THEN 1 ELSE 0 END )END ) > 0  ';
              END;

            PRINT @SqlCommand;

            SET @ParmList = '@cOmCodeFrom			NVARCHAR(30),
						-- @cOmCodeTo				NVARCHAR(30),
						@dOmDateFrom			NVARCHAR(10),
						@dOmDateTo				NVARCHAR(10),
						@cMaker				NVARCHAR(30),
						@cVenCode				NVARCHAR(20),
						@cVenName				NVARCHAR(98),
						@cVenAbbName			NVARCHAR(98),
						@DeptCode				NVARCHAR(12),
						@DeptName				NVARCHAR(255),
						@dStartDateFromOm		NVARCHAR(10),
						@dStartDateToOm		NVARCHAR(10),
						@dArriveDateFromOm		NVARCHAR(10),
						@dArriveDateToOm		NVARCHAR(10),
						@cInvCode				NVARCHAR(60),
						@cInvName				NVARCHAR(255),
						@cInvStd				NVARCHAR(255),
						@cInvAddCode			NVARCHAR(255),
						@cBusType              NVARCHAR(8),
						@iOrderType            NVARCHAR(10),
						@cPersonCode			NVARCHAR(20),
						@cPersonName			NVARCHAR(20)';

            EXEC Sp_executesql
              @SqlCommand,
              @ParmList,
              @cOmCodeFrom = @cOmCodeFrom,
              @dOmDateFrom = @dOmDateFrom,
              @dOmDateTo = @dOmDateTo,
              -- @cOmCodeTo = @cOmCodeTo,
              @cMaker = @cMaker,
              @cVenCode = @cVenCode,
              @cVenName = @cVenName,
              @cVenAbbName = @cVenAbbName,
              @DeptCode = @DeptCode,
              @DeptName = @DeptName,
              @dStartDateFromOm = @dStartDateFromOm,
              @dStartDateToOm = @dStartDateToOm,
              @dArriveDateFromOm = @dArriveDateFromOm,
              @dArriveDateToOm = @dArriveDateToOm,
              @cInvCode = @cInvCode,
              @cInvAddCode = @cInvAddCode,
              @cInvName = @cInvName,
              @cInvStd = @cInvStd,
              @iOrderType = @iOrderType,
              @cBusType = @cBusType,
              @cPersonCode = @cPersonCode,
              @cPersonName = @cPersonName;

            SELECT IDENTITY(INT) AS tmpId,
                   MoID
            INTO   #STPDARefOMID
            FROM   #STPDARefOMIDs
            GROUP  BY MoID;

            CREATE CLUSTERED INDEX ix_STPDARefID_tmpid_813
              ON #STPDARefOMID( tmpId, MoID );

            SET NOCOUNT OFF;

            --查询列表（表头）
            SELECT ''                               AS selcol,
                   '委外订单'                           AS csource,
                   ccode,
                   ccode                            AS comcode,
                   CONVERT(VARCHAR(100), ddate, 23) AS ddate,
                   cptcode,
                   cptname,
                   cbustype,
                   cvencode,
                   cvenname,
                   cvenabbname,
                   cdepcode,
                   cdepname,
                   cpersoncode,
                   cpersonname,
                   cmaker,
                   cverifier,
                   cexch_name,
                   nflat,
                   cdefine1,
                   cdefine2,
                   cdefine3,
                   cdefine4,
                   cdefine5,
                   cdefine6,
                   cdefine7,
                   cdefine8,
                   cdefine9,
                   cdefine10,
                   cdefine11,
                   cdefine12,
                   cdefine13,
                   cdefine14,
                   cdefine15,
                   cdefine16,
                   cmemo,
                   idiscounttaxtype,
                   itaxrate,
                   ( om_mohead.moid )               AS moid,
                   ''                               AS coufts,
                   cvenpuomprotocol,
                   cvenpuomprotocolname,
                   iordertype
            FROM   om_mohead WITH ( NOLOCK )
            WHERE  moid IN (SELECT DISTINCT MoID
                            FROM   #STPDARefOMID);

            --查询表体
            IF ( @GetType = N'DETAIL' )
              BEGIN
                  SELECT ccode,
                         cdepcode,
                         cdepname,
                         modetailsid               AS bodyautoid,
                         ''                        AS selcol,
                         cinvcode,
                         cWhCode                   AS cwhcode,
                         cWhName                   AS cwhname,
                         cinvaddcode,
                         cinvname,
                         cinvstd,
                         cinvdefine1,
                         cinvdefine2,
                         cinvdefine3,
                         cinvdefine4,
                         cinvdefine5,
                         cinvdefine6,
                         cinvdefine7,
                         cinvdefine8,
                         cinvdefine9,
                         cinvdefine10,
                         cinvdefine11,
                         cinvdefine12,
                         cinvdefine13,
                         cinvdefine14,
                         cinvdefine15,
                         cinvdefine16,
                         ccomunitcode,
                         cinvm_unit,
                         cunitid,
                         cinva_unit,
                         iinvexchrate,
                         cfree1,
                         cfree2,
                         cfree3,
                         cfree4,
                         cfree5,
                         cfree6,
                         cfree7,
                         cfree8,
                         cfree9,
                         cfree10,
                         citem_class,
                         ( citem_name )            AS citemcname,
                         citemcode,
                         CONVERT(NVARCHAR(60), '') AS cbatch,
                         ( citemname )             AS cname,
                         CONVERT(DATETIME, NULL)   AS dmadedate,
                         dstartdate,
                         imassdate,
                         CONVERT(DATETIME, NULL)   AS dvdate,
                         darrivedate,
                         ''                        AS cinvouchcode,
                         iquantity,--委外订单订购数量
                         inum,--委外订单订购件数
                         ireceivedqty,--委外订单已入库数量
                         ireceivednum,--委外订单已入库件数
                         ( CASE
                             WHEN Isnull(iquantity, 0) >= Isnull(ireceivedqty, 0) THEN Isnull(iquantity, 0) - Isnull(ireceivedqty, 0)
                             ELSE 0
                           END )                   AS inquantity,--委外订单本次剩余可入库数量
                         ( CASE
                             WHEN Isnull(inum, 0) >= Isnull(ireceivednum, 0) THEN Isnull(inum, 0) - Isnull(ireceivednum, 0)
                             ELSE 0
                           END )                   AS innum,--委外订单本次剩余可入库件数
                         modetailsid,
                         ( ufts )                  AS coufts,
                         ( CASE
                             WHEN Isnull(iquantity, 0) >= Isnull(ireceivedqty, 0) THEN Isnull(iquantity, 0) - Isnull(ireceivedqty, 0)
                             ELSE 0
                           END )                   AS fcurqty,--委外订单本次剩余可入库数量
                         ( CASE
                             WHEN Isnull(inum, 0) >= Isnull(ireceivednum, 0) THEN Isnull(inum, 0) - Isnull(ireceivednum, 0)
                             ELSE 0
                           END )                   AS fcurnum,--委外订单本次剩余可入库件数
                         CONVERT(INT, NULL)        AS icorid,
                         igrouptype,
                         CONVERT(INT, NULL)        AS iinvmpcost,
                         -- imoney ,
                         inatsum,
                         inattax,
                         ( om_mobody.moid )        AS moid,
                         sodid,
                         ipertaxrate,
                         isum,
                         itax,
                         itaxprice,
                         iunitprice,
                         cmassunit,
                         CONVERT(NVARCHAR(60), '') AS contractcode,
                         CONVERT(NVARCHAR(60), '') AS contractrowno,
                         ''                        AS bquansign,
                         btaxcost,
                         cdefine22,
                         cdefine23,
                         cdefine24,
                         cdefine25,
                         cdefine26,
                         cdefine27,
                         cdefine28,
                         cdefine29,
                         cdefine30,
                         cdefine31,
                         cdefine32,
                         cdefine33,
                         cdefine34,
                         cdefine35,
                         cdefine36,
                         cdefine37,
                         sotype,
                         sotype                    AS isotype,
                         csocode,
                         irowno,
                         inatunitprice,
                         inatmoney,
                         ivouchrowno,
                         cbmemo,
                         iproducttype,
                         cmaininvcode,
                         imainmodetailsid,
                         isoordertype,
                         csoordercode,
                         iorderseq,
                         iorderdid,
                         cplanlotnumber,
                         ''                        AS cfactorycode,
                         ''                        AS cfactoryname,
                         binvbatch
                  FROM   om_mohead WITH ( NOLOCK )
                         INNER JOIN om_mobody WITH ( NOLOCK )
                                 ON om_mohead.moid = om_mobody.moid
                         LEFT JOIN (SELECT cInvCode                  AS cInvCode1,
                                           binvbatch,
                                           bService,
                                           iId,
                                           Isnull(cDefWareHouse, '') AS cdefwarehouse
                                    FROM   Inventory) Inventory
                                ON om_mobody.cinvcode = Inventory.cInvCode1
                         LEFT JOIN (SELECT cWhCode,
                                           cWhName
                                    FROM   Warehouse WITH ( NOLOCK )) w
                                ON Isnull(w.cWhCode, N'') = Inventory.cdefwarehouse
                  WHERE  om_mohead.moid IN (SELECT DISTINCT MoID
                                            FROM   #STPDARefOMID)
                         AND dbo.om_mobody.modetailsid IN (SELECT DISTINCT MoDetailsID
                                                           FROM   #STPDARefOMIDs);
              END;

            --删除临时表
            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDATempOmCodes') IS NULL)
              DROP TABLE #STPDATempOmCodes;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDARefOMID') IS NULL)
              DROP TABLE #STPDARefOMID;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDARefOMIDs') IS NULL)
              DROP TABLE #STPDARefOMIDs;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDATempOmIDs') IS NULL)
              DROP TABLE #STPDATempOmIDs;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDATempOMDIDs') IS NULL)
              DROP TABLE #STPDATempOMDIDs;
        END;
      ELSE IF ( @OperType = '3' )
        --ST采购入库-参照委外到货单
        BEGIN
            --定义查询参数
            SET @cBusType = '委外加工';

            DECLARE @iBillTypeOmArr TINYINT;

            IF ( @bRed = '0' )
              SET @iBillTypeOmArr = 0;
            ELSE
              SET @iBillTypeOmArr = 1;

            --委外到货单子表ID
            DECLARE @OmArrDIds NVARCHAR(1000);

            BEGIN
                SET @OmArrDIds = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'OmArrDIds', DEFAULT, DEFAULT);

                IF ( @OmArrDIds <> N'' )
                  BEGIN
                      IF EXISTS (SELECT 0
                                 WHERE  NOT Object_id('tempdb..#STPDATempOMArrDIDs') IS NULL)
                        DROP TABLE #STPDATempOMArrDIDs;

                      CREATE TABLE #STPDATempOMArrDIDs
                        (
                           MoDetailsId INT
                        );

                      INSERT INTO #STPDATempOMArrDIDs
                      EXEC Proc_ts_splitparamstring
                        @OmArrDIds;
                  END;
            END;

            --委外到货单单号起始
            DECLARE @cOmArrCodeFrom NVARCHAR(30);

            SET @cOmArrCodeFrom = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cCodeFrom', DEFAULT, DEFAULT);

            IF( @cOmArrCodeFrom <> N'' )
              BEGIN
                  IF EXISTS (SELECT 0
                             WHERE  NOT Object_id('tempdb..#STPDATempOMArrCodes') IS NULL)
                    DROP TABLE #STPDATempOMArrCodes;

                  CREATE TABLE #STPDATempOMArrCodes
                    (
                       comArrCode NVARCHAR(30)
                    );

                  INSERT INTO #STPDATempOMArrCodes
                  EXEC Proc_ts_splitparamstring
                    @cOmArrCodeFrom;
              END;

            --委外到货单单号截至
            DECLARE @cOmArrCodeTo NVARCHAR(30);

            SET @cOmArrCodeTo = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cCodeTo', DEFAULT, DEFAULT);

            IF ( @cOmArrCodeTo = N'' )
              BEGIN
                  SET @cOmArrCodeTo = @cOmArrCodeFrom;
              END;

            --委外到货单日期FROM
            DECLARE @dOmArrDateFrom VARCHAR(10);

            SET @dOmArrDateFrom = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'dDateFrom', DEFAULT, DEFAULT);

            --委外到货单日期TO
            DECLARE @dOmArrDateTo VARCHAR(10);

            SET @dOmArrDateTo = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'dDateTo', DEFAULT, DEFAULT);

            IF ( @dOmArrDateTo = '' )
              SET @dOmArrDateTo = @dOmArrDateFrom;

            --对应的委外订单单号FROM
            DECLARE @dOmCodeFrom VARCHAR(30);

            SET @dOmCodeFrom = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'dOmCodeFrom', DEFAULT, DEFAULT);

            --对应的委外订单单号To
            DECLARE @dOmCodeTo VARCHAR(30);

            SET @dOmCodeTo = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'dOmCodeTo', DEFAULT, DEFAULT);

            IF ( @dOmCodeTo = N'' )
              BEGIN
                  SET @dOmCodeTo = @dOmCodeFrom;
              END;

            --委外到货单主表ID
            DECLARE @OmArrIds NVARCHAR(1000);

            BEGIN
                SET @OmArrIds = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'OmArrIds', DEFAULT, DEFAULT);

                IF ( @OmArrIds <> N'' )
                  BEGIN
                      IF EXISTS (SELECT 0
                                 WHERE  NOT Object_id('tempdb..#STPDATempOmArrIDs') IS NULL)
                        DROP TABLE #STPDATempOmArrIDs;

                      CREATE TABLE #STPDATempOmArrIDs
                        (
                           OmId INT
                        );

                      INSERT INTO #STPDATempOmArrIDs
                      EXEC Proc_ts_splitparamstring
                        @OmArrIds;
                  END;
            END;

            SET NOCOUNT ON;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDARefOMArrIDs') IS NULL)
              DROP TABLE #STPDARefOMArrIDs;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDARefOMArrID') IS NULL)
              DROP TABLE #STPDARefOMArrID;

            SELECT IDENTITY(INT)   AS tmpId,
                   CONVERT(INT, 0) AS id,
                   CONVERT(INT, 0) AS autoid
            INTO   #STPDARefOMArrIDs
            FROM   pu_ArrHead
            WHERE  1 = 0;

            CREATE CLUSTERED INDEX ix_STPDAOmRefIDs_tmpid_813
              ON #STPDARefOMArrIDs( id, autoid, tmpId );

            SET @SqlCommand = 'INSERT INTO #STPDARefOMArrIDs (id,autoid)
SELECT DISTINCT TOP 100 PERCENT pu_ArrHead.id,pu_arrbody.autoid
FROM      pu_ArrHead
INNER JOIN pu_arrbody ON pu_ArrHead.id = pu_arrbody.id
INNER JOIN ( SELECT cInvCode AS cinvcode1,iId FROM Inventory
            ) inventory ON pu_arrbody.cinvcode = inventory.cinvcode1
WHERE     ibilltype=@iBillTypeOmArr AND ISNULL(cbcloser,N'''') = N''''  and (isnull(cbustype,'''')=''委外加工'') 
AND ISNULL(cverifier,'''') <> '''' AND ISNULL(bgsp,N'''') = N''0'' AND 1=1  and (    isnull(iQuantity,0)-isnull(fRefuseQuantity,0)>isnull(fValidInQuan,0) 
	                 or (igrouptype=2 and isnull(inum,0)-isnull(frefusenum,0)>isnull(fvalidinnum,0))
	                )';

            --委外到货单单号
            IF ( @cOmArrCodeFrom <> N'' )
              --SET @SqlCommand = @SqlCommand
              --    + ' AND ((ccode >= @cOmArrCodeFrom) AND (ccode <= @cOmArrCodeTo))';
              SET @SqlCommand = @SqlCommand
                                + ' AND (ccode in (SELECT DISTINCT comArrCode FROM #STPDATempOMArrCodes))';

            --委外到货单日期
            IF ( @dOmArrDateFrom <> N''
                 AND @dOmArrDateTo <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND ((ddate >= @dOmArrDateFrom) AND (ddate <= @dOmArrDateTo)) ';

            IF ( @cBusType <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (ISNULL(cbustype,'''') =@cBusType) ';

            IF ( @cVenCode <> N'' )
              SET @SqlCommand = @SqlCommand + ' AND (cvencode =@cVenCode) ';

            IF ( @cVenName <> N''
                 AND @cVenName <> N'%%' )
              SET @SqlCommand = @SqlCommand
                                + ' AND cvenname LIKE @cVenName ';

            IF ( @cVenAbbName <> N''
                 AND @cVenAbbName <> N'%%' )
              SET @SqlCommand = @SqlCommand
                                + ' AND cvenabbname LIKE @cVenAbbName ';

            IF ( @DeptCode <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cdepcode = @DeptCode) ';

            IF ( @DeptName <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cdepname = @DeptName) ';

            IF ( @cPersonCode <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cpersoncode = @cPersonCode) ';

            IF ( @cPersonName <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cpersonname = @cPersonName) ';

            IF ( @dOmCodeFrom <> N''
                 AND @dOmCodeTo <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND ((cordercode >= @dOmCodeFrom) AND (cordercode <= @dOmCodeTo)) ';

            IF ( @OmArrIds <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (pu_arrhead.id IN ( SELECT DISTINCT OmId FROM #STPDATempOmArrIDs)) ';

            IF ( @OmArrDIds <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (pu_arrbody.autoid IN ( SELECT DISTINCT MoDetailsId FROM #STPDATempOMArrDIDs)) ';

            IF ( @cMaker <> N'' )
              SET @SqlCommand = @SqlCommand + ' AND (cmaker=@cMaker) ';

            IF ( @cInvCode <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cinvcode = @cInvCode) ';

            IF ( @cInvName <> N''
                 AND @cInvName <> N'%%' )
              SET @SqlCommand = @SqlCommand
                                + ' AND cinvname LIKE @cInvName ';

            IF ( @cInvStd <> N''
                 AND @cInvStd <> N'%%' )
              SET @SqlCommand = @SqlCommand + ' AND cinvstd LIKE @cInvStd ';

            IF ( @cInvAddCode <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (cinvaddcode = @cInvAddCode) ';

            IF ( @bRed = N'1' )
              BEGIN
                  SET @SqlCommand = @SqlCommand
                                    + ' AND ISNULL(pu_arrbody.iproducttype,0) = 0 ';

                  IF ( @ShowClosed = N'0' )
                    BEGIN
                        SET @SqlCommand = @SqlCommand
                                          + ' AND (ISNULL(iquantity,0) - ISNULL(frefusequantity,0) > ISNULL(fvalidinquan,0)
        OR ( igrouptype = 2 AND ISNULL(inum,0) - ISNULL(frefusenum,0) > ISNULL(fvalidinnum,0))) ';
                    END;
                  ELSE
                    BEGIN
                        SET @SqlCommand = @SqlCommand
                                          + ' AND (ISNULL(iquantity,0) < 0 OR ISNULL(inum,0) < 0) ';
                    END;
              END;
            ELSE
              BEGIN
                  IF ( @ShowClosed = N'0' )
                    BEGIN
                        SET @SqlCommand = @SqlCommand
                                          + ' AND (ISNULL(iquantity,0) - ISNULL(frefusequantity,0) > ISNULL(fvalidinquan,0)
        OR ( igrouptype = 2 AND ISNULL(inum,0) - ISNULL(frefusenum,0) > ISNULL(fvalidinnum,0))) ';
                    END;
                  ELSE
                    BEGIN
                        SET @SqlCommand = @SqlCommand
                                          + ' AND (ISNULL(iquantity,0) > 0 OR ISNULL(inum,0) > 0) ';
                    END;
              END;

            --PRINT @SqlCommand;
            SET @ParmList = '@iBillTypeOmArr TINYINT,
						@cOmArrCodeFrom			NVARCHAR(30),
						@cOmArrCodeTo				NVARCHAR(30),
						@dOmArrDateFrom			NVARCHAR(10),
						@dOmArrDateTo				NVARCHAR(10),
						@cMaker				NVARCHAR(30),
						@cVenCode				NVARCHAR(20),
						@cVenName				NVARCHAR(98),
						@cVenAbbName			NVARCHAR(98),
						@DeptCode				NVARCHAR(12),
						@DeptName				NVARCHAR(255),
						@dOmCodeFrom			NVARCHAR(30),
						@dOmCodeTo				NVARCHAR(30),
						@cInvCode				NVARCHAR(60),
						@cInvName				NVARCHAR(255),
						@cInvStd				NVARCHAR(255),
						@cInvAddCode			NVARCHAR(255),
						@cBusType              NVARCHAR(8),
						@cPersonCode			NVARCHAR(20),
						@cPersonName			NVARCHAR(20)';

            EXEC Sp_executesql
              @SqlCommand,
              @ParmList,
              @iBillTypeOmArr = @iBillTypeOmArr,
              @cOmArrCodeFrom = @cOmArrCodeFrom,
              @cOmArrCodeTo = @cOmArrCodeTo,
              @dOmArrDateFrom = @dOmArrDateFrom,
              @dOmArrDateTo = @dOmArrDateTo,
              @cMaker = @cMaker,
              @cVenCode = @cVenCode,
              @cVenName = @cVenName,
              @cVenAbbName = @cVenAbbName,
              @DeptCode = @DeptCode,
              @DeptName = @DeptName,
              @dOmCodeFrom = @dOmCodeFrom,
              @dOmCodeTo = @dOmCodeTo,
              @cInvCode = @cInvCode,
              @cInvAddCode = @cInvAddCode,
              @cInvName = @cInvName,
              @cInvStd = @cInvStd,
              @cBusType = @cBusType,
              @cPersonCode = @cPersonCode,
              @cPersonName = @cPersonName;

            PRINT @SqlCommand;

            SELECT IDENTITY(INT) AS tmpId,
                   id
            INTO   #STPDARefOMArrID
            FROM   #STPDARefOMArrIDs
            GROUP  BY id;

            CREATE CLUSTERED INDEX ix_STPDARefID_tmpid_813
              ON #STPDARefOMArrID( tmpId, id );

            SET NOCOUNT OFF;

            --查询列表（表头）
            SELECT ''                               AS selcol,
                   '委外到货单'                          AS csource,
                   ccode,
                   CONVERT(VARCHAR(100), ddate, 23) AS ddate,
                   cptcode,
                   cptname,
                   cbustype,
                   cvencode,
                   cvenname,
                   cvenabbname,
                   cdepcode,
                   cdepname,
                   cpersoncode,
                   cpersonname,
                   cmaker,
                   cexch_name,
                   iexchrate,
                   cdefine1,
                   cdefine2,
                   cdefine3,
                   cdefine4,
                   cdefine5,
                   cdefine6,
                   cdefine7,
                   cdefine8,
                   cdefine9,
                   cdefine10,
                   cdefine11,
                   cdefine12,
                   cdefine13,
                   cdefine14,
                   cdefine15,
                   cdefine16,
                   cmemo,
                   ufts,
                   itaxrate,
                   ''                               AS coufts,
                   id,
                   idiscounttaxtype,
                   cvenpuomprotocol,
                   cvenpuomprotocolname,
                   ( Isnull(iflowid, 0) )           AS iflowid,
                   cflowname
            FROM   pu_ArrHead
            WHERE  id IN (SELECT DISTINCT id
                          FROM   #STPDARefOMArrID);

            --查询表体
            IF ( @GetType = N'DETAIL' )
              BEGIN
                  SELECT pu_ArrHead.ccode,
                         pu_ArrHead.ccode                                           AS cbarvcode,
                         cdepcode,
                         cdepname,
                         autoid                                                     AS bodyautoid,
                         ''                                                         AS selcol,
                         cwhcode,
                         cwhname,
                         cinvcode,
                         cinvaddcode,
                         cinvname,
                         cinvstd,
                         cinvdefine1,
                         cinvdefine2,
                         cinvdefine3,
                         cinvdefine4,
                         cinvdefine5,
                         cinvdefine6,
                         cinvdefine7,
                         cinvdefine8,
                         cinvdefine9,
                         cinvdefine10,
                         cinvdefine11,
                         cinvdefine12,
                         cinvdefine13,
                         cinvdefine14,
                         cinvdefine15,
                         cinvdefine16,
                         ccomunitcode,
                         cinvm_unit,
                         cunitid,
                         cinva_unit,
                         iinvexchrate,
                         cfree1,
                         cfree2,
                         cfree3,
                         cfree4,
                         cfree5,
                         cfree6,
                         cfree7,
                         cfree8,
                         cfree9,
                         cfree10,
                         cbatch,
                         binvbatch,
                         ( dpdate )                                                 AS dmadedate,
                         imassdate,
                         dvdate,
                         citem_class,
                         ( citem_name )                                             AS citemcname,
                         ''                                                         AS cinvouchcode,
                         citemcode,
                         ( citemname )                                              AS cname,
                         Abs(( Isnull(iquantity, 0) - Isnull(frefusequantity, 0) )) AS iquantity,
                         Abs(( Isnull(inum, 0) - Isnull(frefusenum, 0) ))           AS inum,
                         Abs(fvalidinquan),
                         Abs(fvalidinquan)                                          AS ireceivedqty,
                         Abs(fvalidinnum),
                         ( CASE
                             WHEN Abs(Isnull(iquantity, 0) - Isnull(frefusequantity, 0)) > Abs(Isnull(fvalidinquan, 0)) THEN Abs(Isnull(iquantity, 0) - Isnull(frefusequantity, 0) - Isnull(fvalidinquan, 0))
                             ELSE 0
                           END )                                                    AS inquantity,
                         ( CASE
                             WHEN Abs(Isnull(inum, 0) - Isnull(frefusenum, 0)) > Abs(Isnull(fvalidinnum, 0)) THEN Abs(Isnull(inum, 0) - Isnull(frefusenum, 0) - Isnull(fvalidinnum, 0))
                           END )                                                    AS innum,
                         autoid,
                         ( cordercode )                                             AS cpoid,
                         iposid,
                         ( CASE
                             WHEN Abs(Isnull(iquantity, 0) - Isnull(frefusequantity, 0)) > Abs(Isnull(fvalidinquan, 0)) THEN Abs(Isnull(iquantity, 0) - Isnull(frefusequantity, 0) - Isnull(fvalidinquan, 0))
                             ELSE 0
                           END )                                                    AS fcurqty,
                         ( CASE
                             WHEN Abs(Isnull(inum, 0) - Isnull(frefusenum, 0)) > Abs(Isnull(fvalidinnum, 0)) THEN Abs(Isnull(inum, 0) - Isnull(frefusenum, 0) - Isnull(fvalidinnum, 0))
                             ELSE 0
                           END )                                                    AS fcurnum,
                         frefusenum,
                         frefusequantity,
                         cmassunit,
                         ( CONVERT(INT, NULL) )                                     AS icorid,
                         contractcode,
                         contractrowno,
                         igrouptype,
                         iinvmpcost,
                         pu_arrbody.id,
                         ioricost                                                   AS iunitprice,
                         ioricost,
                         iorimoney,
                         iorisum,
                         ioritaxcost,
                         ioritaxprice,
                         pu_arrbody.itaxrate                                        AS ipertaxrate,
                         isum,
                         itaxprice,
                         sodid,
                         ''                                                         AS bquansign,
                         btaxcost,
                         cdefine22,
                         cdefine23,
                         cdefine24,
                         cdefine25,
                         cdefine26,
                         cdefine27,
                         cdefine28,
                         cdefine29,
                         cdefine30,
                         cdefine31,
                         cdefine32,
                         cdefine33,
                         cdefine34,
                         cdefine35,
                         cdefine36,
                         cdefine37,
                         sotype,
                         sotype                                                     AS isotype,
                         csocode,
                         irowno,
                         csoordercode,
                         iorderdid,
                         iorderseq,
                         iordertype,
                         iexpiratdatecalcu,
                         cexpirationdate,
                         dexpirationdate,
                         cbatchproperty1,
                         cbatchproperty2,
                         cbatchproperty3,
                         cbatchproperty4,
                         cbatchproperty5,
                         cbatchproperty6,
                         cbatchproperty7,
                         cbatchproperty8,
                         cbatchproperty9,
                         cbatchproperty10,
                         ivouchrowno,
                         CONVERT(NVARCHAR(10), '')                                  AS cinvouchtype,
                         ( CONVERT(NVARCHAR(60), '') )                              AS cvmivencode,
                         ( CONVERT(NVARCHAR(60), '') )                              AS cvmivenname,
                         icost,
                         -- imoney ,
                         cbmemo,
                         iproducttype,
                         cmaininvcode,
                         imainmodetailsid,
                         planlotnumber,
                         bgift,
                         ''                                                         AS cfactorycode,
                         ''                                                         AS cfactoryname
                  FROM   pu_ArrHead
                         INNER JOIN pu_arrbody
                                 ON pu_ArrHead.id = pu_arrbody.id
                                    AND pu_arrbody.bgsp = 0
                         INNER JOIN (SELECT cInvCode AS cinvcode1,
                                            iId
                                     FROM   Inventory) inventory
                                 ON pu_arrbody.cinvcode = inventory.cinvcode1
                  WHERE  1 = 1
                         AND pu_ArrHead.id IN (SELECT DISTINCT id
                                               FROM   #STPDARefOMArrID)
                         AND dbo.pu_arrbody.autoid IN (SELECT DISTINCT autoid
                                                       FROM   #STPDARefOMArrIDs);
              END;

            --删除临时表
            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDATempOMArrCodes') IS NULL)
              DROP TABLE #STPDATempOMArrCodes;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDARefOMArrID') IS NULL)
              DROP TABLE #STPDARefOMArrID;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDARefOMArrIDs') IS NULL)
              DROP TABLE #STPDARefOMArrIDs;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDATempOmArrIDs') IS NULL)
              DROP TABLE #STPDATempOmArrIDs;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDATempOMArrDIDs') IS NULL)
              DROP TABLE #STPDATempOMArrDIDs;
        END;
      ELSE IF ( @OperType = N'4'
            OR @OperType = N'5' )
        --参照来料检验单/来料不良品处理单
        BEGIN
            SET NOCOUNT ON;

            --来料检验单主表ID/来料不良品处理单主表ID
            DECLARE @CheckVoucherIds NVARCHAR(1000);

            BEGIN
                SET @CheckVoucherIds = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'Ids', DEFAULT, DEFAULT);

                IF ( @CheckVoucherIds <> N'' )
                  BEGIN
                      IF EXISTS (SELECT 0
                                 WHERE  NOT Object_id('tempdb..#STPDATempCheckVouchIDs') IS NULL)
                        DROP TABLE #STPDATempCheckVouchIDs;

                      CREATE TABLE #STPDATempCheckVouchIDs
                        (
                           CHECKID INT
                        );

                      INSERT INTO #STPDATempCheckVouchIDs
                      EXEC Proc_ts_splitparamstring
                        @CheckVoucherIds;
                  END;
            END;

            --来料不良品处理单单号起始
            DECLARE @cRejectCodeFrom NVARCHAR(30);

            SET @cRejectCodeFrom = N'';

            --来料不良品处理单单号截至
            DECLARE @cRejectCodeTo NVARCHAR(30);

            SET @cRejectCodeTo = N'';

            --来料检验单检验日期起始
            DECLARE @dCheckVoucherDateFrom NVARCHAR(20);

            SET @dCheckVoucherDateFrom = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'dDateFrom', DEFAULT, DEFAULT);

            --来料检验单检验日期截至
            DECLARE @dCheckVoucherDateTo NVARCHAR(20);

            SET @dCheckVoucherDateTo = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'dDateTo', DEFAULT, DEFAULT);

            IF ( @dCheckVoucherDateTo = N'' )
              BEGIN
                  SET @dCheckVoucherDateTo = @dCheckVoucherDateFrom;
              END;

            --检验单单号起始
            DECLARE @cCheckCodeFrom NVARCHAR(max);

            SET @cCheckCodeFrom = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cCodeFrom', DEFAULT, DEFAULT);

            IF( @cCheckCodeFrom <> N'' )
              BEGIN
                  IF EXISTS (SELECT 0
                             WHERE  NOT Object_id('tempdb..#STPDATempPUCheckCodes') IS NULL)
                    DROP TABLE #STPDATempPUCheckCodes;

                  CREATE TABLE #STPDATempPUCheckCodes
                    (
                       CheckCode NVARCHAR(30)
                    );

                  INSERT INTO #STPDATempPUCheckCodes
                  EXEC Proc_ts_splitparamstring
                    @cCheckCodeFrom;
              END;

            --检验单单号截至
            DECLARE @cCheckCodeTo NVARCHAR(30);

            SET @cCheckCodeTo = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cCodeTo', DEFAULT, DEFAULT);

            IF ( @cCheckCodeTo = N'' )
              BEGIN
                  SET @cCheckCodeTo = @cCheckCodeFrom;
              END;

            --检验员编码
            DECLARE @cCheckPersonCode NVARCHAR(30);

            SET @cCheckPersonCode = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cCheckPersonCode', DEFAULT, DEFAULT);

            --检验员名称
            DECLARE @cCheckPersonName NVARCHAR(30);

            SET @cCheckPersonName = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cCheckPersonName', DEFAULT, DEFAULT);

            --来料检验单-对应的到货日期起始
            DECLARE @dCheckVoucherArrDateFrom NVARCHAR(20);

            SET @dCheckVoucherArrDateFrom = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'dArrDateFrom', DEFAULT, DEFAULT);

            --来料检验单-对应的到货日期截至
            DECLARE @dCheckVoucherArrDateTo NVARCHAR(20);

            SET @dCheckVoucherArrDateTo = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'dArrDateTo', DEFAULT, DEFAULT);

            IF ( @dCheckVoucherArrDateTo = N'' )
              BEGIN
                  SET @dCheckVoucherArrDateTo = @dCheckVoucherArrDateFrom;
              END;

            --检验单对应到货单单号起始
            DECLARE @cCheckArrCodeFrom NVARCHAR(MAX);

            SET @cCheckArrCodeFrom = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cArrCodeFrom', DEFAULT, DEFAULT);

            IF( @cCheckArrCodeFrom <> N'' )
              BEGIN
                  IF EXISTS (SELECT 0
                             WHERE  NOT Object_id('tempdb..#STPDATempCheckArrCodes') IS NULL)
                    DROP TABLE #STPDATempCheckArrCodes;

                  CREATE TABLE #STPDATempCheckArrCodes
                    (
                       carrCode NVARCHAR(30)
                    );

                  INSERT INTO #STPDATempCheckArrCodes
                  EXEC Proc_ts_splitparamstring
                    @cCheckArrCodeFrom;
              END;

            --检验单对应到货单单号截至
            DECLARE @cCheckArrCodeTo NVARCHAR(30);

            SET @cCheckArrCodeTo = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cArrCodeTo', DEFAULT, DEFAULT);

            IF ( @cCheckArrCodeTo = N'' )
              BEGIN
                  SET @cCheckArrCodeTo = @cCheckArrCodeFrom;
              END;

            DECLARE @cCheckBusType NVARCHAR(30);

            SET @cCheckBusType = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cBusType', DEFAULT, DEFAULT);

            --来料检验单对应采购订单单号起始
            DECLARE @cCheckVoucherPoCodeFrom NVARCHAR(MAX);

            SET @cCheckVoucherPoCodeFrom = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cPoCodeFrom', DEFAULT, DEFAULT);

            IF( @cCheckVoucherPoCodeFrom <> N'' )
              BEGIN
                  IF EXISTS (SELECT 0
                             WHERE  NOT Object_id('tempdb..#STPDATempCheckPoCodes') IS NULL)
                    DROP TABLE #STPDATempCheckPoCodes;

                  CREATE TABLE #STPDATempCheckPoCodes
                    (
                       cPoCode NVARCHAR(30)
                    );

                  INSERT INTO #STPDATempCheckPoCodes
                  EXEC Proc_ts_splitparamstring
                    @cCheckVoucherPoCodeFrom;
              END;

            --来料检验单对应采购订单单号截至
            DECLARE @cCheckVoucherPoCodeTo NVARCHAR(20);

            SET @cCheckVoucherPoCodeTo = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cPoCodeTo', DEFAULT, DEFAULT);

            IF ( @cCheckVoucherPoCodeTo = N'' )
              BEGIN
                  SET @cCheckVoucherPoCodeTo = @cCheckVoucherPoCodeFrom;
              END;

            IF ( @OperType = N'4' )--参照来料检验单
              BEGIN
                  IF EXISTS (SELECT 0
                             WHERE  NOT Object_id('tempdb..#STPDAPURCHASEINRefCheckIDs') IS NULL)
                    DROP TABLE #STPDAPURCHASEINRefCheckIDs;

                  SELECT TOP 1 ID AS M_ID
                  INTO   #STPDAPURCHASEINRefCheckIDs
                  FROM   QMCHECKVOUCHER
                  WHERE  1 = 0;

                  SET @SqlCommand = 'INSERT INTO #STPDAPURCHASEINRefCheckIDs (M_ID) 
                            SELECT B.ID FROM (SELECT DISTINCT A.ID FROM QMCHECKVOUCHER A 
							INNER JOIN PU_ArrivalVouchs B ON A.SOURCEAUTOID = B.Autoid
							WHERE A.CVOUCHTYPE = N''qm03'' AND ISNULL(A.CVERIFIER,N'''') <> N''''
							AND (ISNULL(A.FREGQUANTITY,0)+ ISNULL(A.FCONQUANTIY,0)) > 0
							AND ISNULL(B.cbcloser,'''') = '''' AND ISNULL(A.BMERGECHECKFLAG,0) = 0
							UNION
							SELECT DISTINCT A.ID FROM QMCHECKVOUCHER A 
							INNER JOIN QMMergeCheckDetail B ON ISNULL(A.BMERGECHECKFLAG,0) = 1
                            AND A.ID = B.ID INNER JOIN PU_ArrivalVouchs C ON B.SOURCEAUTOID = C.Autoid
							WHERE A.CVOUCHTYPE = N''qm03'' AND ISNULL(A.CVERIFIER,N'''') <> N''''
							AND (ISNULL(B.FREGQUANTITY,0)+ISNULL(B.FCONQUANTIY,0) ) > 0
                            AND ISNULL(C.cbcloser,'''') = '''') B INNER JOIN QMCHECKVOUCHER A ON B.ID=A.ID
							WHERE 1=1 ';

                  IF ( @ShowClosed = N'0' )
                    BEGIN
                        SET @SqlCommand = @SqlCommand
                                          + ' AND ISNULL(A.BPUINFLAG,0)=0 ';
                    END;
              END;
            ELSE--参照来料不良品处理单
              BEGIN
                  SET @cRejectCodeFrom = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cRejectCodeFrom', DEFAULT, DEFAULT);
                  SET @cRejectCodeTo = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cRejectCodeTo', DEFAULT, DEFAULT);

                  IF ( @cRejectCodeTo = N'' )
                    BEGIN
                        SET @cRejectCodeTo = @cRejectCodeFrom;
                    END;

                  IF EXISTS (SELECT 0
                             WHERE  NOT Object_id('tempdb..#STPDAPURCHASEINRefCheckIDs1') IS NULL)
                    DROP TABLE #STPDAPURCHASEINRefCheckIDs1;

                  SELECT IDENTITY(INT)   AS tmpId,
                         CONVERT(INT, 0) AS M_ID,
                         CONVERT(INT, 0) AS S_ID
                  INTO   #STPDAPURCHASEINRefCheckIDs1
                  FROM   QMREJECTVOUCHER
                  WHERE  1 = 0;

                  SET @SqlCommand = 'INSERT INTO #STPDAPURCHASEINRefCheckIDs1
									( M_ID,S_ID ) 
									SELECT DISTINCT A.ID,B.AutoID FROM QMREJECTVOUCHER A INNER JOIN QMREJECTVOUCHERS B ON A.ID=B.ID 
									WHERE CVOUCHTYPE = N''QM05'' AND 1=1 ';

                  IF ( @cRejectCodeFrom <> N''
                       AND @cRejectCodeTo <> N'' )
                    SET @SqlCommand = @SqlCommand
                                      + ' AND (( A.CREJECTCODE >= @cRejectCodeFrom ) AND ( A.CREJECTCODE <= @cRejectCodeTo ))';
              END;

            IF ( @dCheckVoucherDateFrom <> N''
                 AND @dCheckVoucherDateTo <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (( A.DDATE >= @dCheckVoucherDateFrom ) AND (A.DDATE <= @dCheckVoucherDateTo ))';

            IF ( @cCheckCodeFrom <> N''
                 AND @cCheckCodeTo <> N'' )
              --SET @SqlCommand = @SqlCommand
              --    + ' AND (( A.CCHECKCODE >= @cCheckCodeFrom ) AND ( A.CCHECKCODE <= @cCheckCodeTo ))';
              SET @SqlCommand=@SqlCommand
                              + ' AND A.CCHECKCODE in (select checkcode from #STPDATempPUCheckCodes)';

            IF ( @cCheckPersonCode <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (A.CCHECKPERSONCODE = @cCheckPersonCode)';

            IF ( @cCheckPersonName <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (A.ccheckpersonname = @cCheckPersonName)';

            IF ( @dCheckVoucherArrDateFrom <> N''
                 AND @dCheckVoucherArrDateTo <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (( A.DARRIVALDATE >= @dCheckVoucherArrDateFrom ) AND (A.DARRIVALDATE <= @dCheckVoucherArrDateTo ))';

            IF ( @cCheckArrCodeFrom <> N''
                 AND @cCheckArrCodeTo <> N'' )
              --SET @SqlCommand = @SqlCommand
              --    + ' AND (( A.SOURCECODE >= @cCheckArrCodeFrom ) AND ( A.SOURCECODE <= @cCheckArrCodeTo ))';
              SET @SqlCommand = @SqlCommand
                                + ' AND (A.SOURCECODE  in (SELECT DISTINCT carrCode FROM #STPDATempCheckArrCodes))';

            IF ( @cCheckVoucherPoCodeFrom <> N''
                 AND @cCheckVoucherPoCodeTo <> N'' )
              --SET @SqlCommand = @SqlCommand
              --    + ' AND (( A.CPOCODE >= @cCheckVoucherPoCodeFrom ) AND ( A.CPOCODE <= @cCheckVoucherPoCodeTo ))';
              SET @SqlCommand = @SqlCommand
                                + ' AND (A.CPOCODE in (SELECT DISTINCT cPoCode FROM #STPDATempCheckPoCodes))';

            --IF ( @cCheckBusType <> N'' )
            --    SET @SqlCommand = @SqlCommand
            --        + ' AND (ISNULL(A.cbustype,'''') =@cCheckBusType) ';
            IF ( @cVenCode <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (A.cvencode =@cVenCode) ';

            IF ( @cInvCode <> N''
                 AND @cInvCode <> N'%%' )
              SET @SqlCommand = @SqlCommand
                                + ' AND A.cInvCode = @cInvCode ';

            --IF ( @cVenName <> N''
            --     AND @cVenName <> N'%%'
            --   )
            --    SET @SqlCommand = @SqlCommand
            --        + ' AND A.cvenname LIKE @cVenName ';
            --IF ( @cVenAbbName <> N''
            --     AND @cVenAbbName <> N'%%'
            --   )
            --    SET @SqlCommand = @SqlCommand
            --        + ' AND cvenabbname LIKE @cVenAbbName ';
            IF ( @DeptCode <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (A.cinspectdepcode = @DeptCode) ';

            --IF ( @DeptName <> N'' )
            --    SET @SqlCommand = @SqlCommand
            --        + ' AND (A.cinspectdepname = @DeptName) ';
            --IF ( @cPersonCode <> N'' )
            --    SET @SqlCommand = @SqlCommand
            --        + ' AND (A.cpersoncode = @cPersonCode) ';
            --IF ( @cPersonName <> N'' )
            --    SET @SqlCommand = @SqlCommand
            --        + ' AND (A.cpersonname = @cPersonName) ';
            IF ( @cMaker <> N'' )
              SET @SqlCommand = @SqlCommand + ' AND (A.CMAKER = @cMaker)';

            IF ( @CheckVoucherIds <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND A.ID IN (SELECT DISTINCT CHECKID FROM #STPDATempCheckVouchIDs)';

            SET @ParmList = '@cRejectCodeFrom		NVARCHAR(30),
							@cRejectCodeTo				NVARCHAR(30),
							@dCheckVoucherDateFrom		NVARCHAR(20),
							@dCheckVoucherDateTo		NVARCHAR(20),
							@cCheckCodeFrom			NVARCHAR(30),
							@cCheckCodeTo				NVARCHAR(30),
							@cCheckPersonCode			NVARCHAR(60),
							@cCheckPersonName			NVARCHAR(255),
							@dCheckVoucherArrDateFrom	NVARCHAR(20),
							@dCheckVoucherArrDateTo	NVARCHAR(20),
							@cCheckArrCodeFrom			NVARCHAR(30),
							@cCheckArrCodeTo			NVARCHAR(30),
							@cCheckBusType				NVARCHAR(30),
							@cCheckVoucherPoCodeFrom	NVARCHAR(30),
							@cCheckVoucherPoCodeTo		NVARCHAR(30),
							@DeptCode					NVARCHAR(12),
							@cMaker					NVARCHAR(30),
							@cInvCode					NVARCHAR(30),
							@cVenCode					NVARCHAR(20)';

            EXEC Sp_executesql
              @SqlCommand,
              @ParmList,
              @cRejectCodeFrom = @cRejectCodeFrom,
              @cRejectCodeTo = @cRejectCodeTo,
              @dCheckVoucherDateFrom = @dCheckVoucherDateFrom,
              @dCheckVoucherDateTo = @dCheckVoucherDateTo,
              @cCheckCodeFrom = @cCheckCodeFrom,
              @cCheckCodeTo = @cCheckCodeTo,
              @cMaker = @cMaker,
              @dCheckVoucherArrDateFrom = @dCheckVoucherArrDateFrom,
              @dCheckVoucherArrDateTo = @dCheckVoucherArrDateTo,
              @cCheckArrCodeFrom = @cCheckArrCodeFrom,
              @cCheckArrCodeTo = @cCheckArrCodeTo,
              @cCheckBusType = @cCheckBusType,
              @cCheckVoucherPoCodeFrom = @cCheckVoucherPoCodeFrom,
              @cCheckVoucherPoCodeTo = @cCheckVoucherPoCodeTo,
              @DeptCode = @DeptCode,
              --@DeptName = @DeptName,
              @cInvCode=@cInvCode,
              @cVenCode = @cVenCode,
              --@cVenName = @cVenName,
              @cCheckPersonCode = @cCheckPersonCode,
              @cCheckPersonName = @cCheckPersonName;

            --@cPersonCode=@cPersonCode,
            --@cPersonName=@cPersonName;	   
            SET NOCOUNT OFF;

            --查询列表（表头）
            IF ( @OperType = N'4' )
              BEGIN
                  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

                  SELECT DISTINCT ID                               AS bodyautoid,
                                  ''                               AS selcol,
                                  '来料检验单'                          AS csource,
                                  cptcode,
                                  CONVERT(VARCHAR(100), DDATE, 23) AS ddate,
                                  DDATE                            AS dCheckDate,
                                  ccheckpersonname,
                                  CCHECKCODE                       AS ccheckcode,
                                  CCHECKPERSONCODE                 AS ccheckpersoncode,
                                  DARRIVALDATE                     AS darrivaldate,
                                  DARRIVALDATE                     AS dbarvdate,
                                  SOURCECODE                       AS sourcecode,
                                  cPTName                          AS cptname,
                                  cbustype,
                                  QMList.cvencode,
                                  QMList.cvenname,
                                  V.cVenAbbName                    AS cvenabbname,
                                  cinspectdepcode,
                                  cinspectdepname,
                                  cpersoncode,
                                  cPersonName                      AS cpersonname,
                                  BEXIGENCY                        AS bexigency,
                                  CDEFINE1                         AS cdefine1,
                                  CDEFINE2                         AS cdefine2,
                                  CDEFINE3                         AS cdefine3,
                                  CDEFINE4                         AS cdefine4,
                                  CDEFINE5                         AS cdefine5,
                                  CDEFINE6                         AS cdefine6,
                                  CDEFINE7                         AS cdefine7,
                                  CDEFINE8                         AS cdefine8,
                                  CDEFINE9                         AS cdefine9,
                                  CDEFINE10                        AS cdefine10,
                                  CDEFINE11                        AS cdefine11,
                                  CDEFINE12                        AS cdefine12,
                                  CDEFINE13                        AS cdefine13,
                                  CDEFINE14                        AS cdefine14,
                                  CDEFINE15                        AS cdefine15,
                                  CDEFINE16                        AS cdefine16,
                                  QMList.cMemo                     AS cmemo,
                                  cwhcode,
                                  cWhName                          AS cwhname,
                                  bWhPos                           AS bwhpos,
                                  cRdCode                          AS crdcode,
                                  cRdName                          AS crdname,
                                  cInvAddCode                      AS cinvaddcode,
                                  CINVCODE                         AS cinvcode,
                                  cInvName                         AS cinvname,
                                  cInvStd                          AS cinvstd,
                                  CBATCH                           AS cbatch,
                                  DPRODATE                         AS dprodate,
                                  DVDATE                           AS dvdate,
                                  imassdate,
                                  cComUnitCode                     AS ccomunitcode,
                                  cComUnitName                     AS ccomunitname,
                                  cComUnitName                     AS cinvm_unit,
                                  CUNITID                          AS cunitid,
                                  cunitname,
                                  cunitname                        AS cinva_unit,
                                  FSUMQUANTITY                     AS ireceivedqty,
                                  iquantity,
                                  fquantity,
                                  fquantity                        AS inquantity,
                                  fnum,
                                  fnum                             AS innum,
                                  fchangrate,
                                  fcost,
                                  iunitcost,
                                  iCost,
                                  iOriTaxCost,
                                  iOriCost,
                                  fmoney,
                                  CITEMCLASS                       AS citemclass,
                                  CITEMCNAME                       AS citemcname,
                                  CITEMCODE                        AS citemcode,
                                  CITEMNAME                        AS citemname,
                                  finvrcost,
                                  finvrmoney,
                                  ID                               AS id,
                                  cDefine22                        AS cdefine22,
                                  cDefine23                        AS cdefine23,
                                  cDefine24                        AS cdefine24,
                                  cDefine25                        AS cdefine25,
                                  cDefine26                        AS cdefine26,
                                  cDefine27                        AS cdefine27,
                                  cDefine28                        AS cdefine28,
                                  cDefine29                        AS cdefine29,
                                  cDefine30                        AS cdefine30,
                                  cDefine31                        AS cdefine31,
                                  cDefine32                        AS cdefine32,
                                  cDefine33                        AS cdefine33,
                                  cDefine34                        AS cdefine34,
                                  cDefine35                        AS cdefine35,
                                  cDefine36                        AS cdefine36,
                                  cDefine37                        AS cdefine37,
                                  CFREE1                           AS cfree1,
                                  CFREE2                           AS cfree2,
                                  CFREE3                           AS cfree3,
                                  CFREE4                           AS cfree4,
                                  CFREE5                           AS cfree5,
                                  CFREE6                           AS cfree6,
                                  CFREE7                           AS cfree7,
                                  CFREE8                           AS cfree8,
                                  CFREE9                           AS cfree9,
                                  CFREE10                          AS cfree10,
                                  cInvDefine1                      AS cinvdefine1,
                                  cInvDefine2                      AS cinvdefine2,
                                  cInvDefine3                      AS cinvdefine3,
                                  cInvDefine4                      AS cinvdefine4,
                                  cInvDefine5                      AS cinvdefine5,
                                  cInvDefine6                      AS cinvdefine6,
                                  cInvDefine7                      AS cinvdefine7,
                                  cInvDefine8                      AS cinvdefine8,
                                  cInvDefine9                      AS cinvdefine9,
                                  cInvDefine10                     AS cinvdefine10,
                                  cInvDefine11                     AS cinvdefine11,
                                  cInvDefine12                     AS cinvdefine12,
                                  cInvDefine13                     AS cinvdefine13,
                                  cInvDefine14                     AS cinvdefine14,
                                  cInvDefine15                     AS cinvdefine15,
                                  cInvDefine16                     AS cinvdefine16,
                                  bfree1,
                                  bfree2,
                                  bfree3,
                                  bfree4,
                                  bfree5,
                                  bfree6,
                                  bfree7,
                                  bfree8,
                                  bfree9,
                                  bfree10,
                                  cGroupCode                       AS cgroupcode,
                                  iGroupType                       AS igrouptype,
                                  bservice,
                                  binvbatch,
                                  ufts,
                                  SOURCEAUTOID                     AS sourceautoid,
                                  cexch_name,
                                  iDiscountTaxType                 AS idiscounttaxtype,
                                  IORDERDID                        AS iorderdid,
                                  IORDERSEQ                        AS iorderseq,
                                  csocode                          AS csocode,
                                  ISOORDERTYPE                     AS isoordertype,
                                  CORDERCODE                       AS cordercode,
                                  ( CASE
                                      WHEN IORDERTYPE <> 0 THEN CORDERCODE
                                      ELSE ''
                                    END )                          AS iordercode,
                                  cciqbookcode,
                                  iExpiratDateCalcu                AS iexpiratdatecalcu,
                                  cExpirationdate                  AS cexpirationdate,
                                  dExpirationdate                  AS dexpirationdate,
                                  QMList.cVenPUOMProtocol          AS cvenpuomprotocol,
                                  cvenpuomprotocolname             AS cvenpuomprotocolname,
                                  cBatchProperty1                  AS cbatchproperty1,
                                  cBatchProperty2                  AS cbatchproperty2,
                                  cBatchProperty3                  AS cbatchproperty3,
                                  cBatchProperty4                  AS cbatchproperty4,
                                  cBatchProperty5                  AS cbatchproperty5,
                                  cBatchProperty6                  AS cbatchproperty6,
                                  cBatchProperty7                  AS cbatchproperty7,
                                  cBatchProperty8                  AS cbatchproperty8,
                                  cBatchProperty9                  AS cbatchproperty9,
                                  cBatchProperty10                 AS cbatchproperty10,
                                  iflowid,
                                  cflowname,
                                  ivouchrowno,
                                  cbMemo                           AS cbmemo,
                                  dkey,
                                  CPOCODE                          AS cpocode,
                                  ISOURCEMOCODE                    AS isourcemocode,
                                  ''                               AS cfactorycode,
                                  ''                               AS cfactoryname,
                                  0.0                              AS iscanedquantity,
                                  0.0                              AS iscanednum,
                                  CITEMCLASS                       citem_class,
                                  CITEMCNAME                       AS citemcname,
                                  CITEMCODE                        AS citemcode,
                                  CITEMNAME                        AS citemname,
                                  ( CASE
                                      WHEN cbustype <> '委外加工' THEN iPOsID
                                      ELSE NULL
                                    END )                          AS iposid,
                                  BMERGECHECKFLAG                  AS bmergecheckflag,
                                  ( CASE
                                      WHEN cbustype = '委外加工' THEN iPOsID
                                      ELSE NULL
                                    END )                          AS iOMoDID,
                                  itaxrate,
                                  IORDERTYPE,
                                  isotype,
                                  isodid
                  FROM   (SELECT *
                          FROM   (SELECT *,
                                         Isnull(BPUINFLAG, 0) AS bAllInput
                                  FROM   (SELECT FSUMQUANTITY,
                                                 FQUANTITY                                             AS iquantity,
                                                 Cast(QMCHECKVOUCHER.ID AS VARCHAR) + 'D'
                                                 + '-1'                                                AS dkey,
                                                 QMCHECKVOUCHER.BPUINFLAG                              AS BPUINFLAG,
                                                 N''                                                   AS selcol,
                                                 QMCHECKVOUCHER.DDATE,
                                                 CCHECKCODE,
                                                 CCHECKPERSONCODE,
                                                 Person.cPersonName                                    AS ccheckpersonname,
                                                 DARRIVALDATE,
                                                 SOURCECODE,
                                                 Isnull(PU_ArrivalVouch.cPTCode, '')                   AS cptcode,
                                                 cPTName,
                                                 Isnull(cBusType, '')                                  AS cbustype,
                                                 Isnull(QMCHECKVOUCHER.CVENCODE, '')                   AS cvencode,
                                                 Isnull(PU_ArrivalVouch.cexch_name, '')                AS cexch_name,
                                                 PU_ArrivalVouch.iDiscountTaxType,
                                                 PU_ArrivalVouch.iExchRate,
                                                 Vendor.iId                                            AS vendoriid,
                                                 Vendor.cVenName                                       AS cvenname,
                                                 Isnull(CINSPECTDEPCODE, '')                           AS cinspectdepcode,
                                                 Department.cDepName                                   AS cinspectdepname,
                                                 Isnull(PU_ArrivalVouch.cPersonCode, '')               AS cpersoncode,
                                                 person1.cPersonName,
                                                 PU_ArrivalVouch.cMemo,
                                                 QMCHECKVOUCHER.CDEFINE1,
                                                 QMCHECKVOUCHER.CDEFINE2,
                                                 QMCHECKVOUCHER.CDEFINE3,
                                                 QMCHECKVOUCHER.CDEFINE4,
                                                 QMCHECKVOUCHER.CDEFINE5,
                                                 QMCHECKVOUCHER.CDEFINE6,
                                                 QMCHECKVOUCHER.CDEFINE7,
                                                 QMCHECKVOUCHER.CDEFINE8,
                                                 QMCHECKVOUCHER.CDEFINE9,
                                                 QMCHECKVOUCHER.CDEFINE10,
                                                 QMCHECKVOUCHER.CDEFINE11,
                                                 QMCHECKVOUCHER.CDEFINE12,
                                                 QMCHECKVOUCHER.CDEFINE13,
                                                 QMCHECKVOUCHER.CDEFINE14,
                                                 QMCHECKVOUCHER.CDEFINE15,
                                                 QMCHECKVOUCHER.CDEFINE16,
                                                 Isnull(QMCHECKVOUCHER.CWHCODE, '')                    AS cwhcode,
                                                 cWhName,
                                                 bWhPos,
                                                 PurchaseType.cRdCode,
                                                 cRdName,
                                                 QMCHECKVOUCHER.CINVCODE,
                                                 Inventory.cInvAddCode,
                                                 Inventory.cInvName,
                                                 Inventory.cInvStd,
                                                 cInvDefine1,
                                                 cInvDefine2,
                                                 cInvDefine3,
                                                 cInvDefine4,
                                                 cInvDefine5,
                                                 cInvDefine6,
                                                 cInvDefine7,
                                                 cInvDefine8,
                                                 cInvDefine9,
                                                 cInvDefine10,
                                                 cInvDefine11,
                                                 cInvDefine12,
                                                 cInvDefine13,
                                                 cInvDefine14,
                                                 cInvDefine15,
                                                 cInvDefine16,
                                                 QMCHECKVOUCHER.CFREE1,
                                                 QMCHECKVOUCHER.CFREE2,
                                                 QMCHECKVOUCHER.CFREE3,
                                                 QMCHECKVOUCHER.CFREE4,
                                                 QMCHECKVOUCHER.CFREE5,
                                                 QMCHECKVOUCHER.CFREE6,
                                                 QMCHECKVOUCHER.CFREE7,
                                                 QMCHECKVOUCHER.CFREE8,
                                                 QMCHECKVOUCHER.CFREE9,
                                                 QMCHECKVOUCHER.CFREE10,
                                                 PU_ArrivalVouchs.ivouchrowno,
                                                 QMCHECKVOUCHER.CBATCH,
                                                 DPRODATE,
                                                 PU_ArrivalVouchs.imassdate,
                                                 QMCHECKVOUCHER.DVDATE,
                                                 QMCHECKVOUCHER.iExpiratDateCalcu,
                                                 QMCHECKVOUCHER.cExpirationdate,
                                                 QMCHECKVOUCHER.dExpirationdate,
                                                 ComputationUnit.cComUnitName,
                                                 computationunit1.cComUnitName                         AS cunitname,
                                                 CASE Isnull(BPUINFLAG, 0)
                                                   WHEN 0 THEN ( CASE Isnull(Inventory.iGroupType, 0)
                                                                   WHEN 0 THEN 0
                                                                   WHEN 1 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                                   WHEN 1 THEN ( Isnull(FREGQUANTITY, 0)
                                                                                                 + Isnull(FCONQUANTIY, 0) - Isnull(FsumQuantity, 0) ) / computationunit1.iChangRate
                                                                                   ELSE ( Isnull(FREGQUANTITY, 0)
                                                                                          + Isnull(FCONQUANTIY, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) - Isnull(FsumQuantity, 0) ) / computationunit1.iChangRate
                                                                                 END )
                                                                   WHEN 2 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                                   WHEN 1 THEN ( Isnull(FCHECKNUM, 0) - Isnull(FsumNum, 0) )
                                                                                   ELSE ( Isnull(FCHECKNUM, 0) - Isnull(FsumNum, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) / FCHECKCHANGRATE )
                                                                                 END )
                                                                 END )
                                                   ELSE 0
                                                 END                                                   AS fnum,
                                                 iCost,
                                                 iCost                                                 AS fcost,
                                                 iCost                                                 AS iunitcost,
                                                 iOriTaxCost,
                                                 iOriCost,
                                                 iInvRCost                                             AS finvrcost,
                                                 CASE Isnull(BPUINFLAG, 0)
                                                   WHEN 0 THEN ( CASE Isnull(Inventory.iGroupType, 0)
                                                                   WHEN 0 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                                   WHEN 1 THEN ( Isnull(FREGQUANTITY, 0)
                                                                                                 + Isnull(FCONQUANTIY, 0) - Isnull(FsumQuantity, 0) )
                                                                                   ELSE ( Isnull(FREGQUANTITY, 0)
                                                                                          + Isnull(FCONQUANTIY, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) - Isnull(FsumQuantity, 0) )
                                                                                 END )
                                                                   WHEN 1 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                                   WHEN 1 THEN ( Isnull(FREGQUANTITY, 0)
                                                                                                 + Isnull(FCONQUANTIY, 0) - Isnull(FsumQuantity, 0) )
                                                                                   ELSE ( Isnull(FREGQUANTITY, 0)
                                                                                          + Isnull(FCONQUANTIY, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) - Isnull(FsumQuantity, 0) )
                                                                                 END )
                                                                   WHEN 2 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                                   WHEN 1 THEN ( Isnull(FCHECKQTY, 0) - Isnull(FsumQuantity, 0) )
                                                                                   ELSE ( Isnull(FCHECKQTY, 0) - Isnull(FsumQuantity, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) )
                                                                                 END )
                                                                 END )
                                                   ELSE 0
                                                 END                                                   AS fquantity,
                                                 CASE Isnull(BPUINFLAG, 0)
                                                   WHEN 0 THEN ( CASE Isnull(Inventory.iGroupType, 0)
                                                                   WHEN 0 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                                   WHEN 1 THEN ( Isnull(FREGQUANTITY, 0)
                                                                                                 + Isnull(FCONQUANTIY, 0) - Isnull(FsumQuantity, 0) )
                                                                                   ELSE ( Isnull(FREGQUANTITY, 0)
                                                                                          + Isnull(FCONQUANTIY, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) - Isnull(FsumQuantity, 0) )
                                                                                 END )
                                                                   WHEN 1 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                                   WHEN 1 THEN ( Isnull(FREGQUANTITY, 0)
                                                                                                 + Isnull(FCONQUANTIY, 0) - Isnull(FsumQuantity, 0) )
                                                                                   ELSE ( Isnull(FREGQUANTITY, 0)
                                                                                          + Isnull(FCONQUANTIY, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) - Isnull(FsumQuantity, 0) )
                                                                                 END )
                                                                   WHEN 2 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                                   WHEN 1 THEN ( Isnull(FCHECKQTY, 0) - Isnull(FsumQuantity, 0) )
                                                                                   ELSE ( Isnull(FCHECKQTY, 0) - Isnull(FsumQuantity, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) )
                                                                                 END )
                                                                 END * iCost )
                                                   ELSE 0
                                                 END                                                   AS fmoney,
                                                 ( CASE Isnull(Inventory.iGroupType, 0)
                                                     WHEN 0 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                     WHEN 1 THEN ( Isnull(FREGQUANTITY, 0)
                                                                                   + Isnull(FCONQUANTIY, 0) - Isnull(FsumQuantity, 0) )
                                                                     ELSE ( Isnull(FREGQUANTITY, 0)
                                                                            + Isnull(FCONQUANTIY, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) - Isnull(FsumQuantity, 0) )
                                                                   END )
                                                     WHEN 1 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                     WHEN 1 THEN ( Isnull(FREGQUANTITY, 0)
                                                                                   + Isnull(FCONQUANTIY, 0) - Isnull(FsumQuantity, 0) )
                                                                     ELSE ( Isnull(FREGQUANTITY, 0)
                                                                            + Isnull(FCONQUANTIY, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) - Isnull(FsumQuantity, 0) )
                                                                   END )
                                                     WHEN 2 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                     WHEN 1 THEN ( Isnull(FCHECKQTY, 0) - Isnull(FsumQuantity, 0) )
                                                                     ELSE ( Isnull(FCHECKQTY, 0) - Isnull(FsumQuantity, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) )
                                                                   END )
                                                   END * iInvRCost )                                   AS finvrmoney,
                                                 PU_ArrivalVouchs.cDefine22,
                                                 PU_ArrivalVouchs.cDefine23,
                                                 PU_ArrivalVouchs.cDefine24,
                                                 PU_ArrivalVouchs.cDefine25,
                                                 PU_ArrivalVouchs.cDefine26,
                                                 PU_ArrivalVouchs.cDefine27,
                                                 PU_ArrivalVouchs.cDefine28,
                                                 PU_ArrivalVouchs.cDefine29,
                                                 PU_ArrivalVouchs.cDefine30,
                                                 PU_ArrivalVouchs.cDefine31,
                                                 PU_ArrivalVouchs.cDefine32,
                                                 PU_ArrivalVouchs.cDefine33,
                                                 PU_ArrivalVouchs.cDefine34,
                                                 PU_ArrivalVouchs.cDefine35,
                                                 PU_ArrivalVouchs.cDefine36,
                                                 PU_ArrivalVouchs.cDefine37,
                                                 PU_ArrivalVouchs.iPOsID,
                                                 QMCHECKVOUCHER.ID,
                                                 SOURCEAUTOID,
                                                 Inventory.cComUnitCode,
                                                 -1                                                    AS autoid,
                                                 QMCHECKVOUCHER.CUNITID,
                                                 CITEMCLASS,
                                                 CITEMCNAME,
                                                 QMCHECKVOUCHER.CITEMCODE,
                                                 QMCHECKVOUCHER.CITEMNAME,
                                                 --( CASE WHEN bFree1 = 1 THEN N'是' ELSE N'否' END ) AS bfree1 ,
                                                 --( CASE WHEN bFree2 = 1 THEN N'是' ELSE N'否' END ) AS bfree2 ,
                                                 --( CASE WHEN bFree3 = 1 THEN N'是' ELSE N'否' END ) AS bfree3 ,
                                                 --( CASE WHEN bFree4 = 1 THEN N'是' ELSE N'否' END ) AS bfree4 ,
                                                 --( CASE WHEN bFree5 = 1 THEN N'是' ELSE N'否' END ) AS bfree5 ,
                                                 --( CASE WHEN bFree6 = 1 THEN N'是' ELSE N'否' END ) AS bfree6 ,
                                                 --( CASE WHEN bFree7 = 1 THEN N'是' ELSE N'否' END ) AS bfree7 ,
                                                 --( CASE WHEN bFree8 = 1 THEN N'是' ELSE N'否' END ) AS bfree8 ,
                                                 --( CASE WHEN bFree9 = 1 THEN N'是' ELSE N'否' END ) AS bfree9 ,
                                                 --( CASE WHEN bFree10 = 1 THEN N'是' ELSE N'否'END ) AS bfree10 ,
                                                 bFree1                                                AS bfree1,
                                                 bFree2                                                AS bfree2,
                                                 bFree3                                                AS bfree3,
                                                 bFree4                                                AS bfree4,
                                                 bFree5                                                AS bfree5,
                                                 bFree6                                                AS bfree6,
                                                 bFree7                                                AS bfree7,
                                                 bFree8                                                AS bfree8,
                                                 bFree9                                                AS bfree9,
                                                 bFree10                                               AS bfree10,
                                                 Inventory.cGroupCode,
                                                 iGroupType,
                                                 --( CASE WHEN bService = 1 THEN N'是' ELSE N'否' END ) AS bservice ,
                                                 --( CASE WHEN bInvBatch = 1 THEN N'是' ELSE N'否' END ) AS binvbatch ,
                                                 bService                                              AS bservice,
                                                 bInvBatch                                             AS binvbatch,
                                                 CONVERT(CHAR, CONVERT(MONEY, QMCHECKVOUCHER.UFTS), 2) AS ufts,
                                                 ( CASE PU_ArrivalVouchs.cmassunit
                                                     WHEN 1 THEN N'年'
                                                     WHEN 2 THEN N'月'
                                                     WHEN 3 THEN N'日'
                                                     ELSE N''
                                                   END )                                               AS cmassunit,
                                                 -- QMCHECKVOUCHER.IORDERTYPE ,
                                                 PU_ArrivalVouchs.iordertype,
                                                 PU_ArrivalVouchs.SoType                               AS isotype,
                                                 QMCHECKVOUCHER.CSOORDERCODE                           AS csocode,
                                                 PU_ArrivalVouchs.irowno                               AS isoseq,
                                                 --QMCHECKVOUCHER.ISOORDERAUTOID AS iSoDID ,
                                                 PU_ArrivalVouchs.SoDId                                AS isodid,
                                                 PU_ArrivalVouchs.IORDERDID,
                                                 QMCHECKVOUCHER.ISOORDERTYPE,
                                                 QMCHECKVOUCHER.CORDERCODE,
                                                 PU_ArrivalVouchs.IORDERSEQ,
                                                 QMCHECKVOUCHER.cBatchProperty1,
                                                 QMCHECKVOUCHER.cBatchProperty2,
                                                 QMCHECKVOUCHER.cBatchProperty3,
                                                 QMCHECKVOUCHER.cBatchProperty4,
                                                 QMCHECKVOUCHER.cBatchProperty5,
                                                 QMCHECKVOUCHER.cBatchProperty6,
                                                 QMCHECKVOUCHER.cBatchProperty7,
                                                 QMCHECKVOUCHER.cBatchProperty8,
                                                 QMCHECKVOUCHER.cBatchProperty9,
                                                 QMCHECKVOUCHER.cBatchProperty10,
                                                 Inventory.iId,
                                                 QMCHECKVOUCHER.CCONTRACTSTRCODE,
                                                 QMCHECKVOUCHER.CCONTRACTCODE,
                                                 CASE Isnull(Inventory.iGroupType, 0)
                                                   WHEN 0 THEN NULL
                                                   WHEN 1 THEN computationunit1.iChangRate
                                                   WHEN 2 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                   WHEN 1 THEN
                                                                     CASE ( Isnull(FCHECKNUM, 0) - Isnull(FsumNum, 0) )
                                                                       WHEN 0 THEN NULL
                                                                       ELSE ( Isnull(FCHECKQTY, 0) - Isnull(FsumQuantity, 0) ) / ( Isnull(FCHECKNUM, 0) - Isnull(FsumNum, 0) )
                                                                     END
                                                                   ELSE
                                                                     CASE ( Isnull(FCHECKNUM, 0) - Isnull(FsumNum, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) / FCHECKCHANGRATE )
                                                                       WHEN 0 THEN NULL
                                                                       ELSE ( Isnull(FCHECKQTY, 0) - Isnull(FsumQuantity, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) ) / ( Isnull(FCHECKNUM, 0) - Isnull(FsumNum, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) / FCHECKCHANGRATE )
                                                                     END
                                                                 END )
                                                 END                                                   AS fchangrate,
                                                 Isnull(QMCHECKVOUCHER.BEXIGENCY, 0)                   AS BEXIGENCY,
                                                 PU_ArrivalVouch.cVenPUOMProtocol,
                                                 AA_Agreement.cName                                    AS cvenpuomprotocolname,
                                                 PU_ArrivalVouchs.cciqbookcode,
                                                 Isnull(PU_ArrivalVouch.iflowid, 0)                    AS iflowid,
                                                 PUBizFlow.cFlowName                                   AS cflowname,
                                                 QMCHECKVOUCHER.FSAMPQTY,
                                                 QMCHECKVOUCHER.FSAMPQTYINS,
                                                 PU_ArrivalVouchs.cbMemo,
                                                 PU_ArrivalVouchs.bgift,
                                                 QMCHECKVOUCHER.CSYSBARCODE,
                                                 QMCHECKVOUCHER.FREGQUANTITY,
                                                 QMCHECKVOUCHER.FREGNUM,
                                                 PU_ArrivalVouch.csysbarcode                           AS carrsysbarcode,
                                                 PU_ArrivalVouchs.cbsysbarcode                         AS carrbsysbarcode,
                                                 QMCHECKVOUCHER.CSOURCEPROORDERCODE                    AS ISOURCEMOCODE,
                                                 QMCHECKVOUCHER.ISOURCEPROORDERAUTOID                  AS ISOURCEMODETAILSID,
                                                 QMCHECKVOUCHER.CPOCODE,
                                                 Isnull(PU_ArrivalVouchs.iInvMPCost, 0)                AS impcost,
                                                 ''                                                    AS cfactorycode,--PU_ArrivalVouchs.cFactoryCode ,
                                                 ''                                                    AS cfactoryname,--Factory.cFactoryName ,
                                                 QMCHECKVOUCHER.BMERGECHECKFLAG,
                                                 PU_ArrivalVouchs.itaxrate
                                          FROM   QMCHECKVOUCHER WITH ( NOLOCK )
                                                 INNER JOIN Inventory
                                                         ON QMCHECKVOUCHER.CINVCODE = Inventory.cInvCode
                                                 INNER JOIN PU_ArrivalVouchs
                                                         ON QMCHECKVOUCHER.SOURCEAUTOID = PU_ArrivalVouchs.Autoid
                                                 INNER JOIN PU_ArrivalVouch
                                                         ON PU_ArrivalVouchs.ID = PU_ArrivalVouch.ID
                                                 LEFT JOIN PUBizFlow
                                                        ON PUBizFlow.iFlowID = PU_ArrivalVouch.iflowid
                                                 LEFT JOIN Person
                                                        ON QMCHECKVOUCHER.CCHECKPERSONCODE = Person.cPersonCode
                                                 LEFT JOIN PurchaseType
                                                        ON PU_ArrivalVouch.cPTCode = PurchaseType.cPTCode
                                                 LEFT JOIN Vendor
                                                        ON QMCHECKVOUCHER.CVENCODE = Vendor.cVenCode
                                                 LEFT JOIN Department
                                                        ON QMCHECKVOUCHER.CINSPECTDEPCODE = Department.cDepCode
                                                 LEFT JOIN Person AS person1
                                                        ON PU_ArrivalVouch.cPersonCode = person1.cPersonCode
                                                 LEFT JOIN Warehouse
                                                        ON QMCHECKVOUCHER.CWHCODE = Warehouse.cWhCode
                                                 LEFT JOIN Rd_Style
                                                        ON PurchaseType.cRdCode = Rd_Style.cRdCode
                                                 LEFT JOIN ComputationUnit
                                                        ON Inventory.cComUnitCode = ComputationUnit.cComunitCode
                                                 LEFT JOIN ComputationUnit AS computationunit1
                                                        ON QMCHECKVOUCHER.CUNITID = computationunit1.cComunitCode
                                                 LEFT JOIN AA_Agreement
                                                        ON PU_ArrivalVouch.cVenPUOMProtocol = AA_Agreement.cCode
                                          --LEFT JOIN Factory ON Factory.cFactoryCode = PU_ArrivalVouchs.cFactoryCode
                                          WHERE  Isnull(QMCHECKVOUCHER.CVERIFIER, N'') <> N''
                                                 AND QMCHECKVOUCHER.CVOUCHTYPE = N'qm03'
                                                 AND ( Isnull(FREGQUANTITY, 0)
                                                       + Isnull(FCONQUANTIY, 0) ) > 0
                                                 AND Isnull(PU_ArrivalVouchs.cbcloser, '') = ''
                                                 AND Isnull(QMCHECKVOUCHER.BMERGECHECKFLAG, 0) = 0
                                          UNION
                                          SELECT QMCHECKVOUCHER.FSUMQUANTITY,
                                                 QMCHECKVOUCHER.fquantity                              AS iquantity,
                                                 Cast(QMCHECKVOUCHER.ID AS VARCHAR) + 'D'
                                                 + Cast(QMMergeCheckDetail.AUTOID AS VARCHAR)          AS dkey,
                                                 QMMergeCheckDetail.BPUINFLAG                          AS BPUINFLAG,
                                                 N''                                                   AS selcol,
                                                 QMCHECKVOUCHER.DDATE,
                                                 QMCHECKVOUCHER.CCHECKCODE,
                                                 QMCHECKVOUCHER.CCHECKPERSONCODE,
                                                 Person.cPersonName                                    AS ccheckpersonname,
                                                 QMMergeCheckDetail.DARRIVALDATE,
                                                 QMMergeCheckDetail.SOURCECODE,
                                                 Isnull(PU_ArrivalVouch.cPTCode, '')                   AS cptcode,
                                                 cPTName,
                                                 Isnull(cBusType, '')                                  AS cbustype,
                                                 Isnull(QMCHECKVOUCHER.CVENCODE, '')                   AS cvencode,
                                                 Isnull(PU_ArrivalVouch.cexch_name, '')                AS cexch_name,
                                                 PU_ArrivalVouch.iDiscountTaxType,
                                                 PU_ArrivalVouch.iExchRate,
                                                 Vendor.iId                                            AS vendoriid,
                                                 Vendor.cVenName                                       AS cvenname,
                                                 Isnull(QMMergeCheckDetail.CINSPECTDEPCODE, '')        AS cinspectdepcode,
                                                 Department.cDepName                                   AS cinspectdepname,
                                                 Isnull(PU_ArrivalVouch.cPersonCode, '')               AS cpersoncode,
                                                 person1.cPersonName,
                                                 PU_ArrivalVouch.cMemo,
                                                 QMCHECKVOUCHER.CDEFINE1,
                                                 QMCHECKVOUCHER.CDEFINE2,
                                                 QMCHECKVOUCHER.CDEFINE3,
                                                 QMCHECKVOUCHER.CDEFINE4,
                                                 QMCHECKVOUCHER.CDEFINE5,
                                                 QMCHECKVOUCHER.CDEFINE6,
                                                 QMCHECKVOUCHER.CDEFINE7,
                                                 QMCHECKVOUCHER.CDEFINE8,
                                                 QMCHECKVOUCHER.CDEFINE9,
                                                 QMCHECKVOUCHER.CDEFINE10,
                                                 QMCHECKVOUCHER.CDEFINE11,
                                                 QMCHECKVOUCHER.CDEFINE12,
                                                 QMCHECKVOUCHER.CDEFINE13,
                                                 QMCHECKVOUCHER.CDEFINE14,
                                                 QMCHECKVOUCHER.CDEFINE15,
                                                 QMCHECKVOUCHER.CDEFINE16,
                                                 Isnull(QMMergeCheckDetail.CWHCODE, '')                AS cwhcode,
                                                 cWhName,
                                                 bWhPos,
                                                 PurchaseType.cRdCode,
                                                 cRdName,
                                                 QMCHECKVOUCHER.CINVCODE,
                                                 Inventory.cInvAddCode,
                                                 Inventory.cInvName,
                                                 Inventory.cInvStd,
                                                 cInvDefine1,
                                                 cInvDefine2,
                                                 cInvDefine3,
                                                 cInvDefine4,
                                                 cInvDefine5,
                                                 cInvDefine6,
                                                 cInvDefine7,
                                                 cInvDefine8,
                                                 cInvDefine9,
                                                 cInvDefine10,
                                                 cInvDefine11,
                                                 cInvDefine12,
                                                 cInvDefine13,
                                                 cInvDefine14,
                                                 cInvDefine15,
                                                 cInvDefine16,
                                                 QMMergeCheckDetail.CFREE1,
                                                 QMMergeCheckDetail.CFREE2,
                                                 QMMergeCheckDetail.CFREE3,
                                                 QMMergeCheckDetail.CFREE4,
                                                 QMMergeCheckDetail.CFREE5,
                                                 QMMergeCheckDetail.CFREE6,
                                                 QMMergeCheckDetail.CFREE7,
                                                 QMMergeCheckDetail.CFREE8,
                                                 QMMergeCheckDetail.CFREE9,
                                                 QMMergeCheckDetail.CFREE10,
                                                 PU_ArrivalVouchs.ivouchrowno,
                                                 QMCHECKVOUCHER.CBATCH,
                                                 QMCHECKVOUCHER.DPRODATE,
                                                 PU_ArrivalVouchs.imassdate,
                                                 QMCHECKVOUCHER.DVDATE,
                                                 QMCHECKVOUCHER.iExpiratDateCalcu,
                                                 QMCHECKVOUCHER.cExpirationdate,
                                                 QMCHECKVOUCHER.dExpirationdate,
                                                 ComputationUnit.cComUnitName,
                                                 computationunit1.cComUnitName                         AS cunitname,
                                                 CASE Isnull(QMMergeCheckDetail.BPUINFLAG, 0)
                                                   WHEN 0 THEN ( CASE Isnull(Inventory.iGroupType, 0)
                                                                   WHEN 0 THEN 0
                                                                   WHEN 1 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                                   WHEN 1 THEN ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                                 + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) ) / computationunit1.iChangRate
                                                                                   ELSE ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                          + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) ) / computationunit1.iChangRate
                                                                                 END )
                                                                   WHEN 2 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                                   WHEN 1 THEN ( Isnull(QMMergeCheckDetail.FCHECKNUM, 0) - Isnull(QMMergeCheckDetail.FSUMNUM, 0) )
                                                                                   ELSE ( Isnull(QMMergeCheckDetail.FCHECKNUM, 0) - Isnull(QMMergeCheckDetail.FSUMNUM, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) / QMCHECKVOUCHER.FCHECKCHANGRATE )
                                                                                 END )
                                                                 END )
                                                   ELSE 0
                                                 END                                                   AS fnum,
                                                 iCost,
                                                 iCost                                                 AS fcost,
                                                 iCost                                                 AS iunitcost,
                                                 iOriTaxCost,
                                                 iOriCost,
                                                 iInvRCost                                             AS finvrcost,
                                                 CASE Isnull(QMMergeCheckDetail.BPUINFLAG, 0)
                                                   WHEN 0 THEN ( CASE Isnull(Inventory.iGroupType, 0)
                                                                   WHEN 0 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                                   WHEN 1 THEN ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                                 + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                                   ELSE ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                          + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                                 END )
                                                                   WHEN 1 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                                   WHEN 1 THEN ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                                 + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                                   ELSE ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                          + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                                 END )
                                                                   WHEN 2 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                                   WHEN 1 THEN ( Isnull(QMMergeCheckDetail.FCHECKQTY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                                   ELSE ( Isnull(QMMergeCheckDetail.FCHECKQTY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) )
                                                                                 END )
                                                                 END )
                                                   ELSE 0
                                                 END                                                   AS fquantity,
                                                 CASE Isnull(QMMergeCheckDetail.BPUINFLAG, 0)
                                                   WHEN 0 THEN ( CASE Isnull(Inventory.iGroupType, 0)
                                                                   WHEN 0 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                                   WHEN 1 THEN ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                                 + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                                   ELSE ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                          + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                                 END )
                                                                   WHEN 1 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                                   WHEN 1 THEN ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                                 + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                                   ELSE ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                          + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                                 END )
                                                                   WHEN 2 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                                   WHEN 1 THEN ( Isnull(QMMergeCheckDetail.FCHECKQTY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                                   ELSE ( Isnull(QMMergeCheckDetail.FCHECKQTY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) )
                                                                                 END )
                                                                 END * iCost )
                                                   ELSE 0
                                                 END                                                   AS fmoney,
                                                 ( CASE Isnull(Inventory.iGroupType, 0)
                                                     WHEN 0 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                     WHEN 1 THEN ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                   + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                     ELSE ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                            + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                   END )
                                                     WHEN 1 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                     WHEN 1 THEN ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                   + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                     ELSE ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                            + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                   END )
                                                     WHEN 2 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                     WHEN 1 THEN ( Isnull(QMMergeCheckDetail.FCHECKQTY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                     ELSE ( Isnull(QMMergeCheckDetail.FCHECKQTY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) )
                                                                   END )
                                                   END * iInvRCost )                                   AS finvrmoney,
                                                 PU_ArrivalVouchs.cDefine22,
                                                 PU_ArrivalVouchs.cDefine23,
                                                 PU_ArrivalVouchs.cDefine24,
                                                 PU_ArrivalVouchs.cDefine25,
                                                 PU_ArrivalVouchs.cDefine26,
                                                 PU_ArrivalVouchs.cDefine27,
                                                 PU_ArrivalVouchs.cDefine28,
                                                 PU_ArrivalVouchs.cDefine29,
                                                 PU_ArrivalVouchs.cDefine30,
                                                 PU_ArrivalVouchs.cDefine31,
                                                 PU_ArrivalVouchs.cDefine32,
                                                 PU_ArrivalVouchs.cDefine33,
                                                 PU_ArrivalVouchs.cDefine34,
                                                 PU_ArrivalVouchs.cDefine35,
                                                 PU_ArrivalVouchs.cDefine36,
                                                 PU_ArrivalVouchs.cDefine37,
                                                 PU_ArrivalVouchs.iPOsID,
                                                 QMCHECKVOUCHER.ID,
                                                 QMMergeCheckDetail.SOURCEAUTOID,
                                                 Inventory.cComUnitCode,
                                                 QMMergeCheckDetail.AUTOID                             AS autoid,
                                                 QMCHECKVOUCHER.CUNITID,
                                                 QMMergeCheckDetail.CITEMCLASS,
                                                 QMMergeCheckDetail.CITEMCNAME,
                                                 QMMergeCheckDetail.CITEMCODE,
                                                 QMMergeCheckDetail.CITEMNAME,
                                                 --( CASE WHEN bFree1 = 1 THEN N'是' ELSE N'否' END ) AS bfree1 ,
                                                 --( CASE WHEN bFree2 = 1 THEN N'是' ELSE N'否' END ) AS bfree2 ,
                                                 --( CASE WHEN bFree3 = 1 THEN N'是' ELSE N'否' END ) AS bfree3 ,
                                                 --( CASE WHEN bFree4 = 1 THEN N'是' ELSE N'否' END ) AS bfree4 ,
                                                 --( CASE WHEN bFree5 = 1 THEN N'是' ELSE N'否' END ) AS bfree5 ,
                                                 --( CASE WHEN bFree6 = 1 THEN N'是' ELSE N'否' END ) AS bfree6 ,
                                                 --( CASE WHEN bFree7 = 1 THEN N'是' ELSE N'否' END ) AS bfree7 ,
                                                 --( CASE WHEN bFree8 = 1 THEN N'是' ELSE N'否' END ) AS bfree8 ,
                                                 --( CASE WHEN bFree9 = 1 THEN N'是' ELSE N'否' END ) AS bfree9 ,
                                                 --( CASE WHEN bFree10 = 1 THEN N'是' ELSE N'否' END ) AS bfree10 ,
                                                 bFree1                                                AS bfree1,
                                                 bFree2                                                AS bfree2,
                                                 bFree3                                                AS bfree3,
                                                 bFree4                                                AS bfree4,
                                                 bFree5                                                AS bfree5,
                                                 bFree6                                                AS bfree6,
                                                 bFree7                                                AS bfree7,
                                                 bFree8                                                AS bfree8,
                                                 bFree9                                                AS bfree9,
                                                 bFree10                                               AS bfree10,
                                                 Inventory.cGroupCode,
                                                 iGroupType,
                                                 --( CASE WHEN bService = 1 THEN N'是' ELSE N'否' END ) AS bservice ,
                                                 --( CASE WHEN bInvBatch = 1 THEN N'是' ELSE N'否' END ) AS binvbatch ,
                                                 bService                                              AS bservice,
                                                 bInvBatch                                             AS binvbatch,
                                                 CONVERT(CHAR, CONVERT(MONEY, QMCHECKVOUCHER.UFTS), 2) AS ufts,
                                                 ( CASE PU_ArrivalVouchs.cmassunit
                                                     WHEN 1 THEN N'年'
                                                     WHEN 2 THEN N'月'
                                                     WHEN 3 THEN N'日'
                                                     ELSE N''
                                                   END )                                               AS cmassunit,
                                                 -- QMMergeCheckDetail.IORDERTYPE ,
                                                 PU_ArrivalVouchs.iordertype,
                                                 PU_ArrivalVouchs.SoType                               AS isotype,
                                                 QMMergeCheckDetail.CSOORDERCODE                       AS csocode,
                                                 PU_ArrivalVouchs.irowno                               AS isoseq,
                                                 -- QMMergeCheckDetail.ISOORDERAUTOID AS iSoDID ,
                                                 PU_ArrivalVouchs.SoDId                                AS isodid,
                                                 PU_ArrivalVouchs.IORDERDID,
                                                 QMMergeCheckDetail.ISOORDERTYPE,
                                                 QMCHECKVOUCHER.CORDERCODE,
                                                 PU_ArrivalVouchs.IORDERSEQ,
                                                 QMCHECKVOUCHER.cBatchProperty1,
                                                 QMCHECKVOUCHER.cBatchProperty2,
                                                 QMCHECKVOUCHER.cBatchProperty3,
                                                 QMCHECKVOUCHER.cBatchProperty4,
                                                 QMCHECKVOUCHER.cBatchProperty5,
                                                 QMCHECKVOUCHER.cBatchProperty6,
                                                 QMCHECKVOUCHER.cBatchProperty7,
                                                 QMCHECKVOUCHER.cBatchProperty8,
                                                 QMCHECKVOUCHER.cBatchProperty9,
                                                 QMCHECKVOUCHER.cBatchProperty10,
                                                 Inventory.iId,
                                                 QMCHECKVOUCHER.CCONTRACTSTRCODE,
                                                 QMCHECKVOUCHER.CCONTRACTCODE,
                                                 CASE Isnull(Inventory.iGroupType, 0)
                                                   WHEN 0 THEN NULL
                                                   WHEN 1 THEN computationunit1.iChangRate
                                                   WHEN 2 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                   WHEN 1 THEN
                                                                     CASE ( Isnull(QMMergeCheckDetail.FCHECKNUM, 0) - Isnull(QMMergeCheckDetail.FSUMNUM, 0) )
                                                                       WHEN 0 THEN NULL
                                                                       ELSE ( Isnull(QMMergeCheckDetail.FCHECKQTY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) ) / ( Isnull(QMMergeCheckDetail.FCHECKNUM, 0) - Isnull(QMMergeCheckDetail.FSUMNUM, 0) )
                                                                     END
                                                                   ELSE
                                                                     CASE ( Isnull(QMMergeCheckDetail.FCHECKNUM, 0) - Isnull(QMMergeCheckDetail.FSUMNUM, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) / QMCHECKVOUCHER.FCHECKCHANGRATE )
                                                                       WHEN 0 THEN NULL
                                                                       ELSE ( Isnull(QMMergeCheckDetail.FCHECKQTY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) ) / ( Isnull(QMMergeCheckDetail.FCHECKNUM, 0) - Isnull(QMMergeCheckDetail.FSUMNUM, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) / QMCHECKVOUCHER.FCHECKCHANGRATE )
                                                                     END
                                                                 END )
                                                 END                                                   AS fchangrate,
                                                 Isnull(QMCHECKVOUCHER.BEXIGENCY, 0)                   AS BEXIGENCY,
                                                 PU_ArrivalVouch.cVenPUOMProtocol,
                                                 AA_Agreement.cName                                    AS cvenpuomprotocolname,
                                                 PU_ArrivalVouchs.cciqbookcode,
                                                 Isnull(PU_ArrivalVouch.iflowid, 0)                    AS iflowid,
                                                 PUBizFlow.cFlowName                                   AS cflowname,
                                                 QMCHECKVOUCHER.FSAMPQTY,
                                                 QMCHECKVOUCHER.FSAMPQTYINS,
                                                 PU_ArrivalVouchs.cbMemo,
                                                 PU_ArrivalVouchs.bgift,
                                                 QMCHECKVOUCHER.CSYSBARCODE,
                                                 QMMergeCheckDetail.FREGQUANTITY,
                                                 QMMergeCheckDetail.FREGNUM,
                                                 PU_ArrivalVouch.csysbarcode                           AS carrsysbarcode,
                                                 PU_ArrivalVouchs.cbsysbarcode                         AS carrbsysbarcode,
                                                 QMMergeCheckDetail.CSOURCEPROORDERCODE                AS ISOURCEMOCODE,
                                                 QMMergeCheckDetail.ISOURCEPROORDERAUTOID              AS ISOURCEMODETAILSID,
                                                 QMMergeCheckDetail.CPOCODE,
                                                 Isnull(PU_ArrivalVouchs.iInvMPCost, 0)                AS impcost,
                                                 ''                                                    AS cfactorycode,--PU_ArrivalVouchs.cFactoryCode ,
                                                 ''                                                    AS cfactoryname,--Factory.cFactoryName ,
                                                 QMCHECKVOUCHER.BMERGECHECKFLAG,
                                                 PU_ArrivalVouchs.itaxrate
                                          FROM   QMCHECKVOUCHER WITH ( NOLOCK )
                                                 INNER JOIN QMMergeCheckDetail
                                                         ON Isnull(QMCHECKVOUCHER.BMERGECHECKFLAG, 0) = 1
                                                            AND QMCHECKVOUCHER.ID = QMMergeCheckDetail.ID
                                                 INNER JOIN Inventory
                                                         ON QMCHECKVOUCHER.CINVCODE = Inventory.cInvCode
                                                 INNER JOIN PU_ArrivalVouchs
                                                         ON QMMergeCheckDetail.SOURCEAUTOID = PU_ArrivalVouchs.Autoid
                                                 INNER JOIN PU_ArrivalVouch
                                                         ON PU_ArrivalVouchs.ID = PU_ArrivalVouch.ID
                                                 LEFT JOIN PUBizFlow
                                                        ON PUBizFlow.iFlowID = PU_ArrivalVouch.iflowid
                                                 LEFT JOIN Person
                                                        ON QMCHECKVOUCHER.CCHECKPERSONCODE = Person.cPersonCode
                                                 LEFT JOIN PurchaseType
                                                        ON PU_ArrivalVouch.cPTCode = PurchaseType.cPTCode
                                                 LEFT JOIN Vendor
                                                        ON QMCHECKVOUCHER.CVENCODE = Vendor.cVenCode
                                                 LEFT JOIN Department
                                                        ON QMMergeCheckDetail.CINSPECTDEPCODE = Department.cDepCode
                                                 LEFT JOIN Person AS person1
                                                        ON PU_ArrivalVouch.cPersonCode = person1.cPersonCode
                                                 LEFT JOIN Warehouse
                                                        ON QMMergeCheckDetail.CWHCODE = Warehouse.cWhCode
                                                 LEFT JOIN Rd_Style
                                                        ON PurchaseType.cRdCode = Rd_Style.cRdCode
                                                 LEFT JOIN ComputationUnit
                                                        ON Inventory.cComUnitCode = ComputationUnit.cComunitCode
                                                 LEFT JOIN ComputationUnit AS computationunit1
                                                        ON QMMergeCheckDetail.CUNITID = computationunit1.cComunitCode
                                                 LEFT JOIN AA_Agreement
                                                        ON PU_ArrivalVouch.cVenPUOMProtocol = AA_Agreement.cCode
                                          --LEFT JOIN Factory ON Factory.cFactoryCode = PU_ArrivalVouchs.cFactoryCode
                                          WHERE  Isnull(QMCHECKVOUCHER.CVERIFIER, N'') <> N''
                                                 AND QMCHECKVOUCHER.CVOUCHTYPE = N'qm03'
                                                 AND ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                       + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) ) > 0
                                                 AND Isnull(PU_ArrivalVouchs.cbcloser, '') = '') AS aa) AS bb
                                 INNER JOIN #STPDAPURCHASEINRefCheckIDs F
                                         ON bb.ID = F.M_ID
                                            --WHERE bb.bAllInput = (CASE WHEN @ShowClosed='0' THEN 0 ELSE (0 OR 1) END)
                                            AND bb.bAllInput = 0--这个地方需要修改 Myl20180705PM todo（这样写的话，之前的bShowClosed的值就没有效果了）
                         --WHERE     ID IN (
                         --          SELECT DISTINCT
                         --            M_ID
                         --          FROM
                         --            #STPDAPURCHASEINRefCheckIDs )
                         ) AS QMList
                         INNER JOIN Vendor V
                                 ON QMList.cvencode = V.cVenCode
                  WHERE  1 = 1
                  ORDER  BY ddate ASC,
                            ccheckcode ASC;

                  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
              END;
            ELSE
              BEGIN
                  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

                  SELECT DISTINCT ID                                      AS bodyautoid,
                                  cInvCode                                AS cinvcode,
                                  cInvName                                AS cinvname,
                                  cInvStd                                 AS cinvstd,
                                  ''                                      AS selcol,
                                  CREJECTCODE                             AS crejectcode,
                                  CONVERT(VARCHAR(100), dDate, 23)        AS ddate,
                                  cPTCode                                 AS cptcode,
                                  cPTName                                 AS cptname,
                                  cCheckpersoncode                        AS ccheckpersoncode,
                                  cCheckpersonName                        AS ccheckpersonname,
                                  CCHECKCODE                              AS ccheckcode,
                                  CCHECKCODE                              AS cchkcode,
                                  CONVERT(VARCHAR(100), DARRIVALDATE, 23) AS darrivaldate,
                                  CONVERT(VARCHAR(100), DARRIVALDATE, 23) AS darvdate,
                                  CONVERT(VARCHAR(100), DARRIVALDATE, 23) AS dbarvdate,
                                  SOURCECODE                              AS sourcecode,
                                  SOURCECODE                              AS cbarvcode,
                                  cBusType                                AS cbustype,
                                  CVENCODE                                AS cvencode,
                                  cVenName                                AS cvenname,
                                  CINSPECTDEPCODE                         AS cinspectdepcode,
                                  cInspectDepName                         AS cinspectdepname,
                                  cPersonCode                             AS cpersoncode,
                                  cPersonName                             AS cpersonname,
                                  CDEFINE1                                AS cdefine1,
                                  CDEFINE2                                AS cdefine2,
                                  CDEFINE3                                AS cdefine3,
                                  CDEFINE4                                AS cdefine4,
                                  CDEFINE5                                AS cdefine5,
                                  CDEFINE6                                AS cdefine6,
                                  CDEFINE7                                AS cdefine7,
                                  CDEFINE8                                AS cdefine8,
                                  CDEFINE9                                AS cdefine9,
                                  CDEFINE10                               AS cdefine10,
                                  CDEFINE11                               AS cdefine11,
                                  CDEFINE12                               AS cdefine12,
                                  CDEFINE13                               AS cdefine13,
                                  CDEFINE14                               AS cdefine14,
                                  CDEFINE15                               AS cdefine15,
                                  CDEFINE16                               AS cdefine16,
                                  cMemo                                   AS cmemo,
                                  cRdCode                                 AS crdcode,
                                  cRdName                                 AS crdname,
                                  ufts,
                                  SOURCEAUTOID                            AS sourceautoid,
                                  SOURCEAUTOID                            AS iARRsID,
                                  cexch_name,
                                  ID                                      AS id,
                                  iDiscountTaxType                        AS idiscounttaxtype,
                                  cVenPUOMProtocol                        AS cvenpuomprotocol,
                                  cvenpuomprotocolname                    AS cvenpuomprotocolname,
                                  PartId                                  AS partid,
                                  fOldQuantity                            AS foldquantity,
                                  fOldNum                                 AS foldnum,
                                  fOldQuantity                            AS inquantity,
                                  0                                       AS ireceivedqty,
                                  fOldQuantity                            AS iquantity,
                                  fOldNum                                 AS innum,
                                  CUNITID                                 AS cunitid,
                                  iflowid,
                                  cflowname,
                                  binvbatch                               AS binvbatch,
                                  --bInvQuality AS binvquality ,
                                  --bSerial AS bserial ,
                                  --bBarCode AS bbarcode ,
                                  ivouchrowno,
                                  0.0                                     AS iscanedquantity,
                                  0.0                                     AS isanednum,
                                  CITEMCLASS                              citem_class,
                                  CITEMCNAME                              AS citemcname,
                                  CITEMCODE                               AS citemcode,
                                  CITEMNAME                               AS citemname,
                                  CPOCODE                                 AS ordercode,
                                  CPOCODE                                 AS cpoid,
                                  iPosid,
                                  ID                                      AS iRejectIds,
                                  dDate                                   AS dCheckDate,
                                  CHECKID                                 AS iCheckIdBAKs
                  FROM   (SELECT *
                          FROM   (SELECT N''                                                         AS selcol,
                                         QMREJECTVOUCHER.CREJECTCODE,
                                         QMREJECTVOUCHER.DCHECKDATE                                  AS dDate,
                                         QMREJECTVOUCHER.CCHECKCODE,
                                         QMREJECTVOUCHER.CCHECKPERSON                                AS cCheckpersoncode,
                                         Person.cPersonName                                          AS cCheckpersonName,
                                         QMREJECTVOUCHER.DARRIVALDATE,
                                         QMREJECTVOUCHER.SOURCECODE,
                                         PU_ArrivalVouch.cPTCode,
                                         cPTName,
                                         cBusType,
                                         PU_ArrivalVouch.cexch_name,
                                         PU_ArrivalVouch.iDiscountTaxType,
                                         PU_ArrivalVouch.iExchRate,
                                         Vendor.iId                                                  AS vendoriid,
                                         QMREJECTVOUCHER.CVENCODE,
                                         cVenName,
                                         QMREJECTVOUCHER.CINSPECTDEPCODE,
                                         Department.cDepName                                         AS cInspectDepName,
                                         PU_ArrivalVouch.cPersonCode,
                                         person1.cPersonName,
                                         PU_ArrivalVouch.cMemo,
                                         QMREJECTVOUCHER.CDEFINE1,
                                         QMREJECTVOUCHER.CDEFINE2,
                                         QMREJECTVOUCHER.CDEFINE3,
                                         QMREJECTVOUCHER.CDEFINE4,
                                         QMREJECTVOUCHER.CDEFINE5,
                                         QMREJECTVOUCHER.CDEFINE6,
                                         QMREJECTVOUCHER.CDEFINE7,
                                         QMREJECTVOUCHER.CDEFINE8,
                                         QMREJECTVOUCHER.CDEFINE9,
                                         QMREJECTVOUCHER.CDEFINE10,
                                         QMREJECTVOUCHER.CDEFINE11,
                                         QMREJECTVOUCHER.CDEFINE12,
                                         QMREJECTVOUCHER.CDEFINE13,
                                         QMREJECTVOUCHER.CDEFINE14,
                                         QMREJECTVOUCHER.CDEFINE15,
                                         QMREJECTVOUCHER.CDEFINE16,
                                         p.PartId,
                                         QMREJECTVOUCHER.CINVCODE                                    AS cOldInvCode,
                                         cOldInvAddCode,
                                         cOldInvName,
                                         cOldInvStd,
                                         bOldConF1,
                                         bOldConF2,
                                         bOldConF3,
                                         bOldConF4,
                                         bOldConF5,
                                         bOldConF6,
                                         bOldConF7,
                                         bOldConF8,
                                         bOldConF9,
                                         bOldConF10,
                                         QMREJECTVOUCHERS.FQUANTITY                                  AS fOldQuantity,
                                         QMREJECTVOUCHERS.FNUM                                       AS fOldNum,
                                         QMREJECTVOUCHERS.IPUPODID                                   AS iPosid,
                                         cInvDefine1,
                                         cInvDefine2,
                                         cInvDefine3,
                                         cInvDefine4,
                                         cInvDefine5,
                                         cInvDefine6,
                                         cInvDefine7,
                                         cInvDefine8,
                                         cInvDefine9,
                                         cInvDefine10,
                                         cInvDefine11,
                                         cInvDefine12,
                                         cInvDefine13,
                                         cInvDefine14,
                                         cInvDefine15,
                                         cInvDefine16,
                                         QMREJECTVOUCHERS.CFREE1                                     AS cFree1,
                                         QMREJECTVOUCHERS.CFREE2                                     AS cFree2,
                                         QMREJECTVOUCHERS.CFREE3                                     AS cFree3,
                                         QMREJECTVOUCHERS.CFREE4                                     AS cFree4,
                                         QMREJECTVOUCHERS.CFREE5                                     AS cFree5,
                                         QMREJECTVOUCHERS.CFREE6                                     AS cFree6,
                                         QMREJECTVOUCHERS.CFREE7                                     AS cFree7,
                                         QMREJECTVOUCHERS.CFREE8                                     AS cFree8,
                                         QMREJECTVOUCHERS.CFREE9                                     AS cFree9,
                                         QMREJECTVOUCHERS.CFREE10                                    AS cFree10,
                                         PU_ArrivalVouchs.cDefine22,
                                         PU_ArrivalVouchs.cDefine23,
                                         PU_ArrivalVouchs.cDefine24,
                                         PU_ArrivalVouchs.cDefine25,
                                         PU_ArrivalVouchs.cDefine26,
                                         PU_ArrivalVouchs.cDefine27,
                                         PU_ArrivalVouchs.cDefine28,
                                         PU_ArrivalVouchs.cDefine29,
                                         PU_ArrivalVouchs.cDefine30,
                                         PU_ArrivalVouchs.cDefine31,
                                         PU_ArrivalVouchs.cDefine32,
                                         PU_ArrivalVouchs.cDefine33,
                                         PU_ArrivalVouchs.cDefine34,
                                         PU_ArrivalVouchs.cDefine35,
                                         PU_ArrivalVouchs.cDefine36,
                                         PU_ArrivalVouchs.cDefine37,
                                         PU_ArrivalVouchs.ivouchrowno,
                                         QMREJECTVOUCHER.CWHCODE                                     AS csourcewhcode,
                                         sourcewarehouse.cWhName                                     AS csourcewhname,
                                         QMREJECTVOUCHERS.CBWHCODE                                   AS cWhCode,
                                         Warehouse.cWhName                                           AS cwhname,
                                         Warehouse.bWhPos                                            AS bwhpos,
                                         PurchaseType.cRdCode,
                                         cRdName,
                                         QMREJECTVOUCHERS.CDIMINVCODE                                AS cInvCode,
                                         cInvAddCode,
                                         Inventory.cInvName,
                                         Inventory.cInvStd,
                                         QMREJECTVOUCHERS.AUTOID,
                                         QMREJECTVOUCHERS.ID,
                                         QMREJECTVOUCHER.SOURCEAUTOID,
                                         QMREJECTVOUCHERS.FMATCOST                                   AS fCost,
                                         ( ( Isnull(FDIMQUANTITY, 0) ) * QMREJECTVOUCHERS.FMATCOST ) AS fMOney,
                                         iInvRCost                                                   AS fInvRCost,
                                         ( Isnull(FDIMQUANTITY, 0) * iInvRCost )                     AS fInvRMOney,
                                         Inventory.cComUnitCode,
                                         QMREJECTVOUCHERS.CDIMUNITID                                 AS CUNITID,
                                         QMREJECTVOUCHER.CITEMCLASS,
                                         QMREJECTVOUCHER.CITEMCNAME,
                                         QMREJECTVOUCHER.CITEMCODE,
                                         QMREJECTVOUCHER.CITEMNAME,
                                         ComputationUnit.cComUnitName,
                                         ComputatiOnUnit1.cComUnitName                               AS CUNITNAME,
                                         QMREJECTVOUCHERS.FDIMCHANGRATE                              AS FCHANGRATE,
                                         FDIMQUANTITY                                                AS fQuantity,
                                         FDIMNUM                                                     AS Fnum,
                                         --( CASE WHEN bFree1 = 1 THEN N'是' ELSE N'否' END ) AS bfree1 ,
                                         --( CASE WHEN bFree2 = 1 THEN N'是' ELSE N'否' END ) AS bfree2 ,
                                         --( CASE WHEN bFree3 = 1 THEN N'是' ELSE N'否' END ) AS bfree3 ,
                                         --( CASE WHEN bFree4 = 1 THEN N'是' ELSE N'否' END ) AS bfree4 ,
                                         --( CASE WHEN bFree5 = 1 THEN N'是' ELSE N'否' END ) AS bfree5 ,
                                         --( CASE WHEN bFree6 = 1 THEN N'是' ELSE N'否' END ) AS bfree6 ,
                                         --( CASE WHEN bFree7 = 1 THEN N'是' ELSE N'否' END ) AS bfree7 ,
                                         --( CASE WHEN bFree8 = 1 THEN N'是' ELSE N'否' END ) AS bfree8 ,
                                         --( CASE WHEN bFree9 = 1 THEN N'是' ELSE N'否' END ) AS bfree9 ,
                                         --( CASE WHEN bFree10 = 1 THEN N'是' ELSE N'否' END ) AS bfree10 ,
                                         bFree1                                                      AS bfree1,
                                         bFree2                                                      AS bfree2,
                                         bFree3                                                      AS bfree3,
                                         bFree4                                                      AS bfree4,
                                         bFree5                                                      AS bfree5,
                                         bFree6                                                      AS bfree6,
                                         bFree7                                                      AS bfree7,
                                         bFree8                                                      AS bfree8,
                                         bFree9                                                      AS bfree9,
                                         bFree10                                                     AS bfree10,
                                         ( CASE Isnull(Inventory.binvbatch, 0)
                                             WHEN 0 THEN NULL
                                             ELSE QMREJECTVOUCHERS.CDIMBATCH
                                           END )                                                     AS cBatch,
                                         ( CASE
                                             WHEN ( Isnull(Inventory.binvbatch, 0) <> 0
                                                    AND Isnull(Inventory.cMassUnit, N'') <> N'' ) THEN QMREJECTVOUCHER.DPRODATE
                                             ELSE NULL
                                           END )                                                     AS dprodate,
                                         ( CASE Isnull(Inventory.bInvQuality, 0)
                                             WHEN 0 THEN NULL
                                             ELSE QMREJECTVOUCHERS.IDIMMASSDATE
                                           END )                                                     AS imassdate,
                                         ( CASE Isnull(Inventory.bInvQuality, 0)
                                             WHEN 0 THEN NULL
                                             ELSE QMREJECTVOUCHERS.DDIMVDATE
                                           END )                                                     AS dVDate,
                                         QMREJECTVOUCHERS.iDIMExpiratDateCalcu                       AS iExpiratDateCalcu,
                                         QMREJECTVOUCHERS.cDIMExpirationdate                         AS cExpirationdate,
                                         QMREJECTVOUCHERS.dDIMExpirationdate                         AS dExpirationdate,
                                         --( CASE WHEN bService = 1 THEN N'是' ELSE N'否' END ) AS bservice ,
                                         --( CASE WHEN bInvBatch = 1 THEN N'是' ELSE N'否' END ) AS binvbatch ,
                                         bService                                                    AS bservice,
                                         bInvBatch                                                   AS binvbatch,
                                         CONVERT(CHAR, CONVERT(MONEY, QMREJECTVOUCHER.UFTS), 2)      AS ufts,
                                         Inventory.cGroupCode,
                                         iGroupType,
                                         ( CASE QMREJECTVOUCHERS.CDIMMASSUNIT
                                             WHEN 1 THEN N'年'
                                             WHEN 2 THEN N'月'
                                             WHEN 3 THEN N'日'
                                             ELSE N''
                                           END )                                                     AS cmassunit,
                                         DEMANDSOURCE.IORDERTYPE                                     AS iordertype,
                                         DEMANDSOURCE.CSOORDERCODE                                   AS csocode,
                                         DEMANDSOURCE.ISOORDERAUTOID                                 AS iSoDID,
                                         CASE
                                           WHEN Isnull(DEMANDSOURCE.CSOORDERCODE, '') = '' THEN Cast(NULL AS INT)
                                           ELSE PU_ArrivalVouchs.irowno
                                         END                                                         AS isoseq,
                                         QMREJECTVOUCHER.IORDERDID,
                                         QMREJECTVOUCHER.ISOORDERTYPE,
                                         QMREJECTVOUCHER.CORDERCODE,
                                         QMREJECTVOUCHER.IORDERSEQ,
                                         PU_ArrivalVouch.cVenPUOMProtocol,
                                         AA_Agreement.cName                                          AS cvenpuomprotocolname,
                                         QMREJECTVOUCHER.CHECKID,
                                         QMREJECTVOUCHER.cBatchProperty1,
                                         QMREJECTVOUCHER.cBatchProperty2,
                                         QMREJECTVOUCHER.cBatchProperty3,
                                         QMREJECTVOUCHER.cBatchProperty4,
                                         QMREJECTVOUCHER.cBatchProperty5,
                                         QMREJECTVOUCHER.cBatchProperty6,
                                         QMREJECTVOUCHER.cBatchProperty7,
                                         QMREJECTVOUCHER.cBatchProperty8,
                                         QMREJECTVOUCHER.cBatchProperty9,
                                         QMREJECTVOUCHER.cBatchProperty10,
                                         QMREJECTVOUCHER.CCONTRACTSTRCODE,
                                         QMREJECTVOUCHER.CCONTRACTCODE,
                                         Inventory.iId,
                                         PU_ArrivalVouchs.cciqbookcode,
                                         PU_ArrivalVouch.iflowid                                     AS iflowid,
                                         PUBizFlow.cFlowName                                         AS cflowname,
                                         PU_ArrivalVouchs.cbMemo,
                                         PU_ArrivalVouchs.bgift,
                                         QMREJECTVOUCHER.CSYSBARCODE,
                                         QMREJECTVOUCHERS.CBSYSBARCODE,
                                         QMREJECTVOUCHER.CSOURCEPROORDERCODE                         AS ISOURCEMOCODE,
                                         QMREJECTVOUCHER.ISOURCEPROORDERAUTOID                       AS ISOURCEMODETAILSID,
                                         QMREJECTVOUCHER.CPOCODE,
                                         Isnull(PU_ArrivalVouchs.iInvMPCost, 0)                      AS impcost,
                                         --PU_ArrivalVouchs.cFactoryCode ,
                                         ''                                                          AS cfactorycode,
                                         --Factory.cFactoryName
                                         ''                                                          AS cfactoryname
                                  FROM   QMREJECTVOUCHER WITH ( NOLOCK )
                                         INNER JOIN QMREJECTVOUCHERS
                                                 ON QMREJECTVOUCHER.ID = QMREJECTVOUCHERS.ID
                                         INNER JOIN (SELECT cInvCode      AS cOldInvCode,
                                                            cInvName      AS cOldInvName,
                                                            cInvAddCode   AS cOldInvAddCode,
                                                            cInvStd       AS cOldInvStd,
                                                            bConfigFree1  AS bOldConF1,
                                                            bConfigFree2  AS bOldConF2,
                                                            bConfigFree3  AS bOldConF3,
                                                            bConfigFree4  AS bOldConF4,
                                                            bConfigFree5  AS bOldConF5,
                                                            bConfigFree6  AS bOldConF6,
                                                            bConfigFree7  AS bOldConF7,
                                                            bConfigFree8  AS bOldConF8,
                                                            bConfigFree9  AS bOldConF9,
                                                            bConfigFree10 AS bOldConF10
                                                     FROM   Inventory WITH ( NOLOCK )) oldinv
                                                 ON QMREJECTVOUCHER.CINVCODE = oldinv.cOldInvCode
                                         LEFT JOIN bas_part p
                                                ON QMREJECTVOUCHER.CINVCODE = p.InvCode
                                                   AND Isnull(QMREJECTVOUCHER.CFREE1, '') = ( CASE
                                                                                                WHEN Isnull(oldinv.bOldConF1, 0) = 1 THEN Isnull(p.Free1, '')
                                                                                                ELSE Isnull(QMREJECTVOUCHER.CFREE1, '')
                                                                                              END )
                                                   AND Isnull(QMREJECTVOUCHER.CFREE2, '') = ( CASE
                                                                                                WHEN Isnull(oldinv.bOldConF2, 0) = 1 THEN Isnull(p.Free2, '')
                                                                                                ELSE Isnull(QMREJECTVOUCHER.CFREE2, '')
                                                                                              END )
                                                   AND Isnull(QMREJECTVOUCHER.CFREE3, '') = ( CASE
                                                                                                WHEN Isnull(oldinv.bOldConF3, 0) = 1 THEN Isnull(p.Free3, '')
                                                                                                ELSE Isnull(QMREJECTVOUCHER.CFREE3, '')
                                                                                              END )
                                                   AND Isnull(QMREJECTVOUCHER.CFREE4, '') = ( CASE
                                                                                                WHEN Isnull(oldinv.bOldConF4, 0) = 1 THEN Isnull(p.Free4, '')
                                                                                                ELSE Isnull(QMREJECTVOUCHER.CFREE4, '')
                                                                                              END )
                                                   AND Isnull(QMREJECTVOUCHER.CFREE5, '') = ( CASE
                                                                                                WHEN Isnull(oldinv.bOldConF5, 0) = 1 THEN Isnull(p.Free5, '')
                                                                                                ELSE Isnull(QMREJECTVOUCHER.CFREE5, '')
                                                                                              END )
                                                   AND Isnull(QMREJECTVOUCHER.CFREE6, '') = ( CASE
                                                                                                WHEN Isnull(oldinv.bOldConF6, 0) = 1 THEN Isnull(p.Free6, '')
                                                                                                ELSE Isnull(QMREJECTVOUCHER.CFREE6, '')
                                                                                              END )
                                                   AND Isnull(QMREJECTVOUCHER.CFREE7, '') = ( CASE
                                                                                                WHEN Isnull(oldinv.bOldConF7, 0) = 1 THEN Isnull(p.Free7, '')
                                                                                                ELSE Isnull(QMREJECTVOUCHER.CFREE7, '')
                                                                                              END )
                                                   AND Isnull(QMREJECTVOUCHER.CFREE8, '') = ( CASE
                                                                                                WHEN Isnull(oldinv.bOldConF8, 0) = 1 THEN Isnull(p.Free8, '')
                                                                                                ELSE Isnull(QMREJECTVOUCHER.CFREE8, '')
                                                                                              END )
                                                   AND Isnull(QMREJECTVOUCHER.CFREE9, '') = ( CASE
                                                                                                WHEN Isnull(oldinv.bOldConF9, 0) = 1 THEN Isnull(p.Free9, '')
                                                                                                ELSE Isnull(QMREJECTVOUCHER.CFREE9, '')
                                                                                              END )
                                                   AND Isnull(QMREJECTVOUCHER.CFREE10, '') = ( CASE
                                                                                                 WHEN Isnull(oldinv.bOldConF10, 0) = 1 THEN Isnull(p.Free10, '')
                                                                                                 ELSE Isnull(QMREJECTVOUCHER.CFREE10, '')
                                                                                               END )
                                         INNER JOIN Inventory
                                                 ON QMREJECTVOUCHERS.CDIMINVCODE = Inventory.cInvCode
                                         INNER JOIN PU_ArrivalVouchs
                                                 ON QMREJECTVOUCHER.SOURCEAUTOID = PU_ArrivalVouchs.Autoid
                                         INNER JOIN PU_ArrivalVouch
                                                 ON PU_ArrivalVouchs.ID = PU_ArrivalVouch.ID
                                         LEFT JOIN PUBizFlow
                                                ON PUBizFlow.iFlowID = PU_ArrivalVouch.iflowid
                                         LEFT JOIN Person
                                                ON QMREJECTVOUCHER.CCHECKPERSON = Person.cPersonCode
                                         LEFT JOIN PurchaseType
                                                ON PU_ArrivalVouch.cPTCode = PurchaseType.cPTCode
                                         LEFT JOIN Vendor
                                                ON QMREJECTVOUCHER.CVENCODE = Vendor.cVenCode
                                         LEFT JOIN Department
                                                ON QMREJECTVOUCHER.CINSPECTDEPCODE = Department.cDepCode
                                         LEFT JOIN Person AS person1
                                                ON PU_ArrivalVouch.cPersonCode = person1.cPersonCode
                                         LEFT JOIN Warehouse
                                                ON QMREJECTVOUCHERS.CBWHCODE = Warehouse.cWhCode
                                         LEFT JOIN Rd_Style
                                                ON PurchaseType.cRdCode = Rd_Style.cRdCode
                                         LEFT JOIN ComputationUnit
                                                ON Inventory.cComUnitCode = ComputationUnit.cComunitCode
                                         LEFT JOIN ComputationUnit AS ComputatiOnUnit1
                                                ON QMREJECTVOUCHERS.CDIMUNITID = ComputatiOnUnit1.cComunitCode
                                         LEFT JOIN AA_Agreement
                                                ON PU_ArrivalVouch.cVenPUOMProtocol = AA_Agreement.cCode
                                         --LEFT JOIN Factory ON Factory.cFactoryCode = PU_ArrivalVouchs.cFactoryCode
                                         LEFT JOIN QMREJECTVOUCHER AS DEMANDSOURCE
                                                ON DEMANDSOURCE.ID = QMREJECTVOUCHERS.ID
                                                   AND DEMANDSOURCE.CINVCODE = QMREJECTVOUCHERS.CDIMINVCODE
                                                   AND Isnull(DEMANDSOURCE.CBATCH, '') = Isnull(QMREJECTVOUCHERS.CDIMBATCH, '')
                                                   AND Isnull(DEMANDSOURCE.CFREE1, '') = Isnull(QMREJECTVOUCHERS.CFREE1, '')
                                                   AND Isnull(DEMANDSOURCE.CFREE2, '') = Isnull(QMREJECTVOUCHERS.CFREE2, '')
                                                   AND Isnull(DEMANDSOURCE.CFREE3, '') = Isnull(QMREJECTVOUCHERS.CFREE3, '')
                                                   AND Isnull(DEMANDSOURCE.CFREE4, '') = Isnull(QMREJECTVOUCHERS.CFREE4, '')
                                                   AND Isnull(DEMANDSOURCE.CFREE5, '') = Isnull(QMREJECTVOUCHERS.CFREE5, '')
                                                   AND Isnull(DEMANDSOURCE.CFREE6, '') = Isnull(QMREJECTVOUCHERS.CFREE6, '')
                                                   AND Isnull(DEMANDSOURCE.CFREE7, '') = Isnull(QMREJECTVOUCHERS.CFREE7, '')
                                                   AND Isnull(DEMANDSOURCE.CFREE8, '') = Isnull(QMREJECTVOUCHERS.CFREE8, '')
                                                   AND Isnull(DEMANDSOURCE.CFREE9, '') = Isnull(QMREJECTVOUCHERS.CFREE9, '')
                                                   AND Isnull(DEMANDSOURCE.CFREE10, '') = Isnull(QMREJECTVOUCHERS.CFREE10, '')
                                         LEFT JOIN Warehouse sourcewarehouse
                                                ON QMREJECTVOUCHER.CWHCODE = sourcewarehouse.cWhCode
                                  WHERE  Isnull(QMREJECTVOUCHER.CVERIFIER, N'') <> N''
                                         AND IDISPOSEFLOW = 2
                                         AND QMREJECTVOUCHER.CVOUCHTYPE = N'QM05'
                                         AND Isnull(QMREJECTVOUCHERS.BFLAG, 0) = 0
                                         AND ( Isnull(FDIMQUANTITY, 0) > 0 )
                                         AND Isnull(PU_ArrivalVouchs.cbcloser, '') = '') AS aa
                          WHERE  ID IN (SELECT DISTINCT M_ID
                                        FROM   #STPDAPURCHASEINRefCheckIDs1)) AS QMList
                         INNER JOIN #STPDAPURCHASEINRefCheckIDs1 b
                                 ON QMList.ID = b.M_ID
                                    AND QMList.AUTOID = b.S_ID
                  WHERE  1 = 1
                  ORDER  BY crejectcode ASC,
                            ddate ASC;

                  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
              END;

            --删除临时表
            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDATempPUCheckCodes') IS NULL)
              DROP TABLE #STPDATempPUCheckCodes;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDATempCheckArrCodes') IS NULL)
              DROP TABLE #STPDATempCheckArrCodes;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDATempCheckPoCodes') IS NULL)
              DROP TABLE #STPDATempCheckPoCodes;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDAPURCHASEINRefCheckIDs') IS NULL)
              DROP TABLE #STPDAPURCHASEINRefCheckIDs;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDATempCheckVouchIDs') IS NULL)
              DROP TABLE #STPDATempCheckVouchIDs;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDAPURCHASEINRefCheckIDs1') IS NULL)
              DROP TABLE #STPDAPURCHASEINRefCheckIDs1;
        END;
      ELSE IF ( @OperType = N'9' )
        BEGIN
            --检验单单号集合
            DECLARE @CheckVoucherCodes NVARCHAR(1000);

            BEGIN
                SET @CheckVoucherCodes = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cCodes', DEFAULT, DEFAULT);

                IF ( @CheckVoucherCodes <> N'' )
                  BEGIN
                      IF EXISTS (SELECT 0
                                 WHERE  NOT Object_id('tempdb..#STPDATempSICheckVoucherCodes') IS NULL)
                        DROP TABLE #STPDATempSICheckVoucherCodes;

                      CREATE TABLE #STPDATempSICheckVoucherCodes
                        (
                           cCode NVARCHAR(30)
                        );

                      INSERT INTO #STPDATempSICheckVoucherCodes
                      EXEC Proc_ts_splitparamstring
                        @CheckVoucherCodes;
                  END;
            END;

            IF ( @CheckVoucherCodes = N'' )
              BEGIN
                  RAISERROR ('未提供有效的检验单单号！',16,1 );

                  RETURN;
              END;

            SELECT DISTINCT autoid                           AS bodyautoid,
                            ''                               selcol,
                            '来料检验单'                          AS csource,
                            CONVERT(VARCHAR(100), DDATE, 23) AS ddate,
                            CORDERCODE                       AS cordercode,
                            CCHECKCODE                       AS ccheckcode,
                            CCHECKPERSONCODE                 AS ccheckpersoncode,
                            ccheckpersonname                 AS ccheckpersonname,
                            DARRIVALDATE                     AS darrivaldate,
                            SOURCECODE                       AS sourcecode,
                            cptcode,
                            cPTName                          AS cptname,
                            cbustype,
                            cvencode,
                            cvenname,
                            cvenname                         AS cvenabbname,
                            NULL                             AS cdepcode,
                            NULL                             AS cdepname,
                            cinspectdepcode,
                            cinspectdepname,
                            cpersoncode,
                            cPersonName                      AS cpersonname,
                            cMemo                            AS cmemo,
                            CDEFINE1                         AS cdefine1,
                            CDEFINE2                         AS cdefine2,
                            CDEFINE3                         AS cdefine3,
                            CDEFINE4                         AS cdefine4,
                            CDEFINE5                         AS cdefine5,
                            CDEFINE6                         AS cdefine6,
                            CDEFINE7                         AS cdefine7,
                            CDEFINE8                         AS cdefine8,
                            CDEFINE9                         AS cdefine9,
                            CDEFINE10                        AS cdefine10,
                            CDEFINE11                        AS cdefine11,
                            CDEFINE12                        AS cdefine12,
                            CDEFINE13                        AS cdefine13,
                            CDEFINE14                        AS cdefine14,
                            CDEFINE15                        AS cdefine15,
                            CDEFINE16                        AS cdefine16,
                            cwhcode,
                            cWhName                          AS cwhname,
                            cRdCode                          AS crdcode,
                            cRdName                          AS crdname,
                            CINVCODE                         AS cinvcode,
                            cInvAddCode                      AS cinvaddcode,
                            cInvName                         AS cinvname,
                            cInvStd                          AS cinvstd,
                            cInvDefine1                      AS cinvdefine1,
                            cInvDefine2                      AS cinvdefine2,
                            cInvDefine3                      AS cinvdefine3,
                            cInvDefine4                      AS cinvdefine4,
                            cInvDefine5                      AS cinvdefine5,
                            cInvDefine6                      AS cinvdefine6,
                            cInvDefine7                      AS cinvdefine7,
                            cInvDefine8                      AS cinvdefine8,
                            cInvDefine9                      AS cinvdefine9,
                            cInvDefine10                     AS cinvdefine10,
                            cInvDefine11                     AS cinvdefine11,
                            cInvDefine12                     AS cinvdefine12,
                            cInvDefine13                     AS cinvdefine13,
                            cInvDefine14                     AS cinvdefine14,
                            cInvDefine15                     AS cinvdefine15,
                            cInvDefine16                     AS cinvdefine16,
                            CFREE1                           AS cfree1,
                            CFREE2                           AS cfree2,
                            CFREE3                           AS cfree3,
                            CFREE4                           AS cfree4,
                            CFREE5                           AS cfree5,
                            CFREE6                           AS cfree6,
                            CFREE7                           AS cfree7,
                            CFREE8                           AS cfree8,
                            CFREE9                           AS cfree9,
                            CFREE10                          AS cfree10,
                            CBATCH                           AS cbatch,
                            DPRODATE                         AS dprodate,
                            DPRODATE                         AS dmadedate,
                            imassdate,
                            DVDATE                           AS dvdate,
                            cComUnitName                     AS ccomunitname,
                            cComUnitName                     AS cinvm_unit,
                            cunitname                        AS cunitname,
                            cunitname                        AS cinva_unit,
                            fcost,
                            finvrcost,
                            fquantity                        AS iquantity,
                            fnum                             AS inum,
                            fquantity                        AS inquantity,
                            fnum                             AS innum,
                            fmoney,
                            finvrmoney,
                            cDefine22                        AS cdefine22,
                            cDefine23                        AS cdefine23,
                            cDefine24                        AS cdefine24,
                            cDefine25                        AS cdefine25,
                            cDefine26                        AS cdefine26,
                            cDefine27                        AS cdefine27,
                            cDefine28                        AS cdefine28,
                            cDefine29                        AS cdefine29,
                            cDefine30                        AS cdefine30,
                            cDefine31                        AS cdefine31,
                            cDefine32                        AS cdefine32,
                            cDefine33                        AS cdefine33,
                            cDefine34                        AS cdefine34,
                            cDefine35                        AS cdefine35,
                            cDefine36                        AS cdefine36,
                            cDefine37                        AS cdefine37,
                            ID                               AS id,
                            SOURCEAUTOID                     AS sourceautoid,
                            cComUnitCode                     AS ccomunitcode,
                            CUNITID                          AS cunitid,
                            CITEMCLASS                       AS citemclass,
                            CITEMCLASS                       citem_class,
                            CITEMCNAME                       AS citemcname,
                            CITEMCODE                        AS citemcode,
                            CITEMNAME                        AS citemname,
                            bfree1,
                            bfree2,
                            bfree3,
                            bfree4,
                            bfree5,
                            bfree6,
                            bfree7,
                            bfree8,
                            bfree9,
                            bfree10,
                            autoid,
                            cGroupCode                       AS cgroupcode,
                            iGroupType                       AS igrouptype,
                            bservice,
                            binvbatch,
                            ufts,
                            cmassunit,
                            IORDERTYPE                       idemandtype,
                            csocode                          cdemandcode,
                            isoseq                           idemandseq,
                            iSoDID                           cdemandid,
                            iId                              AS iid,
                            fchangrate                       AS iinvexchrate,
                            CPOCODE                          AS cpocode,
                            CSYSBARCODE                      AS csysbarcode,
                            ''                               AS cexch_name,
                            ''                               AS nflat,
                            ID                               AS icheckidbaks,
                            Isnull(iflowid, 0)               iflowid,
                            fquantity,
                            Isnull(iDiscountTaxType, 0)      idiscounttaxtype,
                            cexch_name,
                            0                                AS stockinqty,
                            CASE
                              WHEN Isnull(fchangrate, 0) > 0 THEN Isnull(0, 0) / fchangrate
                              ELSE 0
                            END                              AS stockinnum,
                            FREGQUANTITY                     AS inewquantity,
                            CASE
                              WHEN Isnull(fchangrate, 0) > 0 THEN Isnull(0, 0) / fchangrate
                              ELSE 0
                            END                              AS inewnum,
                            BMERGECHECKFLAG                  AS bmergecheckflag,
                            iPOsID                           AS iposid
                            --modify by caiwei 2015-2-10 采购入库单参照检验单带不出金额
                            ,
                            iOriTaxCost                      AS ioritaxcost,
                            iOriCost                         AS ioricost,
                            bTaxCost                         AS btaxcost,
                            0.0                              AS iscanedquantity,
                            0.0                              AS iscanednum
            FROM   (SELECT *
                    FROM   (SELECT *
                            FROM   (SELECT *,
                                           Isnull(BPUINFLAG, 0) AS bAllInput
                                    FROM   (SELECT Cast(QMCHECKVOUCHER.ID AS VARCHAR) + 'D'
                                                   + '-1'                                                AS dkey,
                                                   QMCHECKVOUCHER.BPUINFLAG                              AS BPUINFLAG,
                                                   N''                                                   AS selcol,
                                                   QMCHECKVOUCHER.DDATE,
                                                   CCHECKCODE,
                                                   CCHECKPERSONCODE,
                                                   Person.cPersonName                                    AS ccheckpersonname,
                                                   DARRIVALDATE,
                                                   SOURCECODE,
                                                   Isnull(PU_ArrivalVouch.cPTCode, '')                   AS cptcode,
                                                   cPTName,
                                                   Isnull(cBusType, '')                                  AS cbustype,
                                                   Isnull(QMCHECKVOUCHER.CVENCODE, '')                   AS cvencode,
                                                   Isnull(PU_ArrivalVouch.cexch_name, '')                AS cexch_name,
                                                   PU_ArrivalVouch.iDiscountTaxType,
                                                   PU_ArrivalVouch.iExchRate,
                                                   Vendor.iId                                            AS vendoriid,
                                                   Vendor.cVenName                                       AS cvenname,
                                                   Isnull(CINSPECTDEPCODE, '')                           AS cinspectdepcode,
                                                   Department.cDepName                                   AS cinspectdepname,
                                                   Isnull(PU_ArrivalVouch.cPersonCode, '')               AS cpersoncode,
                                                   person1.cPersonName,
                                                   PU_ArrivalVouch.cMemo,
                                                   QMCHECKVOUCHER.CDEFINE1,
                                                   QMCHECKVOUCHER.CDEFINE2,
                                                   QMCHECKVOUCHER.CDEFINE3,
                                                   QMCHECKVOUCHER.CDEFINE4,
                                                   QMCHECKVOUCHER.CDEFINE5,
                                                   QMCHECKVOUCHER.CDEFINE6,
                                                   QMCHECKVOUCHER.CDEFINE7,
                                                   QMCHECKVOUCHER.CDEFINE8,
                                                   QMCHECKVOUCHER.CDEFINE9,
                                                   QMCHECKVOUCHER.CDEFINE10,
                                                   QMCHECKVOUCHER.CDEFINE11,
                                                   QMCHECKVOUCHER.CDEFINE12,
                                                   QMCHECKVOUCHER.CDEFINE13,
                                                   QMCHECKVOUCHER.CDEFINE14,
                                                   QMCHECKVOUCHER.CDEFINE15,
                                                   QMCHECKVOUCHER.CDEFINE16,
                                                   Isnull(QMCHECKVOUCHER.CWHCODE, '')                    AS cwhcode,
                                                   cWhName,
                                                   PurchaseType.cRdCode,
                                                   cRdName,
                                                   QMCHECKVOUCHER.CINVCODE,
                                                   Inventory.cInvAddCode,
                                                   Inventory.cInvName,
                                                   Inventory.cInvStd,
                                                   cInvDefine1,
                                                   cInvDefine2,
                                                   cInvDefine3,
                                                   cInvDefine4,
                                                   cInvDefine5,
                                                   cInvDefine6,
                                                   cInvDefine7,
                                                   cInvDefine8,
                                                   cInvDefine9,
                                                   cInvDefine10,
                                                   cInvDefine11,
                                                   cInvDefine12,
                                                   cInvDefine13,
                                                   cInvDefine14,
                                                   cInvDefine15,
                                                   cInvDefine16,
                                                   QMCHECKVOUCHER.CFREE1,
                                                   QMCHECKVOUCHER.CFREE2,
                                                   QMCHECKVOUCHER.CFREE3,
                                                   QMCHECKVOUCHER.CFREE4,
                                                   QMCHECKVOUCHER.CFREE5,
                                                   QMCHECKVOUCHER.CFREE6,
                                                   QMCHECKVOUCHER.CFREE7,
                                                   QMCHECKVOUCHER.CFREE8,
                                                   QMCHECKVOUCHER.CFREE9,
                                                   QMCHECKVOUCHER.CFREE10,
                                                   PU_ArrivalVouchs.ivouchrowno,
                                                   QMCHECKVOUCHER.CBATCH,
                                                   DPRODATE,
                                                   PU_ArrivalVouchs.imassdate,
                                                   QMCHECKVOUCHER.DVDATE,
                                                   QMCHECKVOUCHER.iExpiratDateCalcu,
                                                   QMCHECKVOUCHER.cExpirationdate,
                                                   QMCHECKVOUCHER.dExpirationdate,
                                                   ComputationUnit.cComUnitName,
                                                   computationunit1.cComUnitName                         AS cunitname,
                                                   CASE Isnull(BPUINFLAG, 0)
                                                     WHEN 0 THEN ( CASE Isnull(Inventory.iGroupType, 0)
                                                                     WHEN 0 THEN 0
                                                                     WHEN 1 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                                     WHEN 1 THEN ( Isnull(FREGQUANTITY, 0)
                                                                                                   + Isnull(FCONQUANTIY, 0) - Isnull(FsumQuantity, 0) ) / computationunit1.iChangRate
                                                                                     ELSE ( Isnull(FREGQUANTITY, 0)
                                                                                            + Isnull(FCONQUANTIY, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) - Isnull(FsumQuantity, 0) ) / computationunit1.iChangRate
                                                                                   END )
                                                                     WHEN 2 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                                     WHEN 1 THEN ( Isnull(FCHECKNUM, 0) - Isnull(FsumNum, 0) )
                                                                                     ELSE ( Isnull(FCHECKNUM, 0) - Isnull(FsumNum, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) / FCHECKCHANGRATE )
                                                                                   END )
                                                                   END )
                                                     ELSE 0
                                                   END                                                   AS fnum,
                                                   iCost                                                 AS fcost,
                                                   ioritaxcost                                           AS iunitcost,
                                                   iInvRCost                                             AS finvrcost,
                                                   CASE Isnull(BPUINFLAG, 0)
                                                     WHEN 0 THEN ( CASE Isnull(Inventory.iGroupType, 0)
                                                                     WHEN 0 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                                     WHEN 1 THEN ( Isnull(FREGQUANTITY, 0)
                                                                                                   + Isnull(FCONQUANTIY, 0) - Isnull(FsumQuantity, 0) )
                                                                                     ELSE ( Isnull(FREGQUANTITY, 0)
                                                                                            + Isnull(FCONQUANTIY, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) - Isnull(FsumQuantity, 0) )
                                                                                   END )
                                                                     WHEN 1 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                                     WHEN 1 THEN ( Isnull(FREGQUANTITY, 0)
                                                                                                   + Isnull(FCONQUANTIY, 0) - Isnull(FsumQuantity, 0) )
                                                                                     ELSE ( Isnull(FREGQUANTITY, 0)
                                                                                            + Isnull(FCONQUANTIY, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) - Isnull(FsumQuantity, 0) )
                                                                                   END )
                                                                     WHEN 2 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                                     WHEN 1 THEN ( Isnull(FCHECKQTY, 0) - Isnull(FsumQuantity, 0) )
                                                                                     ELSE ( Isnull(FCHECKQTY, 0) - Isnull(FsumQuantity, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) )
                                                                                   END )
                                                                   END )
                                                     ELSE 0
                                                   END                                                   AS fquantity,
                                                   CASE Isnull(BPUINFLAG, 0)
                                                     WHEN 0 THEN ( CASE Isnull(Inventory.iGroupType, 0)
                                                                     WHEN 0 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                                     WHEN 1 THEN ( Isnull(FREGQUANTITY, 0)
                                                                                                   + Isnull(FCONQUANTIY, 0) - Isnull(FsumQuantity, 0) )
                                                                                     ELSE ( Isnull(FREGQUANTITY, 0)
                                                                                            + Isnull(FCONQUANTIY, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) - Isnull(FsumQuantity, 0) )
                                                                                   END )
                                                                     WHEN 1 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                                     WHEN 1 THEN ( Isnull(FREGQUANTITY, 0)
                                                                                                   + Isnull(FCONQUANTIY, 0) - Isnull(FsumQuantity, 0) )
                                                                                     ELSE ( Isnull(FREGQUANTITY, 0)
                                                                                            + Isnull(FCONQUANTIY, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) - Isnull(FsumQuantity, 0) )
                                                                                   END )
                                                                     WHEN 2 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                                     WHEN 1 THEN ( Isnull(FCHECKQTY, 0) - Isnull(FsumQuantity, 0) )
                                                                                     ELSE ( Isnull(FCHECKQTY, 0) - Isnull(FsumQuantity, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) )
                                                                                   END )
                                                                   END * iCost )
                                                     ELSE 0
                                                   END                                                   AS fmoney,
                                                   ( CASE Isnull(Inventory.iGroupType, 0)
                                                       WHEN 0 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                       WHEN 1 THEN ( Isnull(FREGQUANTITY, 0)
                                                                                     + Isnull(FCONQUANTIY, 0) - Isnull(FsumQuantity, 0) )
                                                                       ELSE ( Isnull(FREGQUANTITY, 0)
                                                                              + Isnull(FCONQUANTIY, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) - Isnull(FsumQuantity, 0) )
                                                                     END )
                                                       WHEN 1 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                       WHEN 1 THEN ( Isnull(FREGQUANTITY, 0)
                                                                                     + Isnull(FCONQUANTIY, 0) - Isnull(FsumQuantity, 0) )
                                                                       ELSE ( Isnull(FREGQUANTITY, 0)
                                                                              + Isnull(FCONQUANTIY, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) - Isnull(FsumQuantity, 0) )
                                                                     END )
                                                       WHEN 2 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                       WHEN 1 THEN ( Isnull(FCHECKQTY, 0) - Isnull(FsumQuantity, 0) )
                                                                       ELSE ( Isnull(FCHECKQTY, 0) - Isnull(FsumQuantity, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) )
                                                                     END )
                                                     END * iInvRCost )                                   AS finvrmoney,
                                                   PU_ArrivalVouchs.cDefine22,
                                                   PU_ArrivalVouchs.cDefine23,
                                                   PU_ArrivalVouchs.cDefine24,
                                                   PU_ArrivalVouchs.cDefine25,
                                                   PU_ArrivalVouchs.cDefine26,
                                                   PU_ArrivalVouchs.cDefine27,
                                                   PU_ArrivalVouchs.cDefine28,
                                                   PU_ArrivalVouchs.cDefine29,
                                                   PU_ArrivalVouchs.cDefine30,
                                                   PU_ArrivalVouchs.cDefine31,
                                                   PU_ArrivalVouchs.cDefine32,
                                                   PU_ArrivalVouchs.cDefine33,
                                                   PU_ArrivalVouchs.cDefine34,
                                                   PU_ArrivalVouchs.cDefine35,
                                                   PU_ArrivalVouchs.cDefine36,
                                                   PU_ArrivalVouchs.cDefine37,
                                                   QMCHECKVOUCHER.ID,
                                                   SOURCEAUTOID,
                                                   Inventory.cComUnitCode,
                                                   -1                                                    AS autoid,
                                                   QMCHECKVOUCHER.CUNITID,
                                                   CITEMCLASS,
                                                   CITEMCNAME,
                                                   QMCHECKVOUCHER.CITEMCODE,
                                                   QMCHECKVOUCHER.CITEMNAME,
                                                   bfree1,
                                                   bfree2,
                                                   bfree3,
                                                   bfree4,
                                                   bfree5,
                                                   bfree6,
                                                   bfree7,
                                                   bfree8,
                                                   bfree9,
                                                   bfree10,
                                                   --( CASE
                                                   --WHEN bFree1 = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS bfree1 ,
                                                   --( CASE
                                                   --WHEN bFree2 = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS bfree2 ,
                                                   --( CASE
                                                   --WHEN bFree3 = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS bfree3 ,
                                                   --( CASE
                                                   --WHEN bFree4 = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS bfree4 ,
                                                   --( CASE
                                                   --WHEN bFree5 = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS bfree5 ,
                                                   --( CASE
                                                   --WHEN bFree6 = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS bfree6 ,
                                                   --( CASE
                                                   --WHEN bFree7 = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS bfree7 ,
                                                   --( CASE
                                                   --WHEN bFree8 = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS bfree8 ,
                                                   --( CASE
                                                   --WHEN bFree9 = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS bfree9 ,
                                                   --( CASE
                                                   --WHEN bFree10 = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS bfree10 ,
                                                   Inventory.cGroupCode,
                                                   iGroupType,
                                                   bservice,
                                                   binvbatch,
                                                   --( CASE
                                                   --WHEN bService = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS bservice ,
                                                   --( CASE
                                                   --WHEN bInvBatch = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS binvbatch ,
                                                   CONVERT(CHAR, CONVERT(MONEY, QMCHECKVOUCHER.UFTS), 2) AS ufts,
                                                   ( CASE PU_ArrivalVouchs.cmassunit
                                                       WHEN 1 THEN N'年'
                                                       WHEN 2 THEN N'月'
                                                       WHEN 3 THEN N'日'
                                                       ELSE N''
                                                     END )                                               AS cmassunit,
                                                   --QMCHECKVOUCHER.IORDERTYPE ,
                                                   PU_ArrivalVouchs.iordertype,
                                                   PU_ArrivalVouchs.SoType                               AS isotype,
                                                   QMCHECKVOUCHER.CSOORDERCODE                           AS csocode,
                                                   CASE QMCHECKVOUCHER.IORDERTYPE
                                                     WHEN 1 THEN SO_SODetails.iRowNo
                                                     WHEN 3 THEN ex_orderdetail.irowno
                                                     ELSE NULL
                                                   END                                                   AS isoseq,
                                                   --QMCHECKVOUCHER.ISOORDERAUTOID AS iSoDID ,
                                                   PU_ArrivalVouchs.SoDId                                AS isodid,
                                                   QMCHECKVOUCHER.IORDERDID,
                                                   QMCHECKVOUCHER.ISOORDERTYPE,
                                                   QMCHECKVOUCHER.CORDERCODE,
                                                   QMCHECKVOUCHER.IORDERSEQ,
                                                   QMCHECKVOUCHER.cBatchProperty1,
                                                   QMCHECKVOUCHER.cBatchProperty2,
                                                   QMCHECKVOUCHER.cBatchProperty3,
                                                   QMCHECKVOUCHER.cBatchProperty4,
                                                   QMCHECKVOUCHER.cBatchProperty5,
                                                   QMCHECKVOUCHER.cBatchProperty6,
                                                   QMCHECKVOUCHER.cBatchProperty7,
                                                   QMCHECKVOUCHER.cBatchProperty8,
                                                   QMCHECKVOUCHER.cBatchProperty9,
                                                   QMCHECKVOUCHER.cBatchProperty10,
                                                   Inventory.iId,
                                                   QMCHECKVOUCHER.CCONTRACTSTRCODE,
                                                   QMCHECKVOUCHER.CCONTRACTCODE,
                                                   CASE Isnull(Inventory.iGroupType, 0)
                                                     WHEN 0 THEN NULL
                                                     WHEN 1 THEN computationunit1.iChangRate
                                                     WHEN 2 THEN ( CASE Isnull(IFREGBREAKQTYDEALTYPE, 0)
                                                                     WHEN 1 THEN
                                                                       CASE ( Isnull(FCHECKNUM, 0) - Isnull(FsumNum, 0) )
                                                                         WHEN 0 THEN NULL
                                                                         ELSE ( Isnull(FCHECKQTY, 0) - Isnull(FsumQuantity, 0) ) / ( Isnull(FCHECKNUM, 0) - Isnull(FsumNum, 0) )
                                                                       END
                                                                     ELSE
                                                                       CASE ( Isnull(FCHECKNUM, 0) - Isnull(FsumNum, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) / FCHECKCHANGRATE )
                                                                         WHEN 0 THEN NULL
                                                                         ELSE ( Isnull(FCHECKQTY, 0) - Isnull(FsumQuantity, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) ) / ( Isnull(FCHECKNUM, 0) - Isnull(FsumNum, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) / FCHECKCHANGRATE )
                                                                       END
                                                                   END )
                                                   END                                                   AS fchangrate,
                                                   Isnull(QMCHECKVOUCHER.BEXIGENCY, 0)                   AS BEXIGENCY,
                                                   PU_ArrivalVouch.cVenPUOMProtocol,
                                                   AA_Agreement.cName                                    AS cvenpuomprotocolname,
                                                   PU_ArrivalVouchs.cciqbookcode,
                                                   Isnull(PU_ArrivalVouch.iflowid, 0)                    AS iflowid,
                                                   PUBizFlow.cFlowName                                   AS cflowname,
                                                   QMCHECKVOUCHER.FSAMPQTY,
                                                   QMCHECKVOUCHER.FSAMPQTYINS,
                                                   PU_ArrivalVouchs.cbMemo,
                                                   PU_ArrivalVouchs.bgift,
                                                   QMCHECKVOUCHER.CSYSBARCODE,
                                                   QMCHECKVOUCHER.FREGQUANTITY,
                                                   QMCHECKVOUCHER.FREGNUM,
                                                   PU_ArrivalVouch.csysbarcode                           AS carrsysbarcode,
                                                   PU_ArrivalVouchs.cbsysbarcode                         AS carrbsysbarcode,
                                                   QMCHECKVOUCHER.CSOURCEPROORDERCODE                    AS ISOURCEMOCODE,
                                                   QMCHECKVOUCHER.ISOURCEPROORDERAUTOID                  AS ISOURCEMODETAILSID,
                                                   QMCHECKVOUCHER.CPOCODE,
                                                   BMERGECHECKFLAG,
                                                   iPOsID
                                                   --modify by caiwei 2015-2-10 采购入库单参照检验单带不出金额
                                                   ,
                                                   iOriTaxCost,
                                                   iOriCost,
                                                   bTaxCost
                                            FROM   QMCHECKVOUCHER
                                                   INNER JOIN Inventory
                                                           ON QMCHECKVOUCHER.CINVCODE = Inventory.cInvCode
                                                   INNER JOIN PU_ArrivalVouchs
                                                           ON QMCHECKVOUCHER.SOURCEAUTOID = PU_ArrivalVouchs.Autoid
                                                   INNER JOIN PU_ArrivalVouch
                                                           ON PU_ArrivalVouchs.ID = PU_ArrivalVouch.ID
                                                   LEFT JOIN PUBizFlow
                                                          ON PUBizFlow.iFlowID = PU_ArrivalVouch.iflowid
                                                   LEFT JOIN Person
                                                          ON QMCHECKVOUCHER.CCHECKPERSONCODE = Person.cPersonCode
                                                   LEFT JOIN PurchaseType
                                                          ON PU_ArrivalVouch.cPTCode = PurchaseType.cPTCode
                                                   LEFT JOIN Vendor
                                                          ON QMCHECKVOUCHER.CVENCODE = Vendor.cVenCode
                                                   LEFT JOIN Department
                                                          ON QMCHECKVOUCHER.CINSPECTDEPCODE = Department.cDepCode
                                                   LEFT JOIN Person AS person1
                                                          ON PU_ArrivalVouch.cPersonCode = person1.cPersonCode
                                                   LEFT JOIN Warehouse
                                                          ON QMCHECKVOUCHER.CWHCODE = Warehouse.cWhCode
                                                   LEFT JOIN Rd_Style
                                                          ON PurchaseType.cRdCode = Rd_Style.cRdCode
                                                   LEFT JOIN ComputationUnit
                                                          ON Inventory.cComUnitCode = ComputationUnit.cComunitCode
                                                   LEFT JOIN ComputationUnit AS computationunit1
                                                          ON QMCHECKVOUCHER.CUNITID = computationunit1.cComunitCode
                                                   LEFT JOIN AA_Agreement
                                                          ON PU_ArrivalVouch.cVenPUOMProtocol = AA_Agreement.cCode
                                                   LEFT OUTER JOIN SO_SODetails
                                                                ON QMCHECKVOUCHER.IORDERTYPE = 1
                                                                   AND Cast(SO_SODetails.iSOsID AS NVARCHAR(50)) = QMCHECKVOUCHER.ISOORDERAUTOID
                                                   LEFT OUTER JOIN ex_orderdetail
                                                                ON QMCHECKVOUCHER.IORDERTYPE = 3
                                                                   AND Cast(ex_orderdetail.autoid AS NVARCHAR(50)) = QMCHECKVOUCHER.ISOORDERAUTOID
                                            WHERE  Isnull(QMCHECKVOUCHER.CVERIFIER, N'') <> N''
                                                   AND QMCHECKVOUCHER.CVOUCHTYPE = N'qm03'
                                                   AND ( Isnull(FREGQUANTITY, 0)
                                                         + Isnull(FCONQUANTIY, 0) ) > 0
                                                   AND Isnull(PU_ArrivalVouchs.cbcloser, '') = ''
                                                   AND Isnull(QMCHECKVOUCHER.BMERGECHECKFLAG, 0) = 0
                                                   AND Isnull(BPUINFLAG, 0) = 0
                                            UNION
                                            SELECT Cast(QMCHECKVOUCHER.ID AS VARCHAR) + 'D'
                                                   + Cast(QMMergeCheckDetail.AUTOID AS VARCHAR)          AS dkey,
                                                   QMMergeCheckDetail.BPUINFLAG                          AS BPUINFLAG,
                                                   N''                                                   AS selcol,
                                                   QMCHECKVOUCHER.DDATE,
                                                   QMCHECKVOUCHER.CCHECKCODE,
                                                   QMCHECKVOUCHER.CCHECKPERSONCODE,
                                                   Person.cPersonName                                    AS ccheckpersonname,
                                                   QMMergeCheckDetail.DARRIVALDATE,
                                                   QMMergeCheckDetail.SOURCECODE,
                                                   Isnull(PU_ArrivalVouch.cPTCode, '')                   AS cptcode,
                                                   cPTName,
                                                   Isnull(cBusType, '')                                  AS cbustype,
                                                   Isnull(QMCHECKVOUCHER.CVENCODE, '')                   AS cvencode,
                                                   Isnull(PU_ArrivalVouch.cexch_name, '')                AS cexch_name,
                                                   PU_ArrivalVouch.iDiscountTaxType,
                                                   PU_ArrivalVouch.iExchRate,
                                                   Vendor.iId                                            AS vendoriid,
                                                   Vendor.cVenName                                       AS cvenname,
                                                   Isnull(QMMergeCheckDetail.CINSPECTDEPCODE, '')        AS cinspectdepcode,
                                                   Department.cDepName                                   AS cinspectdepname,
                                                   Isnull(PU_ArrivalVouch.cPersonCode, '')               AS cpersoncode,
                                                   person1.cPersonName,
                                                   PU_ArrivalVouch.cMemo,
                                                   QMCHECKVOUCHER.CDEFINE1,
                                                   QMCHECKVOUCHER.CDEFINE2,
                                                   QMCHECKVOUCHER.CDEFINE3,
                                                   QMCHECKVOUCHER.CDEFINE4,
                                                   QMCHECKVOUCHER.CDEFINE5,
                                                   QMCHECKVOUCHER.CDEFINE6,
                                                   QMCHECKVOUCHER.CDEFINE7,
                                                   QMCHECKVOUCHER.CDEFINE8,
                                                   QMCHECKVOUCHER.CDEFINE9,
                                                   QMCHECKVOUCHER.CDEFINE10,
                                                   QMCHECKVOUCHER.CDEFINE11,
                                                   QMCHECKVOUCHER.CDEFINE12,
                                                   QMCHECKVOUCHER.CDEFINE13,
                                                   QMCHECKVOUCHER.CDEFINE14,
                                                   QMCHECKVOUCHER.CDEFINE15,
                                                   QMCHECKVOUCHER.CDEFINE16,
                                                   Isnull(QMMergeCheckDetail.CWHCODE, '')                AS cwhcode,
                                                   cWhName,
                                                   PurchaseType.cRdCode,
                                                   cRdName,
                                                   QMCHECKVOUCHER.CINVCODE,
                                                   Inventory.cInvAddCode,
                                                   Inventory.cInvName,
                                                   Inventory.cInvStd,
                                                   cInvDefine1,
                                                   cInvDefine2,
                                                   cInvDefine3,
                                                   cInvDefine4,
                                                   cInvDefine5,
                                                   cInvDefine6,
                                                   cInvDefine7,
                                                   cInvDefine8,
                                                   cInvDefine9,
                                                   cInvDefine10,
                                                   cInvDefine11,
                                                   cInvDefine12,
                                                   cInvDefine13,
                                                   cInvDefine14,
                                                   cInvDefine15,
                                                   cInvDefine16,
                                                   QMMergeCheckDetail.CFREE1,
                                                   QMMergeCheckDetail.CFREE2,
                                                   QMMergeCheckDetail.CFREE3,
                                                   QMMergeCheckDetail.CFREE4,
                                                   QMMergeCheckDetail.CFREE5,
                                                   QMMergeCheckDetail.CFREE6,
                                                   QMMergeCheckDetail.CFREE7,
                                                   QMMergeCheckDetail.CFREE8,
                                                   QMMergeCheckDetail.CFREE9,
                                                   QMMergeCheckDetail.CFREE10,
                                                   PU_ArrivalVouchs.ivouchrowno,
                                                   QMCHECKVOUCHER.CBATCH,
                                                   QMMergeCheckDetail.DPRODATE,
                                                   PU_ArrivalVouchs.imassdate,
                                                   QMMergeCheckDetail.DVDATE,
                                                   QMMergeCheckDetail.IEXPIRATDATECALCU,
                                                   QMMergeCheckDetail.CEXPIRATIONDATE,
                                                   QMMergeCheckDetail.DEXPIRATIONDATE,
                                                   ComputationUnit.cComUnitName,
                                                   computationunit1.cComUnitName                         AS cunitname,
                                                   CASE Isnull(QMMergeCheckDetail.BPUINFLAG, 0)
                                                     WHEN 0 THEN ( CASE Isnull(Inventory.iGroupType, 0)
                                                                     WHEN 0 THEN 0
                                                                     WHEN 1 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                                     WHEN 1 THEN ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                                   + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) ) / computationunit1.iChangRate
                                                                                     ELSE ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                            + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) ) / computationunit1.iChangRate
                                                                                   END )
                                                                     WHEN 2 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                                     WHEN 1 THEN ( Isnull(QMMergeCheckDetail.FCHECKNUM, 0) - Isnull(QMMergeCheckDetail.FSUMNUM, 0) )
                                                                                     ELSE ( Isnull(QMMergeCheckDetail.FCHECKNUM, 0) - Isnull(QMMergeCheckDetail.FSUMNUM, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) / QMCHECKVOUCHER.FCHECKCHANGRATE )
                                                                                   END )
                                                                   END )
                                                     ELSE 0
                                                   END                                                   AS fnum,
                                                   iCost                                                 AS fcost,
                                                   ioritaxcost                                           AS iunitcost,
                                                   iInvRCost                                             AS finvrcost,
                                                   CASE Isnull(QMMergeCheckDetail.BPUINFLAG, 0)
                                                     WHEN 0 THEN ( CASE Isnull(Inventory.iGroupType, 0)
                                                                     WHEN 0 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                                     WHEN 1 THEN ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                                   + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                                     ELSE ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                            + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                                   END )
                                                                     WHEN 1 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                                     WHEN 1 THEN ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                                   + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                                     ELSE ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                            + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                                   END )
                                                                     WHEN 2 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                                     WHEN 1 THEN ( Isnull(QMMergeCheckDetail.FCHECKQTY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                                     ELSE ( Isnull(QMMergeCheckDetail.FCHECKQTY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) )
                                                                                   END )
                                                                   END )
                                                     ELSE 0
                                                   END                                                   AS fquantity,
                                                   CASE Isnull(QMMergeCheckDetail.BPUINFLAG, 0)
                                                     WHEN 0 THEN ( CASE Isnull(Inventory.iGroupType, 0)
                                                                     WHEN 0 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                                     WHEN 1 THEN ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                                   + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                                     ELSE ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                            + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                                   END )
                                                                     WHEN 1 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                                     WHEN 1 THEN ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                                   + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                                     ELSE ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                            + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                                   END )
                                                                     WHEN 2 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                                     WHEN 1 THEN ( Isnull(QMMergeCheckDetail.FCHECKQTY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                                     ELSE ( Isnull(QMMergeCheckDetail.FCHECKQTY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) )
                                                                                   END )
                                                                   END * iCost )
                                                     ELSE 0
                                                   END                                                   AS fmoney,
                                                   ( CASE Isnull(Inventory.iGroupType, 0)
                                                       WHEN 0 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                       WHEN 1 THEN ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                     + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                       ELSE ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                              + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                     END )
                                                       WHEN 1 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                       WHEN 1 THEN ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                                     + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                       ELSE ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                                              + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                     END )
                                                       WHEN 2 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                       WHEN 1 THEN ( Isnull(QMMergeCheckDetail.FCHECKQTY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) )
                                                                       ELSE ( Isnull(QMMergeCheckDetail.FCHECKQTY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) )
                                                                     END )
                                                     END * iInvRCost )                                   AS finvrmoney,
                                                   PU_ArrivalVouchs.cDefine22,
                                                   PU_ArrivalVouchs.cDefine23,
                                                   PU_ArrivalVouchs.cDefine24,
                                                   PU_ArrivalVouchs.cDefine25,
                                                   PU_ArrivalVouchs.cDefine26,
                                                   PU_ArrivalVouchs.cDefine27,
                                                   PU_ArrivalVouchs.cDefine28,
                                                   PU_ArrivalVouchs.cDefine29,
                                                   PU_ArrivalVouchs.cDefine30,
                                                   PU_ArrivalVouchs.cDefine31,
                                                   PU_ArrivalVouchs.cDefine32,
                                                   PU_ArrivalVouchs.cDefine33,
                                                   PU_ArrivalVouchs.cDefine34,
                                                   PU_ArrivalVouchs.cDefine35,
                                                   PU_ArrivalVouchs.cDefine36,
                                                   PU_ArrivalVouchs.cDefine37,
                                                   QMCHECKVOUCHER.ID,
                                                   QMMergeCheckDetail.SOURCEAUTOID,
                                                   Inventory.cComUnitCode,
                                                   QMMergeCheckDetail.AUTOID                             AS autoid,
                                                   QMCHECKVOUCHER.CUNITID,
                                                   QMMergeCheckDetail.CITEMCLASS,
                                                   QMMergeCheckDetail.CITEMCNAME,
                                                   QMMergeCheckDetail.CITEMCODE,
                                                   QMMergeCheckDetail.CITEMNAME,
                                                   bFree1,
                                                   bFree2,
                                                   bFree3,
                                                   bFree4,
                                                   bFree5,
                                                   bFree6,
                                                   bFree7,
                                                   bFree8,
                                                   bFree9,
                                                   bFree10,
                                                   --( CASE
                                                   --WHEN bFree1 = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS bfree1 ,
                                                   --( CASE
                                                   --WHEN bFree2 = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS bfree2 ,
                                                   --( CASE
                                                   --WHEN bFree3 = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS bfree3 ,
                                                   --( CASE
                                                   --WHEN bFree4 = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS bfree4 ,
                                                   --( CASE
                                                   --WHEN bFree5 = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS bfree5 ,
                                                   --( CASE
                                                   --WHEN bFree6 = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS bfree6 ,
                                                   --( CASE
                                                   --WHEN bFree7 = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS bfree7 ,
                                                   --( CASE
                                                   --WHEN bFree8 = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS bfree8 ,
                                                   --( CASE
                                                   --WHEN bFree9 = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS bfree9 ,
                                                   --( CASE
                                                   --WHEN bFree10 = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS bfree10 ,
                                                   Inventory.cGroupCode,
                                                   iGroupType,
                                                   bService                                              AS bservice,
                                                   bInvBatch                                             AS binvbatch,
                                                   --( CASE
                                                   --WHEN bService = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS bservice ,
                                                   --( CASE
                                                   --WHEN bInvBatch = 1
                                                   --THEN N'是'
                                                   --ELSE N'否'
                                                   --END ) AS binvbatch ,
                                                   CONVERT(CHAR, CONVERT(MONEY, QMCHECKVOUCHER.UFTS), 2) AS ufts,
                                                   ( CASE PU_ArrivalVouchs.cmassunit
                                                       WHEN 1 THEN N'年'
                                                       WHEN 2 THEN N'月'
                                                       WHEN 3 THEN N'日'
                                                       ELSE N''
                                                     END )                                               AS cmassunit,
                                                   --QMMergeCheckDetail.IORDERTYPE ,
                                                   PU_ArrivalVouchs.iordertype,
                                                   PU_ArrivalVouchs.SoType                               AS isotype,
                                                   QMMergeCheckDetail.CSOORDERCODE                       AS csocode,
                                                   CASE QMMergeCheckDetail.IORDERTYPE
                                                     WHEN 1 THEN SO_SODetails.iRowNo
                                                     WHEN 3 THEN ex_orderdetail.irowno
                                                     ELSE NULL
                                                   END                                                   AS isoseq,
                                                   --QMMergeCheckDetail.ISOORDERAUTOID AS iSoDID ,
                                                   PU_ArrivalVouchs.SoDId                                AS isodid,
                                                   QMMergeCheckDetail.IORDERDID,
                                                   QMMergeCheckDetail.ISOORDERTYPE,
                                                   QMMergeCheckDetail.CORDERCODE,
                                                   QMMergeCheckDetail.IORDERSEQ,
                                                   QMCHECKVOUCHER.cBatchProperty1,
                                                   QMCHECKVOUCHER.cBatchProperty2,
                                                   QMCHECKVOUCHER.cBatchProperty3,
                                                   QMCHECKVOUCHER.cBatchProperty4,
                                                   QMCHECKVOUCHER.cBatchProperty5,
                                                   QMCHECKVOUCHER.cBatchProperty6,
                                                   QMCHECKVOUCHER.cBatchProperty7,
                                                   QMCHECKVOUCHER.cBatchProperty8,
                                                   QMCHECKVOUCHER.cBatchProperty9,
                                                   QMCHECKVOUCHER.cBatchProperty10,
                                                   Inventory.iId,
                                                   QMCHECKVOUCHER.CCONTRACTSTRCODE,
                                                   QMCHECKVOUCHER.CCONTRACTCODE,
                                                   CASE Isnull(Inventory.iGroupType, 0)
                                                     WHEN 0 THEN NULL
                                                     WHEN 1 THEN computationunit1.iChangRate
                                                     WHEN 2 THEN ( CASE Isnull(QMCHECKVOUCHER.IFREGBREAKQTYDEALTYPE, 0)
                                                                     WHEN 1 THEN
                                                                       CASE ( Isnull(QMMergeCheckDetail.FCHECKNUM, 0) - Isnull(QMMergeCheckDetail.FSUMNUM, 0) )
                                                                         WHEN 0 THEN NULL
                                                                         ELSE ( Isnull(QMMergeCheckDetail.FCHECKQTY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) ) / ( Isnull(QMMergeCheckDetail.FCHECKNUM, 0) - Isnull(QMMergeCheckDetail.FSUMNUM, 0) )
                                                                       END
                                                                     ELSE
                                                                       CASE ( Isnull(QMMergeCheckDetail.FCHECKNUM, 0) - Isnull(QMMergeCheckDetail.FSUMNUM, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) / QMCHECKVOUCHER.FCHECKCHANGRATE )
                                                                         WHEN 0 THEN NULL
                                                                         ELSE ( Isnull(QMMergeCheckDetail.FCHECKQTY, 0) - Isnull(QMMergeCheckDetail.FSUMQUANTITY, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) ) / ( Isnull(QMMergeCheckDetail.FCHECKNUM, 0) - Isnull(QMMergeCheckDetail.FSUMNUM, 0) - Isnull(QMMergeCheckDetail.FREGBREAKQUANTITY, 0) * Isnull(QMCHECKVOUCHER.FCHECKRATE, 1) / QMCHECKVOUCHER.FCHECKCHANGRATE )
                                                                       END
                                                                   END )
                                                   END                                                   AS fchangrate,
                                                   Isnull(QMCHECKVOUCHER.BEXIGENCY, 0)                   AS BEXIGENCY,
                                                   PU_ArrivalVouch.cVenPUOMProtocol,
                                                   AA_Agreement.cName                                    AS cvenpuomprotocolname,
                                                   PU_ArrivalVouchs.cciqbookcode,
                                                   Isnull(PU_ArrivalVouch.iflowid, 0)                    AS iflowid,
                                                   PUBizFlow.cFlowName                                   AS cflowname,
                                                   QMCHECKVOUCHER.FSAMPQTY,
                                                   QMCHECKVOUCHER.FSAMPQTYINS,
                                                   PU_ArrivalVouchs.cbMemo,
                                                   PU_ArrivalVouchs.bgift,
                                                   QMCHECKVOUCHER.CSYSBARCODE,
                                                   QMMergeCheckDetail.FREGQUANTITY,
                                                   QMMergeCheckDetail.FREGNUM,
                                                   PU_ArrivalVouch.csysbarcode                           AS carrsysbarcode,
                                                   PU_ArrivalVouchs.cbsysbarcode                         AS carrbsysbarcode,
                                                   QMMergeCheckDetail.CSOURCEPROORDERCODE                AS ISOURCEMOCODE,
                                                   QMMergeCheckDetail.ISOURCEPROORDERAUTOID              AS ISOURCEMODETAILSID,
                                                   QMMergeCheckDetail.CPOCODE,
                                                   BMERGECHECKFLAG,
                                                   iPOsID
                                                   --modify by caiwei 2015-2-10 采购入库单参照检验单带不出金额
                                                   ,
                                                   iOriTaxCost,
                                                   iOriCost,
                                                   bTaxCost
                                            FROM   QMCHECKVOUCHER
                                                   INNER JOIN QMMergeCheckDetail
                                                           ON Isnull(QMCHECKVOUCHER.BMERGECHECKFLAG, 0) = 1
                                                              AND QMCHECKVOUCHER.ID = QMMergeCheckDetail.ID
                                                   INNER JOIN Inventory
                                                           ON QMCHECKVOUCHER.CINVCODE = Inventory.cInvCode
                                                   INNER JOIN PU_ArrivalVouchs
                                                           ON QMMergeCheckDetail.SOURCEAUTOID = PU_ArrivalVouchs.Autoid
                                                   INNER JOIN PU_ArrivalVouch
                                                           ON PU_ArrivalVouchs.ID = PU_ArrivalVouch.ID
                                                   LEFT JOIN PUBizFlow
                                                          ON PUBizFlow.iFlowID = PU_ArrivalVouch.iflowid
                                                   LEFT JOIN Person
                                                          ON QMCHECKVOUCHER.CCHECKPERSONCODE = Person.cPersonCode
                                                   LEFT JOIN PurchaseType
                                                          ON PU_ArrivalVouch.cPTCode = PurchaseType.cPTCode
                                                   LEFT JOIN Vendor
                                                          ON QMCHECKVOUCHER.CVENCODE = Vendor.cVenCode
                                                   LEFT JOIN Department
                                                          ON QMMergeCheckDetail.CINSPECTDEPCODE = Department.cDepCode
                                                   LEFT JOIN Person AS person1
                                                          ON PU_ArrivalVouch.cPersonCode = person1.cPersonCode
                                                   LEFT JOIN Warehouse
                                                          ON QMMergeCheckDetail.CWHCODE = Warehouse.cWhCode
                                                   LEFT JOIN Rd_Style
                                                          ON PurchaseType.cRdCode = Rd_Style.cRdCode
                                                   LEFT JOIN ComputationUnit
                                                          ON Inventory.cComUnitCode = ComputationUnit.cComunitCode
                                                   LEFT JOIN ComputationUnit AS computationunit1
                                                          ON QMMergeCheckDetail.CUNITID = computationunit1.cComunitCode
                                                   LEFT JOIN AA_Agreement
                                                          ON PU_ArrivalVouch.cVenPUOMProtocol = AA_Agreement.cCode
                                                   LEFT OUTER JOIN SO_SODetails
                                                                ON QMMergeCheckDetail.IORDERTYPE = 1
                                                                   AND Cast(SO_SODetails.iSOsID AS NVARCHAR(50)) = QMMergeCheckDetail.ISOORDERAUTOID
                                                   LEFT OUTER JOIN ex_orderdetail
                                                                ON QMMergeCheckDetail.IORDERTYPE = 3
                                                                   AND Cast(ex_orderdetail.autoid AS NVARCHAR(50)) = QMMergeCheckDetail.ISOORDERAUTOID
                                            WHERE  Isnull(QMCHECKVOUCHER.CVERIFIER, N'') <> N''
                                                   AND QMCHECKVOUCHER.CVOUCHTYPE = N'qm03'
                                                   AND ( Isnull(QMMergeCheckDetail.FREGQUANTITY, 0)
                                                         + Isnull(QMMergeCheckDetail.FCONQUANTIY, 0) ) > 0
                                                   AND Isnull(PU_ArrivalVouchs.cbcloser, '') = ''
                                                   AND Isnull(QMMergeCheckDetail.BPUINFLAG, 0) = 0) AS aa) AS bb
                            WHERE  1 = 1) AS QMList
                    WHERE  CCHECKCODE IN (SELECT DISTINCT cCode
                                          FROM   #STPDATempSICheckVoucherCodes)) tab
            ORDER  BY tab.CCHECKCODE ASC;

            --删除临时表
            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDATempSICheckVoucherCodes') IS NULL)
              DROP TABLE #STPDATempSICheckVoucherCodes;
        END;
      ELSE IF ( @OperType = N'A' )
        --入库验收单
        BEGIN
            DECLARE @GSPVouchQCCodes NVARCHAR(MAX);

            BEGIN
                --验收单号
                SET @GSPVouchQCCodes = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'qccodes', DEFAULT, DEFAULT);

                IF ( @GSPVouchQCCodes <> N'' )
                  BEGIN
                      IF EXISTS (SELECT 0
                                 WHERE  NOT Object_id('tempdb..#STPDATempGSPQCVoucherCodes') IS NULL)
                        DROP TABLE #STPDATempGSPQCVoucherCodes;

                      CREATE TABLE #STPDATempGSPQCVoucherCodes
                        (
                           QCID NVARCHAR(30)
                        );

                      INSERT INTO #STPDATempGSPQCVoucherCodes
                      EXEC Proc_ts_splitparamstring
                        @GSPVouchQCCodes;
                  END;
            END;

            --入库验收单单据条码
            SET NOCOUNT ON;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDAPurchaseINGSPQCRefIDs') IS NULL)
              DROP TABLE #STPDAPurchaseINGSPQCRefIDs;

            SELECT IDENTITY(INT)        AS tmpId,
                   CONVERT(INT, 0)      AS M_ID,
                   CONVERT(INT, 0)      AS S_ID,
                   CONVERT(MONEY, ufts) AS oriufts
            INTO   #STPDAPurchaseINGSPQCRefIDs
            FROM   GSP_VouchQC
            WHERE  1 = 0;

            CREATE CLUSTERED INDEX ix_STPDAPurchaseINRefIDs_tmpid_813
              ON #STPDAPurchaseINGSPQCRefIDs( M_ID, S_ID, tmpId );

            SET @SqlCommand = 'INSERT INTO #STPDAPurchaseINGSPQCRefIDs ( M_ID ,S_ID ,oriufts)
SELECT  GSP_VouchQC.id,GSP_VouchsQC.autoid,CONVERT(MONEY,GSP_VouchQC.ufts)
FROM    GSP_VouchsQC
    INNER JOIN GSP_VouchQC ON GSP_VouchQC.id = GSP_VouchsQC.id
WHERE 1=1 and GSP_VOUCHQC.CVOUCHTYPE in (''001'',''002'',''003'',''035'',''036'',''081'',''082'',''083'') 
and ISNULL(GSP_VOUCHQC.CVERIFIER,'''')<>''''
and ISNULL(FELGQUANTITY,0)-ISNULL(FSTQTY,0)<>0 and isnull(dbo.GSP_VOUCHSQC.BMAKEPURIN,0)=0 ';

            --药品入库质量验收记录单号
            IF( @GSPVouchQCCodes <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (QCID IN (SELECT DISTINCT QCID FROM #STPDATempGSPQCVoucherCodes))';

            IF( @CSYSBARCODE <> N'' )
              SET @SqlCommand=@SqlCommand
                              + ' AND (GSP_VouchQC.CBSYSBARCODE =@CSYSBARCODE) ';

            SET @ParmList = '@GSPVouchQCCodes  NVARCHAR(MAX),@CSYSBARCODE NVARCHAR(1000)'

            EXEC Sp_executesql
              @SqlCommand,
              @ParmList,
              @GSPVouchQCCodes=@GSPVouchQCCodes,
              @CSYSBARCODE=@CSYSBARCODE

            SELECT IDENTITY(INT) AS tmpId,
                   M_ID,
                   Max(oriufts)  AS oriufts
            INTO   #STPDAPurchaseINGSPQCRefID
            FROM   #STPDAPurchaseINGSPQCRefIDs
            GROUP  BY M_ID;

            CREATE CLUSTERED INDEX ix_STPDARefID_tmpid_813
              ON #STPDAPurchaseINGSPQCRefID( tmpId, M_ID );

            SET NOCOUNT OFF;
            SET @SqlHEADCommand=N'';
            SET @SqlHEADCommand=N' SELECT DISTINCT CONVERT(BIT, 0)                              isChecked,
                ''''                                           AS selcol,
                ''入库验收单''                                      AS csource,
                GSP_VouchQC.id,
                QCID                                         ccode,--PU_ArrBody.cordercode,
                QCID                                         AS cbuscode,
                QCID                                         AS cchkCode,
                CONVERT(VARCHAR(10), GSP_VouchQC.ddate, 120) AS ddate,
                GSP_VouchQC.ddate                            AS dchkdate,
                GSP_VouchQC.cmaker                           AS cchkPerson,
                0                                            AS bomfirst,
                GSP_VouchQC.ccode                            carvcode,
				GSP_VouchQC.ICODE as ipurarriveid,
                GSP_VouchQC.DArvDate,
                pu_ArrHead.cdepcode,
                cdepname,
                pu_ArrHead.cptcode,
                pu_ArrHead.cptname,
                GSP_VouchQC.cdefine1,
                GSP_VouchQC.cdefine2,
                GSP_VouchQC.cdefine3,
                GSP_VouchQC.cdefine4,
                GSP_VouchQC.cdefine5,
                GSP_VouchQC.cdefine6,
                GSP_VouchQC.cdefine7,
                GSP_VouchQC.cdefine8,
                GSP_VouchQC.cdefine9,
                GSP_VouchQC.cdefine10,
                GSP_VouchQC.cdefine11,
                GSP_VouchQC.cdefine12,
                GSP_VouchQC.cdefine13,
                GSP_VouchQC.cdefine14,
                GSP_VouchQC.cdefine15,
                GSP_VouchQC.cdefine16,
                cbustype,
                pu_ArrHead.cvencode,
                cvenabbname,
                cpersoncode,
                cpersonname,
                GSP_VouchQC.cmemo,
                GSP_VouchQC.ufts,
                GSP_VouchQC.cmaker,
                cexch_name,
                iexchrate,
                pu_ArrHead.itaxrate,
                ''''                                           AS coufts,
                pu_ArrHead.id,
                cvenpuomprotocol,
                cvenpuomprotocolname,
                Isnull(iflowid, 0)                           iflowid,
                Isnull(idiscounttaxtype, 0)                  idiscounttaxtype,
                cflowname,
                GSP_VouchQC.CBSYSBARCODE                     csysbarcode,
                PurchaseType.cRdCode,
                cRdName
FROM   GSP_VouchQC WITH (nolock)
       INNER JOIN dbo.GSP_VOUCHSQC
               ON dbo.GSP_VOUCHQC.ID = dbo.GSP_VOUCHSQC.ID
       LEFT JOIN PU_ArrBody
              ON dbo.GSP_VOUCHSQC.ICODE_T = PU_ArrBody.Autoid
       LEFT JOIN pu_ArrHead
              ON pu_ArrHead.ccode = GSP_VOUCHQC.CCODE
       LEFT JOIN PurchaseType
              ON PurchaseType.cPTCode = pu_ArrHead.cptcode
       LEFT JOIN Rd_Style
              ON PurchaseType.cRdCode = Rd_Style.cRdCode
WHERE  ( ( 1 > 0 )
         AND ( 1 > 0 ) )
       AND ( 1 > 0 )
       AND bgsp = 1
       AND GSP_VOUCHQC.CVOUCHTYPE IN ( ''001'', ''002'', ''003'', ''035'',
                                       ''036'', ''081'', ''082'', ''083'' )
       AND Isnull(GSP_VOUCHQC.CVERIFIER, '''') <> ''''
       AND Isnull(FELGQUANTITY, 0) - Isnull(FSTQTY, 0) <> 0
       AND Isnull(dbo.GSP_VOUCHSQC.BMAKEPURIN, 0) = 0 
                   AND GSP_VouchQC.ID IN (SELECT M_ID
                                          FROM   #STPDAPurchaseINGSPQCRefID)';

            EXEC Sp_executesql
              @SqlHEADCommand;

            IF ( @GetType = N'DETAIL' )
              BEGIN
                  SET @SqlBODYCommand=N'';
                  SET @SqlBODYCommand=N' SELECT ''''                                                         AS selcol,
                         GSP_VouchsQC.cwhcode,
                         cwhname,
						 GSP_VouchQC.cmaker as ccheckperson,
						 GSP_VouchQC.ddate as dcheckDate,
                         GSP_VouchsQC.cinvcode,
                         cinvaddcode,
                         cinvname,
                         cinvstd,
                         cinvdefine1,
                         cinvdefine2,
                         cinvdefine3,
                         cinvdefine4,
                         cinvdefine5,
                         cinvdefine6,
                         cinvdefine7,
                         cinvdefine8,
                         cinvdefine9,
                         cinvdefine10,
                         cinvdefine11,
                         cinvdefine12,
                         cinvdefine13,
                         cinvdefine14,
                         cinvdefine15,
                         cinvdefine16,
                         ccomunitcode,
                         cinvm_unit,
                         GSP_VouchsQC.cunitid,
                         cinva_unit,
                         iinvexchrate,
                         GSP_VouchsQC.cfree1,
                         GSP_VouchsQC.cfree2,
                         GSP_VouchsQC.cfree3,
                         GSP_VouchsQC.cfree4,
                         GSP_VouchsQC.cfree5,
                         GSP_VouchsQC.cfree6,
                         GSP_VouchsQC.cfree7,
                         GSP_VouchsQC.cfree8,
                         GSP_VouchsQC.cfree9,
                         GSP_VouchsQC.cfree10,
                         GSP_VouchsQC.cbatch,
                         ( dpdate )                                                 AS dmadedate,
                         GSP_VouchsQC.imassdate,
                         GSP_VouchsQC.dvdate,
                         citem_class,
                         ( citem_name )                                             AS citemcname,
                         ''''                                                         AS cinvouchcode,
                         citemcode,
                         ( citemname )                                              AS cname,
                         GSP_VOUCHSQC.FELGQUANTITY - Isnull(GSP_VOUCHSQC.FSTQTY, 0) iquantity,
                         Isnull(FQUANTITY, 0)                                       inquantity,
                         GSP_VOUCHSQC.FELGQUANTITYS - Isnull(GSP_VOUCHSQC.FSTnum, 0)inum,
                         Isnull(FQUANTITYS, 0)                                      innum,
                         pu_ArrBody.autoid,
                         ''''                                                         cpoid,
                         iposid,
                         iinvmpcost,
                         ( CONVERT(INT, NULL) )                                     AS icorid,
                         icost,
                         pu_arrbody.id,
                         ioricost,
                         iorimoney,
                         iorisum,
                         ioritaxcost,
                         ioritaxprice,
                         pu_ArrBody.itaxrate                                        AS ipertaxrate,
                         igrouptype,
                         imoney,
                         sodid                                                      cdemandid,
                         isum,
                         itaxprice,
                         ''''                                                         AS bquansign,
                         btaxcost,
                         GSP_VOUCHSQC.contractcode,
                         contractrowno,
                         GSP_VOUCHSQC.cmassunit,
                         GSP_VOUCHSQC.cdefine22,
                         GSP_VOUCHSQC.cdefine23,
                         GSP_VOUCHSQC.cdefine24,
                         GSP_VOUCHSQC.cdefine25,
                         GSP_VOUCHSQC.cdefine26,
                         GSP_VOUCHSQC.cdefine27,
                         GSP_VOUCHSQC.cdefine28,
                         GSP_VOUCHSQC.cdefine29,
                         GSP_VOUCHSQC.cdefine30,
                         GSP_VOUCHSQC.cdefine31,
                         GSP_VOUCHSQC.cdefine32,
                         GSP_VOUCHSQC.cdefine33,
                         GSP_VOUCHSQC.cdefine34,
                         GSP_VOUCHSQC.cdefine35,
                         GSP_VOUCHSQC.cdefine36,
                         GSP_VOUCHSQC.cdefine37,
                         sotype                                                     idemandtype,
                         csocode                                                    cdemandcode,
                         irowno                                                     idemandseq,
                         iorderdid,
                         iorderseq,
                         iordertype,
                         csoordercode,
                         iexpiratdatecalcu,
                         cexpirationdate,
                         dexpirationdate,
                         GSP_VOUCHSQC.cbatchproperty1,
                         GSP_VOUCHSQC.cbatchproperty2,
                         GSP_VOUCHSQC.cbatchproperty3,
                         GSP_VOUCHSQC.cbatchproperty4,
                         GSP_VOUCHSQC.cbatchproperty5,
                         GSP_VOUCHSQC.cbatchproperty6,
                         GSP_VOUCHSQC.cbatchproperty7,
                         GSP_VOUCHSQC.cbatchproperty8,
                         GSP_VOUCHSQC.cbatchproperty9,
                         GSP_VOUCHSQC.cbatchproperty10,
                         ivouchrowno,
                         bGsp,
                         binspect,
                         pu_ArrHead.ccode                                           cbarvcode,
                         pu_ArrBody.autoid                                          AS iArrsId,
						 pu_ArrBody.itaxrate,
                         GSP_VouchsQC.cbsysbarcode,
                         bgift,
                         QCID                                                       ccheckcode,
                         GSP_VouchsQC.AUTOID                                        icheckids,
					GSP_VouchsQC.cordercode as 	 cpoid

                  FROM   GSP_VouchsQC
                         INNER JOIN GSP_VOUCHQC
                                 ON GSP_VOUCHQC.ID = dbo.GSP_VOUCHSQC.ID
                         LEFT JOIN pu_arrbody
                                ON GSP_VouchsQC.ICODE_T = pu_ArrBody.autoid
                         LEFT JOIN pu_ArrHead
                                ON pu_ArrHead.id = pu_ArrBody.id
                  WHERE  Isnull(FELGQUANTITY, 0) - Isnull(FSTQTY, 0) <> 0
                         AND bgsp = 1
                         AND GSP_VouchsQC.ID IN (SELECT M_ID
                                                 FROM   #STPDAPurchaseINGSPQCRefID)';

                  EXEC Sp_executesql
                    @SqlBODYCommand;
              END;

            --删除临时表
            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDATempGSPQCVoucherCodes') IS NULL)
              DROP TABLE #STPDATempGSPQCVoucherCodes;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDAPurchaseINGSPQCRefIDs') IS NULL)
              DROP TABLE #STPDAPurchaseINGSPQCRefIDs;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDAPurchaseINGSPQCRefID') IS NULL)
              DROP TABLE #STPDAPurchaseINGSPQCRefID;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDATempArrIDs') IS NULL)
              DROP TABLE #STPDATempArrIDs;
        END;
      ELSE IF ( @OperType = N'B' )
        --处理通知单
        BEGIN
            DECLARE @GSPVouchINFORMCodes NVARCHAR(MAX);

            BEGIN
                --单号
                SET @GSPVouchINFORMCodes = dbo.Func_ts_getparamvaluebysplitstring(@ParamsList, N'cinids', DEFAULT, DEFAULT);

                IF ( @GSPVouchINFORMCodes <> N'' )
                  BEGIN
                      IF EXISTS (SELECT 0
                                 WHERE  NOT Object_id('tempdb..#STPDATempGSPINFORMVoucherCodes') IS NULL)
                        DROP TABLE #STPDATempGSPINFORMVoucherCodes;

                      CREATE TABLE #STPDATempGSPINFORMVoucherCodes
                        (
                           CINID NVARCHAR(30)
                        );

                      INSERT INTO #STPDATempGSPINFORMVoucherCodes
                      EXEC Proc_ts_splitparamstring
                        @GSPVouchINFORMCodes;
                  END;
            END;

            --处理通知单条码
            SET NOCOUNT ON;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDAPurchaseINGSPINFORMRefIDs') IS NULL)
              DROP TABLE #STPDAPurchaseINGSPINFORMRefIDs;

            SELECT IDENTITY(INT)        AS tmpId,
                   CONVERT(INT, 0)      AS M_ID,
                   CONVERT(INT, 0)      AS S_ID,
                   CONVERT(MONEY, ufts) AS oriufts
            INTO   #STPDAPurchaseINGSPINFORMRefIDs
            FROM   GSP_VOUCHINFORM
            WHERE  1 = 0;

            CREATE CLUSTERED INDEX ix_STPDAPurchaseINRefIDs_tmpid_813
              ON #STPDAPurchaseINGSPINFORMRefIDs( M_ID, S_ID, tmpId );

            SET @SqlCommand = 'INSERT INTO #STPDAPurchaseINGSPINFORMRefIDs ( M_ID ,S_ID ,oriufts)
SELECT  GSP_VOUCHINFORM.id,GSP_VOUCHINFORMS.autoid,CONVERT(MONEY,GSP_VOUCHINFORM.ufts)
FROM  GSP_VOUCHINFORM  
	                               inner join GSP_VOUCHINFORMS ON  GSP_VOUCHINFORMS.ID=GSP_VOUCHINFORM.ID   
	                               inner JOIN GSP_VOUCHSQC on GSP_VOUCHSQC.AUTOID=GSP_VOUCHINFORM.CSOURCEAUTOID
	                               inner join GSP_VOUCHQC ON  GSP_VOUCHQC.ID=GSP_VOUCHSQC.ID and GSP_VOUCHQC.CVOUCHTYPE in (''001'',''002'',''003'',''035'',''036'',''081'',''082'',''083'')
                                   left join pu_ArrHead on  pu_ArrHead.ccode = GSP_VOUCHQC.CCODE
                                   left join PurchaseType on PurchaseType.cPTCode=pu_ArrHead.cptcode
                                   left join Rd_Style on PurchaseType.cRdCode=Rd_Style.cRdCode
                                   where GSP_VOUCHINFORM.cSource in (''001'',''002'',''003'',''035'',''036'',''081'',''082'',''083'') 
								   and (GSP_VOUCHINFORMS.CPROCESS=''先暂存后退货'' or GSP_VOUCHINFORMS.CPROCESS=''入库报损'') 
								   and ISNULL(dbo.GSP_VOUCHINFORM.CVERIFIER,'''')<>'''' 
								   and isnull(GSP_VOUCHSQC.BMAKESCRAPIN,0)=0 and isnull(GSP_VOUCHINFORMS.FQTY,0)-isnull(GSP_VOUCHINFORMS.FOUTINQTY,0)<>0';

            --药品入库质量验收记录单号
            IF( @GSPVouchINFORMCodes <> N'' )
              SET @SqlCommand = @SqlCommand
                                + ' AND (CINID IN (SELECT DISTINCT CINID FROM #STPDATempGSPINFORMVoucherCodes))';

            IF( @CSYSBARCODE <> N'' )
              SET @SqlCommand=@SqlCommand
                              + ' AND (GSP_VOUCHINFORM.CBSYSBARCODE =@CSYSBARCODE) ';

            SET @ParmList = '@GSPVouchINFORMCodes	NVARCHAR(MAX),@CSYSBARCODE NVARCHAR(1000)'

            EXEC Sp_executesql
              @SqlCommand,
              @ParmList,
              @GSPVouchINFORMCodes,
              @CSYSBARCODE=@CSYSBARCODE

            SELECT IDENTITY(INT) AS tmpId,
                   M_ID,
                   Max(oriufts)  AS oriufts
            INTO   #STPDAPurchaseINGSPINFORMRefID
            FROM   #STPDAPurchaseINGSPINFORMRefIDs
            GROUP  BY M_ID;

            CREATE CLUSTERED INDEX ix_STPDARefID_tmpid_813
              ON #STPDAPurchaseINGSPINFORMRefID( tmpId, M_ID );

            SET NOCOUNT OFF;
            SET @SqlHEADCommand=N'';
            SET @SqlHEADCommand=N'SELECT DISTINCT CONVERT(BIT, 0)                                  isChecked,
                            ''''                                               AS selcol,
							''处理通知单'' as csource,
                            GSP_VOUCHINFORM.id,
                            CINID                                            ccode,
                            CONVERT(VARCHAR(10), GSP_VOUCHINFORM.ddate, 120) AS ddate,
                            GSP_VOUCHQC.ccode                                carvcode,
                            icode                                            ipurarriveid,
                            pu_ArrHead.cdepcode,
                            cdepname,
                            pu_ArrHead.cptcode,
                            pu_ArrHead.cptname,
                            cpersoncode,
                            GSP_VOUCHINFORM.cdefine1,
                            GSP_VOUCHINFORM.cdefine2,
                            GSP_VOUCHINFORM.cdefine3,
                            GSP_VOUCHINFORM.cdefine4,
                            GSP_VOUCHINFORM.cdefine5,
                            GSP_VOUCHINFORM.cdefine6,
                            GSP_VOUCHINFORM.cdefine7,
                            GSP_VOUCHINFORM.cdefine8,
                            GSP_VOUCHINFORM.cdefine9,
                            GSP_VOUCHINFORM.cdefine10,
                            GSP_VOUCHINFORM.cdefine11,
                            GSP_VOUCHINFORM.cdefine12,
                            GSP_VOUCHINFORM.cdefine13,
                            GSP_VOUCHINFORM.cdefine14,
                            GSP_VOUCHINFORM.cdefine15,
                            GSP_VOUCHINFORM.cdefine16,
                            cbustype,
                            pu_ArrHead.cvencode,
                            cvenabbname,
                            cpersoncode,
                            cpersonname,
                            GSP_VOUCHINFORM.cmemo,
                            GSP_VOUCHINFORM.ufts,
                            GSP_VOUCHINFORM.cmaker,
                            cexch_name,
                            iexchrate,
                            pu_ArrHead.itaxrate,
                            ''''                                               AS coufts,
                            pu_ArrHead.id,
                            cvenpuomprotocol,
                            cvenpuomprotocolname,
                            Isnull(iflowid, 0)                               iflowid,
                            Isnull(idiscounttaxtype, 0)                      idiscounttaxtype,
                            cflowname,
                            GSP_VOUCHINFORM.CBSYSBARCODE                     csysbarcode,
                            PurchaseType.cRdCode,
                            cRdName
            FROM   GSP_VOUCHINFORM
                   INNER JOIN GSP_VOUCHINFORMS
                           ON GSP_VOUCHINFORMS.ID = GSP_VOUCHINFORM.ID
                   INNER JOIN GSP_VOUCHSQC
                           ON GSP_VOUCHSQC.AUTOID = GSP_VOUCHINFORM.CSOURCEAUTOID
                   INNER JOIN GSP_VOUCHQC
                           ON GSP_VOUCHQC.ID = GSP_VOUCHSQC.ID
                              AND GSP_VOUCHQC.CVOUCHTYPE IN ( ''001'', ''002'', ''003'', ''035'',
                                                              ''036'', ''081'', ''082'', ''083'' )
                   LEFT JOIN pu_ArrHead
                          ON pu_ArrHead.ccode = GSP_VOUCHQC.CCODE
                   LEFT JOIN PurchaseType
                          ON PurchaseType.cPTCode = pu_ArrHead.cptcode
                   LEFT JOIN Rd_Style
                          ON PurchaseType.cRdCode = Rd_Style.cRdCode
            WHERE  GSP_VOUCHINFORM.cSource IN ( ''001'', ''002'', ''003'', ''035'',
                                                ''036'', ''081'', ''082'', ''083'' )
                   AND ( GSP_VOUCHINFORMS.CPROCESS = ''先暂存后退货''
                          OR GSP_VOUCHINFORMS.CPROCESS = ''入库报损'' )
                   AND Isnull(dbo.GSP_VOUCHINFORM.CVERIFIER, '''') <> ''''
                   AND Isnull(GSP_VOUCHSQC.BMAKESCRAPIN, 0) = 0
                   AND Isnull(GSP_VOUCHINFORMS.FQTY, 0) - Isnull(GSP_VOUCHINFORMS.FOUTINQTY, 0) <> 0
                   AND GSP_VOUCHINFORM.ID IN (SELECT M_ID
                                              FROM   #STPDAPurchaseINGSPINFORMRefID)';

            EXEC Sp_executesql
              @SqlHEADCommand

            IF ( @GetType = N'DETAIL' )
              BEGIN
                  SET @SqlBODYCommand=N'';
                  SET @SqlBODYCommand=N'SELECT ''''                                                                       AS selcol,
                         GSP_VOUCHINFORMS.cwhcode,
                         cwhname,
                         GSP_VOUCHINFORM.cinvcode,
                         cinvaddcode,
                         cinvname,
                         cinvstd,
                         cinvdefine1,
                         cinvdefine2,
                         cinvdefine3,
                         cinvdefine4,
                         cinvdefine5,
                         cinvdefine6,
                         cinvdefine7,
                         cinvdefine8,
                         cinvdefine9,
                         cinvdefine10,
                         cinvdefine11,
                         cinvdefine12,
                         cinvdefine13,
                         cinvdefine14,
                         cinvdefine15,
                         cinvdefine16,
                         ccomunitcode,
                         cinvm_unit,
                         GSP_VOUCHINFORM.cunitid,
                         cinva_unit,
                         iinvexchrate,
                         GSP_VOUCHINFORM.cfree1,
                         GSP_VOUCHINFORM.cfree2,
                         GSP_VOUCHINFORM.cfree3,
                         GSP_VOUCHINFORM.cfree4,
                         GSP_VOUCHINFORM.cfree5,
                         GSP_VOUCHINFORM.cfree6,
                         GSP_VOUCHINFORM.cfree7,
                         GSP_VOUCHINFORM.cfree8,
                         GSP_VOUCHINFORM.cfree9,
                         GSP_VOUCHINFORM.cfree10,
                         GSP_VOUCHINFORM.cbatch,
                         GSP_VOUCHINFORM.dprodate                                                 AS dmadedate,
                         GSP_VOUCHINFORM.imassdate,
                         GSP_VOUCHINFORM.dvaldate                                                 dvdate,
                         citem_class,
                         ( citem_name )                                                           AS citemcname,
                         ''''                                                                       AS cinvouchcode,
                         citemcode,
                         ( citemname )                                                            AS cname,
                         Isnull(GSP_VOUCHINFORMS.FQTY, 0) - Isnull(GSP_VOUCHINFORMS.FOUTINQTY, 0) iquantity,
                         Isnull(GSP_VOUCHINFORMS.FQTYS, 0) - Isnull(GSP_VOUCHINFORMS.FOUTINNUM, 0)inum,
                         Isnull(GSP_VOUCHINFORMS.FQTY, 0)                                         inquantity,
                         Isnull(GSP_VOUCHINFORMS.FQTYS, 0)                                        innum,
                         pu_ArrBody.autoid,
                         ''''                                                                       cpoid,
                         iposid,
                         iinvmpcost,
                         ( CONVERT(INT, NULL) )                                                   AS icorid,
                         icost,
                         pu_arrbody.id,
                         ioricost,
                         iorimoney,
                         iorisum,
                         ioritaxcost,
                         ioritaxprice,
                         pu_ArrBody.itaxrate                                                      AS ipertaxrate,
                         igrouptype,
                         imoney,
                         sodid                                                                    cdemandid,
                         isum,
                         itaxprice,
                         ''''                                                                       AS bquansign,
                         btaxcost,
                         GSP_VOUCHSQC.contractcode,
                         contractrowno,
                         GSP_VOUCHINFORM.cmassunit,
                         GSP_VOUCHINFORMS.cdefine22,
                         GSP_VOUCHINFORMS.cdefine23,
                         GSP_VOUCHINFORMS.cdefine24,
                         GSP_VOUCHINFORMS.cdefine25,
                         GSP_VOUCHINFORMS.cdefine26,
                         GSP_VOUCHINFORMS.cdefine27,
                         GSP_VOUCHINFORMS.cdefine28,
                         GSP_VOUCHINFORMS.cdefine29,
                         GSP_VOUCHINFORMS.cdefine30,
                         GSP_VOUCHINFORMS.cdefine31,
                         GSP_VOUCHINFORMS.cdefine32,
                         GSP_VOUCHINFORMS.cdefine33,
                         GSP_VOUCHINFORMS.cdefine34,
                         GSP_VOUCHINFORMS.cdefine35,
                         GSP_VOUCHINFORMS.cdefine36,
                         GSP_VOUCHINFORMS.cdefine37,
                         sotype                                                                   idemandtype,
                         csocode                                                                  cdemandcode,
                         irowno                                                                   idemandseq,
                         iorderdid,
                         iorderseq,
                         iordertype,
                         csoordercode,
                         iexpiratdatecalcu,
                         cexpirationdate,
                         dexpirationdate,
                         GSP_VOUCHINFORM.cbatchproperty1,
                         GSP_VOUCHINFORM.cbatchproperty2,
                         GSP_VOUCHINFORM.cbatchproperty3,
                         GSP_VOUCHINFORM.cbatchproperty4,
                         GSP_VOUCHINFORM.cbatchproperty5,
                         GSP_VOUCHINFORM.cbatchproperty6,
                         GSP_VOUCHINFORM.cbatchproperty7,
                         GSP_VOUCHINFORM.cbatchproperty8,
                         GSP_VOUCHINFORM.cbatchproperty9,
                         GSP_VOUCHINFORM.cbatchproperty10,
                         ivouchrowno,
                         bGsp,
                         binspect,
                         pu_ArrHead.ccode                                                         cbarvcode,
                         pu_ArrBody.autoid                                                        AS iArrsId,
                         GSP_VOUCHINFORMS.cbsysbarcode,
                         bgift,
                         GSP_VOUCHINFORM.CINID                                                    ccheckcode,
                         GSP_VOUCHINFORMS.AUTOID                                                  icheckids
                  FROM   GSP_VOUCHINFORMS
                         INNER JOIN GSP_VOUCHINFORM
                                 ON GSP_VOUCHINFORMS.ID = GSP_VOUCHINFORM.ID
                         INNER JOIN GSP_VOUCHSQC
                                 ON GSP_VOUCHSQC.AUTOID = GSP_VOUCHINFORM.CSOURCEAUTOID
                         INNER JOIN GSP_VOUCHQC
                                 ON GSP_VOUCHQC.ID = GSP_VOUCHSQC.ID
                                    AND GSP_VOUCHQC.CVOUCHTYPE IN ( ''001'', ''002'', ''003'', ''035'',
                                                                    ''036'', ''081'', ''082'', ''083'' )
                         LEFT JOIN pu_arrbody
                                ON GSP_VouchsQC.ICODE_T = pu_ArrBody.autoid
                         LEFT JOIN pu_ArrHead
                                ON pu_ArrHead.ccode = GSP_VOUCHQC.CCODE
                  WHERE  GSP_VOUCHINFORM.cSource IN (''001'', ''002'', ''003'', ''035'',
                                                      ''036'', ''081'', ''082'', ''083'' )
                         AND ( GSP_VOUCHINFORMS.CPROCESS = ''先暂存后退货''
                                OR GSP_VOUCHINFORMS.CPROCESS = ''入库报损'' )
                         AND Isnull(dbo.GSP_VOUCHINFORM.CVERIFIER, '''') <> ''''
                         AND Isnull(GSP_VOUCHSQC.BMAKESCRAPIN, 0) = 0
                         AND Isnull(GSP_VOUCHINFORMS.FQTY, 0) - Isnull(GSP_VOUCHINFORMS.FOUTINQTY, 0) <> 0
                         AND GSP_VOUCHINFORM.ID IN (SELECT M_ID
                                       FROM   #STPDAPurchaseINGSPINFORMRefID)';

                  EXEC Sp_executesql
                    @SqlBODYCommand;
              END;

            --删除临时表
            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDATempGSPINFORMVoucherCodes') IS NULL)
              DROP TABLE #STPDATempGSPINFORMVoucherCodes;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDAPurchaseINGSPINFORMRefIDs') IS NULL)
              DROP TABLE #STPDAPurchaseINGSPINFORMRefIDs;

            IF EXISTS (SELECT 0
                       WHERE  NOT Object_id('tempdb..#STPDAPurchaseINGSPINFORMRefID') IS NULL)
              DROP TABLE #STPDAPurchaseINGSPINFORMRefID;
        END;
      ELSE
        BEGIN
            RAISERROR ('暂不支持进口订单相关来源单据！',16,1 );
        END;
  END; 
