﻿/*---------------------------------------------------------------------
* 			Copyright (C) 2018 TECHSCAN 版权所有。
*           www.techscan.cn
*┌────────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．      │
*│　版权所有：上海太迅自动识别技术有限公司 　 　　　　　　　　　　　　    │
*└────────────────────────────────────┘
*
* 文件名：   proc_ts_BarCodeScanCheck.SQL
* 功能：     存储过程
* 描述：     条码扫描检查
* 作者：     马永龙
* 创建时间： 2018-07-03 15:54:12
* 文件版本： V1.0.3

===============================版本履历===============================
* Ver 		变更日期 				负责人 	变更内容
* V1.0.0	2018-07-03 15:54:12		Myl		Create(三入三出部分)
* V1.0.1	2018-07-05				Myl		添加调拨（@cVouchType=12）和盘点单（@cVouchType=18）的条码扫描校验
* V1.0.2	2018-07-16				Myl		如果U8条码模块中设置了货码允许重复扫描，则这里直接返回，不做下面的重复扫描校验
* V1.0.3	2018-12-27				Myl		原则上删除单据后需要手动删除条码扫描明细，目前U8前台没有关联这块，参照CE这块操作，我们查找扫描明细如果找不到对应的单据
* V1.0.4    2019-03-27              dxh      增到货单校验
* V1.0.5    2019-04-11              dxh      增到装箱单箱码校验
（单据被删除掉的情况下），那直接返回



======================================================================
//--------------------------------------------------------------------*/
--EXEC proc_ts_BarCodeScanCheck '123321',0,'01'

CREATE PROC [dbo].[proc_ts_BarCodeScanCheck]
    (
      @cBarCode NVARCHAR(120) ,
      @bRed BIT ,
      @cVouchType NVARCHAR(30) ,
      @ParamsList NVARCHAR(100) = N''
    )
    -- WITH ENCRYPTION
AS
    BEGIN
    
						--dxh 190801 之前到货单的代号设置的98 导致扫描明细内不能显示到货单类型
					--update hy_bar_scandetails set cvouchtype='26' where cvouchtype='98';
					--update hy_bar_scandetailss set cvouchtype='26' where cvouchtype='98';
					-- end


        DECLARE @cAllowMutipleScanAccValue NVARCHAR(200);
        SELECT  @cAllowMutipleScanAccValue = cValue
        FROM    dbo.AccInformation WITH ( NOLOCK )
        WHERE   cName = 'bKCScanOnces';
        IF ( @@ROWCOUNT <> 0 )
            BEGIN
                IF ( LOWER(@cAllowMutipleScanAccValue) = N'true' )
                    RETURN;
            END;
    
	  --如果传值是99，转换成装箱KC01
	IF(@cVouchType=N'99')  SET @cVouchType=N'KC01';
	--到货单
	IF(@cVouchType=N'98')  SET @cVouchType=N'26';
	IF(@cVouchType=N'97')  SET @cVouchType=N'26';
        IF ( @cVouchType = N'12' )--调拨单
            BEGIN
                DECLARE @cWhCode NVARCHAR(50);
				--调出仓库编码
                DECLARE @cOWhCode NVARCHAR(20);
                SET @cOWhCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cOWhCode',
                                                              DEFAULT, DEFAULT);
				--调入仓库编码                                                    
                DECLARE @cIWhCode NVARCHAR(20);
                SET @cIWhCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cIWhCode',
                                                              DEFAULT, DEFAULT);
                IF ( @cOWhCode = N''
                     OR @cIWhCode = N''
                   )
                    BEGIN
                        RAISERROR('调拨单检查条码扫描缺少调出和调入仓库参数！',16,1);
                    END;
                    
                SELECT TOP 1
                        @cWhCode = cwhcode
                FROM    hy_bar_scandetails WITH ( NOLOCK )
                WHERE   barcode = @cBarCode
                        AND cvouchtype = N'12'
                ORDER BY ID DESC; 
                IF ( @@ROWCOUNT = 0 )
                    RETURN;
                ELSE
                    BEGIN

					if(@cWhCode<>N'')
					BEGIN

                        IF ( @cOWhCode = SUBSTRING(@cWhCode, 1,
                                                   CHARINDEX(',', @cWhCode, 0)
                                                   - 1)
                             OR @cIWhCode = SUBSTRING(@cWhCode,
                                                      CHARINDEX(',', @cWhCode,
                                                              0) + 1,
                                                      LEN(@cWhCode)
                                                      - CHARINDEX(',',
                                                              @cWhCode, 0))
                           )
                            RAISERROR('条码<%s>不允许重复扫描！',16,1, @cBarCode);
							END;
                    END;
                RETURN;
            END;
        ELSE
            IF ( @cVouchType = N'18' )--盘点单
                BEGIN
					--盘点单单号
                    DECLARE @iCount INT;
                    DECLARE @cCode NVARCHAR(50);
                    SET @cCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cCode',
                                                              DEFAULT, DEFAULT);
                    IF ( @cCode = N'' )
                        BEGIN
                            RAISERROR('缺少盘点单单号参数！',16,1);
                        END;
                    SELECT  @iCount = COUNT(*)
                    FROM    hy_bar_scandetails WITH ( NOLOCK )
                    WHERE   barcode = @cBarCode
                            AND cvouchtype = N'18'
                            AND keyval = @cCode;
                    IF ( @@ROWCOUNT = 0 )
                        RETURN;
                    ELSE
                        BEGIN
                            IF ( @iCount > 0 )
                                RAISERROR('条码<%s>不允许重复扫描！',16,1, @cBarCode);
                            ELSE
                                RETURN;
                        END;
                END;
            ELSE
                BEGIN
                    DECLARE @IsStockIn BIT;
                    DECLARE @hyVouchType NVARCHAR(30);
                    DECLARE @hyKeyVal NVARCHAR(50);

                    SELECT TOP 1
                            @hyVouchType = cvouchtype ,
                            @hyKeyVal = keyval
                    FROM    hy_bar_scandetails WITH ( NOLOCK )
                    WHERE   barcode = @cBarCode
                            AND cvouchtype IN ( '01', '08', '09', '10', '11',
                                                '32', '18','26','kc01' ,'05')  and  cVouchType=@cVouchType
                    ORDER BY ID DESC;
        
                    IF ( @@ROWCOUNT = 0 )
                        BEGIN
                            IF ( @IsStockIn = 0
                                 OR ( @IsStockIn = 1
                                      AND @bRed = 1
                                    )
                               )
                                RAISERROR('条码<%s>未扫描入库！',16,1, @cBarCode);
                            ELSE
                                RETURN;
                        END;
            
                    IF ( @cVouchType = '01'
                         OR @cVouchType = '10'
                         OR @cVouchType = '08'
						 OR @cVouchType = '26'
						 OR @cVouchType = 'KC01'
                       )
                        SET @IsStockIn = 1;
                    IF ( @cVouchType = '32'
                         OR @cVouchType = '11'
                         OR @cVouchType = '09'
						 OR @cVouchType = '05'
                       )
                        SET @IsStockIn = 0;

                    IF ( @hyVouchType = N'18')
                        BEGIN
							--第一条明细是盘点单扫描明细的情况
							--盘点单的情况下，蓝字出库或红字入库可扫码，其他不可扫码
                            IF ( ( @IsStockIn = 1
                                   AND @bRed = 1
                                 )
                                 OR ( @IsStockIn = 0
                                      AND @bRed = 0
                                    )
                               )
                                RETURN;
                            ELSE
                                RAISERROR('条码<%s>不允许重复扫描！',16,1, @cBarCode);
                        END;
                    ELSE
                        BEGIN
							--主要是检查最近一次的扫描明细操作内容
                            DECLARE @SqlCommand NVARCHAR(1000);
                            DECLARE @ParmList NVARCHAR(100);
                            DECLARE @bRdFlag TINYINT;
                            DECLARE @iQuantity DECIMAL;
							--DECLARE @hyVouchType NVARCHAR(30);
							--DECLARE @hyKeyVal NVARCHAR(50);
							--SET @hyVouchType = '01';
							--SET @hyKeyVal = '0000000001';



                        IF(@hyVouchType = N'kc01')
							BEGIN


							SET @SqlCommand = 'select top 1 @bRdFlag=1,@iQuantity=1  from kc_boxup H with (nolock) left join kc_boxups S  with (nolock) on H.ID=S.ID where cCode  = @hyKeyVal  and iQuantity>isnull(iUnBoxQty,0) AND (cBoxCode= '''+@cBarCode+ ''' OR cBarCode='''+@cBarCode+''');';

                           SET @ParmList = N'@bRdFlag TINYINT output,@iQuantity DECIMAL output,@hyKeyVal	NVARCHAR(60)';
						    
							END;
							ELSE IF(@hyVouchType = N'05')
							BEGIN
							
                            SET @SqlCommand = N'SELECT TOP 1   @bRdFlag=0,
									@iQuantity=iQuantity
							FROM    DispatchList rd WITH ( NOLOCK )
									LEFT JOIN DispatchLists rds ON rds.DLID = rd.DLID
							WHERE   cDLCode = @hyKeyVal;';
                 
                           SET @ParmList = N'@bRdFlag TINYINT output,@iQuantity DECIMAL output,@hyKeyVal	NVARCHAR(60)';
						    
							END;

							ELSE IF(@hyVouchType = N'26')
							BEGIN
							
                            SET @SqlCommand = N'SELECT TOP 1   @bRdFlag=1,
									@iQuantity=iQuantity
							FROM    PU_ArrivalVouch rd WITH ( NOLOCK )
									LEFT JOIN PU_ArrivalVouchs rds ON rds.ID = rd.ID
							WHERE   cCode = @hyKeyVal;';
                 
                           SET @ParmList = N'@bRdFlag TINYINT output,@iQuantity DECIMAL output,@hyKeyVal	NVARCHAR(60)';
						    
							END;
							ELSE IF(@cVouchType = '32'
                         OR @cVouchType = '11'
                         OR @cVouchType = '09'
						 OR @cVouchType = '05')
							BEGIN
							-- 考虑已出库商品盘盈再出库的情况
						 DECLARE @RCount INT;
						 select @RCount=COUNT(1) from (
select top 1 * from hy_bar_scandetails where barcode=@cBarCode  order by dmaketime desc,ID desc) h1
left join rdrecord08 c on c.cBusCode=h1.keyval  and c.cSource='盘点'
where h1.cvouchtype='18'  and isnull(c.cHandler,'')<>''

IF(@RCount>0)
BEGIN
RETURN;
END;
ELSE
							BEGIN

                            SET @SqlCommand = N'SELECT TOP 1 @bRdFlag=bRdFlag ,
									@iQuantity=iQuantity
							FROM    RdRecord' + @hyVouchType
                                + N' rd WITH ( NOLOCK )
									LEFT JOIN rdrecords' + @hyVouchType
                                + N' rds ON rds.ID = rd.ID
							WHERE   cCode = @hyKeyVal;';
                 
                            SET @ParmList = N'@bRdFlag TINYINT output,@iQuantity DECIMAL output,@hyKeyVal NVARCHAR(60)';
              
				END;


END;
							ELSE
							BEGIN

                            SET @SqlCommand = N'SELECT TOP 1 @bRdFlag=bRdFlag ,
									@iQuantity=iQuantity
							FROM    RdRecord' + @hyVouchType
                                + N' rd WITH ( NOLOCK )
									LEFT JOIN rdrecords' + @hyVouchType
                                + N' rds ON rds.ID = rd.ID
							WHERE   cCode = @hyKeyVal;';
                 
                            SET @ParmList = N'@bRdFlag TINYINT output,@iQuantity DECIMAL output,@hyKeyVal	NVARCHAR(60)';
              
				END;
				     EXEC sp_executesql @SqlCommand, @ParmList,
                                @bRdFlag OUTPUT, @iQuantity OUTPUT,
                                @hyKeyVal = @hyKeyVal;
                         
                            IF ( @@ROWCOUNT <= 0 )
								--Myl - 20181227
                                --RAISERROR('查找条码<%s>对应的出入库记录失败！',16,1, @cBarCode);
								RETURN;
                            ELSE
                                BEGIN
                                    IF ( @bRed = 1 )
                                        BEGIN
											--如果该条码刚做过红字入库或者蓝字出库 则不能再做红字入库
                                            IF ( ( @IsStockIn = 1
                                                   AND @bRdFlag = 1
                                                   AND @iQuantity < 0
                                                 )
                                                 OR ( @IsStockIn = 1
                                                      AND @bRdFlag = 0
                                                      AND @iQuantity > 0
                                                    )
                                               )
                                                RAISERROR('条码<%s>不允许重复扫描！',16,1, @cBarCode);
											--如果该条码刚做过红字出库或者蓝字入库 则不能再做红字出库
                                            IF ( ( @IsStockIn = 0
                                                   AND @bRdFlag = 0
                                                   AND @iQuantity < 0
                                                 )
                                                 OR ( @IsStockIn = 0
                                                      AND @bRdFlag = 1
                                                      AND @iQuantity > 0
                                                    )
                                               )
                                                RAISERROR('条码<%s>不允许重复扫描！',16,1, @cBarCode);
                                        END;
                                    ELSE
                                        BEGIN
											--如果该条码刚做过蓝字入库或者红字出库 则不能再做蓝字入库
                                            IF ( ( @IsStockIn = 1
                                                   AND @bRdFlag = 1
                                                   AND @iQuantity > 0
                                                 )
                                                 OR ( @IsStockIn = 1
                                                      AND @bRdFlag = 0
                                                      AND @iQuantity < 0
                                                    )
                                               )
                                                RAISERROR('条码<%s>不允许重复扫描！',16,1, @cBarCode);
											--如果该条码刚做过红字出库或者蓝字入库 则不能再做红字出库
                                            IF ( ( @IsStockIn = 0
                                                   AND @bRdFlag = 0
                                                   AND @iQuantity > 0
                   )
                                                 OR ( @IsStockIn = 0
                                                      AND @bRdFlag = 1
                                                      AND @iQuantity < 0
                                                    )
                                               )
                                                RAISERROR('条码<%s>不允许重复扫描！',16,1, @cBarCode);
                                        END;
                                END;
                        END;
                    RETURN; 
                END;
    END;