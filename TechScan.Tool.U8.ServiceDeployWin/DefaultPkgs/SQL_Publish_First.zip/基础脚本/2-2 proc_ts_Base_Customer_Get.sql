﻿/*---------------------------------------------------------------------
* 			Copyright (C) 2018 TECHSCAN 版权所有。
*           www.techscan.cn
*┌────────────────────────────────────────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．　│
*│　版权所有：上海太迅自动识别技术有限公司 　 　　　　　　　　　　　　│
*└────────────────────────────────────────────────────────────────────┘
*
* 文件名：   proc_ts_Base_Customer_Get.SQL
* 功能：     存储过程
* 描述：     获取客户信息
* 作者：     马永龙
* 创建时间： 2018-07-06 11:35:31
* 文件版本： V1.0.0

===============================版本履历===============================
* Ver 		变更日期 				负责人 	变更内容
* V1.0.0	2018-07-06 11:35:31		Myl		Create

======================================================================
//--------------------------------------------------------------------*/

--EXEC proc_ts_Base_Customer_Get '', '', '', '1'

CReate PROC proc_ts_Base_Customer_Get
    (
      --客户编码
      @cCusCode NVARCHAR(20) ,
      --客户名称（支持模糊查询）
      @cCusName NVARCHAR(98) ,
      --客户简称（支持模糊查询）
      @cCusAbbName NVARCHAR(60) ,
      --查询类型：
      --'0':查询所有客户信息
      --'1'：销售出库查询客户（根据销售出库单的来源单据（发货单）筛选客户）
      @GetType CHAR(1) = N'0'
    )
    --WITH ENCRYPTION
AS
    BEGIN
        DECLARE @ParmList NVARCHAR(2000);
        DECLARE @SqlCommand NVARCHAR(MAX);
		
		SET @ParmList=N'';
		SET @SqlCommand=N'';

        IF ( @GetType = N'0' )
            BEGIN
            
                SET NOCOUNT ON;
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#UFIDA_MYL_PDA_Base_Customer') IS NULL )
                    DROP TABLE #UFIDA_MYL_PDA_Base_Customer;
                  
                SELECT  cCusCode
                INTO    #UFIDA_MYL_PDA_Base_Customer
                FROM    dbo.Customer WITH ( NOLOCK )
                WHERE   1 = 0; 
                CREATE  CLUSTERED  INDEX [ix_UFIDA_MYL_PDA_Base_Customer_cCusCode] ON  #UFIDA_MYL_PDA_Base_Customer  (cCusCode);
                SET @SqlCommand = N'INSERT INTO #UFIDA_MYL_PDA_Base_Customer (cCusCode)
SELECT cCusCode FROM Customer WITH ( NOLOCK ) WHERE 1=1 ';
                SET @cCusName = '%' + @cCusName + '%';
                SET @cCusAbbName = '%' + @cCusAbbName + '%';
                IF ( @cCusCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (cCusCode=@cCusCode) ';
                IF ( @cCusName <> N''
                     AND @cCusName <> '%%'
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND ( cCusName LIKE @cCusName ) ';
                IF ( @cCusAbbName <> N''
                     AND @cCusAbbName <> '%%'
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND ( cCusAbbName LIKE @cCusAbbName ) ';
                SET @ParmList = '@cCusCode		NVARCHAR(20),
								   @cCusName   NVARCHAR(98),
								   @cCusAbbName     NVARCHAR(60)';
                EXEC sp_executesql @SqlCommand, @ParmList,
                    @cCusCode = @cCusCode, @cCusName = @cCusName,
                    @cCusAbbName = @cCusAbbName;
                SET NOCOUNT OFF;
                SELECT  cCusCode AS ccuscode ,
                        cCusName AS ccusname ,
                        cCusAbbName AS ccusabbname ,
                        cCCCode AS ccccode ,
                        cDCCode AS cdccode ,
                        cTrade AS ctrade ,
                        cCusAddress AS ccusaddress ,
                        cCusPostCode AS ccuspostcode ,
                        cCusRegCode AS ccusregcode ,
                        cCusBank AS ccusbank ,
                        cCusAccount AS ccusaccount ,
                        CONVERT(VARCHAR(100), dCusDevDate, 23) AS dcusdevdate ,
                        cCusLPerson AS ccuslperson ,
                        cCusEmail AS ccusemail ,
                        cCusPerson AS ccusperson ,
                        cCusPhone AS ccusphone ,
                        cCusFax AS ccusfax ,
                        cCusBP AS ccusbp ,
                        cCusHand AS ccushand ,
                        cCusPPerson AS ccuspperson ,
                        iCusDisRate AS icusdisrate ,
                        cCusCreGrade AS ccuscregrade ,
                        iCusCreLine AS icuscreline ,
                        iCusCreDate AS icuscredate ,
                        cCusPayCond AS ccuspaycond ,
                        cCusOAddress AS ccusoaddress ,
                        cCusOType AS ccusotype ,
                        cCusHeadCode AS ccusheadcode ,
                        cCusWhCode AS ccuswhcode ,
                        cCusDepart AS ccusdepart ,
                        iARMoney AS iarmoney ,
                        dLastDate AS dlastdate ,
                        iLastMoney AS ilastmoney ,
                        dLRDate AS dlrdate ,
                        iLRMoney AS ilrmoney ,
                        dEndDate AS denddate ,
                        iFrequency AS ifrequency ,
                        iCostGrade AS icostgrade ,
                        cCreatePerson AS ccreateperson ,
                        cModifyPerson AS cmodifyperson ,
                        dModifyDate AS dmodifydate ,
                        cRelVendor AS crelvendor ,
                        iId AS iid ,
                        cPriceGroup AS cpricegroup ,
                        cOfferGrade AS coffergrade ,
                        iOfferRate AS iofferrate ,
                        cCusDefine1 AS ccusdefine1 ,
                        cCusDefine2 AS ccusdefine2 ,
                        cCusDefine3 AS ccusdefine3 ,
                        cCusDefine4 AS ccusdefine4 ,
                        cCusDefine5 AS ccusdefine5 ,
                        cCusDefine6 AS ccusdefine6 ,
                        cCusDefine7 AS ccusdefine7 ,
                        cCusDefine8 AS ccusdefine8 ,
                        cCusDefine9 AS ccusdefine9 ,
                        cCusDefine10 AS ccusdefine10 ,
                        cCusDefine10 AS ccusdefine11 ,
                        cCusDefine10 AS ccusdefine12 ,
                        cCusDefine10 AS ccusdefine13 ,
                        cCusDefine10 AS ccusdefine14 ,
                        cCusDefine10 AS ccusdefine15 ,
                        cCusDefine10 AS ccusdefine16 ,
                        pubufts ,
                        cInvoiceCompany AS cinvoicecompany ,
                        bCredit AS bcredit ,
                        bCreditDate AS bcreditdate ,
                        bCreditByHead AS bcreditbyhead ,
                        bLicenceDate AS blicencedate ,
                        dLicenceSDate AS dlicencesdate ,
                        dLicenceEDate AS dlicenceedate ,
                        iLicenceADays AS ilicenceadays ,
                        bBusinessDate AS bbusinessdate ,
                        dBusinessSDate AS bbusinesssdate ,
                        dBusinessEDate AS dbusinessedate ,
                        iBusinessADays AS ibusinessadays ,
                        bProxy AS bproxy ,
                        dProxySDate AS dproxysdate ,
                        dProxyEDate AS dproxyedate ,
                        iProxyADays AS iproxyadays ,
                        cMemo AS cmemo ,
                        bLimitSale AS blimitsale ,
                        cCusContactCode AS ccuscontactcode ,
                        cCusCountryCode AS ccuscountrycode ,
                        cCusEnName AS ccusenname ,
                        cCusEnAddr1 AS ccusenaddr1 ,
                        cCusEnAddr2 AS ccusenaddr2 ,
                        cCusEnAddr3 AS ccusenaddr3 ,
                        cCusEnAddr4 AS ccusenaddr4 ,
                        cCusPortCode AS ccusportcode ,
                        cPrimaryVen AS cprimaryven ,
                        fCommisionRate AS fcommisionrate ,
                        fInsueRate AS finsuerate ,
                        bHomeBranch AS bhomebranch ,
                        cBranchAddr AS cbranchaddr ,
                        cBranchPhone AS cbranchphone ,
                        cBranchPerson AS cbranchperson ,
                        cCusTradeCCode AS ccustradeccode ,
                        CustomerKCode AS customerkcode ,
                        bCusState AS bcusstate ,
                        bShop AS bshop ,
                        cCusBankCode AS ccusbankcode ,
                        cCusExch_name AS ccusexch_name ,
                        iCusGSPType AS icusgsptype ,
                        iCusGSPAuth AS icusgspauth ,
                        cCusGSPAuthNo AS ccusgspauthno ,
                        cCusBusinessNo AS ccusbusinessno ,
                        cCusLicenceNo AS ccuslicenceno ,
                        bCusDomestic AS bcusdomestic ,
                        bCusOverseas AS bcusoverseas ,
                        cCusCreditCompany AS ccuscreditcompany ,
                        cCusSAProtocol AS ccussaprotocol ,
                        cCusExProtocol AS ccusexprotocol ,
                        cCusOtherProtocol AS ccusotherprotocol ,
                        fCusDiscountRate AS fcusdiscountrate ,
                        cCusSSCode AS ccussscode ,
                        cCusCMProtocol AS ccuscmprotocol ,
                        dCusCreateDatetime AS dcuscreatedatetime ,
                        cCusAppDocNo AS ccusappdocno ,
                        cCusMnemCode AS ccusmnemcode ,
                        fAdvancePaymentRatio AS fadvancepaymentratio ,
                        bServiceAttribute AS bserviceattribute ,
                        bRequestSign AS brequestsign ,
                        bOnGPinStore AS bongpinstore ,
                        cCusMngTypeCode AS ccusmngtypecode ,
                        account_type ,
                        cCusImAgentProtocol AS ccusimagentprotocol ,
                        iSourceType AS isourcetype ,
                        iSourceId AS isourceid ,
                        fExpense AS fexpense ,
                        fApprovedExpense AS fapprovedexpense ,
                        dTouchedTime AS dtouchedtime ,
                        dRecentlyInvoiceTime AS drecentlyinvoicetime ,
                        dRecentlyQuoteTime AS drecentlyquotetime ,
                        dRecentlyActivityTime AS drecentlyactivitytime ,
                        dRecentlyChanceTime AS drecentlychancetime ,
                        dRecentlyContractTime AS drecentlycontracttime ,
                        cLtcCustomerCode AS cltccustomercode ,
                        bTransFlag AS btransflag ,
                        cLtcPerson AS cltcperson ,
                        dLtcDate AS dltcdate ,
                        cLocationSite AS clocationsite ,
                        iCusTaxRate AS icustaxrate ,
                        alloct_dept_time ,
                        allot_user_time ,
                        recyle_dept_time ,
                        recyle_pub_time ,
                        cLicenceNo AS clicenceno ,
                        cLicenceRange AS clicencerange ,
                        cCusBusinessRange AS ccusbusinessrange ,
                        dCusGSPEDate AS dcusgspedate ,
                        dCusGSPSDate AS dcusgspsdate ,
                        iCusGSPADays AS icusgspadays ,
                        bIsCusAttachFile AS biscusattachfile ,
                        dRecentContractDate AS drecentcontractdate ,
                        dRecentDeliveryDate AS drecentdeliverydate ,
                        dRecentOutboundDate AS drecentoutbounddate ,
                        cProvince AS cprovince ,
                        cCity AS ccity ,
                        cCounty AS ccounty ,
                        cCusAddressGUID AS ccusaddressguid ,
                        cAddCode AS caddcode 
					 --,
                       -- cCreditAddCode AS ccreditaddcode ,
                       -- cRegCash AS cregcash ,
                       -- dDepBeginDate AS ddepbegindate ,
                       -- iEmployeeNum AS iemployeenum ,
                       -- cURL AS curl ,
                       -- PictureGUID AS pictureguid
                FROM    Customer WITH ( NOLOCK )
                WHERE   ccuscode IN ( SELECT    cCusCode
                                      FROM      #UFIDA_MYL_PDA_Base_Customer )
                ORDER BY ccuscode ASC;

                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#UFIDA_MYL_PDA_Base_Customer') IS NULL )
                    DROP TABLE #UFIDA_MYL_PDA_Base_Customer;
            END;
        ELSE
            IF ( @GetType = N'1' )
                BEGIN
                    SET NOCOUNT ON;
                    SET @ParmList = 'cCusCode:' + @cCusCode + '@@cCusName:'
                        + @cCusName;
                    IF OBJECT_ID('tempdb..#MYL_PDA_Base_Customer_Search') IS NOT NULL
                        DROP TABLE #MYL_PDA_Base_Customer_Search;
                    SELECT DISTINCT
                            DispatchList.caddcode ,
                            ( CASE WHEN ISNULL(DispatchList.cSBVCode, '') <> ''
                                   THEN SaleBillVouch.cVouchType
                                   ELSE DispatchList.cVouchType
                              END ) AS cbilltype ,
                            VouchType.cVouchName AS cbillname ,
                            DispatchList.cDLCode AS cdlcode ,
                            DispatchList.SBVID AS sbvid ,
                            DispatchList.cSBVCode AS csbvcode ,
                            CONVERT(VARCHAR(100), DispatchList.dDate, 23) AS ddate ,
                            dbo.DispatchList.cRdCode AS crdcode ,
                            dbo.DispatchList.cSOCode AS csocode ,
                            DispatchList.cPayCode AS cpaycode ,
                            DispatchList.cSCCode AS csccode ,
                            DispatchList.cexch_name ,
                            DispatchList.iExchRate AS iexchrate ,
                            DispatchList.iTaxRate AS itaxrate ,
                            DispatchList.bFirst AS bfirst ,
                            DispatchList.bReturnFlag AS breturnflag ,
                            DispatchList.bSettleAll AS bsettleall ,
                            DispatchList.cSaleOut AS csaleout ,
                            DispatchList.iSale AS isale ,
                            DispatchList.iVTid AS ivtid ,
                            DispatchList.bIAFirst AS biafirst ,
                            DispatchList.bCredit AS bcredit ,
                            DispatchList.iverifystate ,
                            DispatchList.iswfcontrolled ,
                            DispatchList.icreditstate ,
                            DispatchList.bARFirst AS barfirst ,
                            DispatchList.bsigncreate ,
                            DispatchList.bcashsale ,
                            DispatchList.cgathingcode ,
                            DispatchList.cChanger AS cchanger ,
                            DispatchList.cChangeMemo AS cchangememo ,
                            DispatchList.outid ,
                            DispatchList.bmustbook ,
                            DispatchList.cBookType AS cbooktype ,
                            DispatchList.cBookDepcode AS cbookdepcode ,
                            DispatchList.bSaUsed AS bsaused ,
                            DispatchList.bneedbill ,
                            DispatchList.baccswitchflag ,
                            DispatchList.iPrintCount AS iprintcount ,
                            DispatchList.cSourceCode AS csourcecode ,
                            DispatchList.ccusperson ,
                            DispatchList.ccuspersoncode ,
                            DispatchList.bsaleoutcreatebill ,
                            DispatchList.cSysBarCode AS csysbarcode ,
                            DispatchList.csscode ,
                            DispatchList.cCurrentAuditor AS ccurrentauditor ,
                            DispatchList.bNotToGoldTax AS bnottogoldtax ,
                            DispatchList.cBusType AS cbustype ,
                            DispatchList.DLID AS dlid ,
                            DispatchList.cSTCode AS cstcode ,
                            SaleType.cSTName AS cstname ,
                            DispatchList.cCusCode AS ccuscode ,
                            Customer.cCusAbbName AS ccusabbname ,
                            Customer.cCusName AS ccusname ,
                            DispatchList.cDepCode AS cdepcode ,
                            Department.cDepName AS cdepname ,
                            DispatchList.cPersonCode AS cpersoncode ,
                            person.cPersonName AS cpersonname ,
                            DispatchList.cMaker AS cmaker ,
                            DispatchList.cVerifier AS cverifier ,
                            DispatchList.cShipAddress AS cshipaddress ,
                            CONVERT(CHAR, CONVERT(MONEY, DispatchList.ufts), 2) AS ufts ,
                            DispatchList.cDefine1 AS cdefine1 ,
                            DispatchList.cDefine2 AS cdefine2 ,
                            DispatchList.cDefine3 AS cdefine3 ,
                            DispatchList.cDefine4 AS cdefine4 ,
                            DispatchList.cDefine5 AS cdefine5 ,
                            DispatchList.cDefine6 AS cdefine6 ,
                            DispatchList.cDefine7 AS cdefine7 ,
                            DispatchList.cDefine8 AS cdefine8 ,
                            DispatchList.cDefine9 AS cdefine9 ,
                            DispatchList.cDefine10 AS cdefine10 ,
                            DispatchList.cDefine11 AS cdefine11 ,
                            DispatchList.cDefine12 AS cdefine12 ,
                            DispatchList.cDefine13 AS cdefine13 ,
                            DispatchList.cDefine14 AS cdefine14 ,
                            DispatchList.cDefine15 AS cdefine15 ,
                            DispatchList.cDefine16 AS cdefine16 ,
                            DispatchList.cMemo AS cmemo ,
                            SABizFlow.iFlowID AS iflowid ,
                            SABizFlow.cSalesProcessDescribes AS cflowname ,
                            DispatchList.cinvoicecompany ,
                            cus.cCusAbbName AS cinvoicecompanyabbname ,
                            DispatchList.fEBweight AS febweight ,
                            DispatchList.cEBweightUnit AS cebweightunit ,
                            DispatchList.cEBExpressCode AS cebexpresscode ,
                            DispatchList.cGCRouteCode AS cgcroutecode ,
                            V_GC_Route.cName AS cgcroutename
                    INTO    #MYL_PDA_Base_Customer_Search
                    FROM    DispatchList  WITH (NOLOCK) 
                            INNER JOIN DispatchLists   WITH (NOLOCK) ON DispatchList.DLID = DispatchLists.DLID
                            INNER JOIN Inventory   WITH (NOLOCK) ON DispatchLists.cInvCode = Inventory.cInvCode
                            LEFT JOIN ComputationUnit  WITH (NOLOCK)  ON Inventory.cComUnitCode = ComputationUnit.cComunitCode
                            INNER JOIN Warehouse   WITH (NOLOCK) ON DispatchLists.cWhCode = Warehouse.cWhCode
                            LEFT OUTER JOIN SaleType  WITH (NOLOCK)  ON DispatchList.cSTCode = SaleType.cSTCode
                            LEFT OUTER JOIN ( SELECT    cPersonCode AS cpersoncode2 ,
                                                        cPersonName
                                              FROM      Person  WITH (NOLOCK) 
                                            ) person ON DispatchList.cPersonCode = person.cpersoncode2
                            LEFT OUTER JOIN Customer   WITH (NOLOCK) ON DispatchList.cCusCode = Customer.cCusCode
                            LEFT OUTER JOIN Department   WITH (NOLOCK) ON DispatchList.cDepCode = Department.cDepCode
                            LEFT JOIN SaleBillVouch   WITH (NOLOCK) ON SaleBillVouch.SBVID = dbo.DispatchList.SBVID
                            LEFT JOIN VouchType  WITH (NOLOCK)  ON VouchType.cVouchType = CASE
                                                              WHEN SaleBillVouch.SBVID IS NULL
                                                              THEN DispatchList.cVouchType
                                                              ELSE SaleBillVouch.cVouchType
                                                              END
                            LEFT JOIN SABizFlow   WITH (NOLOCK) ON SABizFlow.iFlowID = DispatchList.iflowid
                            LEFT JOIN Vendor v1   WITH (NOLOCK) ON v1.cVenCode = DispatchLists.cvmivencode
                            LEFT JOIN Customer cus   WITH (NOLOCK) ON cus.cCusCode = DispatchList.cinvoicecompany
                            LEFT JOIN V_GC_Route WITH ( NOLOCK ) ON DispatchList.cGCRouteCode = V_GC_Route.cCode
                    WHERE   1 = 2;
                    INSERT  INTO #MYL_PDA_Base_Customer_Search
                            EXEC proc_ts_ReferVouch_SalesOut_Get '0', 'LIST',
                                @ParmList; 
                    SET NOCOUNT OFF;
                    SELECT  cCusCode AS ccuscode ,
                            cCusName AS ccusname ,
                            cCusAbbName AS ccusabbname ,
                            cCCCode AS ccccode ,
                            cDCCode AS cdccode ,
                            cTrade AS ctrade ,
                            cCusAddress AS ccusaddress ,
                            cCusPostCode AS ccuspostcode ,
                            cCusRegCode AS ccusregcode ,
                            cCusBank AS ccusbank ,
                            cCusAccount AS ccusaccount ,
                            CONVERT(VARCHAR(100), dCusDevDate, 23) AS dcusdevdate ,
                            cCusLPerson AS ccuslperson ,
                            cCusEmail AS ccusemail ,
                            cCusPerson AS ccusperson ,
                            cCusPhone AS ccusphone ,
                            cCusFax AS ccusfax ,
                            cCusBP AS ccusbp ,
                            cCusHand AS ccushand ,
                            cCusPPerson AS ccuspperson ,
                            iCusDisRate AS icusdisrate ,
                            cCusCreGrade AS ccuscregrade ,
                            iCusCreLine AS icuscreline ,
                            iCusCreDate AS icuscredate ,
                            cCusPayCond AS ccuspaycond ,
                            cCusOAddress AS ccusoaddress ,
                            cCusOType AS ccusotype ,
                            cCusHeadCode AS ccusheadcode ,
                            cCusWhCode AS ccuswhcode ,
                            cCusDepart AS ccusdepart ,
                            iARMoney AS iarmoney ,
                            dLastDate AS dlastdate ,
                            iLastMoney AS ilastmoney ,
                            dLRDate AS dlrdate ,
                            iLRMoney AS ilrmoney ,
                            dEndDate AS denddate ,
                            iFrequency AS ifrequency ,
                            iCostGrade AS icostgrade ,
                            cCreatePerson AS ccreateperson ,
                            cModifyPerson AS cmodifyperson ,
                            dModifyDate AS dmodifydate ,
                            cRelVendor AS crelvendor ,
                            iId AS iid ,
                            cPriceGroup AS cpricegroup ,
                            cOfferGrade AS coffergrade ,
                            iOfferRate AS iofferrate ,
                            cCusDefine1 AS ccusdefine1 ,
                            cCusDefine2 AS ccusdefine2 ,
                            cCusDefine3 AS ccusdefine3 ,
                            cCusDefine4 AS ccusdefine4 ,
                            cCusDefine5 AS ccusdefine5 ,
                            cCusDefine6 AS ccusdefine6 ,
                            cCusDefine7 AS ccusdefine7 ,
                            cCusDefine8 AS ccusdefine8 ,
                            cCusDefine9 AS ccusdefine9 ,
                            cCusDefine10 AS ccusdefine10 ,
                            cCusDefine10 AS ccusdefine11 ,
                            cCusDefine10 AS ccusdefine12 ,
                            cCusDefine10 AS ccusdefine13 ,
                            cCusDefine10 AS ccusdefine14 ,
                            cCusDefine10 AS ccusdefine15 ,
                            cCusDefine10 AS ccusdefine16 ,
                            pubufts ,
                            cInvoiceCompany AS cinvoicecompany ,
                            bCredit AS bcredit ,
                            bCreditDate AS bcreditdate ,
                            bCreditByHead AS bcreditbyhead ,
                            bLicenceDate AS blicencedate ,
                            dLicenceSDate AS dlicencesdate ,
                            dLicenceEDate AS dlicenceedate ,
                            iLicenceADays AS ilicenceadays ,
                            bBusinessDate AS bbusinessdate ,
                            dBusinessSDate AS bbusinesssdate ,
                            dBusinessEDate AS dbusinessedate ,
                            iBusinessADays AS ibusinessadays ,
                            bProxy AS bproxy ,
                            dProxySDate AS dproxysdate ,
                            dProxyEDate AS dproxyedate ,
                            iProxyADays AS iproxyadays ,
                            cMemo AS cmemo ,
                            bLimitSale AS blimitsale ,
                            cCusContactCode AS ccuscontactcode ,
                            cCusCountryCode AS ccuscountrycode ,
                            cCusEnName AS ccusenname ,
                            cCusEnAddr1 AS ccusenaddr1 ,
                            cCusEnAddr2 AS ccusenaddr2 ,
                            cCusEnAddr3 AS ccusenaddr3 ,
                            cCusEnAddr4 AS ccusenaddr4 ,
                            cCusPortCode AS ccusportcode ,
                            cPrimaryVen AS cprimaryven ,
                            fCommisionRate AS fcommisionrate ,
                            fInsueRate AS finsuerate ,
                            bHomeBranch AS bhomebranch ,
                            cBranchAddr AS cbranchaddr ,
                            cBranchPhone AS cbranchphone ,
                            cBranchPerson AS cbranchperson ,
                            cCusTradeCCode AS ccustradeccode ,
                            CustomerKCode AS customerkcode ,
                            bCusState AS bcusstate ,
                            bShop AS bshop ,
                            cCusBankCode AS ccusbankcode ,
                            cCusExch_name AS ccusexch_name ,
                            iCusGSPType AS icusgsptype ,
                            iCusGSPAuth AS icusgspauth ,
                            cCusGSPAuthNo AS ccusgspauthno ,
                            cCusBusinessNo AS ccusbusinessno ,
                            cCusLicenceNo AS ccuslicenceno ,
                            bCusDomestic AS bcusdomestic ,
                            bCusOverseas AS bcusoverseas ,
                            cCusCreditCompany AS ccuscreditcompany ,
                            cCusSAProtocol AS ccussaprotocol ,
                            cCusExProtocol AS ccusexprotocol ,
                            cCusOtherProtocol AS ccusotherprotocol ,
                            fCusDiscountRate AS fcusdiscountrate ,
                            cCusSSCode AS ccussscode ,
                            cCusCMProtocol AS ccuscmprotocol ,
                            dCusCreateDatetime AS dcuscreatedatetime ,
                            cCusAppDocNo AS ccusappdocno ,
                            cCusMnemCode AS ccusmnemcode ,
                            fAdvancePaymentRatio AS fadvancepaymentratio ,
                            bServiceAttribute AS bserviceattribute ,
                            bRequestSign AS brequestsign ,
                            bOnGPinStore AS bongpinstore ,
                            cCusMngTypeCode AS ccusmngtypecode ,
                            account_type ,
                            cCusImAgentProtocol AS ccusimagentprotocol ,
                            iSourceType AS isourcetype ,
                            iSourceId AS isourceid ,
                            fExpense AS fexpense ,
                            fApprovedExpense AS fapprovedexpense ,
                            dTouchedTime AS dtouchedtime ,
                            dRecentlyInvoiceTime AS drecentlyinvoicetime ,
                            dRecentlyQuoteTime AS drecentlyquotetime ,
                            dRecentlyActivityTime AS drecentlyactivitytime ,
                            dRecentlyChanceTime AS drecentlychancetime ,
                            dRecentlyContractTime AS drecentlycontracttime ,
                            cLtcCustomerCode AS cltccustomercode ,
                            bTransFlag AS btransflag ,
                            cLtcPerson AS cltcperson ,
                            dLtcDate AS dltcdate ,
                            cLocationSite AS clocationsite ,
                            iCusTaxRate AS icustaxrate ,
                            alloct_dept_time ,
                            allot_user_time ,
                            recyle_dept_time ,
                            recyle_pub_time ,
                            cLicenceNo AS clicenceno ,
                            cLicenceRange AS clicencerange ,
                            cCusBusinessRange AS ccusbusinessrange ,
                            dCusGSPEDate AS dcusgspedate ,
                            dCusGSPSDate AS dcusgspsdate ,
                            iCusGSPADays AS icusgspadays ,
                            bIsCusAttachFile AS biscusattachfile ,
                            dRecentContractDate AS drecentcontractdate ,
                            dRecentDeliveryDate AS drecentdeliverydate ,
                            dRecentOutboundDate AS drecentoutbounddate ,
                            cProvince AS cprovince ,
                            cCity AS ccity ,
                            cCounty AS ccounty ,
                            cCusAddressGUID AS ccusaddressguid ,
                            cAddCode AS caddcode 
							--U812.5 没有这几个字段
                           -- cCreditAddCode AS ccreditaddcode ,
                           -- cRegCash AS cregcash ,
                           -- dDepBeginDate AS ddepbegindate ,
                           -- iEmployeeNum AS iemployeenum ,
                           -- cURL AS curl ,
                           -- PictureGUID AS pictureguid
                    FROM    Customer WITH ( NOLOCK )
                    WHERE   ccuscode IN (
                            SELECT  DISTINCT
                                    ccuscode
                            FROM    #MYL_PDA_Base_Customer_Search )
                    ORDER BY ccuscode ASC;
                END;
    END;


 