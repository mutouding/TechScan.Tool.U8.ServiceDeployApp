if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.proc_ts_BarCodeScanCheck'))
begin
	drop proc proc_ts_BarCodeScanCheck
end
--Go 

if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.func_ts_GetRandString'))
begin
	drop FUNCTION func_ts_GetRandString
end
--Go 

if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.func_ts_GetParamValueBySplitString'))
begin
	drop FUNCTION func_ts_GetParamValueBySplitString
end
--Go 

if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.f_ts_SplitParamString'))
begin
	drop FUNCTION f_ts_SplitParamString
end
--Go 

if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.[ts_VoucherFields_Mapping]'))
begin
	drop TABLE [ts_VoucherFields_Mapping]
end
--Go 

if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.ts_proc_InvBatchStock'))
begin
	drop proc ts_proc_InvBatchStock
end
--Go 

if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.proc_ts_ReferVouch_MaterialOut_Get'))
begin
	drop proc proc_ts_ReferVouch_MaterialOut_Get
end
--Go 

if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.proc_ts_ReferVouch_TransVouch_Get'))
begin
	drop proc proc_ts_ReferVouch_TransVouch_Get
end
--Go 

if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.proc_ts_ReferVouch_SalesOut_Get'))
begin
	drop proc proc_ts_ReferVouch_SalesOut_Get
end
--Go 

if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.proc_ts_ReferVouch_PurchaseIn_Get'))
begin
	drop proc proc_ts_ReferVouch_PurchaseIn_Get
end
--Go 

if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.proc_ts_ReferVouch_PU_Arrival_Get'))
begin
	drop proc proc_ts_ReferVouch_PU_Arrival_Get
end
--Go 

if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.proc_ts_ReferVouch_ProductIn_Get'))
begin
	drop proc proc_ts_ReferVouch_ProductIn_Get
end
--Go 

if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.proc_ts_ReferVouch_Notification_Get'))
begin
	drop proc proc_ts_ReferVouch_Notification_Get
end
--Go 

if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.proc_ts_ReferVouch_MaterialOut_Get'))
begin
	drop proc proc_ts_ReferVouch_MaterialOut_Get
end
--Go 

if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.proc_ts_ReferVouch_MaterialOut_Get'))
begin
	drop proc proc_ts_ReferVouch_MaterialOut_Get
end
--Go 

if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.proc_ts_Base_Customer_Get'))
begin
	drop proc proc_ts_Base_Customer_Get
end

if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.proc_ts_SplitParamString'))
begin
	drop proc proc_ts_SplitParamString
end

if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.proc_ts_ReferVouch_SA_Dispatch_Get'))
begin
	drop proc proc_ts_ReferVouch_SA_Dispatch_Get
end

if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.proc_ts_KC_BoxSplit'))
begin
	drop proc proc_ts_KC_BoxSplit
end

if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.proc_ts_ReferVouch_Picking_Get'))
begin
	drop proc proc_ts_ReferVouch_Picking_Get
end

if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.proc_ts_ReferVouch_BoxUp_Get'))
begin
	drop proc proc_ts_ReferVouch_BoxUp_Get
end


if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.ts_barcodeGUID'))
begin
	drop table ts_barcodeGUID
end

if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.ts_EBhistorys'))
begin
	drop table ts_EBhistorys
end

if exists(Select * from dbo.sysobjects where id = OBJECT_ID(N'dbo.proc_ts_BarCodeStatus'))
begin
	drop proc proc_ts_BarCodeStatus
end



