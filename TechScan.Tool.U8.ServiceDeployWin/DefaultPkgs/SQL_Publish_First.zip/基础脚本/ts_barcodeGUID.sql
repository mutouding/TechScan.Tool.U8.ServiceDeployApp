﻿CREATE TABLE [dbo].[ts_BarcodeGuid](
	[GUID] [varchar](100) NOT NULL,
	[vouchtype] [nvarchar](50) NULL,
	[ccode] [nvarchar](50) NULL,
	[ddate] [datetime] NULL,
 CONSTRAINT [PK_ts_BarcodeGuid] PRIMARY KEY CLUSTERED 
(
	[GUID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]