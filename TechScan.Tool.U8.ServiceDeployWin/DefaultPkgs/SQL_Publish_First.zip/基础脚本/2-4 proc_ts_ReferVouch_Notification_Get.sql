﻿/*---------------------------------------------------------------------
* 			Copyright (C) 2018 TECHSCAN 版权所有。
*           www.techscan.cn
*┌──────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．　│
*│　版权所有：上海太迅自动识别技术有限公司 　 　　　　　　　　　　　　│
*└──────────────────────────────────┘
*
* 文件名：   proc_ts_ReferVouch_Notification_Get.SQL
* 功能：     存储过程
* 描述：     获取上游来源单据信息通知
* 作者：     马永龙
* 创建时间： 2018-05-03 16:00:16
* 文件版本： V1.0.8

===============================版本履历===============================
* Ver 		变更日期 				负责人 	变更内容
* V1.0.0	2018-06-20				Myl		Create
======================================================================
//--------------------------------------------------------------------*/

--proc_ts_ReferVouch_Notification_Get 'VOUCHER01:0,1,2,3,4,5,-0,-1,-2,-3'

Create PROC proc_ts_ReferVouch_Notification_Get
    (
      @ParamsList NVARCHAR(1000) = N''
    )
    --WITH ENCRYPTION
AS
    BEGIN
    
        IF EXISTS ( SELECT  0
                    WHERE   NOT OBJECT_ID('tempdb..#STPDAEACHVouchNotify') IS NULL )
            DROP TABLE #STPDAEACHVouchNotify;
                     
        CREATE   TABLE #STPDAEACHVouchNotify
            (
              VouchTypeDesc VARCHAR(20) ,
              EachVouch CHAR(100)
            );
        INSERT  INTO #STPDAEACHVouchNotify
                EXEC proc_ts_SplitParamString @ParamsList, N'@', DEFAULT;
        
        DECLARE @EachVouchTypeDesc VARCHAR(20);         
        DECLARE @EachVouch CHAR(100);
        DECLARE @VOUCH_TYPE CHAR(2);
        DECLARE EACH_VOUCHER_CURSOR CURSOR
        FOR
            SELECT  VouchTypeDesc ,
                    EachVouch
            FROM    #STPDAEACHVouchNotify;
        OPEN EACH_VOUCHER_CURSOR;
        FETCH NEXT FROM EACH_VOUCHER_CURSOR INTO @EachVouchTypeDesc,
            @EachVouch;
        WHILE ( @@fetch_status = 0 )
            BEGIN 
             
                DECLARE @PROC_NAME VARCHAR(50);
                DECLARE @PROC_PARAM VARCHAR(50);
                DECLARE @SQL_PARAM NVARCHAR(500);
                DECLARE @VOUCHER01 NVARCHAR(100);
                
                --SET @VOUCH_TYPE = SUBSTRING(@EachVouch,
                --                            CHARINDEX(N':', @EachVouch, 0) - 2,
                --                            2);
                SET @VOUCH_TYPE = SUBSTRING(@EachVouchTypeDesc,
                                            LEN(@EachVouchTypeDesc) - 1, 2);
                --PRINT @VOUCH_TYPE;
                IF ( @VOUCH_TYPE = N'01' )
                    SET @PROC_NAME = N'proc_ts_ReferVouch_PurchaseIn_Get';
                ELSE
                    IF ( @VOUCH_TYPE = N'10' )
                        SET @PROC_NAME = N'proc_ts_ReferVouch_ProductIn_Get';
                    ELSE
                        IF ( @VOUCH_TYPE = N'32' )
                            SET @PROC_NAME = N'proc_ts_ReferVouch_SalesOut_Get';
                        ELSE
                            IF ( @VOUCH_TYPE = N'11' )
                                SET @PROC_NAME = N'proc_ts_ReferVouch_MaterialOut_Get';
                            ELSE
                                IF ( @VOUCH_TYPE = N'12' )
                                    SET @PROC_NAME = N'proc_ts_ReferVouch_TransVouch_Get';
                                ELSE
                                    IF ( @VOUCH_TYPE = N'97'
                                         OR @VOUCH_TYPE = N'98'
                                       )
                                        SET @PROC_NAME = N'proc_ts_ReferVouch_PU_Arrival_Get';
                                    ELSE
                                        RAISERROR('暂不支持的参照单据通知类型，参照类型编码：%s. ',16,1, @VOUCH_TYPE);

  
                --DECLARE @splitIndex BIGINT;
                --SET @splitIndex = CHARINDEX(N':', @EachVouch, 0);
                --SET @VOUCHER01 = SUBSTRING(@EachVouch, @splitIndex + 1,
                                           --LEN(@EachVouch) - @splitIndex);
			--SET @VOUCHER01 = dbo.func_ts_GetParamValueBySplitString(@ParamsList,N'VOUCHER01',DEFAULT, DEFAULT);

                IF ( @EachVouch <> N'' )
                    BEGIN
                --SET @PROC_NAME = N'proc_ts_ReferVouch_PurchaseIn_Get';
                        IF EXISTS ( SELECT  0
                                    WHERE   NOT OBJECT_ID('tempdb..#STPDAVouchNotifyVouch01') IS NULL )
                            DROP TABLE #STPDAVouchNotifyVouch01;
                    
                        CREATE   TABLE #STPDAVouchNotifyVouch01 ( OperType
                                                              CHAR(5) );
                        INSERT  INTO #STPDAVouchNotifyVouch01
                                EXEC proc_ts_SplitParamString @EachVouch;
                            
                  --Start
                  
                        DECLARE @OperType CHAR(5);
                        DECLARE VOUCHER01_CURSOR CURSOR
                        FOR
                            SELECT  OperType
                            FROM    #STPDAVouchNotifyVouch01;
                        OPEN VOUCHER01_CURSOR;
                        FETCH NEXT FROM VOUCHER01_CURSOR INTO @OperType;
                        WHILE ( @@fetch_status = 0 )
                            BEGIN
                                IF ( CHARINDEX('-', @OperType, 0) <> 0 )
                                    BEGIN
                                        SET @PROC_PARAM = N'bRed:1';
                                        SET @OperType = SUBSTRING(@OperType, 2,
                                                              LEN(@OperType)
                                                              - 1);
                                    END;
                                ELSE
                                    BEGIN
                                        SET @PROC_PARAM = N'';
                                    END;
                                
                                SET @SQL_PARAM = N'EXEC ' + @PROC_NAME
                                    + N' ''' + SUBSTRING(@OperType, 1, 1)
                                    + N''', ''LIST'', ''' + @PROC_PARAM
                                    + N''' ';
                            --PRINT @SQL_PARAM;
                                EXEC sp_executesql @SQL_PARAM;
                                --PRINT @@ROWCOUNT;	 								 
							--用游标去取下一条记录    
                                FETCH NEXT FROM VOUCHER01_CURSOR INTO @OperType;    
                            END;    
					--关闭游标    
                        CLOSE VOUCHER01_CURSOR;    
					--撤销游标    
                        DEALLOCATE VOUCHER01_CURSOR;  
							 
                        IF EXISTS ( SELECT  0
                                    WHERE   NOT OBJECT_ID('tempdb..#STPDAVouchNotifyVouch01') IS NULL )
                            DROP TABLE #STPDAVouchNotifyVouch01;
				--END          

                    END;
            
                FETCH NEXT FROM EACH_VOUCHER_CURSOR INTO @EachVouchTypeDesc,
                    @EachVouch;
            END;
            
            --关闭游标    
        CLOSE EACH_VOUCHER_CURSOR;    
					--撤销游标    
        DEALLOCATE EACH_VOUCHER_CURSOR;  
        IF EXISTS ( SELECT  0
                    WHERE   NOT OBJECT_ID('tempdb..#STPDAEACHVouchNotify') IS NULL )
            DROP TABLE #STPDAEACHVouchNotify;
    END;