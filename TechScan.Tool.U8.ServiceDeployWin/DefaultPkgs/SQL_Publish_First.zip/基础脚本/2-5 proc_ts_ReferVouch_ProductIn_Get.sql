﻿
/*---------------------------------------------------------------------  
*    Copyright (C) 2018 TECHSCAN 版权所有。  
*           www.techscan.cn  
*┌────────────────────────────────────┐  
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．      │  
*│　版权所有：上海太迅自动识别技术有限公司 　 　　　　　　　　　　　　    │  
*└────────────────────────────────────┘  
*  
* 文件名：   proc_ts_ReferVouch_ProductIn_Get.SQL  
* 功能：     存储过程  
* 描述：     ST库存[产成品入库单]-获取上游可参照单据信息  
* 作者：     马永龙  
* 创建时间： 2018-03-06 10:10:29  
* 文件版本： V1.0.6
  
===============================版本履历===============================  
* Ver		变更日期				负责人		变更内容  
* V1.0.0	2018-03-06 10:10:29  Myl		Create  
* V1.0.1	2018-03-08			Myl			增加不良品处理单获取  
* V1.0.2	2018-03-11			Myl			①：产成品入库单所有参照类型，表体字段添加bFree1-bFree10等10个自由项字段  
* V1.0.3	2018-05-15			Myl			修改所有参照单据中的日期格式为'yyyy-MM-dd'格式（CONVERT(varchar(100), ddate, 23)） 
* V1.0.4	2018-03-11			Myl			①：产成品入库单参照生产订单时，表体添加iscanedquantity和isanednum字段 
											②：产成品入库单参照生产订单时，表体添加inquantity和inum，innum字段（inum和innum字段为手动0 AS的）
* V1.0.5	2018-07-13			Myl			表体添加统一bodyautoid字段（表体唯一ID的副本字段，前台用）
* V1.0.6	2018-09-11			Myl			修复产成品入库参照生产订单红字的iNQuantity数量处理错误问题
* V1.0.7	2019-03-28			dxh			参照生产订单入库，过滤掉质检项
* V1.0.8	2019-04-23			dxh			增加部门字段
* V1.0.9	2019-05-07			dxh			生产订单并单
======================================================================  
//--------------------------------------------------------------------*/  
  
--EXEC proc_ts_ReferVouch_ProductIn_Get '2','DETAIL','ShowClosed:0@@cmaker:demo@@Ids:12,1@@cRejectCodeFrom:0000000001'  
--EXEC proc_ts_ReferVouch_ProductIn_Get '1','DETAIL','ShowClosed:0@@cmaker:demo@@Ids:12,1@@cCode:00000010001'  
--EXEC proc_ts_ReferVouch_ProductIn_Get '1','DETAIL','ShowClosed:0@@cmaker:demo@@Ids:1'  
--EXEC proc_ts_ReferVouch_ProductIn_Get '2','DETAIL',''  
--EXEC proc_ts_ReferVouch_ProductIn_Get '2','DETAIL',''  
--exec proc_ts_ReferVouch_ProductIn_Get '3','DETAIL','chkcode:0000000051'

CREATE PROC [dbo].[proc_ts_ReferVouch_ProductIn_Get]
    (
      @OperType CHAR(1) ,  
      --获取类型（'LIST'获取上游参照单据列表;'DETAIL'获取上游参照单据详情（包含表头表体））  
      --默认获取上游参照单据列表  
      @GetType VARCHAR(10) = N'LIST' ,  
      --传入的参数列表字符串  
      --默认传空值  
      @ParamsList NVARCHAR(2000) = N''  
    )
AS
    BEGIN  
  
		--是否参照生产订单（红字）bRed参数  
        DECLARE @bRed VARCHAR(1);  
        SET @bRed = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                           N'bRed', DEFAULT,
                                                           DEFAULT);  
        IF ( @bRed = N'' )
            BEGIN  
                SET @bRed = N'0';  
            END;  
  
		--生产部门编码（OR 委外订单部门编码 OR 领料申请单部门编码）  
        DECLARE @DeptCode NVARCHAR(12);  
        SET @DeptCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'DeptCode',
                                                              DEFAULT, DEFAULT);  
        --生产部门名称（OR 委外订单部门名称 OR 领料申请单部门名称）  
        DECLARE @DeptName NVARCHAR(255);  
        SET @DeptName = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'DeptName',
                                                              DEFAULT, DEFAULT);  
		--产品-存货编码  
        DECLARE @ProInvCode NVARCHAR(60);  
        SET @ProInvCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ProInvCode',
                                                              DEFAULT, DEFAULT);  
        --产品-存货代码  
        DECLARE @ProInvAddCode NVARCHAR(255);  
        SET @ProInvAddCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ProInvAddCode',
                                                              DEFAULT, DEFAULT);  
        --产品-存货名称  
        DECLARE @ProInvName NVARCHAR(255);  
        SET @ProInvName = '%'
            + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                     N'ProInvName', DEFAULT,
                                                     DEFAULT) + '%';  
        --产品-存货规格  
        DECLARE @ProInvStd NVARCHAR(255);  
        SET @ProInvStd = '%'
            + dbo.func_ts_GetParamValueBySplitString(@ParamsList, N'ProInvStd',
                                                     DEFAULT, DEFAULT) + '%';  
                                                       
		--制单人  
        DECLARE @cMaker NVARCHAR(30);  
        SET @cMaker = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                             N'cMaker',
                                                             DEFAULT, DEFAULT);  
		--生产订单单号起始  
        DECLARE @cMoCodeFrom NVARCHAR(max);  
        SET @cMoCodeFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cMoCodeFrom',
                                                              DEFAULT, DEFAULT);  
IF(@cMoCodeFrom <> N'')
            BEGIN                             
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempMOCodes') IS NULL )
                    DROP TABLE #STPDATempMOCodes;
                    
                CREATE   TABLE #STPDATempMOCodes ( MoCode NVARCHAR(30) );
                INSERT  INTO #STPDATempMOCodes
                        EXEC proc_ts_SplitParamString @cMoCodeFrom;
            END;



		--生产订单单号截至  
        --DECLARE @cMoCodeTo NVARCHAR(30);  
        --SET @cMoCodeTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
        --                                                      N'cMoCodeTo',
        --                                                      DEFAULT, DEFAULT);  
        --IF ( @cMoCodeTo = N'' )
        --    BEGIN  
        --        SET @cMoCodeTo = @cMoCodeFrom;  
        --    END; 
			
			  
        --生产批号  
        DECLARE @MoLotCode NVARCHAR(60);  
        SET @MoLotCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MoLotCode',
                                                              DEFAULT, DEFAULT);  
		--服务单号  
        DECLARE @cServiceCode NVARCHAR(30);  
        SET @cServiceCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cServiceCode',
                                                              DEFAULT, DEFAULT);  
        --生产订单行号  
        DECLARE @MoSeq NVARCHAR(30);  
        SET @MoSeq = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                            N'MoSeq', DEFAULT,
                                                            DEFAULT);  
        --执行完未关闭是否显示(1:显示/0:不显示;默认不显示)  
        DECLARE @ShowClosed CHAR(1);  
        SET @ShowClosed = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ShowClosed',
                                                              DEFAULT, DEFAULT);  
        IF ( @ShowClosed = N'' )
            BEGIN  
                SET @ShowClosed = N'0';  
            END;  
              
         
        DECLARE @ParmList NVARCHAR(MAX);set @ParmList = N'';  
        DECLARE @SqlCommand NVARCHAR(MAX) ;set @SqlCommand= N'';  
  
        --参照生产订单带出检验单明细
  	    IF ( @OperType = N'3' and  @GetType = N'DETAIL') 
             BEGIN
                --生产订单关联检验单单号起始  
                DECLARE @chkcode NVARCHAR(1000);   
                SET @chkcode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'chkcode',
                                                              DEFAULT, DEFAULT);

			   IF(@chkcode <> N'')
            BEGIN                             
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempchkcodes') IS NULL )
                    DROP TABLE #STPDATempchkcodes;
                    
                CREATE   TABLE #STPDATempchkcodes ( chkcode NVARCHAR(30) );
                INSERT  INTO #STPDATempchkcodes
                        EXEC proc_ts_SplitParamString @chkcode;
            END;

Declare @SqlHeadCommand  NVARCHAR(MAX) ;set @SqlHeadCommand= N'';  

          SET  @SqlHeadCommand  ='  SELECT DISTINCT 
''''              AS selcol,
                id              bodyautoid,
                sotype          AS isotype,
                SoDId           AS isodid,
                SoCode          AS csocode,
                SoSeq           AS isoseq,
                ddate,
                ccheckcode,
                ccheckpersoncode,
                ccheckpersonname,
                sourcecode,
                cprobatch,
                id              AS iCheckIdBaks,
                cinspectdepcode AS cdepcode,
                cinspectdepname AS cdepname,
                cinspectdepcode,
                cinspectdepname,
                cdefine1,
                cdefine2,
                cdefine3,
                cdefine4,
                cdefine5,
                cdefine6,
                cdefine7,
                cdefine8,
                cdefine9,
                cdefine10,
                cdefine11,
                cdefine12,
                bexigency,
                cdefine13,
                cdefine14,
                cdefine15,
                cdefine16,
                cmemo,
                cinvaddcode,
                cinvcode,
                cinvname,
                cinvstd,
                cbatch,
                dprodate,
                dvdate,
                imassdate,
                ccomunitcode,
                ccomunitname,
                ccomunitname    AS cinvm_unit,
                cunitid,
                cunitname,
				fquantity as inquantity,
               -- fquantity       AS iquantity,
                fnum            AS inum,
                fregquantity    AS iquantity,
                CASE
                  WHEN Isnull(fchangrate, 0) <> 0 THEN fregquantity / fchangrate
                  ELSE 0
                END             AS innum,
                fchangrate,
                fchangrate      ichangerate,
                citemclass,
                citemclass      cItem_class,
                citemcname,
                citemcode,
                citemname,
                id,
                cdefine22,
                cdefine23,
                cdefine24,
                cdefine25,
                cdefine26,
                cdefine27,
                cdefine28,
                cdefine29,
                cdefine30,
                cdefine31,
                cdefine32,
                cdefine33,
                cdefine34,
                cdefine35,
                cdefine36,
                cdefine37,
                cfree1,
                cfree2,
                cfree3,
                cfree4,
                cfree5,
                cfree6,
                cfree7,
                cfree8,
                cfree9,
                cfree10,
                cinvdefine1,
                cinvdefine2,
                cinvdefine3,
                cinvdefine4,
                cinvdefine5,
                cinvdefine6,
                cinvdefine7,
                cinvdefine8,
                fconquantiy,
                fregquantity,
                cinvdefine9,
                cinvdefine10,
                cinvdefine11,
                cinvdefine12,
                cinvdefine13,
                cinvdefine14,
                cinvdefine15,
                cinvdefine16,
                bfree1,
                bfree2,
                bfree3,
                bfree4,
                bfree5,
                bfree6,
                bfree7,
                bfree8,
                bfree9,
                bfree10,
                cgroupcode,
                igrouptype,
                bservice,
                binvbatch,
                ufts,
                sourceautoid    AS impoids,
                sourceautoid,
                imoseq,
                cwhcode,
                cwhname,
                iOpSeq,
                cOpDesc,
                cMWorkCenterCode,
                cMWorkCenter,
                cordercode,
                iorderdid,
                iorderseq,
                isoordertype,
                cCiqBookCode,
                iExpiratDateCalcu,
                cExpirationdate,
                dExpirationdate,
                cbatchproperty1,
                cbatchproperty2,
                cbatchproperty3,
                cbatchproperty4,
                cbatchproperty5,
                cbatchproperty6,
                cbatchproperty7,
                cbatchproperty8,
                cbatchproperty9,
                cbatchproperty10,
                cservicecode,
                dkey,
                csysbarcode,
                bmergecheckflag,
                cdepcode,
                sourcecode      AS cmocode,
                autoid,
                dmadedate,
                CBYPRODUCT,
                iordertype,
                csocode,
                isoseq,
                isodid  ,
                cmassunit,
                imassdate,
                lplancode,isnull(FsumQuantity,0) as ireceivedqty
FROM   (SELECT *
        FROM   (SELECT *,
                       Isnull(bproinflag, 0) AS bAllInput
                FROM   (SELECT Cast(qmcheckvoucher.id AS VARCHAR) + ''D''
                               + ''-1''                                                AS dkey,
                               N''''                                                   AS selcol,
                               qmcheckvoucher.ddate,
                               qmcheckvoucher.bproinflag                             AS bproinflag,
                               qmcheckvoucher.ccheckcode,
                               qmcheckvoucher.ccheckpersoncode,
                               person.cpersonname                                    AS ccheckpersonname,
                               ( CASE Isnull(qmcheckvoucher.CSOURCEPROORDERCODE, '''')
                                   WHEN '''' THEN qmcheckvoucher.sourcecode
                                   ELSE qmcheckvoucher.CSOURCEPROORDERCODE
                                 END )                                               AS sourcecode,
                               qmcheckvoucher.cprobatch,
                               ( CASE Isnull(qmcheckvoucher.ISOURCEPROORDERAUTOID, 0)
                                   WHEN 0 THEN qmcheckvoucher.cinspectdepcode
                                   ELSE mom_orderdetail.MDeptCode
                                 END )                                               AS cinspectdepcode,
                               department.cdepname                                   AS cinspectdepname,
                               ( CASE
                                   WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN ( CASE
                                                                                              WHEN Isnull(mom_orderdetail.sfcflag, 0) = 0 THEN mom_orderdetail.remark
                                                                                              ELSE B.remark
                                                                                            END )
                                   ELSE ( CASE
                                            WHEN Isnull(a.sfcflag, 0) = 0 THEN a.remark
                                            ELSE C.remark
                                          END )
                                 END )                                               AS cmemo,
                               qmcheckvoucher.cdefine1,
                               qmcheckvoucher.cdefine2,
                               qmcheckvoucher.cdefine3,
                               qmcheckvoucher.cdefine4,
                               qmcheckvoucher.cdefine5,
                               qmcheckvoucher.cdefine6,
                               qmcheckvoucher.cdefine7,
                               qmcheckvoucher.cdefine8,
                               qmcheckvoucher.cdefine9,
                               qmcheckvoucher.cdefine10,
                               qmcheckvoucher.cdefine11,
                               qmcheckvoucher.cdefine12,
                               qmcheckvoucher.cdefine13,
                               qmcheckvoucher.cdefine14,
                               qmcheckvoucher.cdefine15,
                               qmcheckvoucher.cdefine16,
                               qmcheckvoucher.cinvcode,
                               cinvaddcode,
                               inventory.cinvname,
                               cinvstd,
                               cinvdefine1,
                               cinvdefine2,
                               cinvdefine3,
                               cinvdefine4,
                               cinvdefine5,
                               cinvdefine6,
                               cinvdefine7,
                               cinvdefine8,
                               cinvdefine9,
                               cinvdefine10,
                               cinvdefine11,
                               cinvdefine12,
                               cinvdefine13,
                               cinvdefine14,
                               cinvdefine15,
                               cinvdefine16,
                               qmcheckvoucher.cFree1,
                               qmcheckvoucher.cFree2,
                               qmcheckvoucher.cfree3,
                               qmcheckvoucher.cfree4,
                               qmcheckvoucher.cfree5,
                               qmcheckvoucher.cfree6,
                               qmcheckvoucher.cfree7,
                               qmcheckvoucher.cfree8,
                               qmcheckvoucher.cfree9,
                               qmcheckvoucher.cfree10,
                               qmcheckvoucher.cbatch,
                               ( CASE
                                   WHEN Isnull(inventory.binvquality, 0) = 1 THEN qmcheckvoucher.dprodate
                                   ELSE NULL
                                 END )                                               AS dprodate,
                               ( CASE
                                   WHEN Isnull(inventory.binvquality, 0) = 1 THEN qmcheckvoucher.dprodate
                                   ELSE NULL
                                 END )                                               AS dmadedate,
                               qmcheckvoucher.imassdate,
                               qmcheckvoucher.dvdate,
                               computationunit.ccomunitname,
                               computationunit1.ccomunitname                         AS cunitname,
                               qmcheckvoucher.iExpiratDateCalcu,
                               qmcheckvoucher.cExpirationdate,
                               qmcheckvoucher.dExpirationdate,
                               CASE Isnull(qmcheckvoucher.bproinflag, 0)
                                 WHEN 0 THEN ( CASE Isnull(inventory.iGroupType, 0)
                                                 WHEN 0 THEN 0
                                                 WHEN 1 THEN ( CASE Isnull(ifregbreakqtydealtype, 0)
                                                                 WHEN 1 THEN ( Isnull(fregquantity, 0)
                                                                               + Isnull(fconquantiy, 0) - Isnull(FsumQuantity, 0) ) / computationunit1.ichangrate
                                                                 ELSE ( Isnull(fregquantity, 0)
                                                                        + Isnull(fconquantiy, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) - Isnull(FsumQuantity, 0) ) / computationunit1.ichangrate
                                                               END )
                                                 WHEN 2 THEN ( CASE Isnull(ifregbreakqtydealtype, 0)
                                                                 WHEN 1 THEN ( Isnull(fchecknum, 0) - Isnull(FsumNum, 0) )
                                                                 ELSE ( Isnull(fchecknum, 0) - Isnull(FsumNum, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) / fcheckchangrate )
                                                               END )
                                               END )
                                 ELSE 0
                               END                                                   AS fnum,
                               CASE Isnull(qmcheckvoucher.bproinflag, 0)
                                 WHEN 0 THEN ( CASE Isnull(inventory.iGroupType, 0)
                                                 WHEN 0 THEN ( CASE Isnull(ifregbreakqtydealtype, 0)
                                                                 WHEN 1 THEN ( Isnull(fregquantity, 0)
                                                                               + Isnull(fconquantiy, 0) - Isnull(FsumQuantity, 0) )
                                                                 ELSE ( Isnull(fregquantity, 0)
                                                                        + Isnull(fconquantiy, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) - Isnull(FsumQuantity, 0) )
                                                               END )
                                                 WHEN 1 THEN ( CASE Isnull(ifregbreakqtydealtype, 0)
                                                                 WHEN 1 THEN ( Isnull(fregquantity, 0)
                                                                               + Isnull(fconquantiy, 0) - Isnull(FsumQuantity, 0) )
                                                                 ELSE ( Isnull(fregquantity, 0)
                                                                        + Isnull(fconquantiy, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) - Isnull(FsumQuantity, 0) )
                                                               END )
                                                 WHEN 2 THEN ( CASE Isnull(ifregbreakqtydealtype, 0)
                                                                 WHEN 1 THEN ( Isnull(fcheckqty, 0) - Isnull(Fsumquantity, 0) )
                                                                 ELSE ( Isnull(fcheckqty, 0) - Isnull(Fsumquantity, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) )
                                                               END )
                                               END )
                                 ELSE 0
                               END                                                   AS fquantity,
                               
                               FsumQuantity,
                               qminspectvouchers.cdefine22,
                               qminspectvouchers.cdefine23,
                               qminspectvouchers.cdefine24,
                               qminspectvouchers.cdefine25,
                               qminspectvouchers.cdefine26,
                               qminspectvouchers.cdefine27,
                               qminspectvouchers.cdefine28,
                               qminspectvouchers.cdefine29,
                               qminspectvouchers.cdefine30,
                               qminspectvouchers.cdefine31,
                               qminspectvouchers.cdefine32,
                               qminspectvouchers.cdefine33,
                               qminspectvouchers.cdefine34,
                               qminspectvouchers.cdefine35,
                               qminspectvouchers.cdefine36,
                               qminspectvouchers.cdefine37,
                               qmcheckvoucher.ID,
                               ( CASE Isnull(qmcheckvoucher.ISOURCEPROORDERAUTOID, 0)
                                   WHEN 0 THEN qmcheckvoucher.SOURCEAUTOID
                                   ELSE qmcheckvoucher.ISOURCEPROORDERAUTOID
                                 END )                                               AS sourceautoid,
                               inventory.ccomunitcode,
                               -1                                                    AS autoid,
                               qmcheckvoucher.cunitid,
                               qmcheckvoucher.citemclass,
                               qmcheckvoucher.citemcname,
                               qmcheckvoucher.citemcode,
                               qmcheckvoucher.citemname,
                               bfree1                                                AS bfree1,
                               bfree2                                                AS bfree2,
                               bfree3                                                AS bfree3,
                               bfree4                                                AS bfree4,
                               bfree5                                                AS bfree5,
                               bfree6                                                AS bfree6,
                               bfree7                                                AS bfree7,
                               bfree8                                                AS bfree8,
                               bfree9                                                AS bfree9,
                               bfree10                                               AS bfree10,
                               inventory.cgroupcode,
                               igrouptype,
                               FREGQUANTITY,
                               FCONQUANTIY,
                               bservice                                              AS bservice,
                               binvbatch                                             AS binvbatch,
                               ( CASE
                                   WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN e.wccode
                                   ELSE f.wccode
                                 END )                                               AS cMWorkCenterCode,
                               ( CASE
                                   WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN e.Description
                                   ELSE f.Description
                                 END )                                               AS cMWorkCenter,
                               ( CASE
                                   WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN B.opseq
                                   ELSE C.opseq
                                 END )                                               AS iOpSeq,
                               ( CASE
                                   WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN B.Description
                                   ELSE C.Description
                                 END )                                               AS cOpDesc,
                               ( CASE Isnull(DBO.qmcheckvoucher.ISOURCEPROORDERROWNO, 0)
                                   WHEN 0 THEN DBO.qmcheckvoucher.IPROORDERAUTOID
                                   ELSE DBO.qmcheckvoucher.ISOURCEPROORDERROWNO
                                 END )                                               AS imoseq,
                               ( CASE
                                   WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN mom_orderdetail.orderdid
                                   ELSE a.orderdid
                                 END )                                               AS IORDERDID,
                               ( CASE
                                   WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN mom_orderdetail.ordertype
                                   ELSE a.ordertype
                                 END )                                               AS ISOORDERTYPE,
                               ( CASE
                                   WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN mom_orderdetail.ordercode
                                   ELSE a.ordercode
                                 END )                                               AS CORDERCODE,
                               ( CASE
                                   WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN mom_orderdetail.orderseq
                                   ELSE a.orderseq
                                 END )                                               AS IORDERSEQ,
                               ( CASE
                                   WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN mom_orderdetail.ManualCode
                                   ELSE a.ManualCode
                                 END )                                               AS cciqbookcode,
                               ( CASE
                                   WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN mom_orderdetail.SourceSvcCode
                                   ELSE a.SourceSvcCode
                                 END )                                               AS cservicecode,
                               qmcheckvoucher.cwhcode                                AS cwhcode,
                               warehouse.cwhname                                     AS cwhname,
                               CONVERT(CHAR, CONVERT(MONEY, qmcheckvoucher.ufts), 2) AS ufts,
                               qmcheckvoucher.iordertype,
                               qmcheckvoucher.CSOORDERCODE                           AS csocode,
                               CASE qmcheckvoucher.iordertype
                                 WHEN 1 THEN SO_SODETAILS.IROWNO
                                 WHEN 3 THEN EX_ORDERDETAIL.IROWNO
                                 ELSE NULL
                               END                                                   AS isoseq,
                               qmcheckvoucher.ISOORDERAUTOID                         AS iSoDID,
                               ( CASE Isnull(QMCheckVOUCHER.CBYPRODUCT, 0)
                                   WHEN 0 THEN N''否''
                                   ELSE N''是''
                                 END )                                               AS bRelated,
                               qmcheckvoucher.CBATCHPROPERTY1,
                               qmcheckvoucher.CBATCHPROPERTY2,
                               qmcheckvoucher.CBATCHPROPERTY3,
                               qmcheckvoucher.CBATCHPROPERTY4,
                               qmcheckvoucher.CBATCHPROPERTY5,
                               qmcheckvoucher.CBATCHPROPERTY6,
                               qmcheckvoucher.CBATCHPROPERTY7,
                               qmcheckvoucher.CBATCHPROPERTY8,
                               qmcheckvoucher.CBATCHPROPERTY9,
                               qmcheckvoucher.CBATCHPROPERTY10,
                               inventory.iid,
                               CASE Isnull(inventory.iGroupType, 0)
                                 WHEN 0 THEN NULL
                                 WHEN 1 THEN computationunit1.ichangrate
                                 WHEN 2 THEN ( CASE Isnull(ifregbreakqtydealtype, 0)
                                                 WHEN 1 THEN
                                                   CASE ( Isnull(fchecknum, 0) - Isnull(FsumNum, 0) )
                                                     WHEN 0 THEN NULL
                                                     ELSE ( Isnull(fcheckqty, 0) - Isnull(FsumQuantity, 0) ) / ( Isnull(fchecknum, 0) - Isnull(FsumNum, 0) )
                                                   END
                                                 ELSE
                                                   CASE ( Isnull(fchecknum, 0) - Isnull(FsumNum, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) / fcheckchangrate )
                                                     WHEN 0 THEN NULL
                                                     ELSE ( Isnull(fcheckqty, 0) - Isnull(FsumQuantity, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) ) / ( Isnull(fchecknum, 0) - Isnull(FsumNum, 0) - Isnull(FREGBREAKQUANTITY, 0) * Isnull(FCHECKRATE, 1) / fcheckchangrate )
                                                   END
                                               END )
                               END                                                   AS fchangrate,
                               ( CASE qmcheckvoucher.cmassunit
                                   WHEN 1 THEN N''年''
                                   WHEN 2 THEN N''月''
                                   WHEN 3 THEN N''日''
                                   ELSE N''''
                                 END )                                               AS cmassunit,
                               qmcheckvoucher.cmaker,
                               Isnull(QMCheckVoucher.BEXIGENCY, 0)                   AS BEXIGENCY,
                               QMCheckVoucher.fsampqty,
                               qmcheckvoucher.FSAMPQTYINS,
                               qmcheckvoucher.CSYSBARCODE,
                               qmcheckvoucher.bmergecheckflag,
                               qmcheckvoucher.id                                     AS iCheckIdBaks,
                               department.cdepcode,
                               qmcheckvoucher.CBYPRODUCT,
                               mom_orderdetail.SoType,
                               mom_orderdetail.SoDId,
                               mom_orderdetail.SoCode,
                               mom_orderdetail.SoSeq,
                               mom_orderdetail.LPlanCode                             AS lplancode
                        FROM   qmcheckvoucher  WITH (NOLOCK)
                               LEFT JOIN qminspectvouchers WITH (NOLOCK)
                                      ON qmcheckvoucher.inspectautoid = qminspectvouchers.autoid
                               LEFT JOIN qminspectvoucher  WITH (NOLOCK)
                                      ON qminspectvouchers.id = qminspectvoucher.id
                               INNER JOIN inventory  WITH (NOLOCK)
                                       ON qmcheckvoucher.cinvcode = inventory.cinvcode
                               LEFT JOIN person  WITH (NOLOCK)
                                      ON qmcheckvoucher.ccheckpersoncode = person.cpersoncode
                               LEFT JOIN computationunit  WITH (NOLOCK)
                                      ON inventory.ccomunitcode = computationunit.ccomunitcode
                               LEFT JOIN computationunit AS computationunit1  WITH (NOLOCK)
                                      ON qmcheckvoucher.cunitid = computationunit1.ccomunitcode
                               LEFT JOIN warehouse  WITH (NOLOCK)
                                      ON qmcheckvoucher.cwhcode = warehouse.cwhcode
                               LEFT JOIN DBO.mom_orderdetail  WITH (NOLOCK)
                                      ON ( CASE Isnull(qmcheckvoucher.ISOURCEPROORDERAUTOID, 0)
                                             WHEN 0 THEN qmcheckvoucher.SOURCEAUTOID
                                             ELSE qmcheckvoucher.ISOURCEPROORDERAUTOID
                                           END ) = DBO.mom_orderdetail.MoDId
                                         AND Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0
                               LEFT OUTER JOIN sfc_morouting D  WITH (NOLOCK)
                                            ON D.MoDId = mom_orderdetail.MoDId
                               LEFT JOIN sfc_moroutingdetail B  WITH (NOLOCK)
                                      ON B.MoRoutingId = D.MoRoutingId
                                         AND B.LastFlag = 1
                               LEFT OUTER JOIN sfc_workcenter E  WITH (NOLOCK)
                                            ON E.WcId = B.WcId
                               LEFT JOIN mom_moallocate  WITH (NOLOCK)
                                      ON mom_moallocate.allocateid = DBO.qmcheckvoucher.SOURCEAUTOID
                                         AND Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 1
                               LEFT JOIN DBO.mom_orderdetail A  WITH (NOLOCK)
                                      ON a.modid = mom_moallocate.modid
                               LEFT OUTER JOIN sfc_morouting  WITH (NOLOCK)
                                            ON sfc_morouting.MoDId = a.MoDId
                               LEFT OUTER JOIN sfc_moroutingdetail C  WITH (NOLOCK)
                                            ON C.MoRoutingId = sfc_morouting.MoRoutingId
                                               AND mom_moallocate.OpSeq = c.OpSeq
                               LEFT OUTER JOIN sfc_workcenter F  WITH (NOLOCK)
                                            ON F.WcId = C.WcId
                               LEFT JOIN department  WITH (NOLOCK)
                                      ON ( CASE Isnull(qmcheckvoucher.ISOURCEPROORDERAUTOID, 0)
                                             WHEN 0 THEN qmcheckvoucher.cinspectdepcode
                                             ELSE mom_orderdetail.MDeptCode
                                           END ) = department.cdepcode
                               LEFT OUTER JOIN SO_SODETAILS
                                            ON qmcheckvoucher.iordertype = 1
                                               AND Cast(SO_SODETAILS.ISOSID AS NVARCHAR(50)) = qmcheckvoucher.ISOORDERAUTOID
                               LEFT OUTER JOIN EX_ORDERDETAIL
                                            ON qmcheckvoucher.iordertype = 3
                                               AND Cast(EX_ORDERDETAIL.AUTOID AS NVARCHAR(50)) = qmcheckvoucher.ISOORDERAUTOID
                        --left join (select chdefine1 as chdefine1,chdefine2 as chdefine2,id as keyextend_t_id_qmcheckvoucher_extradefine_id from qmcheckvoucher_extradefine) extend_t_id_qmcheckvoucher_extradefine on keyextend_t_id_qmcheckvoucher_extradefine_id=qmcheckvoucher.id 
                        WHERE  Isnull(qmcheckvoucher.cverifier, N'''') <> N''''
                               AND qmcheckvoucher.cvouchtype = N''qm04''
                               AND ( ( Isnull(( CASE
                                                  WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN mom_orderdetail.status
                                                  ELSE a.status
                                                END ), 0) = 3
                                       AND Isnull(( CASE Isnull(qmcheckvoucher.ISOURCEPROORDERAUTOID, 0)
                                                      WHEN 0 THEN qmcheckvoucher.sourceautoid
                                                      ELSE qmcheckvoucher.ISOURCEPROORDERAUTOID
                                                    END ), 0) <> 0 )
                                      OR Isnull(( CASE Isnull(qmcheckvoucher.ISOURCEPROORDERAUTOID, 0)
                                                    WHEN 0 THEN qmcheckvoucher.sourceautoid
                                                    ELSE qmcheckvoucher.ISOURCEPROORDERAUTOID
                                                  END ), 0) = 0 )
                               AND ( Isnull(fregquantity, 0)
                                     + Isnull(fconquantiy, 0) ) > 0
                               AND Isnull(qmcheckvoucher.bmergecheckflag, 0) = 0
                        UNION
                        SELECT Cast(qmcheckvoucher.id AS VARCHAR) + ''D''
                               + Cast(M.AUTOID AS VARCHAR)                           AS dkey,
                               N''''                                                   AS selcol,
                               qmcheckvoucher.ddate,
                               qmcheckvoucher.bproinflag                             AS bproinflag,
                               qmcheckvoucher.ccheckcode,
                               qmcheckvoucher.ccheckpersoncode,
                               person.cpersonname                                    AS ccheckpersonname,
                               ( CASE Isnull(M.CSOURCEPROORDERCODE, '''')
                                   WHEN '''' THEN M.sourcecode
                                   ELSE M.CSOURCEPROORDERCODE
                                 END )                                               AS sourcecode,
                               M.cprobatch,
                               ( CASE Isnull(M.ISOURCEPROORDERAUTOID, 0)
                                   WHEN 0 THEN M.cinspectdepcode
                                   ELSE mom_orderdetail.MDeptCode
                                 END )                                               AS cinspectdepcode,
                               department.cdepname                                   AS cinspectdepname,
                               ( CASE
                                   WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN ( CASE
                                                                                              WHEN Isnull(mom_orderdetail.sfcflag, 0) = 0 THEN mom_orderdetail.remark
                                                                                              ELSE B.remark
                                                                                            END )
                                   ELSE ( CASE
                                            WHEN Isnull(a.sfcflag, 0) = 0 THEN a.remark
                                            ELSE C.remark
                                          END )
                                 END )                                               AS cmemo,
                               qmcheckvoucher.cdefine1,
                               qmcheckvoucher.cdefine2,
                               qmcheckvoucher.cdefine3,
                               qmcheckvoucher.cdefine4,
                               qmcheckvoucher.cdefine5,
                               qmcheckvoucher.cdefine6,
                               qmcheckvoucher.cdefine7,
                               qmcheckvoucher.cdefine8,
                               qmcheckvoucher.cdefine9,
                               qmcheckvoucher.cdefine10,
                               qmcheckvoucher.cdefine11,
                               qmcheckvoucher.cdefine12,
                               qmcheckvoucher.cdefine13,
                               qmcheckvoucher.cdefine14,
                               qmcheckvoucher.cdefine15,
                               qmcheckvoucher.cdefine16,
                               qmcheckvoucher.cinvcode,
                               cinvaddcode,
                               inventory.cinvname,
                               cinvstd,
                               cinvdefine1,
                               cinvdefine2,
                               cinvdefine3,
                               cinvdefine4,
                               cinvdefine5,
                               cinvdefine6,
                               cinvdefine7,
                               cinvdefine8,
                               cinvdefine9,
                               cinvdefine10,
                               cinvdefine11,
                               cinvdefine12,
                               cinvdefine13,
                               cinvdefine14,
                               cinvdefine15,
                               cinvdefine16,
                               M.cFree1,
                               M.cFree2,
                               M.cfree3,
                               M.cfree4,
                               M.cfree5,
                               M.cfree6,
                               M.cfree7,
                               M.cfree8,
                               M.cfree9,
                               M.cfree10,
                               qmcheckvoucher.cbatch,
                               ( CASE
                                   WHEN Isnull(inventory.binvquality, 0) = 1 THEN M.dprodate
                                   ELSE NULL
                                 END )                                               AS dprodate,
                               ( CASE
                                   WHEN Isnull(inventory.binvquality, 0) = 1 THEN M.dprodate
                                   ELSE NULL
                                 END )                                               AS dmadedate,
                               qmcheckvoucher.imassdate,
                               M.dvdate,
                               computationunit.ccomunitname,
                               computationunit1.ccomunitname                         AS cunitname,
                               M.iExpiratDateCalcu,
                               M.cExpirationdate,
                               M.dExpirationdate,
                               CASE Isnull(qmcheckvoucher.bproinflag, 0)
                                 WHEN 0 THEN ( CASE Isnull(inventory.iGroupType, 0)
                                                 WHEN 0 THEN 0
                                                 WHEN 1 THEN ( CASE Isnull(M.ifregbreakqtydealtype, 0)
                                                                 WHEN 1 THEN ( Isnull(M.fregquantity, 0)
                                                                               + Isnull(M.fconquantiy, 0) - Isnull(M.FsumQuantity, 0) ) / computationunit1.ichangrate
                                                                 ELSE ( Isnull(M.fregquantity, 0)
                                                                        + Isnull(M.fconquantiy, 0) - Isnull(M.FREGBREAKQUANTITY, 0) * Isnull(M.FCHECKRATE, 1) - Isnull(M.FsumQuantity, 0) ) / computationunit1.ichangrate
                                                               END )
                                                 WHEN 2 THEN ( CASE Isnull(M.ifregbreakqtydealtype, 0)
                                                                 WHEN 1 THEN ( Isnull(M.fchecknum, 0) - Isnull(M.FsumNum, 0) )
                                                                 ELSE ( Isnull(M.fchecknum, 0) - Isnull(M.FsumNum, 0) - Isnull(M.FREGBREAKQUANTITY, 0) * Isnull(M.FCHECKRATE, 1) / M.fcheckchangrate )
                                                               END )
                                               END )
                                 ELSE 0
                               END                                                   AS fnum,
                               CASE Isnull(qmcheckvoucher.bproinflag, 0)
                                 WHEN 0 THEN ( CASE Isnull(inventory.iGroupType, 0)
                                                 WHEN 0 THEN ( CASE Isnull(M.ifregbreakqtydealtype, 0)
                                                                 WHEN 1 THEN ( Isnull(M.fregquantity, 0)
                                                                               + Isnull(M.fconquantiy, 0) - Isnull(M.FsumQuantity, 0) )
                                                                 ELSE ( Isnull(M.fregquantity, 0)
                                                                        + Isnull(M.fconquantiy, 0) - Isnull(M.FREGBREAKQUANTITY, 0) * Isnull(M.FCHECKRATE, 1) - Isnull(M.FsumQuantity, 0) )
                                                               END )
                                                 WHEN 1 THEN ( CASE Isnull(M.ifregbreakqtydealtype, 0)
                                                                 WHEN 1 THEN ( Isnull(M.fregquantity, 0)
                                                                               + Isnull(M.fconquantiy, 0) - Isnull(M.FsumQuantity, 0) )
                                                                 ELSE ( Isnull(M.fregquantity, 0)
                                                                        + Isnull(M.fconquantiy, 0) - Isnull(M.FREGBREAKQUANTITY, 0) * Isnull(M.FCHECKRATE, 1) - Isnull(M.FsumQuantity, 0) )
                                                               END )
                                                 WHEN 2 THEN ( CASE Isnull(M.ifregbreakqtydealtype, 0)
                                                                 WHEN 1 THEN ( Isnull(M.fcheckqty, 0) - Isnull(M.Fsumquantity, 0) )
                                                                 ELSE ( Isnull(M.fcheckqty, 0) - Isnull(M.Fsumquantity, 0) - Isnull(M.FREGBREAKQUANTITY, 0) * Isnull(M.FCHECKRATE, 1) )
                                                               END )
                                               END )
                                 ELSE 0
                               END                                                   AS fquantity,M.FsumQuantity,
                               qminspectvouchers.cdefine22,
                               qminspectvouchers.cdefine23,
                               qminspectvouchers.cdefine24,
                               qminspectvouchers.cdefine25,
                               qminspectvouchers.cdefine26,
                               qminspectvouchers.cdefine27,
                               qminspectvouchers.cdefine28,
                               qminspectvouchers.cdefine29,
                               qminspectvouchers.cdefine30,
                               qminspectvouchers.cdefine31,
                               qminspectvouchers.cdefine32,
                               qminspectvouchers.cdefine33,
                               qminspectvouchers.cdefine34,
                               qminspectvouchers.cdefine35,
                               qminspectvouchers.cdefine36,
                               qminspectvouchers.cdefine37,
                               qmcheckvoucher.ID,
                               ( CASE Isnull(m.ISOURCEPROORDERAUTOID, 0)
                                   WHEN 0 THEN M.SOURCEAUTOID
                                   ELSE m.ISOURCEPROORDERAUTOID
                                 END )                                               AS sourceautoid,
                               inventory.ccomunitcode,
                               M.autoid                                              AS autoid,
                               M.cunitid,
                               M.citemclass,
                               M.citemcname,
                               M.citemcode,
                               M.citemname,
                               bfree1                                                AS bfree1,
                               bfree2                                                AS bfree2,
                               bfree3                                                AS bfree3,
                               bfree4                                                AS bfree4,
                               bfree5                                                AS bfree5,
                               bfree6                                                AS bfree6,
                               bfree7                                                AS bfree7,
                               bfree8                                                AS bfree8,
                               bfree9                                                AS bfree9,
                               bfree10                                               AS bfree10,
                               inventory.cgroupcode,
                               igrouptype,
                               M.FREGQUANTITY,
                               M.FCONQUANTIY,
                               bservice                                              AS bservice,
                               binvbatch                                             AS binvbatch,
                               ( CASE
                                   WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN e.wccode
                                   ELSE f.wccode
                                 END )                                               AS cMWorkCenterCode,
                               ( CASE
                                   WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN e.Description
                                   ELSE f.Description
                                 END )                                               AS cMWorkCenter,
                               ( CASE
                                   WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN B.opseq
                                   ELSE C.opseq
                                 END )                                               AS iOpSeq,
                               ( CASE
                                   WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN B.Description
                                   ELSE C.Description
                                 END )                                               AS cOpDesc,
                               ( CASE Isnull(M.ISOURCEPROORDERROWNO, 0)
                                   WHEN 0 THEN M.IPROORDERAUTOID
                                   ELSE M.ISOURCEPROORDERROWNO
                                 END )                                               AS imoseq,
                               ( CASE
                                   WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN mom_orderdetail.orderdid
                                   ELSE a.orderdid
                                 END )                                               AS IORDERDID,
                               ( CASE
                                   WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN mom_orderdetail.ordertype
                                   ELSE a.ordertype
                                 END )                                               AS ISOORDERTYPE,
                               ( CASE
                                   WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN mom_orderdetail.ordercode
                                   ELSE a.ordercode
                                 END )                                               AS CORDERCODE,
                               ( CASE
                                   WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN mom_orderdetail.orderseq
                                   ELSE a.orderseq
                                 END )                                               AS IORDERSEQ,
                               ( CASE
                                   WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN mom_orderdetail.ManualCode
                                   ELSE a.ManualCode
                                 END )                                               AS cciqbookcode,
                               ( CASE
                                   WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN mom_orderdetail.SourceSvcCode
                                   ELSE a.SourceSvcCode
                                 END )                                               AS cservicecode,
                               M.cwhcode                                             AS cwhcode,
                               warehouse.cwhname                                     AS cwhname,
                               CONVERT(CHAR, CONVERT(MONEY, qmcheckvoucher.ufts), 2) AS ufts,
                               M.iordertype,
                               M.CSOORDERCODE                                        AS csocode,
                               CASE M.iordertype
                                 WHEN 1 THEN SO_SODETAILS.IROWNO
                                 WHEN 3 THEN EX_ORDERDETAIL.IROWNO
                                 ELSE NULL
                               END                                                   AS isoseq,
                               M.ISOORDERAUTOID                                      AS iSoDID,
                               ( CASE Isnull(QMCheckVOUCHER.CBYPRODUCT, 0)
                                   WHEN 0 THEN N''否''
                                   ELSE N''是''
                                 END )                                               AS bRelated,
                               qmcheckvoucher.CBATCHPROPERTY1,
                               qmcheckvoucher.CBATCHPROPERTY2,
                               qmcheckvoucher.CBATCHPROPERTY3,
                               qmcheckvoucher.CBATCHPROPERTY4,
                               qmcheckvoucher.CBATCHPROPERTY5,
                               qmcheckvoucher.CBATCHPROPERTY6,
                               qmcheckvoucher.CBATCHPROPERTY7,
                               qmcheckvoucher.CBATCHPROPERTY8,
                               qmcheckvoucher.CBATCHPROPERTY9,
                               qmcheckvoucher.CBATCHPROPERTY10,
                               inventory.iid,
                               CASE Isnull(inventory.iGroupType, 0)
                                 WHEN 0 THEN NULL
                                 WHEN 1 THEN computationunit1.ichangrate
                                 WHEN 2 THEN ( CASE Isnull(M.ifregbreakqtydealtype, 0)
                                                 WHEN 1 THEN
                                                   CASE ( Isnull(M.fchecknum, 0) - Isnull(M.FsumNum, 0) )
                                                     WHEN 0 THEN NULL
                                                     ELSE ( Isnull(M.fcheckqty, 0) - Isnull(M.FsumQuantity, 0) ) / ( Isnull(M.fchecknum, 0) - Isnull(M.FsumNum, 0) )
                                                   END
                                                 ELSE
                                                   CASE ( Isnull(M.fchecknum, 0) - Isnull(M.FsumNum, 0) - Isnull(M.FREGBREAKQUANTITY, 0) * Isnull(M.FCHECKRATE, 1) / M.fcheckchangrate )
                                                     WHEN 0 THEN NULL
                                                     ELSE ( Isnull(M.fcheckqty, 0) - Isnull(M.FsumQuantity, 0) - Isnull(M.FREGBREAKQUANTITY, 0) * Isnull(M.FCHECKRATE, 1) ) / ( Isnull(M.fchecknum, 0) - Isnull(M.FsumNum, 0) - Isnull(M.FREGBREAKQUANTITY, 0) * Isnull(M.FCHECKRATE, 1) / M.fcheckchangrate )
                                                   END
                                               END )
                               END                                                   AS fchangrate,
                               ( CASE qmcheckvoucher.cmassunit
                                   WHEN 1 THEN N''年''
                                   WHEN 2 THEN N''月''
                                   WHEN 3 THEN N''日''
                                   ELSE N''''
                                 END )                                               AS cmassunit,
                               qmcheckvoucher.cmaker,
                               Isnull(QMCheckVoucher.BEXIGENCY, 0)                   AS BEXIGENCY,
                               QMCheckVoucher.fsampqty,
                               qmcheckvoucher.FSAMPQTYINS,
                               qmcheckvoucher.CSYSBARCODE,
                               qmcheckvoucher.bmergecheckflag,
                               qmcheckvoucher.id                                     AS iCheckIdBaks,
                               department.cdepcode,
                               qmcheckvoucher.CBYPRODUCT,
                               mom_orderdetail.SoType,
                               mom_orderdetail.SoDId,
                               mom_orderdetail.SoCode,
                               mom_orderdetail.SoSeq,
                               mom_orderdetail.LPlanCode                             AS lplancode
                        FROM   qmcheckvoucher
                               INNER JOIN QMMergeCheckDetail M
                                       ON Isnull(qmcheckvoucher.bmergecheckflag, 0) = 1
                                          AND qmcheckvoucher.ID = M.ID
                               LEFT JOIN qminspectvouchers
                                      ON qmcheckvoucher.inspectautoid = qminspectvouchers.autoid
                               LEFT JOIN qminspectvoucher
                                      ON qminspectvouchers.id = qminspectvoucher.id
                               INNER JOIN inventory
                                       ON qmcheckvoucher.cinvcode = inventory.cinvcode
                               LEFT JOIN person
                                      ON qmcheckvoucher.ccheckpersoncode = person.cpersoncode
                               LEFT JOIN computationunit
                                      ON inventory.ccomunitcode = computationunit.ccomunitcode
                               LEFT JOIN computationunit AS computationunit1
                                      ON qmcheckvoucher.cunitid = computationunit1.ccomunitcode
                               LEFT JOIN warehouse
                                      ON qmcheckvoucher.cwhcode = warehouse.cwhcode
                               LEFT JOIN DBO.mom_orderdetail
                                      ON ( CASE Isnull(M.ISOURCEPROORDERAUTOID, 0)
                                             WHEN 0 THEN M.SOURCEAUTOID
                                             ELSE M.ISOURCEPROORDERAUTOID
                                           END ) = DBO.mom_orderdetail.MoDId
                                         AND Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0
                               LEFT OUTER JOIN sfc_morouting D
                                            ON D.MoDId = mom_orderdetail.MoDId
                               LEFT JOIN sfc_moroutingdetail B
                                      ON B.MoRoutingId = D.MoRoutingId
                                         AND B.LastFlag = 1
                               LEFT OUTER JOIN sfc_workcenter E
                                            ON E.WcId = B.WcId
                               LEFT JOIN mom_moallocate
                                      ON mom_moallocate.allocateid = DBO.qmcheckvoucher.SOURCEAUTOID
                                         AND Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 1
                               LEFT JOIN DBO.mom_orderdetail A
                                      ON a.modid = mom_moallocate.modid
                               LEFT OUTER JOIN sfc_morouting
                                            ON sfc_morouting.MoDId = a.MoDId
                               LEFT OUTER JOIN sfc_moroutingdetail C
                                            ON C.MoRoutingId = sfc_morouting.MoRoutingId
                                               AND mom_moallocate.OpSeq = c.OpSeq
                               LEFT OUTER JOIN sfc_workcenter F
                                            ON F.WcId = C.WcId
                               LEFT JOIN department
                                      ON ( CASE Isnull(qmcheckvoucher.ISOURCEPROORDERAUTOID, 0)
                                             WHEN 0 THEN M.cinspectdepcode
                                             ELSE mom_orderdetail.MDeptCode
                                           END ) = department.cdepcode
                               LEFT OUTER JOIN SO_SODETAILS
                                            ON M.iordertype = 1
                                               AND Cast(SO_SODETAILS.ISOSID AS NVARCHAR(50)) = M.ISOORDERAUTOID
                               LEFT OUTER JOIN EX_ORDERDETAIL
                                            ON M.iordertype = 3
                                               AND Cast(EX_ORDERDETAIL.AUTOID AS NVARCHAR(50)) = M.ISOORDERAUTOID
                        WHERE  Isnull(qmcheckvoucher.cverifier, N'''') <> N''''
                               AND qmcheckvoucher.cvouchtype = N''qm04''
                               AND Isnull(M.bproinflag, 0) <> 1
                               AND ( ( Isnull(( CASE
                                                  WHEN Isnull(DBO.qmcheckvoucher.CBYPRODUCT, 0) = 0 THEN mom_orderdetail.status
                                                  ELSE a.status
                                                END ), 0) = 3
                                       AND Isnull(( CASE Isnull(qmcheckvoucher.ISOURCEPROORDERAUTOID, 0)
                                                      WHEN 0 THEN qmcheckvoucher.sourceautoid
                                                      ELSE qmcheckvoucher.ISOURCEPROORDERAUTOID
                                                    END ), 0) <> 0 )
                                      OR Isnull(( CASE Isnull(qmcheckvoucher.ISOURCEPROORDERAUTOID, 0)
                                                    WHEN 0 THEN qmcheckvoucher.sourceautoid
                                                    ELSE qmcheckvoucher.ISOURCEPROORDERAUTOID
                                                  END ), 0) = 0 )
                               AND ( Isnull(M.fregquantity, 0)
                                     + Isnull(M.fconquantiy, 0) ) > 0) AS aa) AS bb
 where 1=1  
 and ( (1>0) AND (1>0) ) 
 AND ( 1=1 
 AND (sourcecode in(select chkcode from #STPDATempchkcodes))
 ) and bAllInput = 0 ) as QMList  where (isnull(QMList.fquantity,0)<>0 or ISNULL(QMList.fnum,0)<>0)
 ';
 if(@DeptCode<>null )
 BEGIN
 SET @DeptCode=N'';
 END;
 
 if(@DeptCode<>null AND @DeptCode<>N'')
 BEGIN
 SET @SqlHeadCommand=@SqlHeadCommand+' and cinspectdepcode=@DeptCode';
 END;



 SET @SqlHeadCommand=@SqlHeadCommand+' ORDER BY ccheckcode';


     SET @ParmList = '@DeptCode   NVARCHAR(30)';  
     
                EXEC sp_executesql @SqlHeadCommand, @ParmList,
                    @DeptCode = @DeptCode;

  
       
	   
	   
	   
	      
		  
					IF EXISTS ( SELECT  0
                WHERE   NOT OBJECT_ID('tempdb..#STPDATempchkcodes') IS NULL )
        DROP TABLE #STPDATempchkcodes;
		  
		    END;  
        ELSE 
        IF ( @OperType = N'0' )  
        --ST产成品入库-参照生产订单  
        --(参照生产订单（红字）生成产成品退货时，使用参数'bRed'传递  
        --[bRed=0表示普通的参照生产订单生成产成品入库单/bRed=1表示参照生产订单（红字）生成产成品退货]。参照生产订单和生产订单（红字）的区别是添加查询条件：'AND ( ISNULL(QualifiedInQty, 0) > 0 )'，即需要已经入过库才能退  
            BEGIN  
              
			--定义查询参数  
  
				--生产订单子表行号  
                DECLARE @MoDids NVARCHAR(1000);  
                BEGIN  
                  
                    SET @MoDids = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'MoDids',
                                                              DEFAULT, DEFAULT);  
                    IF ( @MoDids <> N'' )
                        BEGIN                               
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDATempMODIDs') IS NULL )
                                DROP TABLE #STPDATempMODIDs;  
                      
                            CREATE   TABLE #STPDATempMODIDs ( MoDid INT );  
                            INSERT  INTO #STPDATempMODIDs
                                    EXEC proc_ts_SplitParamString @MoDids;  
                        END;  
                END;  
             
				--产成品预入仓库编码  
                DECLARE @ProductPreInWhCode NVARCHAR(100);  
                BEGIN  
                    SET @ProductPreInWhCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ProductPreInWhCode',
                                                              DEFAULT, DEFAULT);  
                    IF ( @ProductPreInWhCode <> N'' )
                        BEGIN  
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDATempWhs') IS NULL )
                                DROP TABLE #STPDATempWhs;  
                            CREATE   TABLE #STPDATempWhs ( cWhCode
                                                            NVARCHAR(10) );  
                            INSERT  INTO #STPDATempWhs
                                    EXEC proc_ts_SplitParamString @ProductPreInWhCode;  
                        END;  
                END;  
          
				--开工日期起始  
                DECLARE @dStartDateFrom NVARCHAR(20);  
                SET @dStartDateFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dStartDateFrom',
                                                              DEFAULT, DEFAULT);  
				--开工日期截至  
                DECLARE @dStartDateTo NVARCHAR(20);  
                SET @dStartDateTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dStartDateTo',
                                                              DEFAULT, DEFAULT);  
                IF ( @dStartDateTo = N'' )
                    BEGIN  
                        SET @dStartDateTo = @dStartDateFrom;  
                    END;  
				--完工日期起始  
                DECLARE @dEndDateFrom NVARCHAR(20);  
                SET @dEndDateFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dEndDateFrom',
                                                              DEFAULT, DEFAULT);  
				--完工日期截至  
                DECLARE @dEndDateTo NVARCHAR(20);  
                SET @dEndDateTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dEndDateTo',
                                                              DEFAULT, DEFAULT);  
                IF ( @dEndDateTo = N'' )
                    BEGIN  
                        SET @dEndDateTo = @dEndDateFrom;  
                    END;  
       
				--产品-存货自定义项  
				--SELECT cInvDefine2, * FROM dbo.Inventory  
				--产品-存货自定义项1  
				--DECLARE @ProInvDefine1 NVARCHAR(20)  
				--产品-存货自定义项2  
				--DECLARE @ProInvDefine2 NVARCHAR(20)  
              
				--客户编码  
                DECLARE @cCusCode NVARCHAR(20);  
                SET @cCusCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cCusCode',
                                                              DEFAULT, DEFAULT);  
				--客户名称  
                DECLARE @cCusName NVARCHAR(98);  
                SET @cCusName = '%'
                    + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                             N'cCusName',
                                                             DEFAULT, DEFAULT)
                    + '%';  
				--客户简称  
                DECLARE @cCusAbbName NVARCHAR(98);  
                SET @cCusAbbName = '%'
                    + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                             N'cCusAbbName',
                                                             DEFAULT, DEFAULT)
                    + '%';  
                SET NOCOUNT ON;  
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDAPRODUCTINRefIDs') IS NULL )
                    DROP TABLE #STPDAPRODUCTINRefIDs;  
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDAPRODUCTINRefID') IS NULL )
                    DROP TABLE #STPDAPRODUCTINRefID;  
                SELECT  IDENTITY( INT ) AS tmpId ,
                        CONVERT(INT, 0) AS M_ID ,
                        CONVERT(INT, 0) AS S_ID ,
                        CONVERT(MONEY, Ufts) AS oriufts ,
                        CONVERT(SMALLINT, 0) AS mo_Status ,
                        MoCode AS m_MoCode ,
                        CONVERT(BIT, 1) AS m_bp
                INTO    #STPDAPRODUCTINRefIDs
                FROM    mom_order
                WHERE   1 = 0;   
                      
                CREATE CLUSTERED INDEX ix_STPDAPRODUCTINRefIDs_tmpid_813 ON #STPDAPRODUCTINRefIDs( M_ID,S_ID,tmpId );        
                CREATE  INDEX ix_STPDAPRODUCTINRefIDs_tmpid_813_1 ON #STPDAPRODUCTINRefIDs( S_ID,m_bp,M_ID );   
                   
                SET @SqlCommand = '  INSERT INTO #STPDAPRODUCTINRefIDs  
        ( M_ID ,  
          S_ID ,  
          oriufts ,  
          mo_Status ,  
          m_MoCode ,  
          m_bp  
        )  
        SELECT  MoId ,  
                MoDId ,  
                CONVERT(MONEY, Ufts) ,  
                Status ,  
                MoCode ,  
                ByProductFlag  
        FROM    v_st_mom_orderdetail WITH ( NOLOCK )  
        WHERE   ( 1 > 0 )   
                -- AND ISNULL(QcFlag, 0) = 0  
                AND ISNULL(Status, 0) = 3  
                AND ( ISNULL(bWorkshopTrans, 0) = 0  
                      OR ( ISNULL(bWorkshopTrans, 0) = 1  
                           AND ISNULL(SfcFlag, 0) = 1  
                         )  
                    )  
                AND ISNULL(MrpQty, 0) <> 0 ';  
  
                IF ( @cMoCodeFrom <> N'' )
                    --SET @SqlCommand = @SqlCommand
                    --    + ' AND ( ( MoCode >= @cMoCodeFrom ) AND ( MoCode <= @cMoCodeTo ))';  
					SET @SqlCommand = @SqlCommand
            + ' AND (MoCode IN (SELECT DISTINCT MoCode FROM #STPDATempMOCodes))';


                IF ( @ProInvCode <> N'' )
                    SET @SqlCommand = @SqlCommand  
                       -- + ' AND ( ( InvCode >= @ProInvCode ) AND ( InvCode <= @ProInvCode ))';  
                        + ' AND (  InvCode = @ProInvCode )';  
                IF ( @ProInvAddCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (InvAddCode=@ProInvAddCode) ';  
                IF ( @ProInvName <> N''
                     AND @ProInvName <> N'%%'
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (InvName LIKE @ProInvName) ';  
                IF ( @ProInvStd <> N''
                     AND @ProInvStd <> N'%%'
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (InvStd LIKE @ProInvStd) ';  
                IF ( @cCusCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (Cuscode =@cCusCode) ';  
                IF ( @cCusName <> N''
                     AND @cCusName <> N'%%'
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND cusname LIKE @cCusName ';  
                IF ( @cCusAbbName <> N''
                     AND @cCusAbbName <> N'%%'
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND CusabbName LIKE @cCusAbbName ';  
                IF ( @ShowClosed = N'0'
                     AND @bRed = N'0'
                   )
                    BEGIN  
                        SET @SqlCommand = @SqlCommand
                            + ' AND (ISNULL(iQuantity, 0) > 0) ';  
                    END; 
					IF ( @ShowClosed = N'1')
                    BEGIN  
                        SET @SqlCommand = @SqlCommand
                            + ' AND (ISNULL(iQuantity, 0) <= 0) ';  
                    END; 

                --参照生产订单（红字）生成产成品退货                    
                IF ( @bRed = N'1' )
                    BEGIN  
                        SET @SqlCommand = @SqlCommand
                            + N' AND ( CASE WHEN ISNULL(SfcFlag, 0) = 1 THEN QualifiedInQty ELSE 1 END ) <> 0';  
                        SET @SqlCommand = @SqlCommand
                            + ' AND ISNULL(QualifiedInQty, 0) > 0 ';  
                    END;  
                ELSE
                    BEGIN  
                        SET @SqlCommand = @SqlCommand
                            + N' AND ( CASE WHEN ISNULL(SfcFlag, 0) = 1 THEN iQuantity + QualifiedInQty ELSE 1 END ) <> 0';  
                    END;  
                IF ( @DeptCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (MDept = @DeptCode) ';  
                IF ( @DeptName <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (DeptName = @DeptName) ';  
                --产成品预入仓库  
                IF ( @ProductPreInWhCode <> N'' )  
				--现在支持多个仓库（前台传参时仓库编码中间用','隔开）  
                    SET @SqlCommand = @SqlCommand  
                        --+ ' AND v_st_moallocate.WhCode = @MaterialWhCode ';  
                        + ' AND WhCode IN (SELECT DISTINCT cWhCode FROM #STPDATempWhs) ';  
                IF ( @MoDids <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (v_st_moallocate.MoDId IN  (SELECT DISTINCT MoDid FROM #STPDATempMODIDs)) ';  
  
                IF ( @MoSeq <> N'' )
                    SET @SqlCommand = @SqlCommand + ' AND (MoSeq=@MoSeq) ';  
                IF ( @cMaker <> N'' )
                    SET @SqlCommand = @SqlCommand + ' AND (maker=@cMaker) ';  
                IF ( @dStartDateFrom <> N''
                     AND @dStartDateTo <> N''
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (( StartDate >= @dStartDateFrom )  
                            AND ( StartDate <= @dStartDateTo )) ';  
                IF ( @dEndDateFrom <> N''
                     AND @dEndDateTo <> N''
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (( DueDate >= @dEndDateFrom )  
                            AND ( DueDate <= @dEndDateTo )) ';  
                IF ( @MoLotCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (MoLotCode = @MoLotCode) ';  
                IF ( @cServiceCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (cservicecode = @cServiceCode) ';  
                --IF ( @MoDids <> N'' )  
                --    SET @SqlCommand = @SqlCommand  
                --        + ' AND (MoDId IN  (SELECT DISTINCT MoDid FROM #STPDATempMODIDs) ) ';  
                --PRINT @SqlCommand;  
                SET @ParmList = '@cMoCodeFrom   NVARCHAR(30),  
       --  @cMoCodeTo    NVARCHAR(30),  
         @MoSeq     NVARCHAR(30),  
         @cMaker    NVARCHAR(30),  
         @ProInvCode   NVARCHAR(60),  
         @ProInvAddCode   NVARCHAR(255),  
         @ProInvName   NVARCHAR(255),  
         @ProInvStd    NVARCHAR(255),  
         @cCusCode    NVARCHAR(20),  
         @cCusName    NVARCHAR(98),  
         @cCusAbbName   NVARCHAR(98),  
         @DeptCode    NVARCHAR(12),  
         @DeptName    NVARCHAR(255),  
         @dStartDateFrom  NVARCHAR(20),  
         @dStartDateTo   NVARCHAR(20),  
         @dEndDateFrom   NVARCHAR(20),  
         @dEndDateTo   NVARCHAR(20),  
         @MoLotCode    NVARCHAR(60),  
         @cServiceCode   NVARCHAR(30)';  
     
                EXEC sp_executesql @SqlCommand, @ParmList,
                    @cMoCodeFrom = @cMoCodeFrom,
                    @MoSeq = @MoSeq, @cMaker = @cMaker,
                    @ProInvCode = @ProInvCode, @ProInvAddCode = @ProInvAddCode,
                    @ProInvName = @ProInvName, @ProInvStd = @ProInvStd,
                    @cCusCode = @cCusCode, @cCusName = @cCusName,
                    @cCusAbbName = @cCusAbbName, @DeptCode = @DeptCode,
                    @DeptName = @DeptName, @dStartDateFrom = @dStartDateFrom,
                    @dStartDateTo = @dStartDateTo, @dEndDateTo = @dEndDateTo,
                    @dEndDateFrom = @dEndDateFrom, @MoLotCode = @MoLotCode,
                    @cServiceCode = @cServiceCode;   
   
                SELECT  IDENTITY( INT ) AS tmpId ,
                        M_ID ,
                        MAX(S_ID) AS s_id ,
                        MAX(oriufts) AS oriufts
                INTO    #STPDAPRODUCTINRefID
                FROM    #STPDAPRODUCTINRefIDs
                GROUP BY M_ID;  
                CREATE CLUSTERED INDEX ix_STPDARefID_tmpid_813 ON #STPDAPRODUCTINRefID( tmpId,M_ID );   
                SET NOCOUNT OFF;  
                --查询列表（表头）  
                SELECT DISTINCT
                        '' AS selcol ,
                        MoCode AS mocode ,
                        maker AS maker ,
                        CONVERT(VARCHAR(100), MakeDate, 23) AS ddate ,
                        ModifyUser AS modifyuser ,
                        ModifyDate AS modifydate ,
                        Define1 AS cdefine1 ,
                        Define2 AS cdefine2 ,
                        Define3 AS cdefine3 ,
                        Define4 AS cdefine4 ,
                        Define5 AS cdefine5 ,
                        Define6 AS cdefine6 ,
                        Define7 AS cdefine7 ,
                        Define8 AS cdefine8 ,
                        Define9 AS cdefine9 ,
                        Define10 AS cdefine10 ,
                        Define11 AS cdefine11 ,
                        Define12 AS cdefine12 ,
                        Define13 AS cdefine13 ,
                        Define14 AS cdefine14 ,
                        Define15 AS cdefine15 ,
                        Define16 AS cdefine16 ,
                        MoId AS moid
                FROM    v_st_mom_orderdetailH WITH ( NOLOCK )
                        INNER JOIN #STPDAPRODUCTINRefID b ON v_st_mom_orderdetailH.MoId = b.M_ID; --and v_st_mom_orderdetailH.mo.MoDId=b.s_id   
                --查询表体  
                IF ( @GetType = N'DETAIL' )
                    BEGIN  
                      
                        SELECT mocode as ccode,cbSysBarCode, MoDId AS bodyautoid ,
                                '' AS selcol ,
                                SoType AS sotype ,
                                MDept AS cdepcode ,
                                DeptName AS cdepname ,
                                MoLotCode AS cmolotcode ,
                                MoSeq AS imoseq ,
                                InvCode AS cinvcode ,
                                InvAddCode AS cinvaddcode ,
                                InvName AS cinvname ,
                                InvStd AS cinvstd ,
                                InvDefine1 AS cinvdefine1 ,
                                InvDefine2 AS cinvdefine2 ,
                                InvDefine3 AS cinvdefine3 ,
                                InvDefine4 AS cinvdefine4 ,
                                InvDefine5 AS cinvdefine5 ,
                                InvDefine6 AS cinvdefine6 ,
                                InvDefine7 AS cinvdefine7 ,
                                InvDefine8 AS cinvdefine8 ,
                                InvDefine9 AS cinvdefine9 ,
                                InvDefine10 AS cinvdefine10 ,
                                InvDefine11 AS cinvdefine11 ,
                                InvDefine12 AS cinvdefine12 ,
                                InvDefine13 AS cinvdefine13 ,
                                InvDefine14 AS cinvdefine14 ,
                                InvDefine15 AS cinvdefine15 ,
                                InvDefine16 AS cinvdefine16 ,
                                UnitId AS cunitid ,
                                UnitCode AS cunitcode ,
								unitcode as cinvm_unit,
                                AuxUnitId AS auxunitid ,
                                AuxUnitCode AS auxunitcode ,
								AuxUnitCode as cinva_unit,
                                Free1 AS cfree1 ,
                                Free2 AS cfree2 ,
                                Free3 AS cfree3 ,
                                Free4 AS cfree4 ,
                                Free5 AS cfree5 ,
                                Free6 AS cfree6 ,
                                Free7 AS cfree7 ,
                                Free8 AS cfree8 ,
                                Free9 AS cfree9 ,
                                Free10 AS cfree10 ,
                                Inv.bFree1 AS bfree1 ,
                                Inv.bFree2 AS bfree2 ,
                                Inv.bFree3 AS bfree3 ,
                                Inv.bFree4 AS bfree4 ,
                                Inv.bFree5 AS bfree5 ,
                                Inv.bFree6 AS bfree6 ,
                                Inv.bFree7 AS bfree7 ,
                                Inv.bFree8 AS bfree8 ,
                                Inv.bFree9 AS bfree9 ,
                                Inv.bFree10 AS bfree10 ,
                                Qty AS iquantity ,
							    QTY*isnull(Inv.fInExcess,0) as inexcessQty,
                                QualifiedInQty AS qualifiedinqty ,
								QualifiedInQty AS ireceivedqty,
                                ( CASE WHEN ( @bRed = N'1' )
                                       THEN QualifiedInQty
                                       ELSE ( ISNULL(Qty, 0)
                                              - ISNULL(QualifiedInQty, 0) )
                                  END ) AS inquantity ,
                                0 AS inum ,
                                0 AS innum ,
                                StartDate AS dstartdate ,
                                DueDate AS dduedate ,
                                SoCode AS csocode ,
                                SoSeq AS isoseq ,
                                OpSeq AS iopseq ,
                                [Description] AS cdescription ,
                                WcCode AS cwccode ,
                                WcName AS cwcname ,
                                WhCode AS cwhcode ,
                                WhName AS cwhname ,
                                SoDId AS sodid ,
                                MoDId AS modid ,
                                Ufts AS ufts ,
                                ByProductFlag AS byproductflag ,
                                Define22 AS cdefine22 ,
                                Define23 AS cdefine23 ,
                                Define24 AS cdefine24 ,
                                Define25 AS cdefine25 ,
                                Define26 AS cdefine26 ,
                                Define27 AS cdefine27 ,
                                Define28 AS cdefine28 ,
                                Define29 AS cdefine29 ,
                                Define30 AS cdefine30 ,
                                Define31 AS cdefine31 ,
                                Define32 AS cdefine32 ,
                                Define33 AS cdefine33 ,
                                Define34 AS cdefine34 ,
                                Define35 AS cdefine35 ,
                                Define36 AS cdefine36 ,
                                Define37 AS cdefine37 ,
                                AuxQty AS iauxqty ,
                                AuxQualifiedInQty AS auxqualifiedinqty ,
                                ChangeRate AS changerate ,
                                MoId AS moid ,
                                OrderCode AS cordercode ,
                                OrderDId AS orderdid ,
                                OrderSeq AS orderseq ,
                                OrderType AS ordertype ,
                                cciqbookcode ,
                                Cuscode AS ccuscode ,
                                cusname AS ccusname ,
                                CusabbName AS ccusabbname ,
                                cservicecode ,
                                motypecode ,
                                motypedesc ,
                                completeqty AS balqualifiedqty ,
                                cbmemo ,
                                LPlanCode AS lplancode ,
                                '' as cfactorycode ,
                                '' as cfactoryname ,
                                Inv.bInvBatch AS binvbatch ,
                                Inv.bInvQuality AS binvquality ,
                                Inv.bSerial AS bserial ,
                                Inv.bBarCode AS bbarcode ,
                                0.0 AS iscanedquantity ,
                                0.0 AS iscanednum,
                               -- bPropertyCheck bgsp
							   QcFlag bgsp
                        FROM    v_st_mom_orderdetail WITH ( NOLOCK )
                                INNER JOIN #STPDAPRODUCTINRefIDs b ON v_st_mom_orderdetail.Status = b.mo_Status
                                                              AND v_st_mom_orderdetail.MoId = b.M_ID
                                                              AND v_st_mom_orderdetail.MoDId = b.S_ID
                                INNER  
       JOIN dbo.Inventory Inv ON v_st_mom_orderdetail.InvCode = Inv.cInvCode
                        WHERE ( ISNULL(v_st_mom_orderdetail.SourceQCVouchType,
                                         0) <> 1
                                  OR byproductflag = 1
                                )
                                AND M_ID IN ( SELECT DISTINCT
                                                        M_ID
                                              FROM      #STPDAPRODUCTINRefID )
                                AND v_st_mom_orderdetail.ByProductFlag = b.m_bp;   
                    END;  
                --删除临时表  

					IF EXISTS ( SELECT  0
                WHERE   NOT OBJECT_ID('tempdb..#STPDATempMOCodes') IS NULL )
        DROP TABLE #STPDATempMOCodes;

                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDAPRODUCTINRefIDs') IS NULL )
                    DROP TABLE #STPDAPRODUCTINRefIDs;  
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDAPRODUCTINRefID') IS NULL )
                    DROP TABLE #STPDAPRODUCTINRefID;  
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempMODIDs') IS NULL )
                    DROP TABLE #STPDATempMODIDs;  
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempWhs') IS NULL )
                    DROP TABLE #STPDATempWhs;  
            END;  
        ELSE
            IF ( @OperType = N'1'
                 OR @OperType = N'2'
               )--参照检验单/不良品处理单  
                BEGIN  
                  
                --单据ID列表  
                    DECLARE @Ids NVARCHAR(1000);  
                    BEGIN  
                  
                        SET @Ids = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'Ids', DEFAULT,
                                                              DEFAULT);  
                        IF ( @Ids <> N'' )
                            BEGIN                               
                                IF EXISTS ( SELECT  0
                                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempIDs') IS NULL )
                                    DROP TABLE #STPDATempIDs;  
                      
                                CREATE   TABLE #STPDATempIDs ( Did INT );  
                                INSERT  INTO #STPDATempIDs
                                        EXEC proc_ts_SplitParamString @Ids;  
                            END;  
                    END;  
                  
     --不良品处理单单号起始  
                    DECLARE @cRejectCodeFrom NVARCHAR(30);  
                    SET @cRejectCodeFrom = N'';  
                    --不良品处理单单号截至  
                    DECLARE @cRejectCodeTo NVARCHAR(30);  
                    SET @cRejectCodeTo = N'';  
     --检验单检验日期起始  
                    DECLARE @dDateFrom NVARCHAR(20);  
                    SET @dDateFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dDateFrom',
                                                              DEFAULT, DEFAULT);  
     --检验单检验日期截至  
                    DECLARE @dDateTo NVARCHAR(20);  
                    SET @dDateTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dDateTo',
                                                              DEFAULT, DEFAULT);  
                    IF ( @dDateTo = N'' )
                        BEGIN  
                            SET @dDateTo = @dDateFrom;  
                        END;   
     --检验单单号起始  
                    DECLARE @cCodeFrom NVARCHAR(30);  
                    SET @cCodeFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cCodeFrom',
                                                              DEFAULT, DEFAULT);  
     --检验单单号截至  
                    DECLARE @cCodeTo NVARCHAR(30);  
                    SET @cCodeTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cCodeTo',
                                                              DEFAULT, DEFAULT);  
                    IF ( @cCodeTo = N'' )
                        BEGIN  
                            SET @cCodeTo = @cCodeFrom;  
                        END;   
     --检验员编码  
                    DECLARE @cCheckPersonCode NVARCHAR(30);  
                    SET @cCheckPersonCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cCheckPersonCode',
                                                              DEFAULT, DEFAULT);  
     --检验员名称  
                    DECLARE @cCheckPersonName NVARCHAR(30);  
                    SET @cCheckPersonName = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cCheckPersonName',
                                                              DEFAULT, DEFAULT);  
                    IF ( @OperType = N'1' )
                        BEGIN  
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDAPRODUCTINRefCheckIDs') IS NULL )
                                DROP TABLE #STPDAPRODUCTINRefCheckIDs;  
                            SELECT TOP 1
                                    ID AS M_ID
                            INTO    #STPDAPRODUCTINRefCheckIDs
                            FROM    QMCHECKVOUCHER
                            WHERE   1 = 0;   
                          
                            SET @SqlCommand = 'INSERT INTO #STPDAPRODUCTINRefCheckIDs  
             ( M_ID  
             )   
             SELECT DISTINCT ID FROM QMCHECKVOUCHER WHERE 1=1 ';  
                        END;  
                    ELSE
                        BEGIN  
          
                            SET @cRejectCodeFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cRejectCodeFrom',
                                                              DEFAULT, DEFAULT);  
                            SET @cRejectCodeTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cRejectCodeTo',
                                                              DEFAULT, DEFAULT);  
          
                            IF ( @cRejectCodeTo = N'' )
                                BEGIN  
                                    SET @cRejectCodeTo = @cRejectCodeFrom;  
                                END;   
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDAPRODUCTINRefCheckIDs1') IS NULL )
                                DROP TABLE #STPDAPRODUCTINRefCheckIDs1;  
                            SELECT TOP 1
                                    ID AS M_ID
                            INTO    #STPDAPRODUCTINRefCheckIDs1
                            FROM    QMREJECTVOUCHER
                            WHERE   1 = 0;   
                          
                            SET @SqlCommand = 'INSERT INTO #STPDAPRODUCTINRefCheckIDs1  
            ( M_ID  
            )   
            SELECT DISTINCT ID FROM QMREJECTVOUCHER WHERE 1=1 ';  
                        END;  
                    IF ( @dDateFrom <> N''
                         AND @dDateTo <> N''
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND ( ( DDATE >= @dDateFrom )  
                                AND ( DDATE <= @dDateTo )  
                              )';  
                    IF ( @cCodeFrom <> N''
                         AND @cCodeTo <> N''
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND ( ( CCHECKCODE >= @cCodeFrom )  
                                AND ( CCHECKCODE <= @cCodeTo )  
                              )';  
                    IF ( @cCheckPersonCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (CCHECKPERSONCODE = @cCheckPersonCode)';  
                    IF ( @cCheckPersonName <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (ccheckpersonname = @cCheckPersonName)';            
                    --IF ( @cMoCodeFrom <> N''
                    --     AND @cMoCodeTo <> N''
                    --   )
                    --    SET @SqlCommand = @SqlCommand
                    --        + ' AND ( ( sourcecode >= @cMoCodeFrom )  
                    --            AND ( sourcecode <= @cMoCodeTo )  
                    --          )';   
					  IF ( @cMoCodeFrom <> N'')
	SET @SqlCommand = @SqlCommand
            + ' AND (sourcecode IN (SELECT DISTINCT MoCode FROM #STPDATempMOCodes))';


                    IF ( @MoLotCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (CPROBATCH = @MoLotCode)';  
                    IF ( @cMaker <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (CMAKER = @cMaker)';  
                    IF ( @ProInvCode <> N'' )
                        SET @SqlCommand = @SqlCommand  
                       -- + ' AND ( ( CINVCODE >= @ProInvCode ) AND ( CINVCODE <= @ProInvCode ))';  
                            + ' AND (CINVCODE = @ProInvCode )';  
                    IF ( @ProInvAddCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (cInvAddCode=@ProInvAddCode) ';  
                    IF ( @ProInvName <> N''
                         AND @ProInvName <> N'%%'
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (cInvName LIKE @ProInvName) ';  
                    IF ( @ProInvStd <> N''
                         AND @ProInvStd <> N'%%'
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (cInvStd LIKE @ProInvStd) ';  
                    IF ( @cServiceCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (cservicecode = @cServiceCode)';  
                    IF ( @DeptCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (cinspectdepcode = @DeptCode)';  
                    IF ( @DeptName <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (cinspectdepname = @DeptName)';  
                    IF ( @MoSeq <> N'' )
                        BEGIN  
                            SET @SqlCommand = @SqlCommand
                                + ' AND (imoseq=@MoSeq) ';  
                        END;  
                    IF ( @Ids <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (Id IN (SELECT DISTINCT Did FROM #STPDATempIDs)) ';  
                    IF ( @OperType = N'1' )
                        BEGIN  
                            IF ( @ShowClosed = N'0' )
                                BEGIN  
                                    SET @SqlCommand = @SqlCommand
                                        + ' AND ISNULL(bproinflag, 0) = 0';  
                                END;  
                        END;  
                    ELSE
                        BEGIN  
                            IF ( @cRejectCodeFrom <> N''
                                 AND @cRejectCodeTo <> N''
                               )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND ( ( CREJECTCODE >= @cRejectCodeFrom )  
                                AND ( CREJECTCODE <= @cRejectCodeTo )  
                              )';  
                        END;  
                    SET @ParmList = '@cRejectCodeFrom  NVARCHAR(30),  
          @cRejectCodeTo   NVARCHAR(30),  
          @cMoCodeFrom   NVARCHAR(30),  
          -- @cMoCodeTo    NVARCHAR(30),  
          @MoSeq     NVARCHAR(30),  
          @cMaker    NVARCHAR(30),  
          @ProInvCode   NVARCHAR(60),  
          @ProInvAddCode   NVARCHAR(255),  
          @ProInvName   NVARCHAR(255),  
          @ProInvStd    NVARCHAR(255),  
          @DeptCode    NVARCHAR(12),  
          @DeptName    NVARCHAR(255),  
          @dDateFrom    NVARCHAR(20),  
          @dDateTo    NVARCHAR(20),  
          @cCodeFrom    NVARCHAR(30),  
          @cCodeTo    NVARCHAR(30),  
          @MoLotCode    NVARCHAR(60),  
          @cServiceCode   NVARCHAR(30),  
          @cCheckPersonCode  NVARCHAR(30),  
          @cCheckPersonName  NVARCHAR(30)';  
                    --PRINT @SqlCommand;  
                    EXEC sp_executesql @SqlCommand, @ParmList,
                        @cRejectCodeFrom = @cRejectCodeFrom,
                        @cRejectCodeTo = @cRejectCodeTo,
                        @cMoCodeFrom = @cMoCodeFrom,
			
                        @MoSeq = @MoSeq, @cMaker = @cMaker,
                        @ProInvCode = @ProInvCode,
                        @ProInvAddCode = @ProInvAddCode,
                        @ProInvName = @ProInvName, @ProInvStd = @ProInvStd,
                        @DeptCode = @DeptCode, @DeptName = @DeptName,
                        @dDateFrom = @dDateFrom, @dDateTo = @dDateTo,
                        @cCodeFrom = @cCodeFrom, @cCodeTo = @cCodeTo,
                        @MoLotCode = @MoLotCode, @cServiceCode = @cServiceCode,
                        @cCheckPersonCode = @cCheckPersonCode,
                        @cCheckPersonName = @cCheckPersonName;   
  
                    --开始查询检验单内容  
                    IF ( @OperType = '1' )
                        BEGIN  
                            SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;  
                            SELECT DISTINCT
                                    ID AS bodyautoid ,
                                    '' AS selcol ,
                                    CONVERT(VARCHAR(100), DDATE, 23) AS ddate ,
                                    CCHECKCODE AS ccheckcode ,
									CCHECKCODE as csrccode,
                                    CCHECKPERSONCODE AS ccheckpersoncode ,
                                    ccheckpersonname ,
                                    sourcecode ,
                                    CPROBATCH AS cprobatch ,
									 cinspectdepcode  as cdepcode,
                                    cinspectdepname as cdepname,
                                    cinspectdepcode ,
                                    cinspectdepname ,
                                    CDEFINE1 AS cdefine1 ,
                                    CDEFINE2 AS cdefine2 ,
                                    CDEFINE3 AS cdefine3 ,
                                    CDEFINE4 AS cdefine4 ,
                                    CDEFINE5 AS cdefine5 ,
                                    CDEFINE6 AS cdefine6 ,
                                    CDEFINE7 AS cdefine7 ,
                                    CDEFINE8 AS cdefine8 ,
                                    CDEFINE9 AS cdefine9 ,
                                    CDEFINE10 AS cdefine10 ,
                                    CDEFINE11 AS cdefine11 ,
                                    CDEFINE12 AS cdefine12 ,
                                    BEXIGENCY AS bexigency ,
                                    CDEFINE13 AS cdefine13 ,
                                    CDEFINE14 AS cdefine14 ,
                                    CDEFINE15 AS cdefine15 ,
                                    CDEFINE16 AS cdefine16 ,
                                    cmemo ,
                                    cInvAddCode AS cinvaddcode ,
                                    CINVCODE AS cinvcode ,
                                    cInvName AS cinvname ,
                                    cInvStd AS cinvstd ,
                                    CBATCH AS cbatch ,
                                    dprodate ,
                                    DVDATE AS dvdate ,
                                    IMASSDATE AS imassdate ,
                                    cComUnitCode AS ccomunitcode ,
                                    cComUnitName AS ccomunitname ,
									cComUnitName as cinvm_unit,
                                    CUNITID AS cunitid ,
                                    cunitname ,
                                    FsumQuantity as ireceivedqty,
                                    fquantity as iquantity,
                                    fquantity ,
                                    fnum ,
                                    fchangrate ,
                                    CITEMCLASS AS citemclass ,
									CITEMCLASS AS citem_class ,
                                    CITEMCNAME AS citemcname ,
                                    CITEMCODE AS citemcode ,
                                    CITEMNAME AS citemname ,
                                    ID AS id ,
                                    CDEFINE22 AS cdefine22 ,
                                    CDEFINE23 AS cdefine23 ,
                                    CDEFINE24 AS cdefine24 ,
                                    CDEFINE25 AS cdefine25 ,
                                    CDEFINE26 AS cdefine26 ,
                                    CDEFINE27 AS cdefine27 ,
                                    CDEFINE28 AS cdefine28 ,
                                    CDEFINE29 AS cdefine29 ,
                                    CDEFINE30 AS cdefine30 ,
                                    CDEFINE31 AS cdefine31 ,
                                    CDEFINE32 AS cdefine32 ,
                                    CDEFINE33 AS cdefine33 ,
                                    CDEFINE34 AS cdefine34 ,
                                    CDEFINE35 AS cdefine35 ,
                                    CDEFINE36 AS cdefine36 ,
                                    CDEFINE37 AS cdefine37 ,
                                    CFREE1 AS cfree1 ,
                                    CFREE2 AS cfree2 ,
                                    CFREE3 AS cfree3 ,
                                    CFREE4 AS cfree4 ,
                                    CFREE5 AS cfree5 ,
                                    CFREE6 AS cfree6 ,
                                    CFREE7 AS cfree7 ,
                                    CFREE8 AS cfree8 ,
                                    CFREE9 AS cfree9 ,
                                    CFREE10 AS cfree10 ,
                                    cInvDefine1 AS cinvdefine1 ,
                                    cInvDefine2 AS cinvdefine2 ,
                                    cInvDefine3 AS cinvdefine3 ,
                                    cInvDefine4 AS cinvdefine4 ,
                                    cInvDefine5 AS cinvdefine5 ,
                                    cInvDefine6 AS cinvdefine6 ,
                                    cInvDefine7 AS cinvdefine7 ,
                                    cInvDefine8 AS cinvdefine8 ,
                                    FREGQUANTITY AS fregquantity ,
                                    FCONQUANTIY AS fconquantiy ,
                                    cInvDefine9 AS cinvdefine9 ,
                                    cInvDefine10 AS cinvdefine10 ,
                                    cInvDefine11 AS cinvdefine11 ,
                                    cInvDefine12 AS cinvdefine12 ,
                                    cInvDefine13 AS cinvdefine13 ,
                                    cInvDefine14 AS cinvdefine14 ,
                                    cInvDefine15 AS cinvdefine15 ,
                                    cInvDefine16 AS cinvdefine16 ,
                                    bfree1 ,
                                    bfree2 ,
                                    bfree3 ,
                                    bfree4 ,
                                    bfree5 ,
                                    bfree6 ,
                                    bfree7 ,
                                    bfree8 ,
                                    bfree9 ,
                                    bfree10 ,
                                    cGroupCode AS cgroupcode ,
                                    iGroupType AS igrouptype ,
                                    bservice ,
                                    binvbatch ,
                                    bserial ,
                                    binvquality ,
                                    bbarcode ,
                                    ufts ,
                                    sourceautoid ,
                                    imoseq ,
                                    cwhcode ,
                                    cwhname ,
                                    iOpSeq AS iopseq ,
                                    cOpDesc AS copdesc ,
                                    cMWorkCenterCode AS cmworkcentercode ,
                                    cMWorkCenter AS cmworkcenter ,
                                    CORDERCODE AS cordercode ,
                                    IORDERDID AS iorderdid ,
                                    IORDERSEQ AS iorderseq ,
                                    ISOORDERTYPE AS isoordertype ,
                                    cciqbookcode AS cciqbookcode ,
                                    iExpiratDateCalcu AS iexpiratdatecalcu ,
                                    cExpirationdate AS cexpirationdate ,
                                    dExpirationdate AS dexpirationdate ,
                                    cBatchProperty1 AS cbatchproperty1 ,
                                    cBatchProperty2 AS cbatchproperty2 ,
                                    cBatchProperty3 AS cbatchproperty3 ,
                                    cBatchProperty4 AS cbatchproperty4 ,
                                    cBatchProperty5 AS cbatchproperty5 ,
                                    cBatchProperty6 AS cbatchproperty6 ,
                                    cBatchProperty7 AS cbatchproperty7 ,
                                    cBatchProperty8 AS cbatchproperty8 ,
                                    cBatchProperty9 AS cbatchproperty9 ,
                                    cBatchProperty10 AS cbatchproperty10 ,
                                    cservicecode ,
                                    dkey ,
                                    '' AS cfactorycode ,
                                    '' AS cfactoryname,
									iordertype as isotype,	
									iordertype,CORDERCODE as iordercode,		
									csocode ,									
									isoseq,						
									isodid 
                            FROM    ( SELECT    *
                                      FROM      ( SELECT    * ,
                                                            ISNULL(bproinflag,
                                                              0) AS bAllInput
                                                  FROM      ( SELECT
                                                  QMCHECKVOUCHER.FsumQuantity,
                                                              CAST(QMCHECKVOUCHER.ID AS VARCHAR)
                                                              + 'D' + '-1' AS dkey ,
                                                              N'' AS selcol ,
                                                              QMCHECKVOUCHER.DDATE ,
                                                              QMCHECKVOUCHER.BPROINFLAG AS bproinflag ,
                                                              QMCHECKVOUCHER.CCHECKCODE ,
                                                              QMCHECKVOUCHER.CCHECKPERSONCODE ,
                                                              Person.cPersonName AS ccheckpersonname ,
                                                              ( CASE ISNULL(QMCHECKVOUCHER.CSOURCEPROORDERCODE,
                                                              '')
                                                              WHEN ''
                                                              THEN QMCHECKVOUCHER.SOURCECODE
                                                              ELSE QMCHECKVOUCHER.CSOURCEPROORDERCODE
                                                              END ) AS sourcecode ,
                                                              QMCHECKVOUCHER.CPROBATCH ,
                                                              ( CASE ISNULL(QMCHECKVOUCHER.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN QMCHECKVOUCHER.CINSPECTDEPCODE
                                                              ELSE mom_orderdetail.MDeptCode
                                                              END ) AS cinspectdepcode ,
                                                              Department.cDepName AS cinspectdepname ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN ( CASE
                                                              WHEN ISNULL(mom_orderdetail.SfcFlag,
                                                              0) = 0
                                                              THEN mom_orderdetail.Remark
                                                              ELSE B.Remark
                                                              END )
                                                              ELSE ( CASE
                                                              WHEN ISNULL(A.SfcFlag,
                                                              0) = 0
                                                              THEN A.Remark
                                                              ELSE C.Remark
                                                              END )
                                                              END ) AS cmemo ,
                                                              QMCHECKVOUCHER.CDEFINE1 ,
                                                              QMCHECKVOUCHER.CDEFINE2 ,
                                                              QMCHECKVOUCHER.CDEFINE3 ,
                                                              QMCHECKVOUCHER.CDEFINE4 ,
                                                              QMCHECKVOUCHER.CDEFINE5 ,
                                                              QMCHECKVOUCHER.CDEFINE6 ,
                                                              QMCHECKVOUCHER.CDEFINE7 ,
                                                              QMCHECKVOUCHER.CDEFINE8 ,
                                                              QMCHECKVOUCHER.CDEFINE9 ,
                                                              QMCHECKVOUCHER.CDEFINE10 ,
                                                              QMCHECKVOUCHER.CDEFINE11 ,
                                                              QMCHECKVOUCHER.CDEFINE12 ,
                                                              QMCHECKVOUCHER.CDEFINE13 ,
                                                              QMCHECKVOUCHER.CDEFINE14 ,
                                                              QMCHECKVOUCHER.CDEFINE15 ,
                                                              QMCHECKVOUCHER.CDEFINE16 ,
                                                              QMCHECKVOUCHER.CINVCODE ,
                                                              cInvAddCode ,
                                                              Inventory.cInvName ,
                                                              cInvStd ,
                                                              cInvDefine1 ,
                                                              cInvDefine2 ,
                                                              cInvDefine3 ,
                                                              cInvDefine4 ,
                                                              cInvDefine5 ,
                                                              cInvDefine6 ,
                                                              cInvDefine7 ,
                                                              cInvDefine8 ,
                                                              cInvDefine9 ,
                                                              cInvDefine10 ,
                                                              cInvDefine11 ,
                                                              cInvDefine12 ,
                                                              cInvDefine13 ,
                                                              cInvDefine14 ,
                                                              cInvDefine15 ,
                                                              cInvDefine16 ,
                                                              QMCHECKVOUCHER.CFREE1 ,
                                                              QMCHECKVOUCHER.CFREE2 ,
                                                              QMCHECKVOUCHER.CFREE3 ,
                                                              QMCHECKVOUCHER.CFREE4 ,
                                                              QMCHECKVOUCHER.CFREE5 ,
                                                              QMCHECKVOUCHER.CFREE6 ,
                                                              QMCHECKVOUCHER.CFREE7 ,
                                                              QMCHECKVOUCHER.CFREE8 ,
                                                              QMCHECKVOUCHER.CFREE9 ,
                                                              QMCHECKVOUCHER.CFREE10 ,
                                                              QMCHECKVOUCHER.CBATCH ,
                                                              ( CASE
                                                              WHEN ISNULL(Inventory.bInvQuality,
                                                              0) = 1
                                                              THEN QMCHECKVOUCHER.DPRODATE
                                                              ELSE NULL
                                                              END ) AS dprodate ,
                                                              QMCHECKVOUCHER.IMASSDATE ,
                                                              QMCHECKVOUCHER.DVDATE ,
                                                              ComputationUnit.cComUnitName ,
                                                              computationunit1.cComUnitName AS cunitname ,
                                                              QMCHECKVOUCHER.iExpiratDateCalcu ,
                                                              QMCHECKVOUCHER.cExpirationdate ,
                                                              QMCHECKVOUCHER.dExpirationdate ,
                                                              CASE ISNULL(QMCHECKVOUCHER.BPROINFLAG,
                                                              0)
                                                              WHEN 0
                                                              THEN ( CASE ISNULL(Inventory.iGroupType,
                                                              0)
                                                              WHEN 0 THEN 0
                                                              WHEN 1
                                                              THEN ( CASE ISNULL(IFREGBREAKQTYDEALTYPE,
                                                              0)
                                                              WHEN 1
                                                              THEN ( ISNULL(FREGQUANTITY,
                                                              0)
                                                              + ISNULL(FCONQUANTIY,
                                                              0)
                                                              - ISNULL(FsumQuantity,
                                                              0) )
                                                              / computationunit1.iChangRate
                                                              ELSE ( ISNULL(FREGQUANTITY,
                                                              0)
                                                              + ISNULL(FCONQUANTIY,
                                                              0)
                                                              - ISNULL(FREGBREAKQUANTITY,
                                                              0)
                                                              * ISNULL(FCHECKRATE,
                                                              1)
                                                              - ISNULL(FsumQuantity,
                                                              0) )
                                                              / computationunit1.iChangRate
                                                              END )
                                                              WHEN 2
                                                              THEN ( CASE ISNULL(IFREGBREAKQTYDEALTYPE,
                                                              0)
                                                              WHEN 1
                                                              THEN ( ISNULL(FCHECKNUM,
                                                              0)
                                                              - ISNULL(FsumNum,
                                                              0) )
                                                              ELSE ( ISNULL(FCHECKNUM,
                                                              0)
                                                              - ISNULL(FsumNum,
                                                              0)
                                                              - ISNULL(FREGBREAKQUANTITY,
                                                              0)
                                                              * ISNULL(FCHECKRATE,
                                                              1)
                                                              / FCHECKCHANGRATE )
                                                              END )
                                                              END )
                                                              ELSE 0
                                                              END AS fnum ,
                                                              CASE ISNULL(QMCHECKVOUCHER.BPROINFLAG,
                                                              0)
                                                              WHEN 0
                                                              THEN ( CASE ISNULL(Inventory.iGroupType,
                                                              0)
                                                              WHEN 0
                                                              THEN ( CASE ISNULL(IFREGBREAKQTYDEALTYPE,
                                                              0)
                                                              WHEN 1
                                                              THEN ( ISNULL(FREGQUANTITY,
                                                              0)
                                                              + ISNULL(FCONQUANTIY,
                                                              0)
                                                              - ISNULL(FsumQuantity,
                                                              0) )
                                                              ELSE ( ISNULL(FREGQUANTITY,
                                                              0)
                                                              + ISNULL(FCONQUANTIY,
                                                              0)
                                                              - ISNULL(FREGBREAKQUANTITY,
                                                              0)
                                                              * ISNULL(FCHECKRATE,
                                                              1)
                                                              - ISNULL(FsumQuantity,
                                                              0) )
                                                              END )
                                                              WHEN 1
                                                              THEN ( CASE ISNULL(IFREGBREAKQTYDEALTYPE,
                                                              0)
                                                              WHEN 1
                                                              THEN ( ISNULL(FREGQUANTITY,
                                                              0)
                                                              + ISNULL(FCONQUANTIY,
                                                              0)
                                                              - ISNULL(FsumQuantity,
                                                              0) )
                                                              ELSE ( ISNULL(FREGQUANTITY,
                                                              0)
                                                              + ISNULL(FCONQUANTIY,
                                                              0)
                                                              - ISNULL(FREGBREAKQUANTITY,
                                                              0)
                                                              * ISNULL(FCHECKRATE,
                                                              1)
                                                              - ISNULL(FsumQuantity,
                                                              0) )
                                                              END )
                                                              WHEN 2
                                                              THEN ( CASE ISNULL(IFREGBREAKQTYDEALTYPE,
                                                              0)
                                                              WHEN 1
                                                              THEN ( ISNULL(FCHECKQTY,
                                                              0)
                                                              - ISNULL(FsumQuantity,
                                                              0) )
                                                              ELSE ( ISNULL(FCHECKQTY,
                                                              0)
                                                              - ISNULL(FsumQuantity,
                                                              0)
                                                              - ISNULL(FREGBREAKQUANTITY,
                                                              0)
                                                              * ISNULL(FCHECKRATE,
                                                              1) )
                                                              END )
                                                              END )
                                                              ELSE 0
                                                              END AS fquantity ,
                                                              QMINSPECTVOUCHERS.CDEFINE22 ,
                                                              QMINSPECTVOUCHERS.CDEFINE23 ,
                                                              QMINSPECTVOUCHERS.CDEFINE24 ,
                                                              QMINSPECTVOUCHERS.CDEFINE25 ,
                                                              QMINSPECTVOUCHERS.CDEFINE26 ,
                                                              QMINSPECTVOUCHERS.CDEFINE27 ,
                                                              QMINSPECTVOUCHERS.CDEFINE28 ,
                                                              QMINSPECTVOUCHERS.CDEFINE29 ,
                                                              QMINSPECTVOUCHERS.CDEFINE30 ,
                                                              QMINSPECTVOUCHERS.CDEFINE31 ,
                                                              QMINSPECTVOUCHERS.CDEFINE32 ,
                                                              QMINSPECTVOUCHERS.CDEFINE33 ,
                                                              QMINSPECTVOUCHERS.CDEFINE34 ,
                                                              QMINSPECTVOUCHERS.CDEFINE35 ,
                                                              QMINSPECTVOUCHERS.CDEFINE36 ,
                                                              QMINSPECTVOUCHERS.CDEFINE37 ,
                                                              QMCHECKVOUCHER.ID ,
                                                              ( CASE ISNULL(QMCHECKVOUCHER.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN QMCHECKVOUCHER.SOURCEAUTOID
                                                              ELSE QMCHECKVOUCHER.ISOURCEPROORDERAUTOID
                                                              END ) AS sourceautoid ,
                                                              Inventory.cComUnitCode ,
                                                              -1 AS autoid ,
                                                              QMCHECKVOUCHER.CUNITID ,
                                                              QMCHECKVOUCHER.CITEMCLASS ,
                                                              QMCHECKVOUCHER.CITEMCNAME ,
                                                              QMCHECKVOUCHER.CITEMCODE ,
                                                              QMCHECKVOUCHER.CITEMNAME ,  
--(case when bfree1=1 then N'是' else N'否' end) as bfree1,  
--(case when bfree2=1 then N'是' else N'否' end) as bfree2,  
--(case when bfree3=1 then N'是' else N'否' end) as bfree3,  
--(case when bfree4=1 then N'是' else N'否' end) as bfree4,  
--(case when bfree5=1 then N'是' else N'否' end) as bfree5,  
--(case when bfree6=1 then N'是' else N'否' end) as bfree6,  
--(case when bfree7=1 then N'是' else N'否' end) as bfree7,  
--(case when bfree8=1 then N'是' else N'否' end) as bfree8,  
--(case when bfree9=1 then N'是' else N'否' end) as bfree9,  
--(case when bfree10=1 then N'是' else N'否' end) as bfree10,  
                                                              bFree1 AS bfree1 ,
                                                              bFree2 AS bfree2 ,
                                                              bFree3 AS bfree3 ,
                                                              bFree4 AS bfree4 ,
                                                              bFree5 AS bfree5 ,
                                                              bFree6 AS bfree6 ,
                                                              bFree7 AS bfree7 ,
                                                              bFree8 AS bfree8 ,
                                                              bFree9 AS bfree9 ,
                                                              bFree10 AS bfree10 ,
                                                              Inventory.cGroupCode ,
                                                              iGroupType ,
                                                              FREGQUANTITY ,
                                                              FCONQUANTIY ,
                                                              ( CASE
                                                              WHEN bService = 1
                                                              THEN N'是'
                                                              ELSE N'否'
                                                              END ) AS bserviceZh ,
                                                              ( CASE
                                                              WHEN bInvBatch = 1
                                                              THEN N'是'
                                                              ELSE N'否'
                                                              END ) AS binvbatchZh ,
                                                              bService AS bservice ,
                                                              bInvBatch AS binvbatch ,
                                                              bSerial AS bserial ,
                                                              bInvQuality AS binvquality ,
                                                              bBarCode AS bbarcode ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN E.WcCode
                                                              ELSE F.WcCode
                                                              END ) AS cMWorkCenterCode ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN E.Description
                                                              ELSE F.Description
                                                              END ) AS cMWorkCenter ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN B.OpSeq
                                                              ELSE C.OpSeq
                                                              END ) AS iOpSeq ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN B.Description
                                                              ELSE C.Description
                                                              END ) AS cOpDesc ,
                                                              ( CASE ISNULL(dbo.QMCHECKVOUCHER.ISOURCEPROORDERROWNO,
                                                              0)
                                                              WHEN 0
                                                              THEN dbo.QMCHECKVOUCHER.IPROORDERAUTOID
                                                              ELSE dbo.QMCHECKVOUCHER.ISOURCEPROORDERROWNO
                                                              END ) AS imoseq ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.OrderDId
                                                              ELSE A.OrderDId
                                                              END ) AS IORDERDID ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.OrderType
                                                              ELSE A.OrderType
                                                              END ) AS ISOORDERTYPE ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.OrderCode
                                                              ELSE A.OrderCode
                                                              END ) AS CORDERCODE ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.OrderSeq
                                                              ELSE A.OrderSeq
                                                              END ) AS IORDERSEQ ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.ManualCode
                                                              ELSE A.ManualCode
                                                              END ) AS cciqbookcode ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.SourceSvcCode
                                                              ELSE A.SourceSvcCode
                                                              END ) AS cservicecode ,
                                                              QMCHECKVOUCHER.CWHCODE AS cwhcode ,
                                                              Warehouse.cWhName AS cwhname ,
                                                              CONVERT(CHAR, CONVERT(MONEY, QMCHECKVOUCHER.UFTS), 2) AS ufts ,
                                                              QMCHECKVOUCHER.IORDERTYPE ,
                                                              QMCHECKVOUCHER.CSOORDERCODE AS csocode ,
                                                              CASE QMCHECKVOUCHER.IORDERTYPE
                                                              WHEN 1
                                                              THEN SO_SODetails.iRowNo
                                                              WHEN 3
                                                              THEN ex_orderdetail.irowno
                                                              ELSE NULL
                                                              END AS isoseq ,
                                                              QMCHECKVOUCHER.ISOORDERAUTOID AS iSoDID ,
                                                              ( CASE ISNULL(QMCHECKVOUCHER.CBYPRODUCT,
                                                              0)
                                                              WHEN 0 THEN N'否'
                                                              ELSE N'是'
                                                              END ) AS bRelated ,
                                                              QMCHECKVOUCHER.cBatchProperty1 ,
                                                              QMCHECKVOUCHER.cBatchProperty2 ,
                                                              QMCHECKVOUCHER.cBatchProperty3 ,
                                                              QMCHECKVOUCHER.cBatchProperty4 ,
                                                              QMCHECKVOUCHER.cBatchProperty5 ,
                                                              QMCHECKVOUCHER.cBatchProperty6 ,
                                                              QMCHECKVOUCHER.cBatchProperty7 ,
                                                              QMCHECKVOUCHER.cBatchProperty8 ,
                                                              QMCHECKVOUCHER.cBatchProperty9 ,
                                                              QMCHECKVOUCHER.cBatchProperty10 ,
                                                              Inventory.iId ,
                                                              CASE ISNULL(Inventory.iGroupType,
                                                              0)
                                                              WHEN 0 THEN NULL
                                                              WHEN 1
                                                              THEN computationunit1.iChangRate
                                                              WHEN 2
                                                              THEN ( CASE ISNULL(IFREGBREAKQTYDEALTYPE,
                                                              0)
                                                              WHEN 1
                                                              THEN CASE ( ISNULL(FCHECKNUM,
                                                              0)
                                                              - ISNULL(FsumNum,
                                                              0) )
                                                              WHEN 0 THEN NULL
                                                              ELSE ( ISNULL(FCHECKQTY,
                                                              0)
                                                              - ISNULL(FsumQuantity,
                                                              0) )
                                                              / ( ISNULL(FCHECKNUM,
                                                              0)
                                                              - ISNULL(FsumNum,
                                                              0) )
                                                              END
                                                              ELSE CASE ( ISNULL(FCHECKNUM,
                                                              0)
                                                              - ISNULL(FsumNum,
                                                              0)
                                                              - ISNULL(FREGBREAKQUANTITY,
                                                              0)
                                                              * ISNULL(FCHECKRATE,
                                                              1)
                                                              / FCHECKCHANGRATE )
                                                              WHEN 0 THEN NULL
                                                              ELSE ( ISNULL(FCHECKQTY,
                                                              0)
                                                              - ISNULL(FsumQuantity,
                                                              0)
                                                              - ISNULL(FREGBREAKQUANTITY,
                                                              0)
                                                              * ISNULL(FCHECKRATE,
                                                              1) )
                                                              / ( ISNULL(FCHECKNUM,
                                                              0)
                                                              - ISNULL(FsumNum,
                                                              0)
                                                              - ISNULL(FREGBREAKQUANTITY,
                                                              0)
                                                              * ISNULL(FCHECKRATE,
                                                              1)
                                                              / FCHECKCHANGRATE )
                                                              END
                                                              END )
                                                              END AS fchangrate ,
                                                              ( CASE QMCHECKVOUCHER.CMASSUNIT
                                                              WHEN 1 THEN N'年'
                                                              WHEN 2 THEN N'月'
                                                              WHEN 3 THEN N'日'
                                                              ELSE N''
                                                              END ) AS cmassunit ,
                                                              QMCHECKVOUCHER.CMAKER ,
                                                              ISNULL(QMCHECKVOUCHER.BEXIGENCY,
                                                              0) AS BEXIGENCY ,
                                                              QMCHECKVOUCHER.FSAMPQTY ,
                                                              QMCHECKVOUCHER.FSAMPQTYINS ,
                                                              QMCHECKVOUCHER.CSYSBARCODE ,
                                                              '' as cFactoryCode ,
                                                              '' as cFactoryName
                                                              FROM
                                                              QMCHECKVOUCHER
                                                              WITH ( NOLOCK )
                                                              LEFT JOIN QMINSPECTVOUCHERS ON QMCHECKVOUCHER.INSPECTAUTOID = QMINSPECTVOUCHERS.AUTOID
                                                              LEFT JOIN QMINSPECTVOUCHER ON QMINSPECTVOUCHERS.ID = QMINSPECTVOUCHER.ID
                                                              INNER JOIN Inventory ON QMCHECKVOUCHER.CINVCODE = Inventory.cInvCode
                                                              LEFT JOIN Person ON QMCHECKVOUCHER.CCHECKPERSONCODE = Person.cPersonCode
                                                              LEFT JOIN ComputationUnit ON Inventory.cComUnitCode = ComputationUnit.cComunitCode
                                                              LEFT JOIN ComputationUnit
                                                              AS computationunit1 ON QMCHECKVOUCHER.CUNITID = computationunit1.cComunitCode
                                                              LEFT JOIN Warehouse ON QMCHECKVOUCHER.CWHCODE = Warehouse.cWhCode
                                                              LEFT JOIN dbo.mom_orderdetail ON ( CASE ISNULL(QMCHECKVOUCHER.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN QMCHECKVOUCHER.SOURCEAUTOID
                                                              ELSE QMCHECKVOUCHER.ISOURCEPROORDERAUTOID
                                                              END ) = dbo.mom_orderdetail.MoDId
                                                              AND ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              LEFT OUTER JOIN sfc_morouting D ON D.MoDId = mom_orderdetail.MoDId
                                                              LEFT JOIN sfc_moroutingdetail B ON B.MoRoutingId = D.MoRoutingId
                                                              AND B.LastFlag = 1
                                                              LEFT OUTER JOIN sfc_workcenter E ON E.WcId = B.WcId
                                                              LEFT JOIN mom_moallocate ON mom_moallocate.AllocateId = dbo.QMCHECKVOUCHER.SOURCEAUTOID
                                                              AND ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 1
                                                              LEFT JOIN dbo.mom_orderdetail A ON A.MoDId = mom_moallocate.MoDId
                                                              LEFT OUTER JOIN sfc_morouting ON sfc_morouting.MoDId = A.MoDId
                                                              LEFT OUTER JOIN sfc_moroutingdetail C ON C.MoRoutingId = sfc_morouting.MoRoutingId
                                                              AND mom_moallocate.OpSeq = C.OpSeq
                                                              LEFT OUTER JOIN sfc_workcenter F ON F.WcId = C.WcId
                                                              LEFT JOIN Department ON ( CASE ISNULL(QMCHECKVOUCHER.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN QMCHECKVOUCHER.CINSPECTDEPCODE
                                                              ELSE mom_orderdetail.MDeptCode
                                                              END ) = Department.cDepCode
                                                              LEFT OUTER JOIN SO_SODetails ON QMCHECKVOUCHER.IORDERTYPE = 1
                                                              AND CAST(SO_SODetails.iSOsID AS NVARCHAR(50)) = QMCHECKVOUCHER.ISOORDERAUTOID
                                                              LEFT OUTER JOIN ex_orderdetail ON QMCHECKVOUCHER.IORDERTYPE = 3
                                                              AND CAST(ex_orderdetail.autoid AS NVARCHAR(50)) = QMCHECKVOUCHER.ISOORDERAUTOID
                                                              --LEFT JOIN Factory ON Factory.cFactoryCode = mom_orderdetail.FactoryCode
                                                              WHERE
                                                              ISNULL(QMCHECKVOUCHER.CVERIFIER,
                                                              N'') <> N''
                                                              AND QMCHECKVOUCHER.CVOUCHTYPE = N'qm04'
                                                              AND ( ( ISNULL(( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.Status
                                                              ELSE A.Status
                                                              END ), 0) = 3
                                                              AND ISNULL(( CASE ISNULL(QMCHECKVOUCHER.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN QMCHECKVOUCHER.SOURCEAUTOID
                                                              ELSE QMCHECKVOUCHER.ISOURCEPROORDERAUTOID
                                                              END ), 0) <> 0
                                                              )
                                                              OR ISNULL(( CASE ISNULL(QMCHECKVOUCHER.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN QMCHECKVOUCHER.SOURCEAUTOID
                                                              ELSE QMCHECKVOUCHER.ISOURCEPROORDERAUTOID
                                                              END ), 0) = 0
                                                              )
                                                              AND ( ISNULL(FREGQUANTITY,
                                                              0)
                                                              + ISNULL(FCONQUANTIY,
                                                              0) ) > 0
                                                              AND ISNULL(QMCHECKVOUCHER.BMERGECHECKFLAG,
                                                              0) = 0
                                                              UNION
                                                              SELECT
                                                              QMCHECKVOUCHER.FsumQuantity,
                                                              CAST(QMCHECKVOUCHER.ID AS VARCHAR)
                                                              + 'D'
                                                              + CAST(M.AUTOID AS VARCHAR) AS dkey ,
                                                              N'' AS selcol ,
                                                              QMCHECKVOUCHER.DDATE ,
                                                              QMCHECKVOUCHER.BPROINFLAG AS bproinflag ,
                                                              QMCHECKVOUCHER.CCHECKCODE ,
                                                              QMCHECKVOUCHER.CCHECKPERSONCODE ,
                                                              Person.cPersonName AS ccheckpersonname ,
                                                              ( CASE ISNULL(M.CSOURCEPROORDERCODE,
                                                              '')
                                                              WHEN ''
                                                              THEN M.SOURCECODE
                                                              ELSE M.CSOURCEPROORDERCODE
                                                              END ) AS sourcecode ,
                                                              M.CPROBATCH ,
                                                              ( CASE ISNULL(M.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN M.CINSPECTDEPCODE
                                                              ELSE mom_orderdetail.MDeptCode
                                                              END ) AS cinspectdepcode ,
                                                              Department.cDepName AS cinspectdepname ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN ( CASE
                                                              WHEN ISNULL(mom_orderdetail.SfcFlag,
                                                              0) = 0
                                                              THEN mom_orderdetail.Remark
                                                              ELSE B.Remark
                                                              END )
                                                              ELSE ( CASE
                                                              WHEN ISNULL(A.SfcFlag,
                                                              0) = 0
                                                              THEN A.Remark
                                                              ELSE C.Remark
                                                              END )
                                                              END ) AS cmemo ,
                                                              QMCHECKVOUCHER.CDEFINE1 ,
                                                              QMCHECKVOUCHER.CDEFINE2 ,
                                                              QMCHECKVOUCHER.CDEFINE3 ,
                                                              QMCHECKVOUCHER.CDEFINE4 ,
                                                              QMCHECKVOUCHER.CDEFINE5 ,
                                                              QMCHECKVOUCHER.CDEFINE6 ,
                                                              QMCHECKVOUCHER.CDEFINE7 ,
                                                              QMCHECKVOUCHER.CDEFINE8 ,
                                                              QMCHECKVOUCHER.CDEFINE9 ,
                                                              QMCHECKVOUCHER.CDEFINE10 ,
                                                              QMCHECKVOUCHER.CDEFINE11 ,
                                                              QMCHECKVOUCHER.CDEFINE12 ,
                                                              QMCHECKVOUCHER.CDEFINE13 ,
                                                              QMCHECKVOUCHER.CDEFINE14 ,
                                                              QMCHECKVOUCHER.CDEFINE15 ,
                                                              QMCHECKVOUCHER.CDEFINE16 ,
                                                              QMCHECKVOUCHER.CINVCODE ,
                                                              cInvAddCode ,
                                                              Inventory.cInvName ,
                                                              cInvStd ,
                                                              cInvDefine1 ,
                                                              cInvDefine2 ,
                                                              cInvDefine3 ,
                                                              cInvDefine4 ,
                                                              cInvDefine5 ,
                                                              cInvDefine6 ,
                                                              cInvDefine7 ,
                                                              cInvDefine8 ,
                                                              cInvDefine9 ,
                                                              cInvDefine10 ,
                                                              cInvDefine11 ,
                                                              cInvDefine12 ,
                                                              cInvDefine13 ,
                                                              cInvDefine14 ,
                                                              cInvDefine15 ,
                                                              cInvDefine16 ,
                                                              M.CFREE1 ,
                                                              M.CFREE2 ,
                                                              M.CFREE3 ,
                                                              M.CFREE4 ,
                                                              M.CFREE5 ,
                                                              M.CFREE6 ,
                                                              M.CFREE7 ,
                                                              M.CFREE8 ,
                                                              M.CFREE9 ,
                                                              M.CFREE10 ,
                                                              QMCHECKVOUCHER.CBATCH ,
                                                              ( CASE
                                                              WHEN ISNULL(Inventory.bInvQuality,
                                                              0) = 1
                                                              THEN QMCHECKVOUCHER.DPRODATE
                                                              ELSE NULL
                                                              END ) AS dprodate ,
                                                              QMCHECKVOUCHER.IMASSDATE ,
                                                              QMCHECKVOUCHER.DVDATE ,
                                                              ComputationUnit.cComUnitName ,
                                                              computationunit1.cComUnitName AS cunitname ,
                                                              QMCHECKVOUCHER.iExpiratDateCalcu ,
                                                              QMCHECKVOUCHER.cExpirationdate ,
                                                              QMCHECKVOUCHER.dExpirationdate ,
                                                              CASE ISNULL(QMCHECKVOUCHER.BPROINFLAG,
                                                              0)
                                                              WHEN 0
                                                              THEN ( CASE ISNULL(Inventory.iGroupType,
                                                              0)
                                                              WHEN 0 THEN 0
                                                              WHEN 1
                                                              THEN ( CASE ISNULL(M.IFREGBREAKQTYDEALTYPE,
                                                              0)
                                                              WHEN 1
                                                              THEN ( ISNULL(M.FREGQUANTITY,
                                                              0)
                                                              + ISNULL(M.FCONQUANTIY,
                                                              0)
                                                              - ISNULL(M.FSUMQUANTITY,
                                                              0) )
                                                              / computationunit1.iChangRate
                                                              ELSE ( ISNULL(M.FREGQUANTITY,
                                                              0)
                                                              + ISNULL(M.FCONQUANTIY,
                                                              0)
                                                              - ISNULL(M.FREGBREAKQUANTITY,
                                                              0)
                                                              * ISNULL(M.FCHECKRATE,
                                                              1)
                                                              - ISNULL(M.FSUMQUANTITY,
                                                              0) )
                                                              / computationunit1.iChangRate
                                                              END )
                                                              WHEN 2
                                                              THEN ( CASE ISNULL(M.IFREGBREAKQTYDEALTYPE,
                                                              0)
                                                              WHEN 1
                                                              THEN ( ISNULL(M.FCHECKNUM,
                                                              0)
                                                              - ISNULL(M.FSUMNUM,
                                                              0) )
                                                              ELSE ( ISNULL(M.FCHECKNUM,
                                                              0)
                                                              - ISNULL(M.FSUMNUM,
                                                              0)
                                                              - ISNULL(M.FREGBREAKQUANTITY,
                                                              0)
                                                              * ISNULL(M.FCHECKRATE,
                                                              1)
                                                              / M.FCHECKCHANGRATE )
                                                              END )
                                                              END )
                                                              ELSE 0
                                                              END AS fnum ,
                                                              CASE ISNULL(QMCHECKVOUCHER.BPROINFLAG,
                                                              0)
                                                              WHEN 0
                                                              THEN ( CASE ISNULL(Inventory.iGroupType,
                                                              0)
                                                              WHEN 0
                                                              THEN ( CASE ISNULL(M.IFREGBREAKQTYDEALTYPE,
                                                              0)
                                                              WHEN 1
                                                              THEN ( ISNULL(M.FREGQUANTITY,
                                                              0)
                                                              + ISNULL(M.FCONQUANTIY,
                                                              0)
                                                              - ISNULL(M.FSUMQUANTITY,
                                                              0) )
                                                              ELSE ( ISNULL(M.FREGQUANTITY,
                                                              0)
                                                              + ISNULL(M.FCONQUANTIY,
                                                              0)
                                                              - ISNULL(M.FREGBREAKQUANTITY,
                                                              0)
                                                              * ISNULL(M.FCHECKRATE,
                                                              1)
                                                              - ISNULL(M.FSUMQUANTITY,
                                                              0) )
                                                              END )
                                                              WHEN 1
                                                              THEN ( CASE ISNULL(M.IFREGBREAKQTYDEALTYPE,
                                                              0)
                                                              WHEN 1
                                                              THEN ( ISNULL(M.FREGQUANTITY,
                                                              0)
                                                              + ISNULL(M.FCONQUANTIY,
                                                              0)
                                                              - ISNULL(M.FSUMQUANTITY,
                                                              0) )
                                                              ELSE ( ISNULL(M.FREGQUANTITY,
                                                              0)
                                                              + ISNULL(M.FCONQUANTIY,
                                                              0)
                                                              - ISNULL(M.FREGBREAKQUANTITY,
                                                              0)
                                                              * ISNULL(M.FCHECKRATE,
                                                              1)
                                                              - ISNULL(M.FSUMQUANTITY,
                                                              0) )
                                                              END )
                                                              WHEN 2
                                                              THEN ( CASE ISNULL(M.IFREGBREAKQTYDEALTYPE,
                                                              0)
                                                              WHEN 1
                                                              THEN ( ISNULL(M.FCHECKQTY,
                                                              0)
                                                              - ISNULL(M.FSUMQUANTITY,
                                                              0) )
                                                              ELSE ( ISNULL(M.FCHECKQTY,
                                                              0)
                                                              - ISNULL(M.FSUMQUANTITY,
                                                              0)
                                                              - ISNULL(M.FREGBREAKQUANTITY,
                                                              0)
                                                              * ISNULL(M.FCHECKRATE,
                                                              1) )
                                                              END )
                                                              END )
                                                              ELSE 0
                                                              END AS fquantity ,
                                                              QMINSPECTVOUCHERS.CDEFINE22 ,
                                                              QMINSPECTVOUCHERS.CDEFINE23 ,
                                                              QMINSPECTVOUCHERS.CDEFINE24 ,
                                                              QMINSPECTVOUCHERS.CDEFINE25 ,
                                                              QMINSPECTVOUCHERS.CDEFINE26 ,
                                                              QMINSPECTVOUCHERS.CDEFINE27 ,
                                                              QMINSPECTVOUCHERS.CDEFINE28 ,
                                                              QMINSPECTVOUCHERS.CDEFINE29 ,
                                                              QMINSPECTVOUCHERS.CDEFINE30 ,
                                                              QMINSPECTVOUCHERS.CDEFINE31 ,
                                                              QMINSPECTVOUCHERS.CDEFINE32 ,
                                                              QMINSPECTVOUCHERS.CDEFINE33 ,
                                                              QMINSPECTVOUCHERS.CDEFINE34 ,
                                                              QMINSPECTVOUCHERS.CDEFINE35 ,
                                                              QMINSPECTVOUCHERS.CDEFINE36 ,
                                                              QMINSPECTVOUCHERS.CDEFINE37 ,
                                                              QMCHECKVOUCHER.ID ,
                                                              ( CASE ISNULL(M.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN M.SOURCEAUTOID
                                                              ELSE M.ISOURCEPROORDERAUTOID
                                                              END ) AS sourceautoid ,
                                                              Inventory.cComUnitCode ,
                                                              M.AUTOID AS autoid ,
                                                              M.CUNITID ,
                                                              M.CITEMCLASS ,
                                                              M.CITEMCNAME ,
                                                              M.CITEMCODE ,
                                                              M.CITEMNAME ,  
--(case when bfree1=1 then N'是' else N'否' end) as bfree1,  
--(case when bfree2=1 then N'是' else N'否' end) as bfree2,  
--(case when bfree3=1 then N'是' else N'否' end) as bfree3,  
--(case when bfree4=1 then N'是' else N'否' end) as bfree4,  
--(case when bfree5=1 then N'是' else N'否' end) as bfree5,  
--(case when bfree6=1 then N'是' else N'否' end) as bfree6,  
--(case when bfree7=1 then N'是' else N'否' end) as bfree7,  
--(case when bfree8=1 then N'是' else N'否' end) as bfree8,  
--(case when bfree9=1 then N'是' else N'否' end) as bfree9,  
--(case when bfree10=1 then N'是' else N'否' end) as bfree10,  
                                                              bFree1 AS bfree1 ,
                                                              bFree2 AS bfree2 ,
                                                              bFree3 AS bfree3 ,
                                                              bFree4 AS bfree4 ,
                                                              bFree5 AS bfree5 ,
                                                              bFree6 AS bfree6 ,
                                                              bFree7 AS bfree7 ,
                                                              bFree8 AS bfree8 ,
                                                              bFree9 AS bfree9 ,
                                                              bFree10 AS bfree10 ,
                                                              Inventory.cGroupCode ,
                                                              iGroupType ,
                                                              M.FREGQUANTITY ,
                                                              M.FCONQUANTIY ,
                                                              ( CASE
                                                              WHEN bService = 1
                                                              THEN N'是'
                                                              ELSE N'否'
                                                              END ) AS bserviceZh ,
                                                              ( CASE
                                                              WHEN bInvBatch = 1
                                                              THEN N'是'
                                                              ELSE N'否'
                                                              END ) AS binvbatchZh ,
                                                              bService AS bservice ,
                                                              bInvBatch AS binvbatch ,
                                                              bSerial AS bserial ,
                                                              bInvQuality AS binvquality ,
                                                              bBarCode AS bbarcode ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN E.WcCode
                                                              ELSE F.WcCode
                                                              END ) AS cMWorkCenterCode ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN E.Description
                                                              ELSE F.Description
                                                              END ) AS cMWorkCenter ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN B.OpSeq
                                                              ELSE C.OpSeq
                                                              END ) AS iOpSeq ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN B.Description
                                                              ELSE C.Description
                                                              END ) AS cOpDesc ,
                                                              ( CASE ISNULL(M.ISOURCEPROORDERROWNO,
                                                              0)
                                                              WHEN 0
                                                              THEN M.IPROORDERAUTOID
                                                              ELSE M.ISOURCEPROORDERROWNO
                                                              END ) AS imoseq ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.OrderDId
                                                              ELSE A.OrderDId
                                                              END ) AS IORDERDID ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.OrderType
                                                              ELSE A.OrderType
                                                              END ) AS ISOORDERTYPE ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.OrderCode
                                                              ELSE A.OrderCode
                                                              END ) AS CORDERCODE ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.OrderSeq
                                                              ELSE A.OrderSeq
                                                              END ) AS IORDERSEQ ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.ManualCode
                                                              ELSE A.ManualCode
                                                              END ) AS cciqbookcode ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.SourceSvcCode
                                                              ELSE A.SourceSvcCode
                                                              END ) AS cservicecode ,
                                                              M.CWHCODE AS cwhcode ,
                                                              Warehouse.cWhName AS cwhname ,
                                                              CONVERT(CHAR, CONVERT(MONEY, QMCHECKVOUCHER.UFTS), 2) AS ufts ,
                                                              M.IORDERTYPE ,
                                                              M.CSOORDERCODE AS csocode ,
                                                              CASE M.IORDERTYPE
                                                              WHEN 1
                                                              THEN SO_SODetails.iRowNo
                                                              WHEN 3
                                                              THEN ex_orderdetail.irowno
                                                              ELSE NULL
                                                              END AS isoseq ,
                                                              M.ISOORDERAUTOID AS iSoDID ,
                                                              ( CASE ISNULL(QMCHECKVOUCHER.CBYPRODUCT,
                                                              0)
                                                              WHEN 0 THEN N'否'
                                                              ELSE N'是'
                                                              END ) AS bRelated ,
                                                              QMCHECKVOUCHER.cBatchProperty1 ,
                                                              QMCHECKVOUCHER.cBatchProperty2 ,
                                                              QMCHECKVOUCHER.cBatchProperty3 ,
                                                              QMCHECKVOUCHER.cBatchProperty4 ,
                                                              QMCHECKVOUCHER.cBatchProperty5 ,
                                                              QMCHECKVOUCHER.cBatchProperty6 ,
                                                              QMCHECKVOUCHER.cBatchProperty7 ,
                                                              QMCHECKVOUCHER.cBatchProperty8 ,
                                                              QMCHECKVOUCHER.cBatchProperty9 ,
                                                              QMCHECKVOUCHER.cBatchProperty10 ,
                                                              Inventory.iId ,
                                                              CASE ISNULL(Inventory.iGroupType,
                                                              0)
                                                              WHEN 0 THEN NULL
                                                              WHEN 1
                                                              THEN computationunit1.iChangRate
                                                              WHEN 2
                                                              THEN ( CASE ISNULL(M.IFREGBREAKQTYDEALTYPE,
                                                              0)
                                                              WHEN 1
                                                              THEN CASE ( ISNULL(M.FCHECKNUM,
                                                              0)
                                                              - ISNULL(M.FSUMNUM,
                                                              0) )
                                                              WHEN 0 THEN NULL
                                                              ELSE ( ISNULL(M.FCHECKQTY,
                                                              0)
                                                              - ISNULL(M.FSUMQUANTITY,
                                                              0) )
                                                              / ( ISNULL(M.FCHECKNUM,
                                                              0)
                                                              - ISNULL(M.FSUMNUM,
                                                              0) )
                                                              END
                                                              ELSE CASE ( ISNULL(M.FCHECKNUM,
                                                              0)
                                                              - ISNULL(M.FSUMNUM,
                                                              0)
                                                              - ISNULL(M.FREGBREAKQUANTITY,
                                                              0)
                                                              * ISNULL(M.FCHECKRATE,
                                                              1)
                                                              / M.FCHECKCHANGRATE )
                                                              WHEN 0 THEN NULL
                                                              ELSE ( ISNULL(M.FCHECKQTY,
                                                              0)
                                                              - ISNULL(M.FSUMQUANTITY,
                                                              0)
                                                              - ISNULL(M.FREGBREAKQUANTITY,
                                                              0)
                                                              * ISNULL(M.FCHECKRATE,
                                                              1) )
                                                              / ( ISNULL(M.FCHECKNUM,
                                                              0)
                                                              - ISNULL(M.FSUMNUM,
                                                              0)
                                                              - ISNULL(M.FREGBREAKQUANTITY,
                                                              0)
                                                              * ISNULL(M.FCHECKRATE,
                                                              1)
                                                              / M.FCHECKCHANGRATE )
                                                              END
                                                              END )
                                                              END AS fchangrate ,
                                                              ( CASE QMCHECKVOUCHER.CMASSUNIT
                                                              WHEN 1 THEN N'年'
                                                              WHEN 2 THEN N'月'
                                                              WHEN 3 THEN N'日'
                                                              ELSE N''
                                                              END ) AS cmassunit ,
                                                              QMCHECKVOUCHER.CMAKER ,
                                                              ISNULL(QMCHECKVOUCHER.BEXIGENCY,
                                                              0) AS BEXIGENCY ,
                                                              QMCHECKVOUCHER.FSAMPQTY ,
                                                              QMCHECKVOUCHER.FSAMPQTYINS ,
                                                              QMCHECKVOUCHER.CSYSBARCODE ,
                                                              '' as cFactoryCode ,
                                                              '' as cFactoryName
                                                              FROM
                                                              QMCHECKVOUCHER
                                                              WITH ( NOLOCK )
                                                              INNER JOIN QMMergeCheckDetail M ON ISNULL(QMCHECKVOUCHER.BMERGECHECKFLAG,
                                                              0) = 1
                                                              AND QMCHECKVOUCHER.ID = M.ID
                                                              LEFT JOIN QMINSPECTVOUCHERS ON M.INSPECTAUTOID = QMINSPECTVOUCHERS.AUTOID
                                                              LEFT JOIN QMINSPECTVOUCHER ON QMINSPECTVOUCHERS.ID = QMINSPECTVOUCHER.ID
                                                              INNER JOIN Inventory ON QMCHECKVOUCHER.CINVCODE = Inventory.cInvCode
                                                              LEFT JOIN Person ON QMCHECKVOUCHER.CCHECKPERSONCODE = Person.cPersonCode
                                                              LEFT JOIN ComputationUnit ON Inventory.cComUnitCode = ComputationUnit.cComunitCode
                                                              LEFT JOIN ComputationUnit
                                                              AS computationunit1 ON QMCHECKVOUCHER.CUNITID = computationunit1.cComunitCode
                                                              LEFT JOIN Warehouse ON M.CWHCODE = Warehouse.cWhCode
                                                              LEFT JOIN dbo.mom_orderdetail ON ( CASE ISNULL(M.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN M.SOURCEAUTOID
                                                              ELSE M.ISOURCEPROORDERAUTOID
                                                              END ) = dbo.mom_orderdetail.MoDId
                                                              AND ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              LEFT OUTER JOIN sfc_morouting D ON D.MoDId = mom_orderdetail.MoDId
                                                              LEFT JOIN sfc_moroutingdetail B ON B.MoRoutingId = D.MoRoutingId
                                                              AND B.LastFlag = 1
                                                              LEFT OUTER JOIN sfc_workcenter E ON E.WcId = B.WcId
                                                              LEFT JOIN mom_moallocate ON mom_moallocate.AllocateId = M.SOURCEAUTOID
                                                              AND ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 1
                                                              LEFT JOIN dbo.mom_orderdetail A ON A.MoDId = mom_moallocate.MoDId
                                                              LEFT OUTER JOIN sfc_morouting ON sfc_morouting.MoDId = A.MoDId
                                                              LEFT OUTER JOIN sfc_moroutingdetail C ON C.MoRoutingId = sfc_morouting.MoRoutingId
                                                              AND mom_moallocate.OpSeq = C.OpSeq
                                                              LEFT OUTER JOIN sfc_workcenter F ON F.WcId = C.WcId
                                                              LEFT JOIN Department ON ( CASE ISNULL(QMCHECKVOUCHER.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN M.CINSPECTDEPCODE
                                                              ELSE mom_orderdetail.MDeptCode
                                                              END ) = Department.cDepCode
                                                              LEFT OUTER JOIN SO_SODetails ON M.IORDERTYPE = 1
                                                              AND CAST(SO_SODetails.iSOsID AS NVARCHAR(50)) = M.ISOORDERAUTOID
                                                              LEFT OUTER JOIN ex_orderdetail ON M.IORDERTYPE = 3
                                                              AND CAST(ex_orderdetail.autoid AS NVARCHAR(50)) = M.ISOORDERAUTOID
                                                              --LEFT JOIN Factory ON Factory.cFactoryCode = mom_orderdetail.FactoryCode
                                                              WHERE
                                                              ISNULL(QMCHECKVOUCHER.CVERIFIER,
                                                              N'') <> N''
                                                              AND QMCHECKVOUCHER.CVOUCHTYPE = N'qm04'
                                                              AND ISNULL(M.bproinflag,
                                                              0) <> 1
                                                              AND ( ( ISNULL(( CASE
                                                              WHEN ISNULL(dbo.QMCHECKVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.Status
                                                              ELSE A.Status
                                                              END ), 0) = 3
                                                              AND ISNULL(( CASE ISNULL(QMCHECKVOUCHER.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN QMCHECKVOUCHER.SOURCEAUTOID
                                                              ELSE QMCHECKVOUCHER.ISOURCEPROORDERAUTOID
                                                              END ), 0) <> 0
                                                              )
                                                              OR ISNULL(( CASE ISNULL(QMCHECKVOUCHER.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN QMCHECKVOUCHER.SOURCEAUTOID
                                                              ELSE QMCHECKVOUCHER.ISOURCEPROORDERAUTOID
                                                              END ), 0) = 0
                                                              )
                                                              AND ( ISNULL(M.FREGQUANTITY,
                                                              0)
                                                              + ISNULL(M.FCONQUANTIY,
                                                              0) ) > 0
                                                            ) AS aa
                                                ) AS bb
                                      WHERE     1 = 1
                                    ) AS QMList
                            WHERE   id IN ( SELECT DISTINCT
                                                    M_ID
                                            FROM    #STPDAPRODUCTINRefCheckIDs )
                            ORDER BY sourcecode ASC ,
                                    cprobatch ASC;  
                            SET TRANSACTION ISOLATION LEVEL READ COMMITTED;  
                        END;  
                    ELSE
                        BEGIN  
      --不良品处理单  
      --单据头  
                            SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;  
                            SELECT DISTINCT
                                    '' AS selcol ,
                                    CREJECTCODE AS crejectcode ,
									CREJECTCODE as csrccode,
                                    CONVERT(VARCHAR(100), dDate, 23) AS ddate ,
                                    CCHECKCODE AS ccheckcode ,
                                    cCheckPersoncode AS ccheckpersoncode ,
                                    cCheckPersonName AS ccheckpersonname ,
                                    SourceCode AS sourcecode ,
                                    CPROBATCH AS cprobatch ,
                                    cinspectdepcode as cdepcode,
                                    cinspectdepname as cdepname,
									 cinspectdepcode ,
                                    cinspectdepname ,
                                    CDEFINE1 AS cdefine1 ,
                                    CDEFINE2 AS cdefine2 ,
                                    CDEFINE3 AS cdefine3 ,
                                    CDEFINE4 AS cdefine4 ,
                                    CDEFINE5 AS cdefine5 ,
                                    CDEFINE6 AS cdefine6 ,
                                    CDEFINE7 AS cdefine7 ,
                                    CDEFINE8 AS cdefine8 ,
                                    CDEFINE9 AS cdefine9 ,
                                    CDEFINE10 AS cdefine10 ,
                                    CDEFINE11 AS cdefine11 ,
                                    CDEFINE12 AS cdefine12 ,
                                    CDEFINE13 AS cdefine13 ,
                                    CDEFINE14 AS cdefine14 ,
                                    CDEFINE15 AS cdefine15 ,
                                    CDEFINE16 AS cdefine16 ,
                                    cmemo ,
                                    ufts ,
                                    SourceAutoID AS sourceautoid ,
                                    imoseq ,
                                    iOpSeq AS iopseq ,
                                    cOpDesc AS copdesc ,
                                    cMWorkCenterCode AS cmworkcentercode ,
                                    ID AS id ,
                                    cMWorkCenter AS cmworkcenter
                            FROM    ( SELECT    *
                                      FROM      ( SELECT    N'' AS selcol ,
                                                            QMREJECTVOUCHER.CREJECTCODE ,
                                                            QMREJECTVOUCHER.DCHECKDATE AS dDate ,
                                                            QMREJECTVOUCHER.CCHECKCODE ,
                                                            QMREJECTVOUCHER.CCHECKPERSON AS cCheckPersoncode ,
                                                            Person.cPersonName AS cCheckPersonName ,
                                                            ( CASE ISNULL(QMREJECTVOUCHER.CSOURCEPROORDERCODE,
                                                              '')
                                                              WHEN ''
                                                              THEN QMREJECTVOUCHER.SOURCECODE
                                                              ELSE QMREJECTVOUCHER.CSOURCEPROORDERCODE
                                                              END ) AS SourceCode ,
                                                            QMREJECTVOUCHER.CPROBATCH ,
                                                            ( CASE ISNULL(QMREJECTVOUCHER.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN QMREJECTVOUCHER.CINSPECTDEPCODE
                                                              ELSE mom_orderdetail.MDeptCode
                                                              END ) AS cinspectdepcode ,
                                                            Department.cDepName AS cinspectdepname ,
                                                            ( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN ( CASE
                                                              WHEN ISNULL(mom_orderdetail.SfcFlag,
                                                              0) = 0
                                                              THEN mom_orderdetail.Remark
                                                              ELSE B.Remark
                                                              END )
                                                              ELSE ( CASE
                                                              WHEN ISNULL(A.SfcFlag,
                                                              0) = 0
                                                              THEN A.Remark
                                                              ELSE C.Remark
                                                              END )
                                                              END ) AS cmemo ,
                                                            QMREJECTVOUCHER.CDEFINE1 ,
                                                            QMREJECTVOUCHER.CDEFINE2 ,
                                                            QMREJECTVOUCHER.CDEFINE3 ,
                                                            QMREJECTVOUCHER.CDEFINE4 ,
                                                            QMREJECTVOUCHER.CDEFINE5 ,
                                                            QMREJECTVOUCHER.CDEFINE6 ,
                                                            QMREJECTVOUCHER.CDEFINE7 ,
                                                            QMREJECTVOUCHER.CDEFINE8 ,
                                                            QMREJECTVOUCHER.CDEFINE9 ,
                                                            QMREJECTVOUCHER.CDEFINE10 ,
                                                            QMREJECTVOUCHER.CDEFINE11 ,
                                                            QMREJECTVOUCHER.CDEFINE12 ,
                                                            QMREJECTVOUCHER.CDEFINE13 ,
                                                            QMREJECTVOUCHER.CDEFINE14 ,
                                                            QMREJECTVOUCHER.CDEFINE15 ,
                                                            QMREJECTVOUCHER.CDEFINE16 ,
                                                            QMREJECTVOUCHERS.CDIMINVCODE AS cinvcode ,
                                                            Inventory.cInvAddCode AS cInvAddCode ,
                                                            Inventory.cInvName AS cInvName ,
                                                            Inventory.cInvStd AS cInvStd ,
                                                            cInvDefine1 ,
                                                            cInvDefine2 ,
                                                            cInvDefine3 ,
                                                            cInvDefine4 ,
                                                            cInvDefine5 ,
                                                            cInvDefine6 ,
                                                            cInvDefine7 ,
                                                            cInvDefine8 ,
                                                            cInvDefine9 ,
                                                            cInvDefine10 ,
                                                            cInvDefine11 ,
                                                            cInvDefine12 ,
                                                            cInvDefine13 ,
                                                            cInvDefine14 ,
                                                            cInvDefine15 ,
                                                            cInvDefine16 ,
                                                            QMREJECTVOUCHERS.CFREE1 AS cFree1 ,
                                                            QMREJECTVOUCHERS.CFREE2 AS cFree2 ,
                                                            QMREJECTVOUCHERS.CFREE3 AS cFree3 ,
                                                            QMREJECTVOUCHERS.CFREE4 AS cFree4 ,
                                                            QMREJECTVOUCHERS.CFREE5 AS cFree5 ,
                                                            QMREJECTVOUCHERS.CFREE6 AS cFree6 ,
                                                            QMREJECTVOUCHERS.CFREE7 AS cFree7 ,
                                                            QMREJECTVOUCHERS.CFREE8 AS cFree8 ,
                                                            QMREJECTVOUCHERS.CFREE9 AS cFree9 ,
                                                            QMREJECTVOUCHERS.CFREE10 AS cFree10 ,
                                                            ( CASE ISNULL(Inventory.bInvBatch,
                                                              0)
                                                              WHEN 0 THEN NULL
                                                              ELSE QMREJECTVOUCHERS.CDIMBATCH
                                                              END ) AS cBatch ,
                                                            ( CASE
                                                              WHEN ( ISNULL(Inventory.bInvBatch,
                                                              0) <> 0
                                                              AND ISNULL(Inventory.cMassUnit,
                                                              N'') <> N''
                                                              )
                                                              THEN QMREJECTVOUCHER.DPRODATE
                                                              ELSE NULL
                                                              END ) AS dprodate ,
                                                            IDIMMASSDATE AS imassdate ,
                                                            ( CASE ISNULL(Inventory.bInvQuality,
                                                              0)
                                                              WHEN 0 THEN NULL
                                                              ELSE QMREJECTVOUCHERS.DDIMVDATE
                                                              END ) AS dVDate ,
                                                            QMREJECTVOUCHERS.iDIMExpiratDateCalcu AS iExpiratDateCalcu ,
                                                            QMREJECTVOUCHERS.cDIMExpirationdate AS cExpirationdate ,
                                                            QMREJECTVOUCHERS.dDIMExpirationdate AS dExpirationdate ,
                                                            ComputationUnit.cComUnitName ,
                                                            ComputationUnit1.cComUnitName AS CUNITNAME ,
                                                            QMREJECTVOUCHERS.FDIMCHANGRATE AS FCHANGRATE ,
                                                            ( ISNULL(QMREJECTVOUCHERS.FDIMQUANTITY,
                                                              0) ) AS fQuantity ,
                                                            ( ISNULL(QMREJECTVOUCHERS.FDIMNUM,
                                                              0) ) AS Fnum ,
                                                            QMREJECTVOUCHERS.CDEFINE22 ,
                                                            QMREJECTVOUCHERS.CDEFINE23 ,
                                                            QMREJECTVOUCHERS.CDEFINE24 ,
                                                            QMREJECTVOUCHERS.CDEFINE25 ,
                                                            QMREJECTVOUCHERS.CDEFINE26 ,
                                                            QMREJECTVOUCHERS.CDEFINE27 ,
                                                            QMREJECTVOUCHERS.CDEFINE28 ,
                                                            QMREJECTVOUCHERS.CDEFINE29 ,
                                                            QMREJECTVOUCHERS.CDEFINE30 ,
                                                            QMREJECTVOUCHERS.CDEFINE31 ,
                                                            QMREJECTVOUCHERS.CDEFINE32 ,
                                                            QMREJECTVOUCHERS.CDEFINE33 ,
                                                            QMREJECTVOUCHERS.CDEFINE34 ,
                                                            QMREJECTVOUCHERS.CDEFINE35 ,
                                                            QMREJECTVOUCHERS.CDEFINE36 ,
                                                            QMREJECTVOUCHERS.CDEFINE37 ,
                                                            QMREJECTVOUCHERS.AUTOID ,
                                                            QMREJECTVOUCHERS.ID ,
                                                            ( CASE ISNULL(QMREJECTVOUCHER.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN QMREJECTVOUCHER.SOURCEAUTOID
                                                              ELSE QMREJECTVOUCHER.ISOURCEPROORDERAUTOID
                                                              END ) AS SourceAutoID ,
                                                            Inventory.cComUnitCode ,
                                                            QMREJECTVOUCHERS.CDIMUNITID AS CUNITID ,
                                                            QMREJECTVOUCHER.CITEMCLASS ,
                                                            QMREJECTVOUCHER.CITEMCNAME ,
                                                            QMREJECTVOUCHER.CITEMCODE ,
                                                            QMREJECTVOUCHER.CITEMNAME ,
                                                            QMREJECTVOUCHER.CHECKID ,  
--(case when bfree1=1 then N'是' else N'否' end) as bfree1,  
--(case when bfree2=1 then N'是' else N'否' end) as bfree2,  
--(case when bfree3=1 then N'是' else N'否' end) as bfree3,  
--(case when bfree4=1 then N'是' else N'否' end) as bfree4,  
--(case when bfree5=1 then N'是' else N'否' end) as bfree5,  
--(case when bfree6=1 then N'是' else N'否' end) as bfree6,  
--(case when bfree7=1 then N'是' else N'否' end) as bfree7,  
--(case when bfree8=1 then N'是' else N'否' end) as bfree8,  
--(case when bfree9=1 then N'是' else N'否' end) as bfree9,  
--(case when bfree10=1 then N'是' else N'否' end) as bfree10,  
                                                            bFree1 AS bfree1 ,
                                                            bFree2 AS bfree2 ,
                                                            bFree3 AS bfree3 ,
                                                            bFree4 AS bfree4 ,
                                                            bFree5 AS bfree5 ,
                                                            bFree6 AS bfree6 ,
                                                            bFree7 AS bfree7 ,
                                                            bFree8 AS bfree8 ,
                                                            bFree9 AS bfree9 ,
                                                            bFree10 AS bfree10 ,
                                                            Inventory.cGroupCode ,
                                                            iGroupType ,
                                                            ( CASE
                                                              WHEN bService = 1
                                                              THEN N'是'
                                                              ELSE N'否'
                                                              END ) AS bserviceZh ,
                                                            ( CASE
                                                              WHEN Inventory.bInvBatch = 1
                                                              THEN N'是'
                                                              ELSE N'否'
                                                              END ) AS binvbatchZh ,
                                                            bService AS bservice ,
                                                            bInvBatch AS binvbatch ,
                                                            bSerial AS bserial ,
                                                            bInvQuality AS binvquality ,
                                                            bBarCode AS bbarcode ,
                                                            CONVERT(CHAR, CONVERT(MONEY, QMREJECTVOUCHER.UFTS), 2) AS ufts ,
                                                            ( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN E.WcCode
                                                              ELSE F.WcCode
                                                              END ) AS cMWorkCenterCode ,
                                                            ( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN E.Description
                                                              ELSE F.Description
                                                              END ) AS cMWorkCenter ,
                                                            ( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN B.OpSeq
                                                              ELSE C.OpSeq
                                                              END ) AS iOpSeq ,
                                                            ( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN B.Description
                                                              ELSE C.Description
                                                              END ) AS cOpDesc ,
                                                            ( CASE ISNULL(dbo.QMREJECTVOUCHER.ISOURCEPROORDERROWNO,
                                                              0)
                                                              WHEN 0
                                                              THEN dbo.QMREJECTVOUCHER.IPROORDERAUTOID
                                                              ELSE dbo.QMREJECTVOUCHER.ISOURCEPROORDERROWNO
                                                              END ) AS imoseq ,
                                                            ( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.OrderDId
                                                              ELSE A.OrderDId
                                                              END ) AS IORDERDID ,
                                                            ( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.OrderType
                                                              ELSE A.OrderType
                                                              END ) AS ISOORDERTYPE ,
                                                            ( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.OrderCode
                                                              ELSE A.OrderCode
                                                              END ) AS CORDERCODE ,
                                                            ( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.OrderSeq
                                                              ELSE A.OrderSeq
                                                              END ) AS IORDERSEQ ,
                                                            ( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.ManualCode
                                                              ELSE A.ManualCode
                                                              END ) AS cciqbookcode ,
                                                            ( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.SourceSvcCode
                                                              ELSE ( CASE
                                                              WHEN mom_moallocate.QmFlag = 1
                                                              THEN mom_orderdetail.SourceSvcCode
                                                              ELSE NULL
                                                              END )
                                                              END ) AS cservicecode ,
                                                            QMREJECTVOUCHERS.CBWHCODE AS cwhcode ,
                                                            Warehouse.cWhName AS cwhname ,
                                                            QMREJECTVOUCHER.CWHCODE AS csourcewhcode ,
                                                            sourcewarehouse.cWhName AS csourcewhname ,
                                                            0 AS iordertype ,
                                                            CAST('' AS NVARCHAR(100)) AS csocode ,
                                                            CAST('' AS NVARCHAR(50)) AS iSoDID ,
                                                            CAST(NULL AS INT) AS isoseq ,
                                                            ( CASE ISNULL(QMREJECTVOUCHER.CBYPRODUCT,
                                                              0)
                                                              WHEN 0 THEN N'否'
                                                              ELSE N'是'
                                                              END ) AS bRelated ,
                                                            QMREJECTVOUCHER.cBatchProperty1 ,
                                                            QMREJECTVOUCHER.cBatchProperty2 ,
                                                            QMREJECTVOUCHER.cBatchProperty3 ,
                                                            QMREJECTVOUCHER.cBatchProperty4 ,
                                                            QMREJECTVOUCHER.cBatchProperty5 ,
                                                            QMREJECTVOUCHER.cBatchProperty6 ,
                                                            QMREJECTVOUCHER.cBatchProperty7 ,
                                                            QMREJECTVOUCHER.cBatchProperty8 ,
                                                            QMREJECTVOUCHER.cBatchProperty9 ,
                                                            QMREJECTVOUCHER.cBatchProperty10 ,
                                                            Inventory.iId ,
                                                            ( CASE QMREJECTVOUCHERS.CDIMMASSUNIT
                                                              WHEN 1 THEN N'年'
                                                              WHEN 2 THEN N'月'
                                                              WHEN 3 THEN N'日'
                                                              ELSE N''
                                                              END ) AS cmassunit ,
                                                            QMREJECTVOUCHER.CMAKER ,
                                                            QMREJECTVOUCHER.CSYSBARCODE ,
                                                            QMREJECTVOUCHERS.CBSYSBARCODE ,
                                                            --mom_orderdetail.FactoryCode AS cfactorycode ,
                                                            --Factory.cFactoryName
                                                            '' AS cfactorycode ,
                                                            '' AS cFactoryName
                                                  FROM      QMREJECTVOUCHER
                                                            WITH ( NOLOCK )
                                                            INNER JOIN QMREJECTVOUCHERS ON QMREJECTVOUCHER.ID = QMREJECTVOUCHERS.ID
                                                            INNER JOIN Inventory ON QMREJECTVOUCHERS.CDIMINVCODE = Inventory.cInvCode
                                                            LEFT JOIN Person ON QMREJECTVOUCHER.CCHECKPERSON = Person.cPersonCode
                                                            LEFT JOIN ComputationUnit ON Inventory.cComUnitCode = ComputationUnit.cComunitCode
                                                            LEFT JOIN ComputationUnit
                                                            AS ComputationUnit1 ON QMREJECTVOUCHERS.CDIMUNITID = ComputationUnit1.cComunitCode
                                                            LEFT JOIN Warehouse ON QMREJECTVOUCHERS.CBWHCODE = Warehouse.cWhCode
                                                            LEFT JOIN Warehouse sourcewarehouse ON QMREJECTVOUCHER.CWHCODE = sourcewarehouse.cWhCode
                                                            LEFT JOIN dbo.mom_orderdetail ON ( CASE ISNULL(QMREJECTVOUCHER.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN QMREJECTVOUCHER.SOURCEAUTOID
                                                              ELSE QMREJECTVOUCHER.ISOURCEPROORDERAUTOID
                                                              END ) = dbo.mom_orderdetail.MoDId
                                                              AND ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                            LEFT OUTER JOIN sfc_morouting D ON D.MoDId = mom_orderdetail.MoDId
                                                            LEFT JOIN sfc_moroutingdetail B ON B.MoRoutingId = D.MoRoutingId
                                                              AND B.LastFlag = 1
                                                            LEFT OUTER JOIN sfc_workcenter E ON E.WcId = B.WcId
                                                            LEFT JOIN mom_moallocate ON mom_moallocate.AllocateId = dbo.QMREJECTVOUCHER.SOURCEAUTOID
                                                              AND ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 1
                                                            LEFT JOIN dbo.mom_orderdetail A ON A.MoDId = mom_moallocate.MoDId
                                                            LEFT OUTER JOIN sfc_morouting ON sfc_morouting.MoDId = A.MoDId
                                                            LEFT OUTER JOIN sfc_moroutingdetail C ON C.MoRoutingId = sfc_morouting.MoRoutingId
                                                              AND mom_moallocate.OpSeq = C.OpSeq
                                                            LEFT OUTER JOIN sfc_workcenter F ON F.WcId = C.WcId
                                                            LEFT JOIN Department ON ( CASE ISNULL(QMREJECTVOUCHER.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN QMREJECTVOUCHER.CINSPECTDEPCODE
                                                              ELSE mom_orderdetail.MDeptCode
                                                              END ) = Department.cDepCode
                                                            --LEFT JOIN Factory ON Factory.cFactoryCode = mom_orderdetail.FactoryCode
                                                  WHERE     ISNULL(QMREJECTVOUCHER.CVERIFIER,
                                                              N'') <> N''
                                                            AND ISNULL(QMREJECTVOUCHERS.BFLAG,
                                                              0) = 0
                                                            AND QMREJECTVOUCHERS.IDISPOSEFLOW = 2
                                                            AND QMREJECTVOUCHER.CVOUCHTYPE = N'QM06'
                                                            AND ( ( ISNULL(( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.Status
                                                              ELSE A.Status
                                                              END ), 0) = 3
                                                              AND ISNULL(( CASE ISNULL(QMREJECTVOUCHER.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN QMREJECTVOUCHER.SOURCEAUTOID
                                                              ELSE QMREJECTVOUCHER.ISOURCEPROORDERAUTOID
                                                              END ), 0) <> 0
                                                              )
                                                              OR ISNULL(( CASE ISNULL(QMREJECTVOUCHER.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN QMREJECTVOUCHER.SOURCEAUTOID
                                                              ELSE QMREJECTVOUCHER.ISOURCEPROORDERAUTOID
                                                              END ), 0) = 0
                                                              )
                                                            AND ( ISNULL(QMREJECTVOUCHERS.FDIMQUANTITY,
                                                              0) > 0 )
                                                ) AS aa
                                      WHERE     1 = 1
                                                AND ID IN (
                                                SELECT DISTINCT
                                                        M_ID
                                                FROM    #STPDAPRODUCTINRefCheckIDs1 )
                                    ) AS QMList
                            ORDER BY sourcecode ASC ,
                                    cprobatch ASC;  
                            SET TRANSACTION ISOLATION LEVEL READ COMMITTED;  
  
                            IF ( @GetType = N'DETAIL' )
                                BEGIN  
                                    SELECT  AUTOID AS bodyautoid ,
                                            '' AS selcol ,
                                            cInvAddCode AS cinvaddcode ,
                                            cinvcode ,
                                            cInvName AS cinvname ,
                                            cInvStd AS cinvstd ,
                                            cBatch AS cbatch ,
                                            dprodate ,
                                            dVDate AS dvdate ,
                                            imassdate ,
                                            cComUnitCode AS ccomunitcode ,
                                            cComUnitName AS ccomunitname ,
											 cComUnitName AS cinvm_unit,
                                            CUNITID AS cunitid ,
                                            CUNITNAME AS cunitname ,
                                            fQuantity AS fquantity ,
                                            Fnum AS fnum ,
                                            FCHANGRATE AS fchangrate ,
                                            CITEMCLASS AS citemclass ,
											 CITEMCLASS AS citem_class ,
                                            CITEMCNAME AS citemcname ,
                                            CITEMCODE AS citemcode ,
                                            CITEMNAME AS citemname ,
                                            AUTOID AS autoid ,
                                            CDEFINE22 AS cdefine22 ,
                                            CDEFINE23 AS cdefine23 ,
                                            CDEFINE24 AS cdefine24 ,
                                            CDEFINE25 AS cdefine25 ,
                                            CDEFINE26 AS cdefine26 ,
                                            CDEFINE27 AS cdefine27 ,
                                            CDEFINE28 AS cdefine28 ,
                                            CDEFINE29 AS cdefine29 ,
                                            CDEFINE30 AS cdefine30 ,
                                            CDEFINE31 AS cdefine31 ,
                                            CDEFINE32 AS cdefine32 ,
                                            CDEFINE33 AS cdefine33 ,
                                            CDEFINE34 AS cdefine34 ,
                                            CDEFINE35 AS cdefine35 ,
                                            CDEFINE36 AS cdefine36 ,
                                            CDEFINE37 AS cdefine37 ,
                                            cFree1 AS cfree1 ,
                                            cFree2 AS cfree2 ,
                                            cFree3 AS cfree3 ,
                                            cFree4 AS cfree4 ,
                                            cFree5 AS cfree5 ,
                                            cFree6 AS cfree6 ,
                                            cFree7 AS cfree7 ,
                                            cFree8 AS cfree8 ,
                                            cFree9 AS cfree9 ,
                                            cFree10 AS cfree10 ,
                                            cInvDefine1 AS cinvdefine1 ,
                                            cInvDefine2 AS cinvdefine2 ,
                                            cInvDefine3 AS cinvdefine3 ,
                                            cInvDefine4 AS cinvdefine4 ,
                                            cInvDefine5 AS cinvdefine5 ,
                                            cInvDefine6 AS cinvdefine6 ,
                                            cInvDefine7 AS cinvdefine7 ,
                                            cInvDefine8 AS cinvdefine8 ,
                                            cInvDefine9 AS cinvdefine9 ,
                                            cInvDefine10 AS cinvdefine10 ,
                                            cInvDefine11 AS cinvdefine11 ,
                                            cInvDefine12 AS cinvdefine12 ,
                                            cInvDefine13 AS cinvdefine13 ,
                                            cInvDefine14 AS cinvdefine14 ,
                                            cInvDefine15 AS cinvdefine15 ,
                                            cInvDefine16 AS cinvdefine16 ,
                                            bfree1 ,
                                            bfree2 ,
                                            bfree3 ,
                                            bfree4 ,
                                            bfree5 ,
                                            bfree6 ,
                                            bfree7 ,
                                            bfree8 ,
                                            bfree9 ,
                                            bfree10 ,
                                            cGroupCode AS cgroupcode ,
                                            iGroupType AS igrouptype ,
                                            bService AS bservice ,
                                            binvbatch ,
                                            bserial ,
                                            binvquality ,
                                            bbarcode ,
                                            cwhcode ,
                                            cwhname ,
                                            CORDERCODE AS cordercode ,
                                            IORDERDID AS iorderdid ,
                                            IORDERSEQ AS iorderseq ,
                                            ISOORDERTYPE AS isoordertype ,
                                            cciqbookcode ,
                                            ID AS id ,
                                            iExpiratDateCalcu AS iexpiratdatecalcu ,
                                            cExpirationdate AS cexpirationdate ,
                                            dExpirationdate AS dexpirationdate ,
                                            cBatchProperty1 AS cbatchproperty1 ,
                                            cBatchProperty2 AS cbatchproperty2 ,
                                            cBatchProperty3 AS cbatchproperty3 ,
                                            cBatchProperty4 AS cbatchproperty4 ,
                                            cBatchProperty5 AS cbatchproperty5 ,
                                            cBatchProperty6 AS cbatchproperty6 ,
                                            cBatchProperty7 AS cbatchproperty7 ,
                                            cBatchProperty8 AS cbatchproperty8 ,
                                            cBatchProperty9 AS cbatchproperty9 ,
                                            cBatchProperty10 AS cbatchproperty10 ,
                                            cservicecode ,
                                            '' AS cfactorycode ,
                                            '' AS cfactoryname
                                    FROM    ( SELECT    *
                                              FROM      ( SELECT
                                                              N'' AS selcol ,
                                                              QMREJECTVOUCHER.CREJECTCODE ,
                                                              CONVERT(VARCHAR(100), QMREJECTVOUCHER.DCHECKDATE, 23) AS dDate ,
                                                              QMREJECTVOUCHER.CCHECKCODE ,
                                                              QMREJECTVOUCHER.CCHECKPERSON AS cCheckPersoncode ,
                                                              Person.cPersonName AS cCheckPersonName ,
                                                              ( CASE ISNULL(QMREJECTVOUCHER.CSOURCEPROORDERCODE,
                                                              '')
                                                              WHEN ''
                                                              THEN QMREJECTVOUCHER.SOURCECODE
                                                              ELSE QMREJECTVOUCHER.CSOURCEPROORDERCODE
                                                              END ) AS SourceCode ,
                                                              QMREJECTVOUCHER.CPROBATCH ,
                                                              ( CASE ISNULL(QMREJECTVOUCHER.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN QMREJECTVOUCHER.CINSPECTDEPCODE
                                                              ELSE mom_orderdetail.MDeptCode
                                                              END ) AS cinspectdepcode ,
                                                              Department.cDepName AS cinspectdepname ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN ( CASE
                                                              WHEN ISNULL(mom_orderdetail.SfcFlag,
                                                              0) = 0
                                                              THEN mom_orderdetail.Remark
                                                              ELSE B.Remark
                                                              END )
                                                              ELSE ( CASE
                                                              WHEN ISNULL(A.SfcFlag,
                                                              0) = 0
                                                              THEN A.Remark
                                                              ELSE C.Remark
                                                              END )
                                                              END ) AS cmemo ,
                                                              QMREJECTVOUCHER.CDEFINE1 ,
                                                              QMREJECTVOUCHER.CDEFINE2 ,
                                                              QMREJECTVOUCHER.CDEFINE3 ,
                                                              QMREJECTVOUCHER.CDEFINE4 ,
                                                              QMREJECTVOUCHER.CDEFINE5 ,
                                                              QMREJECTVOUCHER.CDEFINE6 ,
                                                              QMREJECTVOUCHER.CDEFINE7 ,
                                                              QMREJECTVOUCHER.CDEFINE8 ,
                                                              QMREJECTVOUCHER.CDEFINE9 ,
                                                              QMREJECTVOUCHER.CDEFINE10 ,
                                                              QMREJECTVOUCHER.CDEFINE11 ,
                                                              QMREJECTVOUCHER.CDEFINE12 ,
                                                              QMREJECTVOUCHER.CDEFINE13 ,
                                                              QMREJECTVOUCHER.CDEFINE14 ,
                                                              QMREJECTVOUCHER.CDEFINE15 ,
                                                              QMREJECTVOUCHER.CDEFINE16 ,
                                                              QMREJECTVOUCHERS.CDIMINVCODE AS cinvcode ,
                                                              Inventory.cInvAddCode AS cInvAddCode ,
                                                              Inventory.cInvName AS cInvName ,
                                                              Inventory.cInvStd AS cInvStd ,
                                                              cInvDefine1 ,
                                                              cInvDefine2 ,
                                                              cInvDefine3 ,
                                                              cInvDefine4 ,
                                                              cInvDefine5 ,
                                                              cInvDefine6 ,
                                                              cInvDefine7 ,
                                                              cInvDefine8 ,
                                                              cInvDefine9 ,
                                                              cInvDefine10 ,
                                                              cInvDefine11 ,
                                                              cInvDefine12 ,
                                                              cInvDefine13 ,
                                                              cInvDefine14 ,
                                                              cInvDefine15 ,
                                                              cInvDefine16 ,
                                                              QMREJECTVOUCHERS.CFREE1 AS cFree1 ,
                                                              QMREJECTVOUCHERS.CFREE2 AS cFree2 ,
                                                              QMREJECTVOUCHERS.CFREE3 AS cFree3 ,
                                                              QMREJECTVOUCHERS.CFREE4 AS cFree4 ,
                                                              QMREJECTVOUCHERS.CFREE5 AS cFree5 ,
                                                              QMREJECTVOUCHERS.CFREE6 AS cFree6 ,
                                                              QMREJECTVOUCHERS.CFREE7 AS cFree7 ,
                                                              QMREJECTVOUCHERS.CFREE8 AS cFree8 ,
                                                              QMREJECTVOUCHERS.CFREE9 AS cFree9 ,
                                                              QMREJECTVOUCHERS.CFREE10 AS cFree10 ,
                                                              ( CASE ISNULL(Inventory.bInvBatch,
                                                              0)
                                                              WHEN 0 THEN NULL
                                                              ELSE QMREJECTVOUCHERS.CDIMBATCH
                                                              END ) AS cBatch ,
                                                              ( CASE
                                                              WHEN ( ISNULL(Inventory.bInvBatch,
                                                              0) <> 0
                                                              AND ISNULL(Inventory.cMassUnit,
                                                              N'') <> N''
                                                              )
                                                              THEN QMREJECTVOUCHER.DPRODATE
                                                              ELSE NULL
                                                              END ) AS dprodate ,
                                                              IDIMMASSDATE AS imassdate ,
                                                              ( CASE ISNULL(Inventory.bInvQuality,
                                                              0)
                                                              WHEN 0 THEN NULL
                                                              ELSE QMREJECTVOUCHERS.DDIMVDATE
                                                              END ) AS dVDate ,
                                                              QMREJECTVOUCHERS.iDIMExpiratDateCalcu AS iExpiratDateCalcu ,
                                                              QMREJECTVOUCHERS.cDIMExpirationdate AS cExpirationdate ,
                                                              QMREJECTVOUCHERS.dDIMExpirationdate AS dExpirationdate ,
                                                              ComputationUnit.cComUnitName ,
                                                              ComputationUnit1.cComUnitName AS CUNITNAME ,
                                                              QMREJECTVOUCHERS.FDIMCHANGRATE AS FCHANGRATE ,
                                                              ( ISNULL(QMREJECTVOUCHERS.FDIMQUANTITY,
                                                              0) ) AS fQuantity ,
                                                              ( ISNULL(QMREJECTVOUCHERS.FDIMNUM,
                                                              0) ) AS Fnum ,
                                                              QMREJECTVOUCHERS.CDEFINE22 ,
                                                              QMREJECTVOUCHERS.CDEFINE23 ,
                                                              QMREJECTVOUCHERS.CDEFINE24 ,
                                                              QMREJECTVOUCHERS.CDEFINE25 ,
                                                              QMREJECTVOUCHERS.CDEFINE26 ,
                                                              QMREJECTVOUCHERS.CDEFINE27 ,
                                                              QMREJECTVOUCHERS.CDEFINE28 ,
                                                              QMREJECTVOUCHERS.CDEFINE29 ,
                                                              QMREJECTVOUCHERS.CDEFINE30 ,
                                                              QMREJECTVOUCHERS.CDEFINE31 ,
                                                              QMREJECTVOUCHERS.CDEFINE32 ,
                                                              QMREJECTVOUCHERS.CDEFINE33 ,
                                                              QMREJECTVOUCHERS.CDEFINE34 ,
                                                              QMREJECTVOUCHERS.CDEFINE35 ,
                                                              QMREJECTVOUCHERS.CDEFINE36 ,
                                                              QMREJECTVOUCHERS.CDEFINE37 ,
                                                              QMREJECTVOUCHERS.AUTOID ,
                                                              QMREJECTVOUCHERS.ID ,
                                                              ( CASE ISNULL(QMREJECTVOUCHER.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN QMREJECTVOUCHER.SOURCEAUTOID
                                                              ELSE QMREJECTVOUCHER.ISOURCEPROORDERAUTOID
                                                              END ) AS SourceAutoID ,
                                                              Inventory.cComUnitCode ,
                                                              QMREJECTVOUCHERS.CDIMUNITID AS CUNITID ,
                                                              QMREJECTVOUCHER.CITEMCLASS ,
                                                              QMREJECTVOUCHER.CITEMCNAME ,
                                                              QMREJECTVOUCHER.CITEMCODE ,
                                                              QMREJECTVOUCHER.CITEMNAME ,
                                                              QMREJECTVOUCHER.CHECKID ,
                                                              bFree1 AS bfree1 ,
                                                              bFree2 AS bfree2 ,
                                                              bFree3 AS bfree3 ,
                                                              bFree4 AS bfree4 ,
                                                              bFree5 AS bfree5 ,
                                                              bFree6 AS bfree6 ,
                                                              bFree7 AS bfree7 ,
                                                              bFree8 AS bfree8 ,
                                                              bFree9 AS bfree9 ,
                                                              bFree10 AS bfree10 ,  
                                                              --( CASE  
                                                              --WHEN bFree1 = 1  
                                                              --THEN N'是'  
                                                              --ELSE N'否'  
                                                              --END ) AS bfree1 ,  
                                                              --( CASE  
                                                              --WHEN bFree2 = 1  
                                                              --THEN N'是'  
                                                              --ELSE N'否'  
                                                              --END ) AS bfree2 ,  
                                                              --( CASE  
                                                              --WHEN bFree3 = 1  
                                                              --THEN N'是'  
                                                              --ELSE N'否'  
                                                              --END ) AS bfree3 ,  
                                                              --( CASE  
                                                              --WHEN bFree4 = 1  
                                                              --THEN N'是'  
                                                              --ELSE N'否'  
                                                              --END ) AS bfree4 ,  
                                                              --( CASE  
                                                              --WHEN bFree5 = 1  
                                                              --THEN N'是'  
                                                              --ELSE N'否'  
                                                              --END ) AS bfree5 ,  
                                                              --( CASE  
                                                              --WHEN bFree6 = 1  
                                                              --THEN N'是'  
                                                              --ELSE N'否'  
                                     --END ) AS bfree6 ,  
                                                              --( CASE  
                                                              --WHEN bFree7 = 1  
                                                              --THEN N'是'  
                                                              --ELSE N'否'  
                                                              --END ) AS bfree7 ,  
                                                              --( CASE  
                                                              --WHEN bFree8 = 1  
                                                              --THEN N'是'  
                                                              --ELSE N'否'  
                                                              --END ) AS bfree8 ,  
                                                              --( CASE  
                                                              --WHEN bFree9 = 1  
                                                              --THEN N'是'  
                                                              --ELSE N'否'  
                                                              --END ) AS bfree9 ,  
                                                              --( CASE  
                                                              --WHEN bFree10 = 1  
                                                              --THEN N'是'  
                                                              --ELSE N'否'  
                                                              --END ) AS bfree10 ,  
                                                              Inventory.cGroupCode ,
                                                              iGroupType ,  
                                --( CASE WHEN bService = 1 THEN N'是'  
                                --       ELSE N'否'  
                                --  END ) AS bservice ,  
                                --( CASE WHEN Inventory.bInvBatch = 1 THEN N'是'  
                                --       ELSE N'否'  
                                --  END ) AS binvbatch ,  
                                                              bService ,
                                                              Inventory.bInvBatch AS binvbatch ,
                                                              Inventory.bInvQuality AS binvquality ,
                                                              Inventory.bSerial AS bserial ,
                                                              Inventory.bBarCode AS bbarcode ,
                                                              CONVERT(CHAR, CONVERT(MONEY, QMREJECTVOUCHER.UFTS), 2) AS ufts ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN E.WcCode
                                                              ELSE F.WcCode
                                                              END ) AS cMWorkCenterCode ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN E.Description
                                                              ELSE F.Description
                                                              END ) AS cMWorkCenter ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN B.OpSeq
                                                              ELSE C.OpSeq
                                                              END ) AS iOpSeq ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN B.Description
                                                              ELSE C.Description
                                                              END ) AS cOpDesc ,
                                                              ( CASE ISNULL(dbo.QMREJECTVOUCHER.ISOURCEPROORDERROWNO,
                                                              0)
                                                              WHEN 0
                                                              THEN dbo.QMREJECTVOUCHER.IPROORDERAUTOID
                                                              ELSE dbo.QMREJECTVOUCHER.ISOURCEPROORDERROWNO
                                                              END ) AS imoseq ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.OrderDId
                                                              ELSE A.OrderDId
                                                              END ) AS IORDERDID ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.OrderType
                                                              ELSE A.OrderType
                                                              END ) AS ISOORDERTYPE ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.OrderCode
                                                              ELSE A.OrderCode
                                                              END ) AS CORDERCODE ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.OrderSeq
                                                              ELSE A.OrderSeq
                                                              END ) AS IORDERSEQ ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.ManualCode
                                                              ELSE A.ManualCode
                                                              END ) AS cciqbookcode ,
                                                              ( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.SourceSvcCode
                                                              ELSE ( CASE
                                                              WHEN mom_moallocate.QmFlag = 1
                                                              THEN mom_orderdetail.SourceSvcCode
                                                              ELSE NULL
                                                              END )
                                                              END ) AS cservicecode ,
                                                              QMREJECTVOUCHERS.CBWHCODE AS cwhcode ,
                                                              Warehouse.cWhName AS cwhname ,
                                                              QMREJECTVOUCHER.CWHCODE AS csourcewhcode ,
                                                              sourcewarehouse.cWhName AS csourcewhname ,
                                                              0 AS iordertype ,
                                                              CAST('' AS NVARCHAR(100)) AS csocode ,
                                                              CAST('' AS NVARCHAR(50)) AS iSoDID ,
                                                              CAST(NULL AS INT) AS isoseq ,
                                                              ( CASE ISNULL(QMREJECTVOUCHER.CBYPRODUCT,
                                                              0)
                                                              WHEN 0 THEN N'否'
                                                              ELSE N'是'
                                                              END ) AS bRelated ,
                                                              QMREJECTVOUCHER.cBatchProperty1 ,
                                                              QMREJECTVOUCHER.cBatchProperty2 ,
                                                              QMREJECTVOUCHER.cBatchProperty3 ,
                                                              QMREJECTVOUCHER.cBatchProperty4 ,
                                                              QMREJECTVOUCHER.cBatchProperty5 ,
                                                              QMREJECTVOUCHER.cBatchProperty6 ,
                                                              QMREJECTVOUCHER.cBatchProperty7 ,
                                                              QMREJECTVOUCHER.cBatchProperty8 ,
                                                              QMREJECTVOUCHER.cBatchProperty9 ,
                                                              QMREJECTVOUCHER.cBatchProperty10 ,
                                                              Inventory.iId ,
                                                              ( CASE QMREJECTVOUCHERS.CDIMMASSUNIT
                                                              WHEN 1 THEN N'年'
                                                              WHEN 2 THEN N'月'
                                                              WHEN 3 THEN N'日'
                                                              ELSE N''
                                                              END ) AS cmassunit ,
                                                              QMREJECTVOUCHER.CMAKER ,
                                                              QMREJECTVOUCHER.CSYSBARCODE ,
                                                              QMREJECTVOUCHERS.CBSYSBARCODE ,
                                                              '' AS  cfactorycode ,
                                                              '' AS cFactoryName
                                                          FROM
                                                              QMREJECTVOUCHER
                                                              WITH ( NOLOCK )
                                                              INNER JOIN QMREJECTVOUCHERS ON QMREJECTVOUCHER.ID = QMREJECTVOUCHERS.ID
                                                              INNER JOIN Inventory ON QMREJECTVOUCHERS.CDIMINVCODE = Inventory.cInvCode
                                                              LEFT JOIN Person ON QMREJECTVOUCHER.CCHECKPERSON = Person.cPersonCode
                                                              LEFT JOIN ComputationUnit ON Inventory.cComUnitCode = ComputationUnit.cComunitCode
                                                              LEFT JOIN ComputationUnit
                                                              AS ComputationUnit1 ON QMREJECTVOUCHERS.CDIMUNITID = ComputationUnit1.cComunitCode
                                                              LEFT JOIN Warehouse ON QMREJECTVOUCHERS.CBWHCODE = Warehouse.cWhCode
                                                              LEFT JOIN Warehouse sourcewarehouse ON QMREJECTVOUCHER.CWHCODE = sourcewarehouse.cWhCode
                                                              LEFT JOIN dbo.mom_orderdetail ON ( CASE ISNULL(QMREJECTVOUCHER.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN QMREJECTVOUCHER.SOURCEAUTOID
                                                              ELSE QMREJECTVOUCHER.ISOURCEPROORDERAUTOID
                                                              END ) = dbo.mom_orderdetail.MoDId
                                                              AND ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              LEFT OUTER JOIN sfc_morouting D ON D.MoDId = mom_orderdetail.MoDId
                                                              LEFT JOIN sfc_moroutingdetail B ON B.MoRoutingId = D.MoRoutingId
                                                              AND B.LastFlag = 1
                                                              LEFT OUTER JOIN sfc_workcenter E ON E.WcId = B.WcId
                                                              LEFT JOIN mom_moallocate ON mom_moallocate.AllocateId = dbo.QMREJECTVOUCHER.SOURCEAUTOID
                                                              AND ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 1
                                                              LEFT JOIN dbo.mom_orderdetail A ON A.MoDId = mom_moallocate.MoDId
                                                              LEFT OUTER JOIN sfc_morouting ON sfc_morouting.MoDId = A.MoDId
                                                              LEFT OUTER JOIN sfc_moroutingdetail C ON C.MoRoutingId = sfc_morouting.MoRoutingId
                                                              AND mom_moallocate.OpSeq = C.OpSeq
                                                              LEFT OUTER JOIN sfc_workcenter F ON F.WcId = C.WcId
                                                              LEFT JOIN Department ON ( CASE ISNULL(QMREJECTVOUCHER.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN QMREJECTVOUCHER.CINSPECTDEPCODE
                                                              ELSE mom_orderdetail.MDeptCode
                                                              END ) = Department.cDepCode
                                                              --LEFT JOIN Factory ON Factory.cFactoryCode = mom_orderdetail.FactoryCode
                                                          WHERE
                                                               ISNULL(QMREJECTVOUCHER.CVERIFIER,
                                                              N'') <> N''
                                                              AND ISNULL(QMREJECTVOUCHERS.BFLAG,
                                                              0) = 0
                                                              AND QMREJECTVOUCHERS.IDISPOSEFLOW = 2
                                                              AND QMREJECTVOUCHER.CVOUCHTYPE = N'QM06'
                                                              AND ( ( ISNULL(( CASE
                                                              WHEN ISNULL(dbo.QMREJECTVOUCHER.CBYPRODUCT,
                                                              0) = 0
                                                              THEN mom_orderdetail.Status
                                                              ELSE A.Status
                                                              END ), 0) = 3
                                                              AND ISNULL(( CASE ISNULL(QMREJECTVOUCHER.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN QMREJECTVOUCHER.SOURCEAUTOID
                                                              ELSE QMREJECTVOUCHER.ISOURCEPROORDERAUTOID
                                                              END ), 0) <> 0
                                                              )
                                                              OR ISNULL(( CASE ISNULL(QMREJECTVOUCHER.ISOURCEPROORDERAUTOID,
                                                              0)
                                                              WHEN 0
                                                              THEN QMREJECTVOUCHER.SOURCEAUTOID
                                                              ELSE QMREJECTVOUCHER.ISOURCEPROORDERAUTOID
                                                              END ), 0) = 0
                                                              )
                                                              AND ( ISNULL(QMREJECTVOUCHERS.FDIMQUANTITY,
                                                              0) > 0 )
                                                        ) AS aa
                                            ) AS QMList
                                    WHERE   id IN (
                                            SELECT DISTINCT
                                                    M_ID
                                            FROM    #STPDAPRODUCTINRefCheckIDs1 );  
                                END;  
                        END;  
                    --结束查询检验单内容/不良品处理单  
                      
                    --删除临时表  
                    IF EXISTS ( SELECT  0
                                WHERE   NOT OBJECT_ID('tempdb..#STPDAPRODUCTINRefCheckIDs') IS NULL )
                        DROP TABLE #STPDAPRODUCTINRefCheckIDs;  
                    IF EXISTS ( SELECT  0
                                WHERE   NOT OBJECT_ID('tempdb..#STPDAPRODUCTINRefCheckIDs1') IS NULL )
                        DROP TABLE #STPDAPRODUCTINRefCheckIDs1;  
                    IF EXISTS ( SELECT  0
                                WHERE   NOT OBJECT_ID('tempdb..#STPDATempIDs') IS NULL )
                        DROP TABLE #STPDATempIDs;  
                END;  
            ELSE
                BEGIN  
                    PRINT @OperType;  
                END;  
    END;  
   
