﻿
/*---------------------------------------------------------------------
* 			Copyright (C) 2018 TECHSCAN 版权所有。
*           www.techscan.cn
*┌──────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．　│
*│　版权所有：上海太迅自动识别技术有限公司 　 　　　　　　　　　　　　│
*└──────────────────────────────────┘
*
* 文件名：   proc_ts_ReferVouch_SA_Dispatch_Get.SQL
* 功能：     存储过程
* 描述：     发货/退货单-获取上游可参照单据信息
* 作者：     马永龙
* 创建时间： 2018-08-14 10:50:28
* 文件版本： V1.0.2

===============================版本履历===============================
* Ver 		变更日期 				负责人 	变更内容
* V1.0.0	2018-08-14 10:50:28		Myl		Create（添加OperType=0和OperType=2，参照销售订单）
* V1.0.1	2018-08-15				Myl		添加OperType=1和OperType=5（参照退货申请单）
* V1.0.2	2018-08-16				Myl		添加OperType=3（退货单-参照发货单）
											添加OperType=4（退货单-参照出库单）--这个暂时有点问题，后期再修改  todo
======================================================================
//--------------------------------------------------------------------*/
--proc_ts_ReferVouch_SA_Dispatch_Get '0','detail','bshowclosed:1@@cmaker:demo@@csocode:0000000002'
--proc_ts_ReferVouch_SA_Dispatch_Get '0','detail','bshowclosed:1@@cmaker:demo'
--proc_ts_ReferVouch_SA_Dispatch_Get '2','detail','bshowclosed:0@@cmaker:demo'
--proc_ts_ReferVouch_SA_Dispatch_Get '5','detail','bshowclosed:0@@cmaker:demo'
--proc_ts_ReferVouch_SA_Dispatch_Get '3','detail','bshowclosed:0@@cmaker:demo@@returntype:0'
CREATE PROC [dbo].[proc_ts_ReferVouch_SA_Dispatch_Get]
    (
      @OperType CHAR(1) ,
      --@OperType=0：SA发货单-参照销售订单
	  --@OperType=1：SA发货单-参照退货申请单（做红字发货单）
      --@OperType=2：SA退货单-参照销售订单
      --@OperType=3：SA退货单-参照发货单
      --@OperType=4：SA退货单-参照出库单
      --@OperType=5：SA退货单-参照退货申请单

      --获取类型（'LIST'获取上游参照单据列表;'DETAIL'获取上游参照单据详情（包含表头表体））
      --默认获取上游参照单据列表
      @GetType VARCHAR(10) = N'LIST' ,
      --传入的参数列表字符串
      --默认传空值
      @ParamsList NVARCHAR(2000) = N''
    )
AS
    BEGIN
		--制单人
        DECLARE @cMaker NVARCHAR(30);
        SET @cMaker = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                             N'cMaker',
                                                             DEFAULT, DEFAULT);
                                                              
		--是否参照生产订单（红字）/委外订单（红字）bRed参数
        DECLARE @bRed VARCHAR(1); SET @bRed= N'';
        --SET @bRed = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
        --                                                   N'bRed', DEFAULT,
        --                                                   DEFAULT);
        IF ( @bRed = N'' )
            BEGIN
                SET @bRed = N'0';
            END;
   
        --已经完成的采购订单是否显示(1:显示/0:不显示;默认不显示)
        DECLARE @ShowClosed CHAR(1);
        SET @ShowClosed = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ShowClosed',
                                                              DEFAULT, DEFAULT);
        IF ( @ShowClosed = N'' )
            BEGIN
                SET @ShowClosed = N'0';
            END;
        
        --客户编码
        DECLARE @cCusCode NVARCHAR(20);
        SET @cCusCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cCusCode',
                                                              DEFAULT, DEFAULT);
        --客户名称
        DECLARE @cCusName NVARCHAR(120);
        SET @cCusName = '%'
            + dbo.func_ts_GetParamValueBySplitString(@ParamsList, N'cCusName',
                                                     DEFAULT, DEFAULT) + '%';
        --销售部门编码
        DECLARE @cDepCode NVARCHAR(12);
        SET @cDepCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cDepCode',
                                                              DEFAULT, DEFAULT);    
        --销售部门名称
        DECLARE @cDepName NVARCHAR(255);
        SET @cDepName = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cDepName',
                                                              DEFAULT, DEFAULT);
        --业务员编码
        DECLARE @cPersonCode NVARCHAR(20);
        SET @cPersonCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cPersonCode',
                                                              DEFAULT, DEFAULT);
        --存货编码
        DECLARE @cInvCode NVARCHAR(60);
        SET @cInvCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cInvCode',
                                                              DEFAULT, DEFAULT);
        
        --业务类型
        DECLARE @cBusType NVARCHAR(8);
        SET @cBusType = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cBusType',
                                                              DEFAULT, DEFAULT);
-- 这里暂不设默认值，不然其他业务类型的参照不到 Modified By dxh 190320 
        --IF ( @cBusType = N'' )
        --    SET @cBusType = '普通销售';
        
        DECLARE @ParmList NVARCHAR(MAX);SET @ParmList  = N'';
        DECLARE @SqlCommand NVARCHAR(MAX);SET @ParmList  = N'';
        IF ( @OperType = N'0'--SA发货单参照销售订单
             OR @OperType = N'2'--SA退货单参照销售订单
           )
			--@OperType=0：SA发货单-参照销售订单
			--@OperType=2：SA退货单-参照销售订单
            BEGIN
            --定义查询参数
            
				--订单日期FROM
                DECLARE @SoDateFrom VARCHAR(10);
                SET @SoDateFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'SoDateFrom',
                                                              DEFAULT, DEFAULT);
				--订单日期TO
                DECLARE @SoDateTo VARCHAR(10);
                SET @SoDateTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'SoDateTo',
                                                              DEFAULT, DEFAULT);
                IF ( @SoDateFrom = N'' )
                    SET @SoDateTo = @SoDateFrom;
				--预发货日期FROM
                DECLARE @SoShipDateFrom VARCHAR(10);
                SET @SoShipDateFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'SoShipDateFrom',
                                                              DEFAULT, DEFAULT);
				--预发货日期TO
                DECLARE @SoShipDateTo VARCHAR(10);
                SET @SoShipDateTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'SoShipDateTo',
                                                              DEFAULT, DEFAULT);
                IF ( @SoShipDateTo = N'' )
                    SET @SoShipDateTo = @SoShipDateFrom;

				--订单单号
                DECLARE @cSoCode NVARCHAR(30);
                SET @cSoCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cSoCode',
                                                              DEFAULT, DEFAULT)
                    + '%';

				--销售订单主表ID
                DECLARE @SoIds NVARCHAR(1000);                
                BEGIN
                
                    SET @SoIds = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'SoIds',
                                                              DEFAULT, DEFAULT);
                    IF ( @SoIds <> N'' )
                        BEGIN                             
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDATempSASOIDs') IS NULL )
                                DROP TABLE #STPDATempSASOIDs;
                    
                            CREATE   TABLE #STPDATempSASOIDs ( SoId INT );
                            INSERT  INTO #STPDATempSASOIDs
                                    EXEC proc_ts_SplitParamString @SoIds;
                        END;
                                                              
                END;
                
                --销售订单子表ID
                DECLARE @SoDids NVARCHAR(1000);
                BEGIN
                    SET @SoDids = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'SoDids',
                                                              DEFAULT, DEFAULT);
                    IF ( @SoDids <> N'' )
                        BEGIN                             
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDATempSASODIDs') IS NULL )
                                DROP TABLE #STPDATempSASODIDs;
                    
                            CREATE   TABLE #STPDATempSASODIDs ( SoDid INT );
                            INSERT  INTO #STPDATempSASODIDs
                                    EXEC proc_ts_SplitParamString @SoDids;
                        END;
                END;
                
                SET NOCOUNT ON;
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDARefIDs') IS NULL )
                    DROP TABLE #STPDARefIDs;
                --IF EXISTS ( SELECT  0
                --            WHERE   NOT OBJECT_ID('tempdb..#STPDARefID') IS NULL )
                --    DROP TABLE #STPDARefID;
                    
                SELECT  IDENTITY( INT ) AS identityautoid ,
                        CONVERT(INT, 0) AS id ,
                        CONVERT(INT, 0) AS isosid ,
                        CONVERT(NVARCHAR(50), N'') AS cparentcode
                INTO    #STPDARefIDs
                FROM    sale_RefSOVouch_T WITH ( NOLOCK )
                WHERE   1 = 0; 
                CREATE CLUSTERED INDEX ix_STPDADispatchRefIDs_tmpid_813 ON #STPDARefIDs( id,isosid,identityautoid ); 
                SET @SqlCommand = ' INSERT INTO #STPDARefIDs (id,isosid,cparentcode)
									SELECT sale_RefSOVouch_T.id,sale_RefSOVouch_B.isosid,cparentcode
									FROM sale_RefSOVouch_T WITH ( NOLOCK )
									INNER JOIN sale_RefSOVouch_B WITH ( NOLOCK ) ON sale_RefSOVouch_T.id = sale_RefSOVouch_B.id
									WHERE (( ISNULL(istatus,0) = 1
            AND ISNULL(ccloser, N'''') = N'''' AND ISNULL(cscloser, N'''') = N''''
            AND ( ISNULL(borderbom, N''否'') = N''否'' OR ( ISNULL(borderbom, N''否'') = N''是'' AND ISNULL(borderbomover, 0) = 1 )) ';
                IF ( @OperType = N'0' )
                    BEGIN
                        SET @SqlCommand = @SqlCommand
                            + ' AND ISNULL(csvouchtype, N'''') <> N''EB10'' ';
                    END;
                SET @SqlCommand = @SqlCommand + ' ) AND ( 1 = 1 ';
                IF ( @cMaker <> N'' )
                    SET @SqlCommand = @SqlCommand + ' AND (cmaker=@cMaker) ';
                IF ( @cCusCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (ccuscode = @cCusCode) ';
                IF ( @cCusName <> N''
                     AND @cCusName <> N'%%'
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (ccusname LIKE @cCusName) ';
                IF ( @cDepCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (cdepcode = @cDepCode) ';
                IF ( @cDepName <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (cdepname = @cDepName) ';
                IF ( @SoDateFrom <> N''
                     AND @SoDateTo <> N''
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND ((ddate >= @SoDateFrom)
                            AND (ddate <= @SoDateTo)) ';
                IF ( @SoShipDateFrom <> N''
                     AND @SoShipDateTo <> N''
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND ((sale_RefSOVouch_T.dPreDateBT >= @SoShipDateFrom)
                            AND (sale_RefSOVouch_T.dPreDateBT <= @SoShipDateTo)) ';
                IF ( @cPersonCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (cpersoncode = @cPersonCode) ';
                IF ( @cSoCode <> N''
                     AND @cSoCode <> N'%'
                   )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (sale_RefSOVouch_T.csocode LIKE @cSoCode) '; 
                IF ( @cInvCode <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (cinvcode = @cInvCode) ';
                IF ( @cBusType <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (cbustype = @cBusType) ';
                IF ( @SoIds <> N'' )
                    SET @SqlCommand = @SqlCommand
                        + ' AND (id IN (SELECT DISTINCT SoId FROM #STPDATempSASOIDs)) ';
                IF ( @SoDids <> N'' )
                    BEGIN
                        SET @SqlCommand = @SqlCommand
                            + ' AND (isosid IN (SELECT DISTINCT SoDid FROM #STPDATempSASODIDs)) ';
                    END;
                IF ( @OperType = N'0' )
                    BEGIN
                        --发货单参照销售订单
                        IF ( @ShowClosed = N'0' )
                            BEGIN
						--不显示已经执行完成的订单
                                SET @SqlCommand = @SqlCommand
                                    + '   AND CAST(CASE WHEN ISNULL(iquantity,0) = 0
                                   AND cbustype <> N''直运销售''
                              THEN ABS(ISNULL(isum,0)) - ABS(ISNULL(ifhmoney,0))
                              WHEN ISNULL(iquantity,0) = 0 AND cbustype = N''直运销售''
                              THEN ABS(ISNULL(isum,0)) - ABS(ISNULL(ikpmoney,0))
                              WHEN ISNULL(iquantity,0) <> 0 AND cbustype = N''直运销售''
                              THEN ABS(ISNULL(iquantity,0)) - ABS(ISNULL(ikpquantity,0))
                              WHEN ISNULL(iquantity,0) <> 0 AND cbustype <> N''直运销售''
                              THEN ABS(ISNULL(iquantity,0)) - ABS(ISNULL(ifhquantity,0))
                         END AS DECIMAL(26,9)) > 0)) AND ( ISNULL(cchildcode,N'''') = N'''' ) ';
                            END;
                        ELSE
                            BEGIN
								--显示已经执行完成的订单
                                SET @SqlCommand = @SqlCommand
                                    + ' )) AND (ISNULL(cchildcode,N'''') = N'''' ) ';
                            END;
                    END;
                ELSE
                    BEGIN
                        SET @SqlCommand = @SqlCommand
                            + '  AND (CAST(CASE WHEN cbustype = N''直运销售''
                                THEN ISNULL(iquantity,0) - ISNULL(ikpquantity,0)
                                ELSE ISNULL(iquantity,0) - ISNULL(ifhquantity,0)
                           END AS DECIMAL(26,9)) >= 0
                      OR ISNULL(iquantity,0) = 0 OR itb = N''正常''))) AND (ISNULL(cchildcode,N'''') = N'''' ) ';
                    END;
                
                SET @ParmList = '@cMaker			NVARCHAR(30),
				   @cCusCode			NVARCHAR(20),
				   @cCusName			NVARCHAR(120),
				   @cDepCode			NVARCHAR(12),
				   @cDepName			NVARCHAR(255),
				   @SoDateFrom			VARCHAR(10),
				   @SoDateTo			VARCHAR(10),
				   @SoShipDateFrom		VARCHAR(10),
				   @SoShipDateTo		VARCHAR(10),
				   @cPersonCode			NVARCHAR(20),
				   @cSoCode				NVARCHAR(30),
				   @cInvCode			NVARCHAR(60),
				   @cBusType			NVARCHAR(8)';
                --PRINT @SqlCommand;
                EXEC sp_executesql @SqlCommand, @ParmList, @cMaker = @cMaker,
                    @cCusCode = @cCusCode, @cCusName = @cCusName,
                    @cDepCode = @cDepCode, @cDepName = @cDepName,
                    @SoDateFrom = @SoDateFrom, @SoDateTo = @SoDateTo,
                    @SoShipDateFrom = @SoShipDateFrom,
                    @SoShipDateTo = @SoShipDateTo, @cPersonCode = @cPersonCode,
                    @cSoCode = @cSoCode, @cInvCode = @cInvCode,
                    @cBusType = @cBusType;
                SET NOCOUNT OFF;
                --查询列表（表头）
                SELECT  N'' AS selcol ,

                        ( cmobilephone ) AS cmobilephone ,
                        ( cofficephone ) AS cofficephone ,
                        ( caddcode ) AS caddcode ,
                        ( ccontactname ) AS ccontactname ,
                        ( ccreditcuscode ) AS ccreditcuscode ,
                        ( ccreditcusname ) AS ccreditcusname ,
                        ( cdeliverunit ) AS cdeliverunit ,
                        ( cgatheringplan ) AS cgatheringplan ,
                        ( cgatheringplanname ) AS cgatheringplanname ,
                        ccuswhcode ,
                        cwhname ,
                        ivtid ,
                        ccuspostcode ,
                        ( CONVERT(CHAR, CONVERT(MONEY, ufts), 2) ) AS corufts ,
                        ( 0 ) AS bproxywh ,
                        ccushand ,
                        ccuspersoncode ,
                        cbustype ,
                        ccusaddress ,
                        ccuspaycond ,
                        cstcode ,
                        ccusperson ,
                        cstname ,
                        csocode ,
                        CONVERT(VARCHAR(100), ddate, 23) AS ddate ,
                        cexch_name ,
                        iexchrate ,
                        clocker ,
                        coppcode ,
                        ( cinvoicecusname ) AS cinvoicecusname ,
                        ( cpsnmobilephone ) AS cpsnmobilephone ,
                        ( cpsnophone ) AS cpsnophone ,
                        ( iflowid ) AS iflowid ,
                        ( cflowname ) AS cflowname ,
                        ( cgathingcode ) AS cgathingcode ,
                        ( cebbuyer ) AS cebbuyer ,
                        ( cebbuyernote ) AS cebbuyernote ,
                        ( cebcity ) AS cebcity ,
                        ( cebdistrict ) AS cebdistrict ,
                        ( cebprovince ) AS cebprovince ,
                        ( cebtrnumber ) AS cebtrnumber ,
						'' AS ccuswhfactorycode ,
						'' AS ccuswhfactoryname ,
                        --( ccuswhfactorycode ) AS ccuswhfactorycode ,
                        --( ccuswhfactoryname ) AS ccuswhfactoryname ,
                        ( bcashsale ) AS bcashsale ,
                        ccuscode ,
                        cinvoicecompany ,
                        ccusabbname ,
                        ccusname ,
                        cinvoicecompanyabbname ,
                        ccusoaddress ,
                        ccusphone ,
                        icuscreline ,
                        cdepcode ,
                        cdepname ,
                        cpersoncode ,
                        cpersonname ,
                        cpaycode ,
                        cpayname ,
                        csccode ,
                        csscode ,
                        cssname ,
                        cscname ,
                        cmaker ,
                        cverifier ,
                        cchanger ,
                        ccloser ,
                        ccrechpname ,
                        ( itaxrate ) AS itaxrate ,
                        ( cmemo ) AS cmemo ,
                        cdefine1 ,
                        cdefine2 ,
                        cdefine3 ,
                        cdefine4 ,
                        cdefine5 ,
                        cdefine6 ,
                        cdefine7 ,
                        cdefine8 ,
                        cdefine9 ,
                        cdefine10 ,
                        cdefine11 ,
                        cdefine12 ,
                        cdefine13 ,
                        cdefine14 ,
                        cdefine15 ,
                        cdefine16 ,
                        ccusdefine1 ,
                        ccusdefine2 ,
                        ccusdefine3 ,
                        ccusdefine4 ,
                        ccusdefine5 ,
                        ccusdefine6 ,
                        ccusdefine7 ,
                        ccusdefine8 ,
                        ccusdefine9 ,
                        ccusdefine10 ,
                        ccusdefine11 ,
                        ccusdefine12 ,
                        ccusdefine13 ,
                        ccusdefine14 ,
                        ccusdefine15 ,
                        ccusdefine16 ,
                        cmodifier ,
                        dmoddate ,
                        dverifydate ,
                        dcreatesystime ,
                        dverifysystime ,
                        dmodifysystime ,
                        dPreDateBT AS dpredatebt ,
                        brequestsign ,
                        bmustbook ,
                       '' as  cgcroutecode ,
                        '' as cgcroutename
                FROM    sale_RefSOVouch_T WITH ( NOLOCK )
                        INNER JOIN ( select distinct id from #STPDARefIDs) a  ON a.id = sale_RefSOVouch_T.id
                --WHERE   #STPDARefIDs.identityautoid >= 0
                --        AND #STPDARefIDs.identityautoid <= 0
                ORDER BY sale_RefSOVouch_T.id; 
                 
                --查询表体
                IF ( @GetType = N'DETAIL' )
                    BEGIN
                        SELECT  sale_RefSOVouch_B.isosid AS bodyautoid ,
                                N'' AS selcol ,
                                ( cordercode ) AS cordercode ,
                                ( cordercode ) AS csocode ,
								( cordercode ) AS csrccode,
                                ( iorderrowno ) AS iorderrowno ,
                                ccontractid ,
                                ccontracttagcode ,
                                dtEndDate AS dtenddate ,
                                dtStartDate AS dtstartdate ,
                                cwhcode ,
                                ( N'' ) AS cquocode ,
                                cinvcode ,
                                sale_RefSOVouch_B.cwhname ,
                                cinvaddcode ,
                                cinvname ,
                                cinvstd ,
                                ( ccontractrowguid ) AS ccontractrowguid ,
                                ccusinvcode ,
                                cvenabbname ,
                                ccusinvname ,
                                dpredate ,
                                ( dpremodate ) AS dpremodate ,
                                cinvm_unit ,
                                iquantity ,
                                cgroupcode ,
                                igrouptype ,
                                iinvexchrate ,
                                cunitid ,
                                cinva_unit ,
                                inum ,
                                iquotedprice ,
                                itaxunitprice ,
                                iunitprice ,
                                ( sale_RefSOVouch_B.imoney ) AS imoney ,
                                itax ,
                                imassdate ,
                                ( N'' ) AS cconfigstatus ,
                                cmassunit ,
                                isum ,
                                ( sale_RefSOVouch_B.itaxrate ) AS itaxrate ,
                                inatunitprice ,
                                inatmoney ,
                                cscloser ,
                                inattax ,
                                inatsum ,
                                bsalepricefree1 ,
                                bsalepricefree10 ,
                                bsalepricefree2 ,
                                bsalepricefree3 ,
                                bsalepricefree4 ,
                                bsalepricefree5 ,
                                bsalepricefree6 ,
                                bsalepricefree7 ,
                                bsalepricefree8 ,
                                bsalepricefree9 ,
                                bfree1 ,
                                bfree10 ,
                                bfree2 ,
                                bfree3 ,
                                bfree4 ,
                                bfree5 ,
                                bfree6 ,
                                bfree7 ,
                                bfree8 ,
                                bfree9 ,
                                ( fcusminprice ) AS iinvlscost ,
                                kl ,
                                kl2 ,
                                btracksalebill ,
                                ( N'' ) AS dkl1 ,
                                ( N'' ) AS dkl2 ,
                                itb ,
                                idiscount ,
                                inatdiscount ,
                                fsalecost ,
                                binvquality ,
                                fsaleprice ,
                                ( iexpiratdatecalcu ) AS iexpiratdatecalcu ,
                                ifhquantity ,
								ifhquantity as ireceivedqty,
                                ifhnum ,
                                ifhmoney ,
                                ikpquantity ,
                                ikpnum ,
                                ikpmoney ,
                                imoquantity ,
                                ( iprekeepquantity ) AS iprekeepquantity ,
                                ( iprekeepnum ) AS iprekeepnum ,
                                fcusminprice ,
                                binvtype ,
                                bservice ,
                                ( iprekeeptotquantity ) AS iprekeeptotquantity ,
                                ( iprekeeptotnum ) AS iprekeeptotnum ,
                                ( iquantity ) AS inewquantity ,
                                ( CASE WHEN @OperType = N'0'
                                       THEN ( ISNULL(iquantity, 0)
                                              - ISNULL(ifhquantity, 0) )
                                       ELSE ( CASE WHEN TH.cbustype = N'直运销售'
                                                   THEN ISNULL(ikpquantity, 0)
                                                   ELSE ISNULL(ifhquantity, 0)
                                              END )
                                  END ) AS inquantity ,
                                ( CASE WHEN @OperType = N'0'
                                       THEN ( ISNULL(inum, 0) - ISNULL(ifhnum,
                                                              0) )
                                       ELSE ( CASE WHEN TH.cbustype = N'直运销售'
                                                   THEN ISNULL(ikpnum, 0)
                                                   ELSE ISNULL(ifhnum, 0)
                                              END )
                                  END ) AS innum ,
                                ( inum ) AS inewnum ,
                                ( sale_RefSOVouch_B.imoney ) AS inewmoney ,
                                ( itax ) AS inewtax ,
                                ( isum ) AS inewsum ,
                                ( inatmoney ) AS inewnatmoney ,
                                ( inattax ) AS inewnattax ,
                                ( idiscount ) AS inewdiscount ,
                                ( N'' ) AS corufts ,
                                ( inatdiscount ) AS inewnatdiscount ,
                                ( inatsum ) AS inewnatsum ,
                                ( sale_RefSOVouch_B.cmemo ) AS cmemo ,
                                citem_class ,
                                citem_cname ,
                                btrack ,
                                binvbatch ,
                                citemcode ,
                                citemname ,
                                cfree1 ,
                                cfree2 ,
                                cfree3 ,
                                cfree4 ,
                                cfree5 ,
                                cfree6 ,
                                ( N'' ) AS flossrate ,
                                cfree7 ,
                                cfree8 ,
                                cfree9 ,
                                cfree10 ,
                                ( N'' ) AS frlossqty ,
                                cinvdefine1 ,
                                cinvdefine2 ,
                                cinvdefine3 ,
                                cinvdefine4 ,
                                cinvdefine6 ,
                                cinvdefine5 ,
                                cinvdefine7 ,
                                cinvdefine8 ,
                                cinvdefine9 ,
                                cinvdefine10 ,
                                cinvdefine11 ,
                                cinvdefine12 ,
                                cinvdefine13 ,
                                cinvdefine14 ,
                                cinvdefine15 ,
                                cinvdefine16 ,
                                ( N'否' ) AS bqaneedcheck ,
                                ( N'否' ) AS bqaurgency ,
                                sale_RefSOVouch_B.bproxywh ,
                                cdefine22 ,
                                cdefine23 ,
                                cdefine24 ,
                                cdefine25 ,
                                cdefine26 ,
                                cdefine27 ,
                                cdefine28 ,
                                cdefine29 ,
                                cdefine30 ,
                                cdefine31 ,
                                cdefine32 ,
                                ( bgsp ) AS bgsp ,
                                cdefine33 ,
                                cdefine34 ,
                                cdefine35 ,
                                cdefine36 ,
                                cdefine37 ,
                                csrpolicy ,
                                icusbomid ,
                                sale_RefSOVouch_B.isosid ,
                                ( dreleasedate ) AS dreleasedate ,
                                ( sale_RefSOVouch_B.id ) AS id ,
                                ( N'' ) AS bneedsign ,
                                body_outid ,
                                iinvweight ,
                                idemandseq ,
                                idemandtype ,
                                cdemandcode ,
                                cdemandid ,
                                  ( case when isnull(idemandtype,'')='' then sale_RefSOVouch_B.csocode else  cdemandcode end )  cdemandcode ,
                                irowno ,
                                ( ippartid ) AS ippartid ,
                                ( ippartqty ) AS ippartqty ,
                                ( cfactorycode ) AS cfactorycode ,
                                ( cfactoryname ) AS cfactoryname ,
                                ( bptomodel ) AS bptomodel ,
                                ( binvmodel ) AS binvmodel ,
                                ( 0 ) AS bmpforderclosed ,
                                bgift ,
                                ( cchildcode ) AS cchildcode ,
                                bsaleprice ,
                                ( bserial ) AS bserial ,
                                ( icalctype ) AS icalctype ,
                                ( fchildqty ) AS fchildqty ,
                                ( fchildrate ) AS fchildrate ,
                                ( cvencode ) AS cvencode ,
                                ( sale_RefSOVouch_B.cparentcode ) AS cparentcode ,
                                fpurquan ,
                                gcsourceid ,
                                gcsourceids ,
                                cdetailsdemandcode ,
                                cdetailsdemandmemo ,
                                0.0 AS iscanedquantity ,
                                0.0 AS iscanednum
                        FROM    sale_RefSOVouch_B WITH ( NOLOCK )
                                INNER JOIN #STPDARefIDs ON sale_RefSOVouch_B.isosid = #STPDARefIDs.isosid
                                INNER JOIN sale_RefSOVouch_T TH ON sale_RefSOVouch_B.id = TH.id
                        ORDER BY identityautoid ,
                                sale_RefSOVouch_B.id DESC ,
                                sale_RefSOVouch_B.isosid ,
                                sale_RefSOVouch_B.autoid;
                    END;
                --删除临时表
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDARefIDs') IS NULL )
                    DROP TABLE #STPDARefIDs;
                --IF EXISTS ( SELECT  0
                --            WHERE   NOT OBJECT_ID('tempdb..#STPDARefID') IS NULL )
                --    DROP TABLE #STPDARefID;
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempSASOIDs') IS NULL )
                    DROP TABLE #STPDATempSASOIDs;
                IF EXISTS ( SELECT  0
                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempSASODIDs') IS NULL )
                    DROP TABLE #STPDATempSASODIDs;
            END;
       
        ELSE
            IF ( @OperType = N'1'
                 OR @OperType = N'5'
               )
                BEGIN
					--退货申请单日期FROM
                    DECLARE @ReturnApplyDateFrom VARCHAR(10);
                    SET @ReturnApplyDateFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dDateFrom',
                                                              DEFAULT, DEFAULT);
					--退货申请单日期TO
                    DECLARE @ReturnApplyDateTo VARCHAR(10);
                    SET @ReturnApplyDateTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dDateTo',
                                                              DEFAULT, DEFAULT);
                    IF ( @ReturnApplyDateFrom = N'' )
                        SET @ReturnApplyDateTo = @ReturnApplyDateFrom;
					--退货申请单单号From
                    DECLARE @ReturnApplyCodeFrom NVARCHAR(30);
                    SET @ReturnApplyCodeFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cCodeFrom',
                                                              DEFAULT, DEFAULT);
                    --退货申请单单号To
                    DECLARE @ReturnApplyCodeTo NVARCHAR(30);
                    SET @ReturnApplyCodeTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cCodeTo',
                                                              DEFAULT, DEFAULT);
                    IF ( @ReturnApplyCodeTo = N'' )
                        SET @ReturnApplyCodeTo = @ReturnApplyCodeFrom;
                
					--退货原因
                    DECLARE @ReturnReason NVARCHAR(30);
                    SET @ReturnReason = N'%'
                        + dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ReturnReason',
                                                              DEFAULT, DEFAULT)
                        + N'%';
					--退货申请单主表ID
                    DECLARE @ApplyIds NVARCHAR(1000);                
                    BEGIN
                
                        SET @ApplyIds = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ApplyIds',
                                                              DEFAULT, DEFAULT);
                        IF ( @ApplyIds <> N'' )
                            BEGIN                             
                                IF EXISTS ( SELECT  0
                                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempApplyIDs') IS NULL )
                                    DROP TABLE #STPDATempApplyIDs;
                    
                                CREATE   TABLE #STPDATempApplyIDs ( ApplyId
                                                              INT );
                                INSERT  INTO #STPDATempApplyIDs
                                        EXEC proc_ts_SplitParamString @ApplyIds;
                            END;
                                                              
                    END;
                
					--退货申请单子表ID
                    DECLARE @ApplyDids NVARCHAR(1000);
                    BEGIN
                        SET @ApplyDids = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ApplyDids',
                                                              DEFAULT, DEFAULT);
                        IF ( @ApplyDids <> N'' )
                            BEGIN                             
                                IF EXISTS ( SELECT  0
                                            WHERE   NOT OBJECT_ID('tempdb..#STPDATempApplyDIDs') IS NULL )
                                    DROP TABLE #STPDATempApplyDIDs;
                    
                                CREATE   TABLE #STPDATempApplyDIDs ( ApplyDid
                                                              INT );
                                INSERT  INTO #STPDATempApplyDIDs
                                        EXEC proc_ts_SplitParamString @ApplyDids;
                            END;
                    END;
                
                    SET NOCOUNT ON;
                    IF EXISTS ( SELECT  0
                                WHERE   NOT OBJECT_ID('tempdb..#STPDAApplyRefIDs') IS NULL )
                        DROP TABLE #STPDAApplyRefIDs;
                --IF EXISTS ( SELECT  0
                --            WHERE   NOT OBJECT_ID('tempdb..#STPDARefID') IS NULL )
                --    DROP TABLE #STPDARefID;
                    
                    SELECT  IDENTITY( INT ) AS identityautoid ,
                            CONVERT(INT, 0) AS id ,
                            CONVERT(INT, 0) AS autoid
                    INTO    #STPDAApplyRefIDs
                    FROM    SA_ReturnsApplyMainView WITH ( NOLOCK )
                    WHERE   1 = 0; 
                    CREATE CLUSTERED INDEX ix_STPDAApplyRefIDs_tmpid_813 ON #STPDAApplyRefIDs( id,autoid,identityautoid ); 
                    SET @SqlCommand = 'INSERT INTO #STPDAApplyRefIDs (id,autoid)
									  SELECT SA_ReturnsApplyMainView.id,SA_ReturnsApplyDetailView.autoid 
									  FROM SA_ReturnsApplyMainView WITH ( NOLOCK )
        INNER JOIN SA_ReturnsApplyDetailView WITH ( NOLOCK ) ON SA_ReturnsApplyMainView.id = SA_ReturnsApplyDetailView.id 
        WHERE ( ISNULL(ccloser, N'''') = N'''' AND ISNULL(cscloser, N'''') = N'''' AND ISNULL(cverifier, N'''') <> N''''
          AND ISNULL(cchildcode, N'''') = N'''' AND ISNULL(bneedbill, 0) = 1
          AND ( CASE WHEN ISNULL(iquantity, 0) = 0 THEN ABS(ISNULL(isum,0)) - ABS(ISNULL(fretsum,0))
        ELSE ABS(ISNULL(iquantity,0)) - ABS(ISNULL(fretqty,0)) END ) > 0 ) AND ( 1 = 1 ';
                    IF ( @OperType = N'1' )
                        BEGIN
                            SET @SqlCommand = @SqlCommand
                                + ' AND ISNULL(icorid, 0) = 0 ';
                        END;
                    ELSE
                        BEGIN
                            SET @SqlCommand = @SqlCommand
                                + ' AND ((ISNULL(iappquantity,0) < 0 OR ISNULL(iappnum,0) < 0)
                    OR ( ISNULL(iappquantity,0) = 0 AND ISNULL(isum,0) < 0)
                    OR ( ISNULL(iappnum,0) = 0 AND ISNULL(isum,0) < 0))';
                        END;
        
                    IF ( @cMaker <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (cmaker=@cMaker) ';
                    IF ( @cCusCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (ccuscode = @cCusCode) ';
                    IF ( @cCusName <> N''
                         AND @cCusName <> N'%%'
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (ccusname LIKE @cCusName) ';
                    IF ( @cDepCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (cdepcode = @cDepCode) ';
                    IF ( @cDepName <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (cdepname = @cDepName) ';
                    IF ( @ReturnApplyDateFrom <> N''
                         AND @ReturnApplyDateTo <> N''
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND ((ddate >= @ReturnApplyDateFrom)
                            AND (ddate <= @ReturnApplyDateTo)) ';       
                    IF ( @ReturnApplyCodeFrom <> N''
                         AND @ReturnApplyCodeTo <> N''
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND ((ccode >= @ReturnApplyCodeFrom)
                            AND (ccode <= @ReturnApplyCodeTo)) ';
                    IF ( @cInvCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (cinvcode = @cInvCode) ';
                    IF ( @cBusType <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (cbustype = @cBusType) ';
                    IF ( @cPersonCode <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (cpersoncode = @cPersonCode) ';
                    IF ( @ReturnReason <> N''
                         AND @ReturnReason <> N'%%'
                       )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (creasonname LIKE @ReturnReason) '; 
                    IF ( @ApplyIds <> N'' )
                        SET @SqlCommand = @SqlCommand
                            + ' AND (SA_ReturnsApplyMainView.id IN (SELECT DISTINCT ApplyId FROM #STPDATempApplyIDs)) ';
                    IF ( @ApplyDids <> N'' )
                        BEGIN
                            SET @SqlCommand = @SqlCommand
                                + ' AND (SA_ReturnsApplyDetailView.autoid IN (SELECT DISTINCT ApplyDid FROM #STPDATempApplyDIDs)) ';
                        END;
                  
                    SET @SqlCommand = @SqlCommand
                        + '  AND (ISNULL(iflowid,0) = 0 )) ';
                  
                    SET @ParmList = '@cMaker					NVARCHAR(30),
									   @cCusCode				NVARCHAR(20),
									   @cCusName				NVARCHAR(120),
									   @cDepCode				NVARCHAR(12),
									   @cDepName				NVARCHAR(255),
									   @ReturnApplyDateFrom		VARCHAR(10),
									   @ReturnApplyDateTo		VARCHAR(10),
									   @ReturnApplyCodeFrom		VARCHAR(10),
									   @ReturnApplyCodeTo		VARCHAR(10),
									   @cPersonCode				NVARCHAR(20),
									   @ReturnReason			NVARCHAR(30),
									   @cInvCode				NVARCHAR(60),
									   @cBusType				NVARCHAR(8)';
					--PRINT @SqlCommand;
                    EXEC sp_executesql @SqlCommand, @ParmList,
                        @cMaker = @cMaker, @cCusCode = @cCusCode,
                        @cCusName = @cCusName, @cDepCode = @cDepCode,
                        @cDepName = @cDepName,
                        @ReturnApplyDateFrom = @ReturnApplyDateFrom,
                        @ReturnApplyDateTo = @ReturnApplyDateTo,
                        @ReturnApplyCodeFrom = @ReturnApplyCodeFrom,
                        @ReturnApplyCodeTo = @ReturnApplyCodeTo,
                        @cPersonCode = @cPersonCode,
                        @ReturnReason = @ReturnReason, @cInvCode = @cInvCode,
                        @cBusType = @cBusType;
                    SET NOCOUNT OFF;
					--查询列表（表头）
                    SELECT  N'' AS selcol ,
                            ( SA_ReturnsApplyMainView.id ) AS id ,
                            ( caddcode ) AS caddcode ,
                            ( ccontactname ) AS ccontactname ,
                            ( cdeliverunit ) AS cdeliverunit ,
                            ( cgatheringplan ) AS cgatheringplan ,
                            ( cgatheringplanname ) AS cgatheringplanname ,
                            ( cofficephone ) AS cofficephone ,
                            ( cmobilephone ) AS cmobilephone ,
                            ivtid ,
                            ( CONVERT(CHAR, CONVERT(MONEY, ufts), 2) ) AS corufts ,
                            ccushand ,
                            ccuspersoncode ,
                            cbustype ,
                            ccusaddress ,
                            cstcode ,
                            ccusperson ,
                            cstname ,
                            ccode ,
                            CONVERT(VARCHAR(100), ddate, 23) AS ddate ,
                            cexch_name ,
                            iexchrate ,
                            ( iflowid ) AS iflowid ,
                            ( cpsnmobilephone ) AS cpsnmobilephone ,
                            ( cpsnophone ) AS cpsnophone ,
                            ( cflowname ) AS cflowname ,
                            ( cebcity ) AS cebcity ,
                            ( cebdistrict ) AS cebdistrict ,
                            ( cebprovince ) AS cebprovince ,
                            ( bcashsale ) AS bcashsale ,
                            ccuscode ,
                            ccusabbname ,
                            ccusname ,
                            ccusoaddress ,
                            cshipaddress ,
                            ccusphone ,
                            ccuspostcode ,
                            ccuspaycond ,
                            cdepcode ,
                            cdepname ,
                            cpersoncode ,
                            cpersonname ,
                            cpaycode ,
                            cpayname ,
                            csscode ,
                            csccode ,
                            cscname ,
                            cssname ,
                            cmaker ,
                            cverifier ,
                            ccloser ,
                            ( itaxrate ) AS itaxrate ,
                            ( cmemo ) AS cmemo ,
                            cdefine1 ,
                            cdefine2 ,
                            cdefine3 ,
                            cdefine4 ,
                            cdefine5 ,
                            cdefine6 ,
                            cdefine7 ,
                            cdefine8 ,
                            cdefine9 ,
                            cdefine10 ,
                            cdefine11 ,
                            cdefine12 ,
                            cdefine13 ,
                            cdefine14 ,
                            cdefine15 ,
                            cdefine16 ,
                            ccusdefine1 ,
                            ccusdefine2 ,
                            ccusdefine3 ,
                            ccusdefine4 ,
                            ccusdefine5 ,
                            ccusdefine6 ,
                            ccusdefine7 ,
                            ccusdefine8 ,
                            ccusdefine9 ,
                            ccusdefine10 ,
                            ccusdefine11 ,
                            ccusdefine12 ,
                            ccusdefine13 ,
                            ccusdefine14 ,
                            ccusdefine15 ,
                            ccusdefine16 ,
                            brequestsign ,
                            cmodifier ,
                            dmoddate ,
                            dverifydate ,
                            dcreatesystime ,
                            dverifysystime ,
                            dmodifysystime ,
                            cinvoicecompany ,
                            cinvoicecompanyabbname
                    FROM    SA_ReturnsApplyMainView WITH ( NOLOCK )
                            INNER JOIN #STPDAApplyRefIDs ON #STPDAApplyRefIDs.id = SA_ReturnsApplyMainView.id
                    --WHERE   #STPDAApplyRefIDs.identityautoid >= 0
                    --        AND #STPDAApplyRefIDs.identityautoid <= 0
                    ORDER BY #STPDAApplyRefIDs.identityautoid;
                    IF ( @GetType = N'DETAIL' )
                        BEGIN
                            SELECT  autoid AS bodyautoid ,
                                    N'' AS selcol ,
                                    irowno ,
                                    ccontractid ,
                                    ( cdlcode ) AS cdlcode ,
									 ( cdlcode ) AS csrccode,
                                    ( csocode ) AS csocode ,
                                    cinvouchtype ,
                                    ccontracttagcode ,
                                    ( iorderrowno ) AS iorderrowno ,
                                    cwhcode ,
                                    cwhname ,
                                    SA_ReturnsApplyDetailView.cinvcode AS cinvcode ,
                                    SA_ReturnsApplyDetailView.cinvaddcode AS cinvaddcode ,
                                    ( ccontractrowguid ) AS ccontractrowguid ,
                                    SA_ReturnsApplyDetailView.cinvname AS cinvname ,
                                    SA_ReturnsApplyDetailView.cinvstd AS cinvstd ,
                                    ccusinvcode ,
                                    ccusinvname ,
                                    cbatch ,
                                    dmdate ,
                                    SA_ReturnsApplyDetailView.imassdate AS imassdate ,
                                    SA_ReturnsApplyDetailView.cmassunit AS cmassunit ,
                                    dvdate ,
                                    cincode ,
                                    cinvm_unit ,
                                    iquantity ,
                                    SA_ReturnsApplyDetailView.cgroupcode AS cgroupcode ,
                                    SA_ReturnsApplyDetailView.igrouptype AS igrouptype ,
                                    cunitid ,
                                    iinvexchrate ,
                                    cinva_unit ,
                                    inum ,
                                    ( iquantity ) AS inewquantity ,
                                    ( inum ) AS inewnum ,
									ISNULL(fretqty,0) as ireceivedqty,
                                    ( CASE WHEN @OperType = N'1'
                                           THEN ( iquantity - ISNULL(fretqty,
                                                              0) )
                                           ELSE -( ABS(iquantity)
                                                   - ABS(ISNULL(fretqty, 0)) )
                                      END ) AS inquantity ,
                                    ( CASE WHEN @OperType = N'1'
                                           THEN ( CASE WHEN SA_ReturnsApplyDetailView.igrouptype = 0
                                                       THEN NULL
                                                       ELSE CAST(( ISNULL(inum,
                                                              0)
                                                              - ISNULL(fretqty,
                                                              0)
                                                              / iinvexchrate ) AS DECIMAL(26,
                                                              9))
                                                  END )
                                           ELSE ( CASE WHEN SA_ReturnsApplyDetailView.igrouptype = 0
                                                       THEN NULL
                                                       ELSE CAST(-( ABS(ISNULL(inum,
                                                              0))
                                                              - ABS(ISNULL(fretqty,
                                                              0))
                                                              / iinvexchrate ) AS DECIMAL(26,
                                                              9))
                                                  END )
                                      END ) AS innum ,
                                    ( SA_ReturnsApplyDetailView.itaxrate ) AS itaxrate ,
                                    ( imoney ) AS inewmoney ,
                                    ( itax ) AS inewtax ,
                                    ( isum ) AS inewsum ,
                                    ( inatmoney ) AS inewnatmoney ,
                                    ( inattax ) AS inewnattax ,
                                    SA_ReturnsApplyDetailView.bfree1 ,
                                    SA_ReturnsApplyDetailView.bfree2 ,
                                    SA_ReturnsApplyDetailView.bfree3 ,
                                    SA_ReturnsApplyDetailView.bfree4 ,
                                    SA_ReturnsApplyDetailView.bfree5 ,
                                    SA_ReturnsApplyDetailView.bfree6 ,
                                    SA_ReturnsApplyDetailView.bfree7 ,
                                    SA_ReturnsApplyDetailView.bfree8 ,
                                    SA_ReturnsApplyDetailView.bfree9 ,
                                    SA_ReturnsApplyDetailView.bfree10 ,
                                    bsalepricefree1 ,
                                    bsalepricefree2 ,
                                    bsalepricefree3 ,
                                    bsalepricefree4 ,
                                    bsalepricefree5 ,
                                    bsalepricefree6 ,
                                    bsalepricefree7 ,
                                    bsalepricefree8 ,
                                    bsalepricefree9 ,
                                    bsalepricefree10 ,
                                    ( inatsum ) AS inewnatsum ,
                                    iappnum ,
                                    iappquantity ,
                                    SA_ReturnsApplyDetailView.btracksalebill AS btracksalebill ,
                                    fretqty ,
                                    fretsum ,
                                    itb ,
                                    ( CASE WHEN SA_ReturnsApplyDetailView.binvbatch = 1
                                           THEN N'是'
                                           ELSE N'否'
                                      END ) AS binvbatch1 ,
                                    ( CASE WHEN SA_ReturnsApplyDetailView.binvquality = 1
                                           THEN N'是'
                                           ELSE N'否'
                                      END ) AS binvquality1 ,
                                    ( bbatchcreate ) AS bbatchcreate ,
                                    ( bbatchproperty1 ) AS bbatchproperty1 ,
                                    ( bbatchproperty2 ) AS bbatchproperty2 ,
                                    ( bbatchproperty3 ) AS bbatchproperty3 ,
                                    ( bbatchproperty4 ) AS bbatchproperty4 ,
                                    ( bbatchproperty5 ) AS bbatchproperty5 ,
                                    ( bbatchproperty6 ) AS bbatchproperty6 ,
                                    ( bbatchproperty7 ) AS bbatchproperty7 ,
                                    ( bbatchproperty8 ) AS bbatchproperty8 ,
                                    ( bbatchproperty9 ) AS bbatchproperty9 ,
                                    ( bbatchproperty10 ) AS bbatchproperty10 ,
                                    ( cbatchproperty1 ) AS cbatchproperty1 ,
                                    ( cbatchproperty2 ) AS cbatchproperty2 ,
                                    ( cbatchproperty3 ) AS cbatchproperty3 ,
                                    ( cbatchproperty4 ) AS cbatchproperty4 ,
                                    ( cbatchproperty5 ) AS cbatchproperty5 ,
                                    ( cbatchproperty6 ) AS cbatchproperty6 ,
                                    ( cbatchproperty7 ) AS cbatchproperty7 ,
                                    ( cbatchproperty8 ) AS cbatchproperty8 ,
                                    ( cbatchproperty9 ) AS cbatchproperty9 ,
                                    ( cbatchproperty10 ) AS cbatchproperty10 ,
                                    ( cexpirationdate ) AS cexpirationdate ,
                                    ( dexpirationdate ) AS dexpirationdate ,
                                    ( iexpiratdatecalcu ) AS iexpiratdatecalcu ,
                                    ( CASE WHEN SA_ReturnsApplyDetailView.btrack = 1
                                           THEN N'是'
                                           ELSE N'否'
                                      END ) AS btrack ,
                                    ( cvmivencode ) AS cvmivencode ,
                                    ( cvmivenname ) AS cvmivenname ,
                                    iquotedprice ,
                                    itaxunitprice ,
                                    iunitprice ,
                                    imoney ,
                                    fcusminprice ,
                                    SA_ReturnsApplyDetailView.bservice AS bservice ,
                                    SA_ReturnsApplyDetailView.binvtype AS binvtype ,
                                    itax ,
                                    isum ,
                                    inatunitprice ,
                                    inatmoney ,
                                    inattax ,
                                    inatsum ,
                                    ( fcusminprice ) AS iinvlscost ,
                                    fsalecost ,
                                    fsaleprice ,
                                    ( N'' ) AS corufts ,
                                    ( idiscount ) AS inewdiscount ,
                                    ( inatdiscount ) AS inewnatdiscount ,
                                    kl ,
                                    kl2 ,
                                    dkl1 ,
                                    dkl2 ,
                                    idiscount ,
                                    inatdiscount ,
                                    citem_class ,
                                    citem_cname ,
                                    citemcode ,
                                    citemname ,
                                    ( cmemo ) AS cmemo ,
                                    SA_ReturnsApplyDetailView.iinvweight AS iinvweight ,
                                    cfree1 ,
                                    cfree2 ,
                                    cfree3 ,
                                    cfree4 ,
                                    cfree5 ,
                                    cfree6 ,
                                    cfree7 ,
                                    cfree8 ,
                                    cfree9 ,
                                    cfree10 ,
                                    SA_ReturnsApplyDetailView.cinvdefine1 AS cinvdefine1 ,
                                    SA_ReturnsApplyDetailView.cinvdefine2 AS cinvdefine2 ,
                                    SA_ReturnsApplyDetailView.cinvdefine3 AS cinvdefine3 ,
                                    SA_ReturnsApplyDetailView.cinvdefine4 AS cinvdefine4 ,
                                    SA_ReturnsApplyDetailView.cinvdefine5 AS cinvdefine5 ,
                                    SA_ReturnsApplyDetailView.cinvdefine6 AS cinvdefine6 ,
                                    SA_ReturnsApplyDetailView.cinvdefine7 AS cinvdefine7 ,
                                    SA_ReturnsApplyDetailView.cinvdefine8 AS cinvdefine8 ,
                                    SA_ReturnsApplyDetailView.cinvdefine9 AS cinvdefine9 ,
                                    SA_ReturnsApplyDetailView.cinvdefine10 AS cinvdefine10 ,
                                    SA_ReturnsApplyDetailView.cinvdefine11 AS cinvdefine11 ,
                                    SA_ReturnsApplyDetailView.cinvdefine12 AS cinvdefine12 ,
                                    SA_ReturnsApplyDetailView.cinvdefine13 AS cinvdefine13 ,
                                    SA_ReturnsApplyDetailView.cinvdefine14 AS cinvdefine14 ,
                                    SA_ReturnsApplyDetailView.cinvdefine15 AS cinvdefine15 ,
                                    SA_ReturnsApplyDetailView.cinvdefine16 AS cinvdefine16 ,
                                    bproxywh ,
                                    ( N'否' ) AS bqaneedcheck ,
                                    ( N'否' ) AS bqaurgency ,
                                    cdefine22 ,
                                    cdefine23 ,
                                    cdefine24 ,
                                    cdefine25 ,
                                    cdefine26 ,
                                    cdefine27 ,
                                    cdefine28 ,
                                    cdefine29 ,
                                    cdefine30 ,
                                    cdefine31 ,
                                    cdefine32 ,
                                    cdefine33 ,
                                    cdefine34 ,
                                    cdefine35 ,
                                    cdefine36 ,
                                    cdefine37 ,
                                    SA_ReturnsApplyDetailView.csrpolicy AS csrpolicy ,
                                    ( autoid ) AS autoid ,
                                    ( icorid ) AS icorid ,
                                    ( id ) AS id ,
                                    ( isosid ) AS isosid ,
                                    ibatch ,
                                    idemandseq ,
                                    idemandtype ,
                                    bneedbill ,
                                    cdemandcode ,
                                    cdemandid ,
                                    cdemandmemo ,
                                    ( N'' ) AS bneedsign ,
                                    bsaleprice ,
                                    ( SA_ReturnsApplyDetailView.bserial ) AS bserial ,
                                    ( N'' ) AS bcashsale ,
                                    bgift ,
                                    ( cfactorycode ) AS cfactorycode ,
                                    ( cfactoryname ) AS cfactoryname ,
                                    ( SA_ReturnsApplyDetailView.cvencode ) AS cvencode ,
                                    ( cparentcode ) AS cparentcode ,
                                    ( creasoncode ) AS creasoncode ,
                                    ( creasonname ) AS creasonname ,
                                    ( N'' ) AS crtnappcode ,
                                    cinvsn ,
                                    Inv.bInvBatch AS binvbatch ,
                                    Inv.bInvQuality AS binvquality ,
                                    --Inv.bSerial AS bserial ,
                                    Inv.bBarCode AS bbarcode ,
                                    0.0 AS iscanedquantity ,
                                    0.0 AS iscanednum
                            FROM    SA_ReturnsApplyDetailView WITH ( NOLOCK )
                                    INNER
							JOIN dbo.Inventory Inv ON SA_ReturnsApplyDetailView.cinvcode = Inv.cInvCode
                            WHERE   autoid IN ( SELECT  DISTINCT
                                                        autoid
                                                FROM    #STPDAApplyRefIDs );
                        END;
					--删除临时表
                    IF EXISTS ( SELECT  0
                                WHERE   NOT OBJECT_ID('tempdb..#STPDAApplyRefIDs') IS NULL )
                        DROP TABLE #STPDAApplyRefIDs;
                 
                    IF EXISTS ( SELECT  0
                                WHERE   NOT OBJECT_ID('tempdb..#STPDATempApplyIDs') IS NULL )
                        DROP TABLE #STPDATempApplyIDs;
                    IF EXISTS ( SELECT  0
                                WHERE   NOT OBJECT_ID('tempdb..#STPDATempApplyDIDs') IS NULL )
                        DROP TABLE #STPDATempApplyDIDs;
                END;
            ELSE
                IF ( @OperType = N'3' )
                    BEGIN
                    --退货单参照发货单
                    
						--未开发票退货:0
						--已开发票退货:1(默认)
                        DECLARE @ReturnType VARCHAR(1);
                        SET @ReturnType = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ReturnType',
                                                              DEFAULT, DEFAULT);
                        IF ( @ReturnType = N'' )
                            SET @ReturnType = '1';
						--发货单日期FROM
                        DECLARE @DispatchDateFrom VARCHAR(10);
                        SET @DispatchDateFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dDateFrom',
                                                              DEFAULT, DEFAULT);
						--发货单日期TO
                        DECLARE @DispatchDateTo VARCHAR(10);
                        SET @DispatchDateTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dDateTo',
                                                              DEFAULT, DEFAULT);
                        IF ( @DispatchDateFrom = N'' )
                            SET @DispatchDateTo = @DispatchDateFrom;
						--发货单单号From
                        DECLARE @DispatchCodeFrom NVARCHAR(30);
                        SET @DispatchCodeFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cCodeFrom',
                                                              DEFAULT, DEFAULT);
						--发货单单号To
                        DECLARE @DispatchCodeTo NVARCHAR(30);
                        SET @DispatchCodeTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cCodeTo',
                                                              DEFAULT, DEFAULT);
                        IF ( @DispatchCodeTo = N'' )
                            SET @DispatchCodeTo = @DispatchCodeFrom;
                
						--仓库编码
                        DECLARE @cWhCode NVARCHAR(10);
                        SET @cWhCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cWhCode',
                                                              DEFAULT, DEFAULT);
						--发货单主表ID
                        DECLARE @DispatchIds NVARCHAR(1000);                
                        BEGIN
                
                            SET @DispatchIds = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'DispatchIds',
                                                              DEFAULT, DEFAULT);
                            IF ( @DispatchIds <> N'' )
                                BEGIN                             
                                    IF EXISTS ( SELECT  0
                                                WHERE   NOT OBJECT_ID('tempdb..#STPDATempDispatchIDs') IS NULL )
                                        DROP TABLE #STPDATempDispatchIDs;
                    
                                    CREATE   TABLE #STPDATempDispatchIDs ( DispatchId
                                                              INT );
                                    INSERT  INTO #STPDATempDispatchIDs
                                            EXEC proc_ts_SplitParamString @DispatchIds;
                                END;
                                                              
                        END;
                
						--发货单子表ID
                        DECLARE @DispatchDids NVARCHAR(1000);
                        BEGIN
                            SET @DispatchDids = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'DispatchDids',
                                                              DEFAULT, DEFAULT);
                            IF ( @DispatchDids <> N'' )
                                BEGIN                             
                                    IF EXISTS ( SELECT  0
                                                WHERE   NOT OBJECT_ID('tempdb..#STPDATempDispatchDIDs') IS NULL )
                                        DROP TABLE #STPDATempDispatchDIDs;
                    
                                    CREATE   TABLE #STPDATempDispatchDIDs ( DispatchDid
                                                              INT );
                                    INSERT  INTO #STPDATempDispatchDIDs
                                            EXEC proc_ts_SplitParamString @DispatchDids;
                                END;
                        END;
                        SET NOCOUNT ON;
                        
                        IF EXISTS ( SELECT  0
                                    WHERE   NOT OBJECT_ID('tempdb..#STPDADispatchRefIDs') IS NULL )
                            DROP TABLE #STPDADispatchRefIDs;
               
                        SELECT  IDENTITY( INT ) AS identityautoid ,
                                CONVERT(INT, 0) AS dlid ,
                                CONVERT(INT, 0) AS idlsid ,
                                CONVERT(NVARCHAR(50), N'') AS cparentcode
                        INTO    #STPDADispatchRefIDs
                        FROM    sale_BlueDispToRedDisp_T WITH ( NOLOCK )
                        WHERE   1 = 0; 
                        CREATE CLUSTERED INDEX ix_STPDADispatchRefIDs_tmpid_813 ON #STPDADispatchRefIDs( dlid,idlsid,identityautoid ); 
                        SET @SqlCommand = 'INSERT INTO #STPDADispatchRefIDs (dlid,idlsid,cparentcode)
									  SELECT sale_BlueDispToRedDisp_T.dlid,sale_BlueDispToRedDisp_B.idlsid,cparentcode
									  FROM sale_BlueDispToRedDisp_T WITH ( NOLOCK )
									  INNER JOIN sale_BlueDispToRedDisp_B WITH ( NOLOCK ) ON sale_BlueDispToRedDisp_T.dlid = sale_BlueDispToRedDisp_B.dlid
									  WHERE ( cvouchtype = N''05'' AND sale_BlueDispToRedDisp_B.bsettleall = 0 AND ISNULL(isale, 0) = 0
          AND ISNULL(cverifier, N'''') <> N'''' AND ISNULL(icorid, 0) = 0 AND ( ISNULL(bsaleoutcreatebill, 0) = 0 OR ( ISNULL(bsaleoutcreatebill, 0) = 1 
          AND ISNULL(cwhcode, N'''') = N'''' AND ISNULL(cparentcode, N'''') = N''''))) AND ( 1 = 1 ';
                        IF ( @cMaker <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (cmaker=@cMaker) ';
                        IF ( @cCusCode <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (ccuscode = @cCusCode) ';
                        IF ( @cCusName <> N''
                             AND @cCusName <> N'%%'
                           )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (ccusname LIKE @cCusName) ';
                        IF ( @cDepCode <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (cdepcode = @cDepCode) ';
                        IF ( @cDepName <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (cdepname = @cDepName) ';
                        IF ( @DispatchDateFrom <> N''
                             AND @DispatchDateTo <> N''
                           )
                            SET @SqlCommand = @SqlCommand
                                + ' AND ((ddate >= @DispatchDateFrom)
                            AND (ddate <= @DispatchDateTo)) ';       
                        IF ( @DispatchCodeFrom <> N''
                             AND @DispatchCodeTo <> N''
                           )
                            SET @SqlCommand = @SqlCommand
                                + ' AND ((cdlcode >= @DispatchCodeFrom)
                            AND (cdlcode <= @DispatchCodeTo)) ';
                        IF ( @cInvCode <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (cinvcode = @cInvCode) ';
                        IF ( @cBusType <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (cbustype = @cBusType) ';
                        IF ( @cPersonCode <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (cpersoncode = @cPersonCode) ';
                        IF ( @cWhCode <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (cwhcode = @cWhCode) '; 
                        IF ( @DispatchIds <> N'' )
                            SET @SqlCommand = @SqlCommand
                                + ' AND (sale_BlueDispToRedDisp_T.dlid IN (SELECT DISTINCT DispatchId FROM #STPDATempDispatchIDs)) ';
                        IF ( @DispatchDids <> N'' )
                            BEGIN
                                SET @SqlCommand = @SqlCommand
                                    + ' AND (sale_BlueDispToRedDisp_B.idlsid IN (SELECT DISTINCT DispatchDid FROM #STPDATempDispatchDIDs)) ';
                            END;
                            
                        IF ( @ReturnType = N'0' )
                            BEGIN
                                SET @SqlCommand = @SqlCommand
                                    + ' AND (CASE WHEN ISNULL(iquantity,0) = 0 THEN CAST(ISNULL(isum,0) - ISNULL(isettlenum,0) - ISNULL(fretsum,0) AS DECIMAL(26,0))
                         ELSE CAST(ISNULL(iquantity,0) - ISNULL(isettlequantity,0) - ISNULL(fretqtywkp,0) AS DECIMAL(20,6)) END > 0)) AND ( ISNULL(cchildcode,N'''') = N'''' ) ';
                            END;
                        ELSE
                            BEGIN
                                SET @SqlCommand = @SqlCommand
                                    + ' AND CAST(CASE WHEN ISNULL(iquantity,0) = 0 THEN ISNULL(isettlenum,0) - ISNULL(fretsumykp,0) 
                                    ELSE ISNULL(isettlequantity,0)- ISNULL(fretqtyykp,0) END AS DECIMAL(26,9)) > 0) AND ( ISNULL(cchildcode,N'''') = N'''' )';
                            END;
        
                        SET @ParmList = '@cMaker					NVARCHAR(30),
									   @cCusCode				NVARCHAR(20),
									   @cCusName				NVARCHAR(120),
									   @cDepCode				NVARCHAR(12),
									   @cDepName				NVARCHAR(255),
									   @DispatchDateFrom		VARCHAR(10),
									   @DispatchDateTo			VARCHAR(10),
									   @DispatchCodeFrom		VARCHAR(10),
									   @DispatchCodeTo			VARCHAR(10),
									   @cPersonCode				NVARCHAR(20),
									   @cWhCode					NVARCHAR(10),
									   @cInvCode				NVARCHAR(60),
									   @cBusType				NVARCHAR(8)';
                        --PRINT @SqlCommand;
                        EXEC sp_executesql @SqlCommand, @ParmList,
                            @cMaker = @cMaker, @cCusCode = @cCusCode,
                            @cCusName = @cCusName, @cDepCode = @cDepCode,
                            @cDepName = @cDepName,
                            @DispatchDateFrom = @DispatchDateFrom,
                            @DispatchDateTo = @DispatchDateTo,
                            @DispatchCodeFrom = @DispatchCodeFrom,
                            @DispatchCodeTo = @DispatchCodeTo,
                            @cPersonCode = @cPersonCode, @cWhCode = @cWhCode,
                            @cInvCode = @cInvCode, @cBusType = @cBusType;
                        SET NOCOUNT OFF;
                        --查询列表（表头）
                        	select distinct * from 
						(
                        SELECT   N'' AS selcol ,
                                ( csocode ) AS csocode ,
                                ( sale_BlueDispToRedDisp_T.dlid ) AS dlid ,
                                cvouchtype ,
                                ( dcreditstart ) AS dcreditstart ,
                                ( cmobilephone ) AS cmobilephone ,
                                ( dgatheringdate ) AS dgatheringdate ,
                                ( icreditdays ) AS icreditdays ,
                                ( bcredit ) AS bcredit ,
                                ( caddcode ) AS caddcode ,
                                ( ccontactname ) AS ccontactname ,
                                ( ccreditcuscode ) AS ccreditcuscode ,
                                ( ccreditcusname ) AS ccreditcusname ,
                                ( cdeliverunit ) AS cdeliverunit ,
                                ( cgatheringplan ) AS cgatheringplan ,
                                ( cgatheringplanname ) AS cgatheringplanname ,
                                ( cofficephone ) AS cofficephone ,
                                ivtid ,
                                ( CONVERT(CHAR, CONVERT(MONEY, ufts), 2) ) AS corufts ,
                                ccushand ,
                                ccuspersoncode ,
                                cbustype ,
                                ccusaddress ,
                                cstcode ,
                                ccusperson ,
                                cstname ,
                                cdlcode ,
                                CONVERT(VARCHAR(100), ddate, 23) AS ddate ,
                                cexch_name ,
                                iexchrate ,
                                ( iflowid ) AS iflowid ,
                                ( cpsnmobilephone ) AS cpsnmobilephone ,
                                ( cflowname ) AS cflowname ,
                                ( cebcity ) AS cebcity ,
                                ( cebdistrict ) AS cebdistrict ,
                                ( cebprovince ) AS cebprovince ,
                                ( bcashsale ) AS bcashsale ,
                                csbvcode ,
                                ccuscode ,
                                ccusabbname ,
                                ccusname ,
                                ccusoaddress ,
                                cshipaddress ,
                                ccusphone ,
                                ccuspostcode ,
                                ccuspaycond ,
                                icuscreline ,
                                cdepcode ,
                                cdepname ,
                                cpersoncode ,
                                cpersonname ,
                                cpaycode ,
                                cpayname ,
                                csccode ,
                                csscode ,
                                cssname ,
                                cscname ,
                                cmaker ,
                                cverifier ,
                                caccounter ,
                                ccloser ,
                                ccrechpname ,
                                ( itaxrate ) AS itaxrate ,
                                ( cmemo ) AS cmemo ,
                                cdefine1 ,
                                cdefine2 ,
                                cdefine3 ,
                                cdefine4 ,
                                cdefine5 ,
                                cdefine6 ,
                                cdefine7 ,
                                cdefine8 ,
                                cdefine9 ,
                                cdefine10 ,
                                cdefine11 ,
                                cdefine12 ,
                                cdefine13 ,
                                cdefine14 ,
                                cdefine15 ,
                                cdefine16 ,
                                ccusdefine1 ,
                                ccusdefine2 ,
                                ccusdefine3 ,
                                ccusdefine4 ,
                                ccusdefine5 ,
                                ccusdefine6 ,
                                ccusdefine7 ,
                                ccusdefine8 ,
                                ccusdefine9 ,
                                ccusdefine10 ,
                                ccusdefine11 ,
                                ccusdefine12 ,
                                ccusdefine13 ,
                                ccusdefine14 ,
                                ccusdefine15 ,
                                ccusdefine16 ,
                                cmodifier ,
                                dmoddate ,
                                dverifydate ,
                                dcreatesystime ,
                                dverifysystime ,
                                dmodifysystime ,
                                cinvoicecompany ,
                                cinvoicecompanyabbname
                        FROM    sale_BlueDispToRedDisp_T WITH ( NOLOCK )
                                INNER JOIN #STPDADispatchRefIDs ON #STPDADispatchRefIDs.dlid = sale_BlueDispToRedDisp_T.dlid) as t 
								 ORDER BY dlid;
                        IF ( @GetType = N'DETAIL' )
                            BEGIN
                                SELECT  sale_BlueDispToRedDisp_B.idlsid AS bodyautoid ,
                                        N'' AS selcol ,
                                        irowno ,
                                        ccontractid ,
                                        ( cordercode ) AS cordercode ,
                                        ( cordercode ) AS csocode ,
                                        cinvouchtype ,
                                        ccontracttagcode ,
                                        ( iorderrowno ) AS iorderrowno ,
                                        ccorcode ,
                                        cwhcode ,
                                        cwhname ,
                                        cinvcode ,
                                        cinvaddcode ,
                                        cinvname ,
                                        ( ccontractrowguid ) AS ccontractrowguid ,
                                        cinvstd ,
                                        cvenabbname ,
                                        ccusinvcode ,
                                        ccusinvname ,
                                        cbatch ,
                                        dmdate ,
                                        imassdate ,
                                        cmassunit ,
                                        dvdate ,
                                        ccode ,
                                        cinvm_unit ,
                                        fretsum ,
                                        iquantity ,
                                        cgroupcode ,
                                        igrouptype ,
                                        cunitid ,
                                        iinvexchrate ,
                                        cinva_unit ,
                                        inum ,
                                        ( iquantity ) AS inewquantity ,
                                        ( inum ) AS inewnum ,
                                        ( itaxrate ) AS itaxrate ,
                                        ( imoney ) AS inewmoney ,
                                        ( itax ) AS inewtax ,
                                        ( isum ) AS inewsum ,
                                        ( inatmoney ) AS inewnatmoney ,
                                        ( inattax ) AS inewnattax ,
                                        bfree1 ,
                                        bfree10 ,
                                        bfree2 ,
                                        bfree3 ,
                                        bfree4 ,
                                        bfree5 ,
                                        bfree6 ,
                                        bfree7 ,
                                        bfree8 ,
                                        bfree9 ,
                                        bsalepricefree1 ,
                                        bsalepricefree10 ,
                                        bsalepricefree2 ,
                                        bsalepricefree3 ,
                                        bsalepricefree4 ,
                                        bsalepricefree5 ,
                                        bsalepricefree6 ,
                                        bsalepricefree7 ,
                                        bsalepricefree8 ,
                                        bsalepricefree9 ,
                                        ( inatsum ) AS inewnatsum ,
                                        foutquantity ,
                                        fretqtywkp ,
                                        fretqtyykp ,
                                        ( CASE WHEN @ReturnType = N'0'
                                               THEN ( ISNULL(iquantity, 0)
                                                      - ISNULL(fretqtywkp, 0) )
                                               ELSE ( ISNULL(iquantity, 0)
                                                      - ISNULL(fretqtyykp, 0) )
                                          END ) AS inquantity ,
                                        ( CASE WHEN igrouptype = 0 THEN NULL
                                               ELSE ( CASE WHEN @ReturnType = N'0'
                                                           THEN ( ( ISNULL(iquantity,
                                                              0)
                                                              - ISNULL(fretqtywkp,
                                                              0) )
                                                              / iinvexchrate )
                                                           ELSE ( ( ISNULL(iquantity,
                                                              0)
                                                              - ISNULL(fretqtyykp,
                                                              0) )
                                                              / iinvexchrate )
                                                      END )
                                          END ) AS innum ,
                                        btracksalebill ,
                                        iretquantity ,
										iretquantity as ireceivedqty,
                                        isettlequantity ,
                                        isettlenum ,
                                        itb ,
                                        bsettleall ,
                                        csettleall ,
                                        binvbatch ,
                                        binvquality ,
                                        ( bbatchcreate ) AS bbatchcreate ,
                                        ( bbatchproperty1 ) AS bbatchproperty1 ,
                                        ( bbatchproperty10 ) AS bbatchproperty10 ,
                                        ( bbatchproperty2 ) AS bbatchproperty2 ,
                                        ( bbatchproperty3 ) AS bbatchproperty3 ,
                                        ( bbatchproperty4 ) AS bbatchproperty4 ,
                                        ( bbatchproperty5 ) AS bbatchproperty5 ,
                                        ( bbatchproperty6 ) AS bbatchproperty6 ,
                                        ( bbatchproperty7 ) AS bbatchproperty7 ,
                                        ( bbatchproperty8 ) AS bbatchproperty8 ,
                                        ( bbatchproperty9 ) AS bbatchproperty9 ,
                                        ( cbatchproperty1 ) AS cbatchproperty1 ,
                                        ( cbatchproperty10 ) AS cbatchproperty10 ,
                                        ( cbatchproperty2 ) AS cbatchproperty2 ,
                                        ( cbatchproperty3 ) AS cbatchproperty3 ,
                                        ( cbatchproperty4 ) AS cbatchproperty4 ,
                                        ( cbatchproperty5 ) AS cbatchproperty5 ,
                                        ( cbatchproperty6 ) AS cbatchproperty6 ,
                                        ( cbatchproperty7 ) AS cbatchproperty7 ,
                                        ( cbatchproperty8 ) AS cbatchproperty8 ,
                                        ( cbatchproperty9 ) AS cbatchproperty9 ,
                                        ( dexpirationdate ) AS dexpirationdate ,
                                        ( cexpirationdate ) AS cexpirationdate ,
                                        ( iexpiratdatecalcu ) AS iexpiratdatecalcu ,
                                        btrack ,
                                        bgsp ,
                                        fretailrealamount ,
                                        fretailsettleamount ,
                                        ( cvmivencode ) AS cvmivencode ,
                                        ( cvmivenname ) AS cvmivenname ,
                                        iquotedprice ,
                                        itaxunitprice ,
                                        iunitprice ,
                                        imoney ,
                                        fcusminprice ,
                                        binvtype ,
                                        bservice ,
                                        itax ,
                                        isum ,
                                        inatunitprice ,
                                        inatmoney ,
                                        inattax ,
                                        inatsum ,
                                        ( fcusminprice ) AS iinvlscost ,
                                        fsalecost ,
                                        fsaleprice ,
                                        ( idiscount ) AS inewdiscount ,
                                        ( N'' ) AS corufts ,
                                        ( inatdiscount ) AS inewnatdiscount ,
                                        kl ,
                                        kl2 ,
                                        dkl1 ,
                                        dkl2 ,
                                        idiscount ,
                                        inatdiscount ,
                                        foutnum ,
                                        citem_class ,
                                        citem_cname ,
                                        citemcode ,
                                        citemname ,
                                        ( cmemo ) AS cmemo ,
                                        iinvweight ,
                                        cfree1 ,
                                        cfree2 ,
                                        cfree3 ,
                                        cfree4 ,
                                        cfree5 ,
                                        cfree6 ,
                                        cfree7 ,
                                        cfree8 ,
                                        cfree9 ,
                                        cfree10 ,
                                        cinvdefine1 ,
                                        cinvdefine2 ,
                                        cinvdefine3 ,
                                        cinvdefine4 ,
                                        cinvdefine5 ,
                                        cinvdefine6 ,
                                        cinvdefine7 ,
                                        cinvdefine8 ,
                                        cinvdefine9 ,
                                        cinvdefine10 ,
                                        cinvdefine11 ,
                                        cinvdefine12 ,
                                        cinvdefine13 ,
                                        cinvdefine14 ,
                                        cinvdefine15 ,
                                        cinvdefine16 ,
                                        ( N'否' ) AS bqaneedcheck ,
                                        ( N'否' ) AS bqaurgency ,
                                        bproxywh ,
                                        cdefine22 ,
                                        cdefine23 ,
                                        cdefine24 ,
                                        cdefine25 ,
                                        cdefine26 ,
                                        cdefine27 ,
                                        cdefine28 ,
                                        cdefine29 ,
                                        cdefine30 ,
                                        cdefine31 ,
                                        csrpolicy ,
                                        cdefine32 ,
                                        cdefine33 ,
                                        cdefine34 ,
                                        cdefine35 ,
                                        cdefine36 ,
                                        cdefine37 ,
                                        isosid ,
                                        ( sale_BlueDispToRedDisp_B.dlid ) AS dlid ,
                                        ( sale_BlueDispToRedDisp_B.idlsid ) AS icorid ,
                                        ibatch ,
                                        sale_BlueDispToRedDisp_B.idlsid ,
                                        idemandseq ,
                                        idemandtype ,
                                        cdemandcode ,
                                        cdemandid ,
                                        cdemandmemo ,
                                        bsaleprice ,
                                        ( cchildcode ) AS cchildcode ,
                                        ( bptomodel ) AS bptomodel ,
                                        ( binvmodel ) AS binvmodel ,
                                        ( bserial ) AS bserial ,
                                        bgift ,
                                        ( fchildqty ) AS fchildqty ,
                                        ( fchildrate ) AS fchildrate ,
                                        ( sale_BlueDispToRedDisp_B.cparentcode ) AS cparentcode ,
                                        ( cvencode ) AS cvencode ,
                                        ( cfactorycode ) AS cfactorycode ,
                                        ( cfactoryname ) AS cfactoryname ,
                                        ( icalctype ) AS icalctype ,
                                        ( ippartid ) AS ippartid ,
                                        ( ippartqty ) AS ippartqty ,
                                        fretsumykp ,
                                        biacreatebill ,
                                        0.0 AS iscanedquantity ,
                                        0.0 AS iscanednum
                                FROM    sale_BlueDispToRedDisp_B WITH ( NOLOCK )
                                        INNER JOIN #STPDADispatchRefIDs ON sale_BlueDispToRedDisp_B.idlsid = #STPDADispatchRefIDs.idlsid
                                ORDER BY identityautoid ,
                                        --sale_BlueDispToRedDisp_B.sortcode DESC ,
                                        sale_BlueDispToRedDisp_B.idlsid;
                            END;
                        --删除临时表
                        IF EXISTS ( SELECT  0
                                    WHERE   NOT OBJECT_ID('tempdb..#STPDADispatchRefIDs') IS NULL )
                            DROP TABLE #STPDADispatchRefIDs;
                        IF EXISTS ( SELECT  0
                                    WHERE   NOT OBJECT_ID('tempdb..#STPDATempDispatchIDs') IS NULL )
                            DROP TABLE #STPDATempDispatchIDs;
                        IF EXISTS ( SELECT  0
                                    WHERE   NOT OBJECT_ID('tempdb..#STPDATempDispatchDIDs') IS NULL )
                            DROP TABLE #STPDATempDispatchDIDs;
                    END;
                ELSE
                    IF ( @OperType = N'4' )
                        BEGIN
							--未开发票退货:0
							--已开发票退货:1(默认)
                            DECLARE @ReturnTypeShip VARCHAR(1);
                            SET @ReturnTypeShip = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ReturnType',
                                                              DEFAULT, DEFAULT);
                            IF ( @ReturnType = N'' )
                                SET @ReturnType = '1';
							--出库单日期FROM
                            DECLARE @ShipDateFrom VARCHAR(10);
                            SET @ShipDateFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dDateFrom',
                                                              DEFAULT, DEFAULT);
							--出库单日期TO
                            DECLARE @ShipDateTo VARCHAR(10);
                            SET @ShipDateTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'dDateTo',
                                                              DEFAULT, DEFAULT);
                            IF ( @ShipDateFrom = N'' )
                                SET @ShipDateTo = @ShipDateFrom;
							--出库单单号From
                            DECLARE @ShipCodeFrom NVARCHAR(30);
                            SET @ShipCodeFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cCodeFrom',
                                                              DEFAULT, DEFAULT);
							--出库单单号To
                            DECLARE @ShipCodeTo NVARCHAR(30);
                            SET @ShipCodeTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cCodeTo',
                                                              DEFAULT, DEFAULT);
                            IF ( @ShipCodeFrom = N'' )
                                SET @ShipCodeTo = @ShipCodeFrom;
							--对应发货单单号From
                            DECLARE @ShipDispatchCodeFrom NVARCHAR(30);
                            SET @ShipDispatchCodeFrom = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cDispatchCodeFrom',
                                                              DEFAULT, DEFAULT);
							--对应发货单单号To
                            DECLARE @ShipDispatchCodeTo NVARCHAR(30);
                            SET @ShipDispatchCodeTo = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cDispatchCodeTo',
                                                              DEFAULT, DEFAULT);
                            IF ( @ShipDispatchCodeFrom = N'' )
                                SET @ShipDispatchCodeTo = @ShipDispatchCodeFrom;
                            --仓库编码
                            DECLARE @cShipWhCode NVARCHAR(10);
                            SET @cShipWhCode = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'cWhCode',
                                                              DEFAULT, DEFAULT);
							--出库单主表ID
                            DECLARE @ShipIds NVARCHAR(1000);                
                            BEGIN
                                SET @ShipIds = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ShipIds',
                                                              DEFAULT, DEFAULT);
                                IF ( @ShipIds <> N'' )
                                    BEGIN
                                        IF EXISTS ( SELECT  0
                                                    WHERE   NOT OBJECT_ID('tempdb..#STPDATempShipIDs') IS NULL )
                                            DROP TABLE #STPDATempShipIDs;
                    
                                        CREATE   TABLE #STPDATempShipIDs ( ShipId
                                                              INT );
                                        INSERT  INTO #STPDATempShipIDs
                                                EXEC proc_ts_SplitParamString @ShipIds;
                                    END;
                                                              
                            END;
                
							--出库单子表ID
                            DECLARE @ShipDids NVARCHAR(1000);
                            BEGIN
                                SET @ShipDids = dbo.func_ts_GetParamValueBySplitString(@ParamsList,
                                                              N'ShipDids',
                                                              DEFAULT, DEFAULT);
                                IF ( @ShipDids <> N'' )
                                    BEGIN
                                        IF EXISTS ( SELECT  0
                                                    WHERE   NOT OBJECT_ID('tempdb..#STPDATempShipDIDs') IS NULL )
                                            DROP TABLE #STPDATempShipDIDs;
                    
                                        CREATE   TABLE #STPDATempShipDIDs ( ShipDid
                                                              INT );
                                        INSERT  INTO #STPDATempShipDIDs
                                                EXEC proc_ts_SplitParamString @ShipDids;
                                    END;
                            END;
                            SET NOCOUNT ON;
                        
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDAShipRefIDs') IS NULL )
                                DROP TABLE #STPDAShipRefIDs;
               
                            SELECT  IDENTITY( INT ) AS identityautoid ,
                                    CONVERT(INT, 0) AS id ,
                                    CONVERT(INT, 0) AS isaleoutid
                            INTO    #STPDAShipRefIDs
                            FROM    sa_refSaleOutT WITH ( NOLOCK )
                            WHERE   1 = 0; 
                            CREATE CLUSTERED INDEX ix_STPDAShipRefIDs_tmpid_813 ON #STPDAShipRefIDs( id,isaleoutid,identityautoid ); 
                            SET @SqlCommand = 'INSERT INTO #STPDAShipRefIDs (id,isaleoutid)
									  SELECT sa_refSaleOutT.id,sa_refSaleOutB.isaleoutid 
									  FROM sa_refSaleOutT WITH ( NOLOCK )
        INNER JOIN sa_refSaleOutB WITH ( NOLOCK ) ON sa_refSaleOutT.id = sa_refSaleOutB.id
WHERE   ( cbustype <> N''委托代销'' )  AND ( 1 = 1 ';
                            IF ( @cMaker <> N'' )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND (cmaker=@cMaker) ';
                            IF ( @cCusCode <> N'' )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND (ccuscode = @cCusCode) ';
                            IF ( @cCusName <> N''
                                 AND @cCusName <> N'%%'
                               )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND (ccusname LIKE @cCusName) ';
                            IF ( @cDepCode <> N'' )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND (cdepcode = @cDepCode) ';
                            IF ( @cDepName <> N'' )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND (cdepname = @cDepName) ';
                            IF ( @ShipDateFrom <> N''
                                 AND @ShipDateTo <> N''
                               )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND ((ddate >= @ShipDateFrom) AND (ddate <= @ShipDateTo)) ';       
                            IF ( @ShipCodeFrom <> N''
                                 AND @ShipCodeTo <> N''
                               )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND ((sa_refSaleOutT.ccode >= @ShipCodeFrom) AND (sa_refSaleOutT.ccode <= @ShipCodeTo)) ';
                            IF ( @ShipDispatchCodeFrom <> N''
                                 AND @ShipDispatchCodeTo <> N''
                               )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND ((cdlcode >= @ShipDispatchCodeFrom) AND (cdlcode <= @ShipDispatchCodeTo)) ';
                            IF ( @cInvCode <> N'' )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND (cinvcode = @cInvCode) ';
                            IF ( @cBusType <> N'' )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND (cbustype = @cBusType) ';
                            IF ( @cPersonCode <> N'' )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND (cpersoncode = @cPersonCode) ';
                            IF ( @cShipWhCode <> N'' )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND (cwhcode = @cShipWhCode) '; 
                            IF ( @ShipIds <> N'' )
                                SET @SqlCommand = @SqlCommand
                                    + ' AND (sa_refSaleOutT.id IN (SELECT DISTINCT ShipId FROM #STPDATempShipIDs)) ';
                            IF ( @ShipDids <> N'' )
                                BEGIN
                                    SET @SqlCommand = @SqlCommand
                                        + ' AND (sa_refSaleOutB.isaleoutid IN (SELECT DISTINCT ShipDid FROM #STPDATempShipDIDs)) ';
                                END;
                            
                            IF ( @ReturnType = N'0' )
                                BEGIN
                                    SET @SqlCommand = @SqlCommand
                                        + ' AND ISNULL(iquantity,0) > 0 AND CAST(ABS(ISNULL(iquantity,0)) - ABS(ISNULL(fsettleqty,0))
              - ABS(ISNULL(fretqtywkp,0)) AS DECIMAL(26, 9)) > 0) '; 
                                END;
                            ELSE
                                BEGIN
                                    SET @SqlCommand = @SqlCommand
                                        + ' AND ISNULL(iquantity,0) > 0 AND CAST(ABS(ISNULL(fsettleqty,0)) - ABS(ISNULL(fretqtyykp,0)) AS DECIMAL(26,9)) > 0) '; 
                                END;
                             
                            SET @ParmList = '@cMaker			NVARCHAR(30),
									   @cCusCode				NVARCHAR(20),
									   @cCusName				NVARCHAR(120),
									   @cDepCode				NVARCHAR(12),
									   @cDepName				NVARCHAR(255),
									   @ShipDateFrom			VARCHAR(10),
									   @ShipDateTo				VARCHAR(10),
									   @ShipCodeFrom			VARCHAR(10),
									   @ShipCodeTo				VARCHAR(10),
									   @ShipDispatchCodeFrom	VARCHAR(10),
									   @ShipDispatchCodeTo		VARCHAR(10),
									   @cPersonCode				NVARCHAR(20),
									   @cShipWhCode				NVARCHAR(10),
									   @cInvCode				NVARCHAR(60),
									   @cBusType				NVARCHAR(8)';
							--PRINT @SqlCommand;
                            EXEC sp_executesql @SqlCommand, @ParmList,
                                @cMaker = @cMaker, @cCusCode = @cCusCode,
                                @cCusName = @cCusName, @cDepCode = @cDepCode,
                                @cDepName = @cDepName,
                                @ShipDateFrom = @ShipDateFrom,
                                @ShipDateTo = @ShipDateTo,
                                @ShipCodeFrom = @ShipCodeFrom,
                                @ShipCodeTo = @ShipCodeTo,
                                @ShipDispatchCodeFrom = @ShipDispatchCodeFrom,
                                @ShipDispatchCodeTo = @ShipDispatchCodeTo,
                                @cPersonCode = @cPersonCode,
                                @cShipWhCode = @cShipWhCode,
                                @cInvCode = @cInvCode, @cBusType = @cBusType;
                            SET NOCOUNT OFF;
							--查询列表（表头）
                            SELECT  N'' AS selcol ,
                                    ccode ,
                                    CONVERT(VARCHAR(100), ddate, 23) AS ddate ,
                                    cbustype ,
                                    cstname ,
                                    ccusabbname ,
                                    chwhname ,
                                    cpersonname ,
                                    cdepname ,
                                    cmaker ,
                                    cverifier ,
                                    ( sa_refSaleOutT.id ) AS id ,
                                    chwhcode ,
                                    ( caddcode ) AS caddcode ,
                                    ( ccreditcuscode ) AS ccreditcuscode ,
                                    ( ccreditcusname ) AS ccreditcusname ,
                                    ccushand ,
                                    ccusregcode ,
                                    ccusbank ,
                                    ccusaccount ,
                                    ccusaddress ,
                                    ccusphone ,
                                    ccusfax ,
                                    ccuspaycond ,
                                    cstcode ,
                                    ( N'' ) AS cdlcode ,
                                    ( iflowid ) AS iflowid ,
                                    ( cflowname ) AS cflowname ,
                                    cinvoicecompany ,
                                    ccuscode ,
                                    ccusname ,
                                    cinvoicecompanyabbname ,
                                    ccusoaddress ,
                                    ccuspostcode ,
                                    cdepcode ,
                                    cpersoncode ,
                                    ( cmemo ) AS cmemo ,
                                    cdefine1 ,
                                    cdefine2 ,
                                    cdefine3 ,
                                    cdefine4 ,
                                    cdefine5 ,
                                    cdefine6 ,
                                    cdefine7 ,
                                    cdefine8 ,
                                    cdefine9 ,
                                    cdefine10 ,
                                    cdefine11 ,
                                    cdefine12 ,
                                    cdefine13 ,
                                    cdefine14 ,
                                    cdefine15 ,
                                    cdefine16 ,
                                    ccusdefine1 ,
                                    ccusdefine2 ,
                                    ccusdefine3 ,
                                    ccusdefine4 ,
                                    ccusdefine5 ,
                                    ccusdefine6 ,
                                    ccusdefine7 ,
                                    ccusdefine8 ,
                                    ccusdefine9 ,
                                    ccusdefine10 ,
                                    ccusdefine11 ,
                                    ccusdefine12 ,
                                    ccusdefine13 ,
                                    ccusdefine14 ,
                                    ccusdefine15 ,
                                    ccusdefine16 ,
                                    cmodifier ,
                                    dmoddate ,
                                    dverifydate ,
                                    dcreatesystime ,
                                    dverifysystime ,
                                    dmodifysystime ,
                                    ( cpsnmobilephone ) AS cpsnmobilephone
                            FROM    sa_refSaleOutT WITH ( NOLOCK )
                                    INNER JOIN #STPDAShipRefIDs ON #STPDAShipRefIDs.id = sa_refSaleOutT.id
                            --WHERE   #STPDAShipRefIDs.identityautoid >= 0
                            --        AND #STPDAShipRefIDs.identityautoid <= 0
                            ORDER BY #STPDAShipRefIDs.identityautoid ,
                                    #STPDAShipRefIDs.id ,
                                    #STPDAShipRefIDs.isaleoutid;
                            IF ( @GetType = N'DETAIL' )
                                BEGIN
                                    SELECT  sa_refSaleOutB.isaleoutid AS bodyautoid ,
                                            N'' AS selcol ,
                                            ( N'' ) AS corufts ,
                                            ( N'否' ) AS bqaneedcheck ,
                                            ( N'否' ) AS bqaurgency ,
                                            0.0 AS iscanedquantity ,
                                            0.0 AS iscanednum ,
                                            sa_refSaleOutB.*
                                    FROM    sa_refSaleOutB WITH ( NOLOCK )
                                            INNER JOIN #STPDAShipRefIDs ON sa_refSaleOutB.isaleoutid = #STPDAShipRefIDs.isaleoutid
                                    ORDER BY sa_refSaleOutB.id ,
                                            sa_refSaleOutB.isaleoutid;
                                END;
							--删除临时表
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDAShipRefIDs') IS NULL )
                                DROP TABLE #STPDAShipRefIDs;
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDATempShipIDs') IS NULL )
                                DROP TABLE #STPDATempShipIDs;
                            IF EXISTS ( SELECT  0
                                        WHERE   NOT OBJECT_ID('tempdb..#STPDATempShipDIDs') IS NULL )
                                DROP TABLE #STPDATempShipDIDs;
                        END;
                    ELSE
                        BEGIN
                            RAISERROR('暂不支持该参照单据类型！',16,1);
                        END;
    END;


